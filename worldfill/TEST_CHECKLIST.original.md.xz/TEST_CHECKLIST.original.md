# In-game test checklist (after step 20)

**Tested so far:**
- In the sandbox: `/ee check all` on a real Minecraft server (Forge 1.20.1 with the mod and Terra++, flat
  test world, no player): all 87 checks passed, plus the 3 known limits. Since step 15 a sample of the
  log is in `sample_ee_check_all_log.txt`.
- In your game (2026-10-12, Hyderabad, 1948): ALL 88 CHECKS PASSED with step 11, in a brand-new world
  ("New World (32)"), where the mod installed its data by itself. That includes the parts that need a player
  ("Here and now", where you stand). The failures in the two earlier reports came from new worlds that did
  not have the data yet; before step 11 it had to be installed by hand.

- Step 14 (the core), in the sandbox: all 91 checks passed on the test server (the 87 from before plus 4
  new ones about the core), and a war, an outbreak and a trade route came back after a restart. In your
  game expect **ALL 92 CHECKS PASSED** (your 88 plus the 4 new ones). Rebuild the mod first.

- Step 15: `/ee check all` creates no files any more. Every line goes to the Minecraft log instead, marked
  `[EE check]` (see Step 1). Sandbox test server: ALL 91 CHECKS PASSED, and no file in the world
  folder was created or changed. Your game should still show **ALL 92 CHECKS PASSED**.

- In your game with step 15 (2026-10-12, Hyderabad 1948, "New World (33)", Terra++ time): the log worked
  (every line marked `[EE check]`, no file), and 91 passed, 1 failed: "no world system has failed" caught the
  crowd spawner crashing ("Start element ... is larger than end element ..."). Fixed in step 16.
- Step 16, in the sandbox, with a fake player standing in a town (a sandbox-only helper mod): the crash came
  back with the old code, word for word, and is gone with the new one. The crowd now stands (352 figures; 765
  after a walk and back), with no warnings in the log, at 2 to 4.5 ms per server tick. `/ee check all` as that
  player: ALL 94 PASSED; from the console: ALL 91.
- Step 17 (people and places), in the sandbox with a fake player in Kolkata 1850: ALL 94 PASSED. The same
  people come back after you leave (33 of 37), names fit the place (Kolkata: North Indian, not Telugu), and no
  freeze when the first villagers appear.
- In your game expect **no FAIL**: 94 checks when crowd figures stand around you, 93 when none do. The new
  counted line is "the history data loaded in … s in the background when this world started". Rebuild the mod first.
- Step 18 in your game (2026-10-13, Hyderabad 1948, Terra++ time): ALL 99 PASSED, including the 5 Talk lines.
  Your log showed two things, both fixed in step 18b: the date was always 1 July (the Terra++ days were not
  read), and two townspeople suffocated inside walls that Terra++ built around them.
- Step 18b in the sandbox: `/ee check all` from the console ALL 96 PASSED (3 known limits); a merchant boxed in
  by stone stepped out unhurt. In your game expect **ALL 99 CHECKS PASSED** again (no new counted lines).
  Rebuild the mod first.
- Step 18c in the sandbox: the talk box was laid out at 15 screen sizes from 320 x 240 to 1920 x 1080, measured
  with Minecraft's own font. It stays inside the screen at every size, nothing overlaps, and the date always
  shows. (Your 1920 x 1080 screen is 480 x 270 GUI units: there the old box put Goodbye past the right edge once
  the Back button appeared.) The date line works on the server ("Tuesday, 14 September 1948 | Mancherial").
  `/ee check all` ALL 96 PASSED. In your game expect **ALL 99 CHECKS PASSED** again. Rebuild the mod first; the
  game and the server need the same new version (network version 3), which single player does by itself.
- Step 18d (one calendar) in the sandbox, with the Eternal Engine clock (the sandbox's Terra++ has no time):
  `/time set day` at night gave the next morning and the next date; `/time set 0` went forward, not back;
  Minecraft's day set back past `/time` (as another mod would) was put right within one tick; `/ee year set 1900`
  was refused and `/ee date` went back; a new speed kept the date; the date survived a restart; the date changed
  by itself at 6 in the morning. `/ee check all` ALL 97 PASSED. In your game expect **ALL 100 CHECKS PASSED** (the
  new line: "the date follows the Minecraft days and only /ee date moves it back"). Rebuild the mod first.
- Step 18d in your game (2026-10-13, "New World (35)", Hyderabad, Terra++ time at 1x): **ALL 100 CHECKS PASSED**,
  with the new calendar line. `/terra timejump 1948` (forward) worked and the calendar followed (1 January 1948, a
  Thursday). Your log also showed the game standing still about 8 seconds right after joining, and that you use
  Terra++'s own time commands. Both handled in step 18e.
- Step 18e in the sandbox: the people spawner caused the stand-still. When a player arrived it read the ground height
  at the named place's centre, often far away, so Minecraft built that chunk on the spot: 777 ms of an 834 ms cycle
  here, much longer with Terra++'s real terrain. Now 71 ms at most, and the same people appear. `/terra timejump` to an
  earlier year is refused before it runs; `/terra timescale` runs as `/ee speed set`. `/ee check all` ALL 97 PASSED. In
  your game expect **ALL 100 CHECKS PASSED** again (no new counted lines). Rebuild the mod first.
- Step 18f: the date line at the top right of the screen is gone (you did not like it). The talk box still shows the
  date, and `/ee date` tells it. Sandbox: 15 network messages (16 before), talking works, `/ee check all` ALL 97 PASSED.
  In your game expect **ALL 100 CHECKS PASSED**. Network version 4 now: rebuild the mod (single player updates both
  sides by itself).
- Step 19a (the purse) in the sandbox, with a fake player at Mancherial on 14 September 1948: the first `/ee purse` gave
  1 rupee of Osmania sicca (a day's pay), the second gave nothing more, 4 annas went in, taking out 100 rupees was
  refused, and after a server restart the purse still held 1 rupee 4 annas. `/ee check all` from the console: ALL 100
  PASSED (97 + 3 new); as the player: ALL 103. In your game expect **ALL 103 CHECKS PASSED** (your 100 + 3 new: the
  money table, Hyderabad's money in 1948, the purse's sums). Rebuild the mod first. See Step 9.
- Step 19b (earning money) in the sandbox, with a fake player at Mancherial on 14 September 1948: a merchant bought 100
  sheaves of wheat for 1 rupee 6 annas 11 pai (and the first sale gave the start money), refused an old offer, paid
  out no more than his 8 rupees a day and had money again the next Minecraft day; a money-changer swapped 3 old Mughal
  dams for 10 annas 9 pai and a pound for 15 rupees 3 annas 10 pai; a townsperson pointed to both by name. In
  Bombay the crowd had exactly one money-changer among 40 people. `/ee reset confirm` emptied the purse. `/ee check
  all` from the console: ALL 103 PASSED; as the player: ALL 106. In your game expect **ALL 106 CHECKS PASSED** (your
  103 + 3 new "Market:" lines). Rebuild the mod first. See Step 10.
- Steps 19c to 19f (sellers, newspapers, maps, old money, new history) in the sandbox, with a fake player in Mumbai
  and in the village of Kothapalle on 14 September 1948: Mumbai's crowd had one paper seller and one money-changer
  among 40 people, the village a town crier. A paper seller sold the Mumbai News for 1 anna and a map for 8 annas, and
  refused a second copy of the same paper ("You have that already."); reading the paper put 2 news marks on the map. A
  merchant sold 16 sheaves of wheat (stock 4 lots, then 3), refused bread to a purse too thin ("That is 1 rupee 9 annas.
  You have only 2 pice."), refused old Mughal dams ("That old Mughal rupee is not taken any more. A money-changer will
  change it for you.") and sold after the money-changer had changed them. The crier called "Hear ye! …" and told three
  stories of the day for nothing. After `/ee timeline diverge operation_polo_1948 …` the Hyderabad paper printed "History
  took another road in 1948" and "Operation Polo (Hyderabad) did not happen", without the stories of the old history.
  `/ee check all` from the console: ALL 107 PASSED; as the player: ALL 110. In your game expect **ALL 110 CHECKS
  PASSED** (your 106 + 4 new: "News: who brings the news …", "Shops: …", "News: the paper in Hyderabad …", "Map: …").
  Network version 5: rebuild the mod. The three new screens were checked in pictures drawn with the game's own font
  (`probes/out/screen_*.png`), not yet in a real game window. See Step 11.
- Product atlas part B, in the sandbox (fake player in Mumbai, 14 September 1948): `/ee products here` listed 103
  things made here, 10 brought from far (kerosene, petrol, radio …), 11 not here yet (nylon, plastics, television …)
  and 5 gone; a merchant had his 10 goods and 8 things of the place (blue dye, mud bricks, fired bricks, glass bottles,
  torches, an iron axe, paper, a printed book); buying 16 × Paper for 4 annas 3 pice put 16 paper in the inventory, and
  his stock went from 2 lots to 1. `/ee check all` from the console: ALL 110 PASSED; as the player: ALL 113. In your
  game expect **ALL 113 CHECKS PASSED** (110 + 3 new "Products: …" lines). See Step 12.
- Step 19g (somebody buys everywhere), in the sandbox: in Mumbai 1948 a pedlar bought 32 sheets of paper (paper gone
  from the inventory, 4 annas 2 pice 2 pies in the purse); on 1 January 1966 a trader changed the old anna rupees into
  1 rupee 14 paise, keeping 10 in 100; in Kothapalle in 3000 BCE a farmer swapped 20 wheat for goods worth a quarter
  of a day's work, and a trader took rupees as metal. `/ee check all` from the console: ALL 113 PASSED; as the player:
  ALL 116. In your game expect **ALL 116 CHECKS PASSED** (113 + 3 new "Buyers: …" lines). See Step 13.
- Step 20 (the history book and the tracker compass), in the sandbox (fake player in Kothapalle, 14 September 1948):
  reading the day's paper put 5 names in the book with notes; tracking the Nizam gave a compass and "about 192 km
  south-west of you"; the journal and "Stop" worked; a villager's "Where?" answer offered "Track it on my compass". The
  book's screen was drawn at 3 sizes without a game window. `/ee check all` from the console: ALL 115 PASSED; as the
  player: ALL 118. In your game expect **ALL 118 CHECKS PASSED**. Network version 6: rebuild the mod. See Step 14.

**Not tested yet:** how villagers look, move and sound. The automatic part takes about 20 seconds; the eye
checks take about 15 minutes.

## Step 0: nothing to set up (from step 11)

The mod now puts its foundation data (the authored events, the stories and the rest) into a world by
itself, when the world starts without it. Section 2 of the check says when it did that, and the check's
second line names the world, so you can see which world the lines come from.

With an older build of the mod, do this once per world instead:
1. `/ee data install`
2. `/ee data load`
3. Leave the world and join it again. The stories are only read when the world starts.

## Step 1: let the game check itself

1. Turn cheats on (or be an operator). `/ee check all` needs it.
2. Stand anywhere in the world and type `/ee check all`. (`/ee check` on its own does the same.)
3. Wait about 20 seconds. The game keeps running while the history part is checked in the background.
4. Read the last lines:
   - `ALL … CHECKS PASSED` (with `3 known limits`) means every automatic test passed.
   - `… CHECK(S) FAILED` lists what failed and what to do. Each failure is also shown in red where it
     happened.
5. Every line is also in the Minecraft log, the file `logs/latest.log` in your game folder (normal
   launcher: `.minecraft/logs/latest.log`; on a server: `logs/latest.log` in the server folder). The last
   chat line shows the exact path; click it to copy it. Each line of the check is marked `[EE check]`,
   so search the file for that. Send me those lines if anything failed.

The chat shows one line per check. The log has every line, including what villagers should say at each
of the 15 places below.

Good to know about the log:
- `/ee check all` creates no files. Before step 15 it saved a report file in the world folder
  (`eternalengine/checks/`); if your worlds have that folder, you can delete it.
- In single player the chat lines are in the log twice: once marked `[CHAT]` and once marked
  `[EE check]`. The `[EE check]` lines are the complete list, in order.
- `latest.log` starts over every time Minecraft starts. Older logs are kept, zipped, in the same `logs`
  folder (`<date>-<number>.log.gz`).

There are no single checks any more. `/ee check all` always runs everything:

| Section | What it checks |
|---|---|
| 1-5 | The live system: clock, schedules, history corpus, event chain, stories, timelines, Terra++, the gazette. Since step 14 section 1 also says which clock runs and how fast, whether history is paused, and checks that the config's intervals are used, that no world system failed, that a save would hold the running world and the last save reads back (the check itself saves nothing), and that the world's data files are this mod version's |
| Here and now | What villagers where you stand can say this year (only when a player runs it) |
| 6 | Every history file and all 24 event and place packs load |
| 7 | The 15 places in the table below: state, ruler and trade route. The log adds everything else villagers say there |
| 8 | 25 more places whose rulers were fixed in step 8 |
| 9 | Villager lines at 12 standard places, and how often villagers repeat themselves |
| 10 | A battle down the road always beats country-wide news |
| 11 | The fast event search gives the same answers as a full search |
| 12 | Who lives where at 400 land points in 13 years is unchanged since the data was built |
| 13 | No lag: the first-load time, and how long one villager answer takes |

Three answers are known limits, not failures. They show in yellow as `KNOWN`:
- Memphis in 2570 BC names Bikheris, not Khufu (Wikipedia's dates for that dynasty overlap).
- Hyderabad from 1799 to 1946 names the British monarch, not the Nizam (the border map puts the city
  under the British).
- Damascus in 2000 names Abdul Halim Khaddam (acting president for five weeks), not Bashar al-Assad (two
  rulers took office in the same year, and the first one listed wins).

## Step 2: look with your own eyes

`/ee check all` cannot see how villagers look and move, or judge whether their talk feels natural.

How to test one place:
1. Go there: `/tpll <latitude> <longitude>` (from the table below).
2. Set the year: `/ee year set <year>`. Use a minus sign for BC: `/ee year set -59` is 59 BC.
   Write down the old year first (`/ee year` shows it) so you can go back.
3. Ask who rules here: `/ee villager who`.
4. Listen to the villagers nearby. They should say the same thing in their talk
   ("This land belongs to …, ruled by …"). The log (`[EE check]` lines) lists their other lines for each place.

## The places

| # | Place | Go to | Year | Should say (head of state) |
|---|---|---|---|---|
| 1 | Rome | `/tpll 41.89 12.49` | `-59` | Roman Republic, ruled by C. Julius Caesar and M. Calpurnius Bibulus (Consuls) |
| 2 | Rome | same | `100` | Roman Empire, ruled by Trajan |
| 3 | Chang'an (Xi'an) | `/tpll 34.30 108.90` | `1` | Han Dynasty, ruled by Emperor Ping of Han |
| 4 | Xi'an | same | `700` | Tang Dynasty, ruled by Wu Zetian |
| 5 | Thebes (Luxor) | `/tpll 25.70 32.64` | `-1270` | New Kingdom of Egypt, ruled by Ramesses II |
| 6 | Babylon | `/tpll 32.54 44.42` | `-1760` | Babylonia, ruled by Hammurabi |
| 7 | Paithan | `/tpll 19.48 75.38` | `1` | Satavahana Dynasty, ruled by Pulumavi I; "Merchants on the Dakshinapatha pass through here" |
| 8 | Warangal | `/tpll 17.97 79.59` | `1280` | Kakatiya Dynasty, ruled by Rudrama-devi |
| 9 | Golconda | `/tpll 17.38 78.40` | `1600` | Golconda Sultanate, ruled by Muhammad Quli Qutb Shah |
| 10 | Hyderabad | `/tpll 17.385 78.4867` | `1700` | Mughal Empire, ruled by Aurangzeb Alamgir |
| 11 | Delhi | `/tpll 28.61 77.21` | `1650` | Mughal Empire, ruled by Shah Jahan |
| 12 | Kolkata | `/tpll 22.57 88.36` | `1850` | British Empire, ruled by Victoria |
| 13 | Seoul | `/tpll 37.57 126.98` | `1990` | Republic of Korea, ruled by Roh Tae-woo |
| 14 | Pyongyang | `/tpll 39.04 125.76` | `1990` | Democratic People's Republic of Korea, ruled by Kim Il Sung |
| 15 | Carnuntum (near Vienna) | `/tpll 48.11 16.86` | `100` | Roman Empire, ruled by Trajan; "Merchants on the Amber Road pass through here" |

## Step 3 (optional): try an alternative timeline

A real event can be stopped while it is happening, at its own place and in its own year. The game then
splits off an alternative timeline where that event never happened. Operation Polo (Hyderabad, 1948) is
one you can stop. It has no written "what if" story, so the event simply disappears and nothing new
follows. (The only story so far is for the Mumbai attacks of 26 November 2008.)

1. `/ee speed set 1`: the world's year moves on by itself, one year every 2 minutes at the normal speed
   (10); at speed 1 it is one year every 20 minutes, enough time for the test. (That is the Eternal Engine
   clock. With Terra++ time the year follows the Minecraft days instead; `/ee speed status` says which one
   your game uses and how long a year takes.)
2. `/ee year set 1948`, standing at `/tpll 17.4347 78.5016`.
3. Fight there: kill about 6 hostile mobs on the spot (for example `/summon pillager`; pillagers do not
   burn in daylight), or place and break about 24 blocks there. Killing villagers does not count.
4. `/ee check all`. Section 3 should now say "active timeline: … (an alternate timeline)" and that the
   divergence has no authored story; section 4 and "Here and now" should no longer mention Operation Polo.
5. `/ee speed set 10` to go back to the normal speed. The alternative timeline stays in that world, so use
   a test world.

## Step 4 (new in step 14): the core

About 5 minutes, in a test world.

1. `/ee speed status`: the last lines say which clock runs your world's year ("the Eternal Engine clock" or
   "Terra++ time") and how many real minutes or hours one year takes, and whether history is running.
2. Pause: `/ee year`, then `/ee pause`, wait two minutes, `/ee year` again: the same year. `/ee resume`
   lets it go on. The pause is kept when you leave and come back; `/ee resume` ends it.
3. A restart keeps the world: `/ee war declare rome carthage test`, leave the world, join again, then
   `/ee war list`: the war is still there. `/ee war end <the war's id>` ends it.
4. `/ee data status`: the data version of your world and whether any file was updated or kept.
5. `/ee performance`: how much time each world system takes; nothing should be marked FAILED.

Good to know:
- History pauses by itself while nobody is online. In single player you are always online while you play,
  so you will not see this; it matters on a server. Switch it off with `pauseWhenEmpty = false` in
  `config/eternalengine-common.toml`.
- After editing a config file, `/ee reload` applies it at once.
- `/ee reset` explains what a reset does; `/ee reset confirm` (within a minute) starts the world's history
  over. It makes a backup first, and blocks, buildings and items are not touched.

## Step 5 (new in step 16): the crowd

The town's crowd has never stood in your game: the spawner crashed every time it tried. Now it works.

1. Stand in a town in a year it has people (your Hyderabad 1948 spot is good) and wait about 30 seconds.
   Still figures appear around you, 32 every 2 seconds, never within 24 blocks of you, up to 400.
2. Walk about 50 blocks and come back: the same people stand in the same places.
3. `/ee check all`: section 4 says "the crowd around you is sound: … figures …, each found by its own UUID,
   nobody twice".
4. Watch your frame rate, and `/ee performance` for the spawner's time.

If it is too much, in `config/eternalengine-common.toml`:
- `presenceDrawnFiguresMax = 100` (25 to 600; 400 is the default) draws fewer;
- `presenceDrawnCrowd = false` switches the crowd off (the living villagers stay).
Then `/ee reload`.

Good to know: since step 17, figures more than 128 blocks from you are taken away, and the same people stand
there again when you come back (their identity comes from their spot).

## Step 6 (new in step 17): the people

1. Join a world and walk into a town: no freeze when the first villagers appear.
2. Read a few names (look at them or right-click): they should fit the place. Hyderabad: Telugu names
   ("Mallaiah Reddy"); Kolkata or Delhi: North Indian names. English, French or Spanish places still have no list
   of their own, so names there can look odd.
3. Note three names, go about 300 blocks away (or `/tp`), wait 5 seconds, come back: most of the same people
   should be there.

## Step 7 (new in step 18): talking to villagers

Build and install the mod as before. The game and the server must have the same mod version now (the talk
uses new network messages; since step 18f it is network version 4); in single player that is automatic.

1. Type `/ee date 1948 9 14`. It should say "It is now Tuesday, 14 September 1948".
   - With Terra++ time (your world) it adds "With Terra++ time one Minecraft day is one day of history (20 real
     minutes)." The day is set in the Minecraft day count and time keeps running: a new day every 20 minutes,
     each Minecraft morning. (Step 18b; before, the date was stuck on 1 July.)
   - With the Eternal Engine clock, history pauses so the day stays.
   - The "Talk" line of `/ee check all` shows the same date, with ", from the Minecraft day count: Terra++ time".
2. Go to the Charminar: `/tpll 17.3616 78.4747`.
3. Right-click a villager. A talk box should open at the bottom right of the screen: the villager's face, name,
   job and the date (beside the name, or on the line below it when there is no room). The villager opens with "Have you heard? The Indian Army has entered the state…". (With
   Terra++ time the day moves on every 20 minutes: if it is the 15th by now, the news is about Suryapet.)
4. Click a gold name ("police action"), or press 1–9 for the questions. Try "Where is it now?": Naldurg should
   be about 240 km west. Try "How do you know?". Backspace goes back; Esc or Goodbye closes the box.
5. Type `Laiq Ali` in the "Ask about a name…" box and press Enter. A street villager should send you to the
   clerks at King Kothi Palace, about 3.5 km north.
6. A palace clerk knows court business. If none is near, make one:
   `/summon eternalengine:human_npc ~ ~ ~ {CustomName:'"Venkat Rao"',Role:"scribe"}`. Ask him the same:
   he should answer.
7. `/ee date 1948 9 12`, then ask about the police action: "I haven't heard of that." (It starts on the 13th.)
   `/ee date 1948 9 15`: the army has taken Suryapet. `/ee date 1948 9 17`: the news is the ceasefire.
   `/ee date 1948 9 25`: the villager opens with "The Hyderabad army has surrendered at Secunderabad", and
   "Where is it now?" gives "It is over. On 18 September an Indian armoured column came into the city…".
   `/ee date 1948 7 1`: only "Good day to you. This is Hyderabad." Day-by-day news is there for 12-30 September
   1948; on other days villagers greet you and still answer questions. Nobody says "today" or "yesterday" on
   the wrong day.
8. Somewhere else (`/tpll 48.8566 2.3522`, Paris) the box still opens, with the basic topics: who rules, the
   place, life here, famous people, the villager.
9. With the Eternal Engine clock, `/ee resume` lets time run again (Terra++ time never stops). `/ee check all`
   has 5 new "Talk" lines in section 5.
10. Walls (step 18b): townspeople should not die in walls any more. If Terra++ puts a building where one
    stands, they step out beside it or climb on top. Tell me if "suffocated in a wall" shows up in the log again.
11. The box fits the screen (step 18c). Click a question: the "◀ Back" button appears and Goodbye must stay
    inside the screen, with the whole box. Try other GUI scales too (Options, Video Settings, GUI Scale: 2, 3 and
    Auto). On a small window the box may cover the hotbar; if it still cannot show everything, the mouse wheel
    scrolls it (small arrows show there is more). No question should end in "…".
12. Nothing at the top right of the screen any more: the date line of step 18c was removed in step 18f, at your wish.
    The talk box still shows the date, and `/ee date` tells it.

Tell me how the box looks: size, colours, whether the text fits, and whether anything overlaps.

## Step 8 (new in step 18d): the calendar

About 5 minutes, in a test world (it moves the date). Only /ee date may move the date back; everything else
moves it forward or leaves it.

1. `/ee date`: "Today in the game: … With Terra++ time one Minecraft day is one day of history (20 real
   minutes). … only /ee date moves it back."
2. `/time set night`, then `/time set day`: the next morning, and chat says "The date moves on to …". `/ee date`
   shows the next day. The year must **not** jump back to 3000 BCE (before step 18d it did: Terra++
   reads the year from Minecraft's day counter, and `/time set` put that counter back to 0).
3. Sleep in a bed at night: you wake up on the next date.
4. `/time add 24000`: one day later.
5. `/ee year set 1900`: refused, "Only /ee date moves the date back: /ee date 1900 1 1 …". Then `/ee date 1948 9 14`
   goes back to 14 September 1948 (this one is allowed).
6. `/ee speed set 5`: the day stays, or moves a few days on (at 5x one Minecraft day is five days, so 14 September
   becomes 17 September). Before step 18d it jumped back to 1 January. `/ee speed set 1` keeps the date again.
7. `/ee check all`: **ALL 100 CHECKS PASSED**, with "[ OK ] the date follows the Minecraft days and only /ee date
   moves it back".
8. If the log ever says "[Calendar] Minecraft's day went back", something moved the time back past the mod (another
   mod or a command) and the mod put it right. Tell me what you did just before.
9. Terra++'s own time commands (step 18e): `/terra timejump 1900` (earlier) is refused with "Only /ee date moves the
   date back …"; a later year works as before. `/terra timescale 10x` runs as `/ee speed set 10` and keeps the date.
10. `/ee date 1900 1 1` (going back, step 18e): the land around you is rebuilt for 1900, the way `/terra timejump` does
    it. The log says "[TerraTimeBridge] Year jump to 1900: 7 of 7 Terra++ time-jump steps done; … loaded chunks queued
    for rebuilding". Then `/ee date 1948 9 14` to come back.
11. Joining a world (step 18e): no long stand-still after you arrive. If the game still freezes, the log now names the
    part: "World system '…' took … ms in one tick", "Tick budget exceeded! … slowest in one tick: …", or "[Spawner] One
    cycle around … took … ms: …". Send me the log.

## Step 9 (new in step 19a): the purse

About 3 minutes. Money is a number in your purse, not coins in your bag. Each place and year has its own money.

1. `/ee date 1948 9 14`, and stand anywhere in the old Hyderabad State (Hyderabad, Warangal, Mancherial …).
2. `/ee purse`: "You start with 1 rupee (Osmania sicca), about a day's pay here." Then "Your purse: 1 rupee (Osmania
   sicca), about 1 day's work here." and "Money here: the Osmania sicca. 1 rupee = 16 annas, 1 anna = 12 pai. A day's
   work pays about 1 rupee. Also taken here: the Indian rupee (7 O.S. rupees = 6 Indian rupees)."
3. `/ee purse` again: no second start money.
4. `/ee purse add 4 annas` (admin): "Added 4 annas (Osmania sicca)." The purse shows 1 rupee 4 annas.
5. `/ee purse add -100 rupees`: refused, "You have only 1 rupee 4 annas (Osmania sicca)."
6. Leave the world and come back (or restart the server): `/ee purse` still shows 1 rupee 4 annas.
7. `/ee money at 41.89 12.49 100` (admin): Rome in the year 100 pays in the Roman denarius, a day's pay 1 denarius
   3 asses. Try other places and years: `/ee money at 51.5 -0.13 1800` (London: 1 shilling 8 pence a day),
   `/ee money at 32.54 44.42 -1750` (Babylon: 6 grains of silver), `/ee money at -33.87 151.21 1500` (Sydney: no money,
   people swap goods).
8. `/ee date 1700 1 1`, `/ee purse reset`, `/ee purse`: you start with 3 dams of the Mughal rupee. Back with
   `/ee date 1948 9 14`, `/ee purse` says "Not taken here: 3 dams (Mughal rupee)." (Step 10: the money-changer swaps them.)
   Then `/ee purse reset` and `/ee purse` give you the 1948 start money again.
9. `/ee check all`: **ALL 106 CHECKS PASSED** since step 19b (103 with step 19a), with three new lines: "Money: the money table loads …", "Money: Hyderabad
   in 1948 pays in Osmania sicca …" and "Purse: sums and words work …", and the line "Purse here and now …".

Tell me if a money name or a day's pay looks wrong for a place you know.

## Step 10 (new in step 19b): earning money

About 5 minutes. Merchants buy your goods and pay in the money of the place and year; a money-changer swaps money.

1. `/ee date 1948 9 14` and go to Hyderabad or Secunderabad. Villages have no merchants: they keep to towns and cities.
2. Carry some goods: wheat, bread, logs, stone, coal (or charcoal), iron, copper, wool, gold or emeralds. (Admin:
   `/give @s minecraft:wheat 100`.) Wine, silk and spices have no item yet.
3. Find a merchant: right-click townspeople, the talk box shows the job under the name. Or ask anyone "Who buys goods
   here?" (the last choice): "Ask …, a merchant, about 25 m north-east of here. To change money, see …, the
   money-changer, about 10 m north of here."
4. A merchant's first choice is "I have goods to sell." He says what he buys and pays: "I pay 4 annas 5 pai for 16
   sheaves of wheat, … 1 rupee 14 annas 9 pai for a bar of gold …". Under it, one button for each good you carry:
   "Sell 100 sheaves of wheat: 1 rupee 6 annas 11 pai".
5. Click it: the goods leave your bag and the grey line says "Sold 100 sheaves of wheat for 1 rupee 6 annas 11 pai.
   Your purse: …". The very first sale also gives the start money. `/ee purse` shows it all.
6. He pays full price for the first 64 sheaves of a day, half for the next 64, then he has enough wheat for today. He
   can pay out 8 rupees a day ("Today I can still pay out …"); the next Minecraft day his money is back.
7. The money-changer (one in each market; ask a merchant "Who changes money here?"): "Can you change my money?" He
   keeps 2 in every 100 where the rate is fixed (7 O.S. rupees = 6 Indian rupees; pounds and dollars through the
   rupee), 10 in every 100 for old money or money from far away. To try (admin): `/ee date 1700 1 1`,
   `/ee purse add 3 dams`, `/ee date 1948 9 14`; then he offers "Change your Mughal rupee: 10 annas 9 pai".
8. `/ee market` (admin): what a merchant pays where you stand. `/ee market at 41.89 12.49 100`: Rome in the year 100
   pays in sestertii and denarii; `/ee market at 32.54 44.42 -1750`: Babylon buys no iron yet.
9. Only in a test world: `/ee reset` and `/ee reset confirm` start history over and now also empty every purse.
10. `/ee check all`: **ALL 106 CHECKS PASSED**, with three new lines ("Market: the goods table loads …", "Market: a
    merchant in Hyderabad in 1948 pays …", "Market: a money-changer stands where merchants do …") and the line
    "Market here and now …" (how many merchants and money-changers stand within 96 blocks).

Settings, in `eternalengine-common.toml` under `[market]`: `merchantBuyPercent` (70), `merchantBudgetDays` (8),
`moneyChangerFeePercent` (2), `moneyChangerStrangeFeePercent` (10). Tell me if a price looks wrong for a place and year.

## Step 11 (new in steps 19c to 19f): sellers, newspapers and maps

About 10 minutes. Rebuild the mod first (network version 5).

1. `/ee date 1948 9 14` and go to Hyderabad or Secunderabad (a city). Each town and city has one paper seller; each
   village a town crier. Ask anyone "Where can I get the news?" (the last choice): "Buy a paper from …, the paper
   seller, about 30 m east of here. Maps too."
2. Talk to the paper seller: the first choice is "Show me your papers and maps." The trade screen opens: trades on the
   left (picture, name, price), the picked trade on the right (big picture, name, price, a few words, your purse), Buy,
   what the seller says, "‹ Back to …" and Goodbye. Arrow keys pick, Enter buys.
3. Buy today's paper: "The Evening Herald, 14 Sep 1948", 1 anna. Right-click it in your hand: the newspaper opens
   (masthead, "HYDERABAD · TUESDAY, 14 SEPTEMBER 1948 · 1 ANNA", the lead story, two columns, what merchants pay, an
   advertisement for maps). The mouse wheel scrolls it. The note at the end says its names are now in your history book.
   A second copy of the same day: "You have that already."
4. Buy the map, "Map of Hyderabad State", 8 annas. Read the paper again while you carry the map, then right-click the
   map: 24 towns (big ones in bold), two dashed roads, a white square where you stand, and coloured news marks for the
   places in your papers ("News marks from your papers: 14 Sep"). Click a town: what your papers said about it, or "a
   town on your map. No news about it in your papers."
5. With Xaero's Minimap: click a town, then "Add to Xaero's map". A waypoint should appear (I could not test Xaero here;
   tell me if it does not). Without Xaero the button writes the town's x and z in the chat.
6. Merchants: "Show me your goods." He sells what he buys, at full price (16 sheaves of wheat for 6 annas 5 pai; he buys
   them for 4 annas 5 pai), a few lots of each a day, and things made here: Osmania biscuits (1 anna for 8), toddy, a
   gongadi blanket (3 rupees); coal is "Singareni coal".
7. Old money: `/ee date 1700 1 1`, `/ee purse add 3 dams`, `/ee date 1948 9 14`. Spend your annas, then try to buy: "That
   old Mughal rupee is not taken any more. A money-changer will change it for you." Change it, and buy again.
8. A town crier (go to a village): he calls "Hear ye! …" over his head now and then, and "What is the news today?" tells
   three stories for nothing.
9. Before print: `/ee date 1700 3 1` in Hyderabad: a newsletter writer sells a handwritten newsletter (3 dams, a day's
   pay) on older paper, and a map drawn by hand. `/ee date 1948 9 14` to come back.
10. Only in a test world: `/ee timeline diverge operation_polo_1948 test`. Today's paper now starts with "History took
    another road in 1948" and "Operation Polo (Hyderabad) did not happen"; the stories of the old history are gone.
    Papers you bought before keep their old news.
11. Admin: `/ee shop` (what sellers sell here), `/ee paper` (today's paper as text; `/ee paper give` gives one), `/ee
    map` (what a map here shows; `/ee map give`).
12. `/ee check all`: **ALL 110 CHECKS PASSED**, with four new lines ("News: who brings the news …", "Shops: …", "News:
    the paper in Hyderabad on 14 September 1948 …", "Map: the Map of Hyderabad State …") and "News here and now …".

Tell me if a price, a paper or a map looks wrong for a place and year.

## Step 12 (new in product atlas part B): what is made where, and when

About 5 minutes. Rebuild the mod first (no new network version).

1. `/ee products` where you stand (Hyderabad, 14 September 1948). The first line says the area, the region and the
   counts ("Southern Asia (Southern India), 1948: 103 made here, 10 brought from far, 11 not here yet, 5 gone"). Then
   the food, cloth, fuel and light people have, and the lists: "Brought from far (10): … kerosene (from 1870), petrol
   and diesel (from 1910), … radio (from 1927) …", "Not here yet (11): coming next: nylon … (1950), plastics … (1950),
   television (1959), the internet (1995) …", "Gone (5): stone tools (800 BCE) …".
2. Other places and years: `/ee products at 30.63 72.86 -2500` (Harappa: wheat, cotton, fired bricks, copper and bronze
   made here, tin brought; no iron, coins, paper, sugar, chillies or tea yet), `/ee products at 41.89 12.49 100` (Rome:
   pepper and silk brought from far), `/ee products at 51.51 -0.13 1850` (London: tea and cotton brought; no electric
   light, telephone or cars yet), `/ee products at 19.43 -99.13 1500` (Tenochtitlan: maize and cacao; no wheat, iron or
   horses).
3. Merchants: "Show me your goods." After his goods he now has up to 8 things of the place (each merchant his own
   kinds): for example 16 × Paper, a Printed book, an Iron axe, 16 × Fired bricks, a Kerosene lamp (a lantern called
   so). "Made here." or "Brought from far away, so it costs more." (twice the price). 2 lots of each a day. Buy one:
   the item comes into your inventory and the money leaves your purse.
4. `/ee date 1700 3 1` and talk to a merchant again: no kerosene lamp now; an oil lamp instead (if he carries lamps), and
   palm leaves or paper. `/ee date 1948 9 14` to come back.
5. `/ee check all`: **ALL 113 CHECKS PASSED** (110 from the console), with three new lines ("Products: 129 products …
   Harappa in 2500 BCE, Rome in 100, London in 1850 and Hyderabad in 1948 have what they should", "Products: every
   input is made or brought …", "Products: food, cloth, fuel and light in all 146 regions …") and "Products here and
   now …".

The years are estimates for whole areas (in `PRODUCT_ATLAS_TABLE.md`). Tell me any product or year that looks wrong
for a place you know.

## Step 13 (new in step 19g): somebody buys in every settled place

About 10 minutes. Rebuild the mod first (no new network version).

1. **A village** (for example Kothapalle, 18.87 79.43, in 1948): look for the **pedlar** among the people (dressed like
   a merchant, one per village). "Show me your goods." shows his pack: 4 small things (no wheat, logs, bricks or
   saddles). "I have goods to sell.": he says "I carry what I buy to the towns, so I pay less than a trader there." and
   pays half the worth. Sell him something. "Who changes money here?": "Nobody near here changes money. A money-changer
   in a city will, or a trader in a town market."
2. **A town** (a place smaller than a city): the **trader** sells like a merchant (fewer things of the place), buys at
   60 in 100, and "Can you change my money?" changes money keeping 10 in 100. "Tell me about yourself": "I buy and
   sell for the market of this town, and I change money."
3. **Things of the place**: carry paper, torches, an iron axe or eggs to a merchant, trader or pedlar. "I have goods to
   sell." now lists them too ("Sell 16 sheets of paper: …"). Something brought from far fetches twice as much where it
   is scarce.
4. **Old money at a trader**: `/ee date 1966 1 1` with Indian rupees (annas) in your purse; a trader (or a city
   money-changer) changes them into rupees and paise. `/ee date 1948 9 14` to come back.
5. **Where people swap**: `/ee date -3000 6 1` in a village. A farmer says "I have goods to swap." and swaps a little;
   a trader in a town says "Will you take my coins?" and takes coins as metal. `/ee date 1948 9 14` to come back.
6. A citizen in a city with no merchant near: "Who buys goods here?" now says "Nobody near here buys goods. Every town
   and city has a market, and pedlars go round the villages."
7. `/ee market`: "Who buys here (village): a pedlar (50 in 100, 2 days' pay a day)." and the things of the place a
   merchant takes, with prices.
8. `/ee check all`: **ALL 116 CHECKS PASSED** (113 from the console), with three new lines ("Buyers: somebody buys in
   every settled place …", "Buyers: merchants take 18 atlas products in Bombay in 1948 …", "Buyers: a town trader
   changes money …") and "Buyers here and now …".

## Step 14 (new in step 20): the history book and the tracker compass

About 10 minutes. Rebuild the mod first (network version 6: the game and a server need the same build).

1. Join your world: a **History book** is in your inventory (once per player), with the words "You have a history
   book …". `/ee book give` gives another copy (any copy is the same book).
2. Talk to people in Hyderabad (14 September 1948) and ask about a few names; buy and read today's paper. Right-click
   the book: the left page lists the names in groups (Events, People, …) with their notes, grey when you only heard the
   name; type a few letters to find one. The right page shows each note with its day and who said it.
3. Open a name you only heard: "You have heard this name, but you know nothing more about it yet." and who would know.
4. Open the Nizam: **Track on the compass**. The first time you are given a compass (else your own compass is used): it
   is called "Tracker compass: The Nizam" and its needle points to King Kothi. Hold it: the action bar says "The Nizam:
   about … km …" and "You are at …" when you get there. "Tracking · Stop" makes it a plain compass again.
5. Ask a villager "Where does he live?" about the Nizam: the answer offers **Track it on my compass**.
6. The **Journal** tab: "Learned about … from …", "Read The Evening Herald …", what you bought and sold, "Set the compass
   to …". The **Family tree** tab on the Nizam (after asking a palace clerk about the family).
7. The mouse wheel scrolls the page under the mouse; Escape closes the book.
8. `/ee book` (and `/ee book journal`) tells the book in the chat too.
9. `/ee check all`: **ALL 118 CHECKS PASSED** (115 from the console), with two new lines ("History book: a player's
   notes make the book …", "History book: the tracker compass can point to King Kothi …") and "Your history book: …".

## Step 15 (new in step 21): people stay while you talk; no Minecraft monsters

About 10 minutes. Rebuild the mod first (network version 7: the game and a server need the same build).

1. Walk into a crowd and right-click one of the still figures (not a named townsperson). The talk box opens; the
   figure turns to face you, gets a name over its head, and stays where it is while you talk, even if you stand still
   for a long time (before, the crowd re-arranged itself around a player who stood still, and people vanished).
2. Talk to a townsperson who was walking: they stop and look at you. Open their trade screen, buy something, go
   back to the talk: they are still there.
3. Close the talk with Goodbye. A minute later walk away: people leave the way they always did, once you are gone.
4. Open a talk and walk away more than 8 blocks: the box closes and the action bar says "You walked away from …".
5. Open a talk and have somebody else (or `/kill` from another player) remove the person: the box says
   "… has left." with only Goodbye, instead of closing without a word.
6. Change the year with `/ee date` while you talk: the person stays until you say Goodbye, then goes (they belong to
   the other year).
7. Stay out at night on Normal difficulty: no zombies, skeletons, creepers or phantoms come; no pillager patrol, no
   raid, no wandering trader. A spawn egg or `/summon minecraft:zombie` still works. To have them back, set
   `minecraftMonsters`, `raidsAndPatrols` or `wanderingTraders` to true under `[minecraftMobs]` in
   `config/eternalengine-common.toml`.
8. A map waypoint, the tracker compass and the people of a named place now use the same positions as the land.
   Track King Kothi from Charminar: the needle should point about 3.5 km away, roughly north (in Minecraft terms the
   direction is turned, because true north is turned 29 degrees at Hyderabad), and walking that way should bring you
   there. Before step 21 the needle pointed at a block thousands of kilometres away; only the words were right.
9. `/ee check all`: **ALL 122 CHECKS PASSED** with crowd figures around you (121 without them; 119 from the console),
   with four new lines: "Talk: a person stays …", "Map positions use the world's own projection … 435 places …",
   "Minecraft's own mobs in the history world: monsters off …" and "Technology: nothing before its first known year …".

## Step 16 (new in step 22): the history book is bought, in the form of the place and year

1. Join a new world (or a new player): you get **no** book, but the chat says once "What people tell you and what you
   read goes into your notes. To read them, buy a history book from a seller in the market; anybody can tell you
   where." (To give the book on joining as before, set `historyBookOnJoin = true` under `[historyBook]` in
   `config/eternalengine-common.toml`.)
2. `/ee book` without a book: "You have no history book. Your notes are kept (… names); buy a book from a seller to
   read them." Talk to people anyway: the names still go into your notes.
3. Right-click somebody who sells nothing (a farmer, a citizen, a money-changer): the questions include "Where can I get
   something to keep notes in?" right after "Tell me about yourself.". The answer names the nearest seller and the way,
   e.g. "Vyapari Suresh Trivedi, the merchant, sells notebooks, about 30 m east of here.", and the hint line shows it.
4. Open a merchant's, trader's or pedlar's goods (or a paper seller's): the book is in the list right after the goods,
   named "<form> (history book)", with its own picture and a price in the money of the place. Hyderabad or Bombay
   1948: a notebook for about 1 anna 2 pice. Buy it: "Bought a notebook (history book) for … Right-click it to read your
   notes." The offer then shows as owned; buying again says "You have that already."
5. Right-click the book: your notes open as before, with everything people told you before you had it.
6. Try other places and years with `/ee date` and a jump. What you should see in the sellers' lists:
   - Ur or Babylon before 500 BCE: clay tablets; Egypt: a papyrus roll; Athens 430 BCE: a papyrus roll and wax tablets;
   - Rome AD 100: a parchment book, a papyrus roll and wax tablets (in denarii, sestertii and asses);
   - China before 100: bamboo slips; Chang'an 750: a notebook; India before paper: a palm-leaf book;
   - Mexico before 1521: a bark-paper book; Cusco before 1532: knotted cords; Moscow 1400: a birch-bark book;
   - Norway 1200: rune sticks beside parchment; London 1300: a parchment book and wax tablets (no paper yet);
   - Great Zimbabwe 1300, Benin 1500, Cahokia 1100: a tally stick; Australia before 1788: a message stick.
7. Where nobody near sells one (no seller within about 100 blocks), the person you ask gives you the local memory aid:
   "Nobody near here sells such things. … Take this tally stick: cut a notch for each thing you want to keep. That is
   how we remember." It goes into your inventory and your journal, and it reads your notes like any book.
8. Hover over each form: its own description, "Your history book …", "Right-click to read". Look at the 13 pictures in
   the creative menu (search "history book"): each should be clear at normal size.
9. `/ee book forms` lists the forms, sellers and prices where you stand (or `/ee book forms <lat> <lon> <year>`, also
   from the server console). Operators: `/ee book give <form>` (for example `papyrus`).
10. `/ee check all`: **ALL 125 CHECKS PASSED** with crowd figures around you (124 without them; 122 from the console),
    with three new lines: "History book: bought from a seller …", "History book forms: 32 test places right …" and
    "History book for sale: …".

## Step 17 (new in step 23a): real money in every place and year

The money is still a number in your purse (coins you can hold come in step 23b), but now every place and year has its
own money, coins and wages.

1. `/ee money at <lat> <lon> <year>` (operators, also from the server console) tells the money, its coins, a day's pay,
   and the price of a paper and a map. Try places all over the world, for example:
   - Oslo 1200 (`59.91 10.75 1200`): the Scandinavian mark, 5 penninge a day; Oslo 900: weighed silver;
   - Reykjavik 1100: homespun cloth, 2 ells a day; Venice 1400: the Italian lira of account, 10 soldi;
   - Persepolis 500 BCE (`29.94 52.89 -500`): the Persian siglos, 6 grains of silver;
   - Calabar 1800 (`4.95 8.32 1800`): manillas, with cowries also taken; Addis Ababa 1900: Maria Theresa thalers;
   - Bangkok 1800: the Siamese tical (baht, salueng, fueang, att and cowries); Hanoi 1500: Vietnamese cash;
   - Lhasa 1900: the Tibetan tangka; Seoul 1800: Korean mun; Phnom Penh 1977: no money (barter);
   - Rio 1750: réis; Buenos Aires 1990: australes; York Factory 1750: the made beaver; Montreal 1950: Canadian dollars;
   - Moscow 1970: Soviet rubles, 4 a day; Varna 2026: euros, 38 a day (Bulgaria joined the euro on 1 January 2026);
     Lagos 2026: naira, 6000 a day.
2. Join anywhere with `/ee date` and a jump, and type `/ee purse`: "You start with … (the money of the place), about a
   day's pay here." Elsewhere, with other money in the purse: "You have nothing people here take." and the money of the
   place.
3. Open a merchant's, trader's or pedlar's goods: the prices are in the coins of the place (Rio 1750: a loaf of bread for
   1 vintém 1 real; Moscow 1970: 40 kopeks; Lagos 2026: 600 naira).
4. Where the money is shared, the prices follow the wages of the place: a notebook costs about €3.80 in Bulgaria 2026
   but about €11 in France 2026.
5. `/ee check all`: all checks pass (the count of today's build is in step 18), with the line "Money of the world: 401
   kinds of money … 121 test places right … 0 placeholder".

Tell me any place and year where the money looks wrong (the wrong money, a wage far too high or too low, or "local
money"): the place, the year and what `/ee money` said.

## Step 18 (new in step 23b): money you can hold

Money is now pieces in your inventory (coins, notes, cowries, cacao beans, cut silver, manillas, salt bars, cloth,
beaver pelts) instead of a number.

1. Go somewhere with `/ee date` and a jump, and type `/ee purse`. The start money comes as pieces, and the purse lists
   them. In Bombay 1948 (`18.94 72.83`): "You start with 15 annas 3 pice (Indian rupee)", as 8 annas, 4 annas, 2 annas
   and 1 anna (nickel coins), 2 pice and 1 pice (copper).
2. Look at the pieces in your inventory. Each has its own picture and name ("1 anna (Indian rupee)", "20 euros (euro)",
   "2 manillas", "100 mon (Japanese mon)"), equal pieces stack, and the tooltip names the money. The 16 pictures:
   gold, silver, copper, holed cash, nickel, banknote, cowries, cacao beans, cut silver, weighed copper, manillas, nzimbu
   shells, salt bars, cloth, beaver pelts, bullet coins.
3. Buy something from a seller: the pieces leave your inventory and the change comes back as pieces. In Varna 2026
   (`43.21 27.91`) the €3.80 notebook takes your €5 note and gives back €1 and 20 cents.
4. Sell something to a merchant (a stack of wheat): he pays in pieces of the place, in whole pieces ("Sell 16 sheaves of
   wheat: 336 rubles" in Moscow 2026).
5. Take money from one place to another (euros from Varna to Moscow 2026, `55.76 37.62`). The shop says "We don't take
   the euro here. A money-changer will change it for you."; the money-changer gives rubles as pieces for all your euros.
6. Try other eras and places: Calabar 1800 (`4.95 8.32`, manillas), Edo 1700 (`35.68 139.76`, holed mon), Oslo 1200
   (`59.91 10.75`, silver penninge), Rome 100 (asses, denarii, a gold aureus), Bangkok 1800 (cowries, copper att,
   bullet coins). Where people swap goods (Sydney 1500), there are no pieces: "You start with goods worth about 1 day's
   work to swap."
7. Pieces are items: drop them, put them in a chest, give them to a friend. If you die, they drop like other items.
   `/ee purse reset` takes all your pieces away and gives the start money again.
8. `/ee check all`: **ALL 127 CHECKS PASSED** with crowd figures around you (126 without them; 124 from the console),
   with the new line "Money you can hold: 398 of 398 monies with coins have pieces … in 16 looks … you carry …".

Tell me if a piece looks wrong for its place and time (a gold coin that should be silver, a note that should be a
coin), with the piece's name, the place and the year. Also tell me if you ever get too little change.

## Step 19 (new in step 24): Minecraft's trade screen

Trading happens on Minecraft's own villager trade screen now, with real slots.

1. Go to Bombay 1948 (`/ee date 1948 9 14`, then jump to `18.94 72.83`), find a merchant and talk to him. The first
   option is "Let's trade.", then "What do you buy?". There is no longer one "Sell …" option per good.
2. "Let's trade." opens the screen: his trades on the left (coins, an arrow, the thing), two slots and the slot to take
   from, your inventory below. Above it is what he says, with the date. Below it is what the slots do and your money.
   Hover over a trade: its name, price and how many are left today.
3. Click the notebook. A 2-anna piece moves from your bag into a slot, and the notebook appears on the right. Below it
   says "You pay 2 annas. Your change: 1 pice 2 pies." Take the notebook: the change appears in your bag, and the row
   now shows a cross ("You have that already").
4. Click something cheap (16 eggs) and shift-click the result: you buy again and again while the slots pay.
5. Put 16 or more wheat in your bag and open the screen again. "Sell 16 sheaves of wheat" is in the list: click it,
   take the coins (4 annas, and 1 pice and 1 pie go into your bag).
6. Put a coin of another money in a slot by hand (an O.S. rupee from Hyderabad, or euros). The words say "We don't take
   the … here. A money-changer will change it for you." Close the screen: the coin comes back into your bag.
7. At a money-changer ("Can you change my money?"), put in just one of your foreign notes: he changes only that one.
   Try "Smaller pieces" with a big note and "Bigger pieces" with small coins.
8. "‹ Back to …" (right of the word Inventory) returns to the talk. Walk more than 8 blocks away while trading: the
   screen closes and the talk box says "You are too far away from …".
9. Calabar 1800 (`4.95 8.32`): small things cost cowries. Pay with a manilla and get cowries back.
10. Where people swap goods (Cahokia 1150, `38.655 -90.062`), a merchant's trades ask for goods. Your start tab pays
    first. Put coal or logs in the slots for the rest; what you give too much he owes you.
11. `/ee check all`: **ALL 128 CHECKS PASSED** with crowd figures around you (127 without them; 125 from the console), with the new line
    "Trade screen: Minecraft's, with two slots to pay and one to take …".

Tell me if anything on the screen sits in the wrong place, a tooltip is missing, a sound is wrong, or a trade takes too
much or gives too little: the place, the year and the words under the slots.

## What to look out for

- A place that says nothing, or the wrong ruler: tell me the place, the year and what it said.
- How often villagers repeat the same line, and whether it feels natural. Section 9 measures this for ten
  villagers over ten minutes; your ears decide whether it feels right.
- Lag when you arrive somewhere new. The history data loads in about 1 to 5 seconds the first time;
  section 13 shows the time on your computer.
- A freeze of several seconds soon after joining (fixed in turn 89: the ground look-ups no longer wait for Terra++'s
  land-cover map). If it still happens, send the log line that starts with "[Spawner] One cycle around": it now says
  where the time went.
- After a long jump, how long until townspeople stand around you. With `debugLogging = true` (under `[debug]` in
  `config/eternalengine-common.toml`) the log says each cycle why spots were refused ("[Spawner] Townspeople around
  …: have 0 of 40; … chunk not loaded 12 …"): send those lines if it is slow.

## Step 20 (new in step 25): the history data fix

Villagers name the right state and ruler in many more places and years. Ask a townsperson about the land (or use the
state card in the talk box) at each place:

1. Bombay on 1 January 1948 (`/ee date 1948 1 1`, then jump to `18.94 72.83`): "This land belongs to Dominion of India,
   ruled by George VI". On `/ee date 1950 3 1`: the Republic of India, and the same townspeople are still there.
2. Hyderabad outside the old city, for example Warangal (`17.97 79.59`) in 1850: "Hyderabad State, ruled by
   Nasir-ud-Daula, Asaf Jah IV (Nizam)", "The court follows Islam; most people here follow Hinduism", and "Most people
   around here live by crafts and trade". Gulbarga 1900 pays in hali sicca rupees (`/ee money` there).
3. London 1600 (`51.51 -0.12`): "The main faith here is Anglicanism"; no "town of the Hanseatic League".
4. St Petersburg 1900 (`59.94 30.31`): ruled by Nicholas II, not a prime minister. Paris 1900: Émile Loubet (President).
   Vienna 1900: Franz Joseph I. Moscow 1980: Leonid Brezhnev (General Secretary).
5. Prague 1980 (`50.08 14.42`): Czechoslovakia, ruled by Gustáv Husák, not the Soviet Union. Jerusalem 1940
   (`31.78 35.22`): Mandatory Palestine. Dresden 1750 (`51.05 13.74`): the Electorate of Saxony.
6. Today (`/ee date 2026 6 1`): Bombay names the Republic of India and Droupadi Murmu, Washington the United States and
   Donald Trump, Moscow the Russian Federation and Vladimir Putin. Before step 25 nobody ruled anywhere in 2025–2026.
7. Rome in a new world: `/ee date 100 6 1`, look at the townspeople (Romans); `/ee date 2026 6 1`, new people (Italians);
   `/ee date 100 6 1` again: the same Romans as before, with the label "rome", never "republic_of_italy".
8. `/ee check all`: part 14, "The history data fix (step 25)", all OK. Totals: console 165, as a player 168 (2 known).

## Step 21 (new in step 26): foundations for big data, occupations and border cities

1. Occupied lands keep their own state. Ask about the land (or use the state card) at: Copenhagen 1942 (`55.68 12.57`):
   "the Kingdom of Denmark, ruled by Christian X"; Paris 1942: "Vichy France, ruled by Philippe Pétain"; Athens 1942
   (`37.98 23.73`): "the Kingdom of Greece, ruled by George II"; Batavia 1943 (`-6.20 106.85`): "Dutch East Indies";
   Cologne 1946 (`50.94 6.96`): "Allied-occupied Germany", and it pays in marks (`/ee money`).
2. Rebels are not the state: Aleppo 2020 (`36.20 37.16`): "Syria, ruled by Bashar al-Assad"; Kabul 1990 (`34.53 69.17`):
   "Afghanistan, ruled by Mohammad Najibullah". Dublin 2026 (`53.35 -6.26`): "Ireland, ruled by Catherine Connolly".
3. Border cities: Kinshasa 2026 (`-4.32 15.31`): "the Democratic Republic of the Congo, ruled by Felix Tshisekedi", money
   the Congolese franc; Brazzaville across the river (`-4.27 15.28`): the Republic of the Congo, the CFA franc. Tijuana
   (`32.53 -117.04`): Mexico and the peso; San Diego (`32.72 -117.16`): the United States. Nice: France; Monaco: Monaco.
4. As operator, `/ee villager who` shows the marks and the key: Aleppo 2020 "[recorded]", Aleppo 2026 "[estimate: the
   record ends in 2024 ...]", Sydney 1900 "[estimate: taken from the neighbouring squares]", and a last line "key: ...,
   timeline main, universe prime". Players never see marks or sources.
5. In another dimension (the Nether), `/ee villager who` finds no recorded history (the key's universe is not the prime one).
6. `/ee check all`: part 15, "Foundations for big data (step 26)", all OK (the key, the marks, the tiles, every data file
   the same as built, licences and credits, budgets). Totals: console 200, as a player 203 (2 known).
7. The mod's jar has `DATA_CREDITS.md` at its root and no `famous_people.json.gz` (only `famous_people.tiles`).

## Step 22 (new in step 27): knowledge cards for every place, famous people and groups

1. Famous people with cards. Set the date with `/ee date Y M D` and talk to a villager (or `/ee talk at LAT LON topic
   famous`): Florence 1610 (`43.77 11.25`) "People here talk about Galileo Galilei, Urban VIII, Marie de' Medici and
   Gregory XV"; London 1700 (`51.51 -0.13`) Isaac Newton, Daniel Defoe, Edmond Halley; Athens 400 BC (`37.98 23.73`)
   Plato, Socrates; Lagos 1990 (`6.52 3.38`) Wole Soyinka; Cusco 1500 (`-13.53 -71.97`) "People here still tell of
   Pachacútec ... who lived long ago". Every name is under "Ask about…".
2. A person's card (click the name): "Who is he?", "What has he done?", "Where is he from?". Galileo in 1610: "an Italian
   polymath ... born in Pisa in 1564, so he is about 46 now"; "He studied at University of Pisa"; "He comes from Pisa,
   about 70 km west of here" with "Track it on my compass" (the compass then points to Pisa).
3. Nobody knows the future: Galileo in 1580 is unknown ("I haven't heard of that"); Kennedy (`/ee talk at 38.90 -77.04
   card pc_9696`) in 1950 is not called president, in 1962 "the president of the United States", and his 1963 speech is
   not among his deeds; Victoria (`card pc_9439`) is "the queen of the United Kingdom" in 1840, not in 1830; the East
   India Company (`card oc_83164`) "closed in 1874" when asked in 1880.
4. Groups: "What is this place?" then "What groups are there here?": Bombay 1948 (`18.94 72.83`) The Times of India,
   University of Mumbai, Reserve Bank of India; Bologna 1300 (`44.49 11.34`) the University of Bologna ("founded in
   1088"); Kinshasa 2026 the University of Kinshasa. The nine first questions of the talk box are the same as before.
5. The ruler's card: "Who rules here?" at Rome AD 100 (`41.89 12.49`) "ruled by Trajan" with Trajan as a name to ask about
   ("Trajan is the 13th Roman Emperor ..."); Delhi 1600 (`28.61 77.21`) Akbar; Moscow 1980 (`55.76 37.62`) Leonid
   Brezhnev; Bombay 1948 George VI.
6. The history book: a person or a group you heard of is in the book (with a book bought from a seller), and "Track"
   points the compass to their home or seat.
7. No source names in any card (no "Wikipedia", "Wikidata").
8. `/ee check all`: part 16, "Knowledge cards for every place (step 27)", all OK. Totals: console 209, as a player 212
   (2 known).

## Step 23 (new in step 28): events, causes and effects, natural events, occupied and disputed land

1. An event card: `/ee date 1916 7 1`, then `/ee talk at 48.86 2.35 card ec_361` (World War I): "World War I is a global
   conflict"; "When did it begin?" "It began in 1914, and it is still going on."; "Why did it happen?" names the
   Scramble for Africa, the Triple Entente, the assassination of Archduke Franz Ferdinand and the Triple Alliance;
   "What happened in it?" names battles up to 1916 only. In 1925 it "was", "About 17 million people died", and "What
   came of it?" names the Russian Revolution. In 1913 it is unknown.
2. The news with a card: Melegnano in 1515 (`/ee talk at 45.36 9.31 topic news`): "Word from nearby: Battle of
   Marignano ..." with the name to ask about, and "Who took part?" (Venice, France, Milan, the Swiss). Tacloban in 2013
   (`11.24 125.00`): "Typhoon Haiyan (winds of about 310 km/h)"; Gulfport in 2005 (`30.37 -89.09`): Hurricane Katrina.
3. A place's past: "What is this place?" then "What happened here before?": Hastings in 1200 (`50.91 0.49`) "the Battle
   of Hastings (1066)"; Waterloo in 1900 (`50.68 4.41`) Waterloo, Fleurus, Ligny, Quatre Bras. Hastings in 1050: no.
4. Occupied land ("Who rules here?"): Paris 1942 "... German troops have held this land since 1940."; Copenhagen and
   Oslo 1942 the same; Batavia 1944 (`-6.20 106.85`) "Japanese troops"; Tehran 1943 "British troops"; Paris 1946 and
   1938: no troops.
5. Disputed land ("Who rules here?") in 2020: Ramallah (`31.90 35.20`) "Israel has held this land since 1967 ..."; Gaza
   (`31.50 34.45`) in 2024; the Golan (`33.00 35.75`); Simferopol (`44.95 34.10`) "Russia has held this land since
   2014. Ukraine claims it ..."; Kyrenia (`35.34 33.32`); Laayoune (`27.15 -13.20`). Tel Aviv, West Jerusalem,
   Sevastopol in 2010 and Ramallah in 1960 keep "This land belongs to ...".
6. `/ee check all`: part 17, "Events, causes and effects, natural events, occupied and disputed land (step 28)", all OK.
   Totals: console 219, as a player 222 (2 known).

## Step 24 (new in step 29): towns through time, and the ties between states

1. Names by era ("What is this place?"): `/ee date 1900 6 1`, `/ee talk at 18.94 72.83 topic place`: "This is Bombay,
   year 1900."; in 2026 "This is Mumbai" and "It was called Bombay until 1995." Edo in 1700 (`35.68 139.76`), Tokyo in
   1900; Léopoldville in 1955 (`-4.32 15.31`), Kinshasa in 2000; Constantinople in 1000 and 1800 (`41.01 28.98`),
   Istanbul in 1950; Petrograd 1920, Leningrad 1950, Saint Petersburg 2000 (`59.94 30.31`); Stalingrad 1940 (`48.71
   44.51`); Danzig 1900 (`54.35 18.65`); Rangoon 1950 (`16.80 96.16`); Beiping 1935 (`39.90 116.40`); Kigali 2000
   (`-1.95 30.06`, a town with no history site).
2. People and founding: Paris 2015 "About 2.2 million people live in Paris. People say the town was founded in the 4th
   century BCE."; Hyderabad 2026 (`17.385 78.4867`) "About 9.2 million people ... The town is growing. People say the
   town was founded in 1591."; Hyderabad 1650 "Travellers also call it Bhagnagar."
3. "Which province is this?": Bombay 1900 "It lies in the Bombay Presidency.", 1955 "Bombay State", 2000 "Maharashtra";
   Hyderabad 2020 "It lies in Hyderabad district, in Telangana."; Cairo 1900 (`30.04 31.24`) "the Khedivate of Egypt".
   Hyderabad 1900: no province question (Hyderabad State is the ruler line's).
4. "Who runs this town?": Paris 2015 "Anne Hidalgo is the mayor of Paris (since 2014)."; New York 2010 (`40.713
   -74.006`) Michael Bloomberg and the Governor of New York; Hyderabad 2026 "Revanth Reddy is the Chief Minister of
   Telangana (since 2023)."; Sydney 1950 the Premier of New South Wales; New York 1500: nobody.
5. "Which states is it tied to?" (`topic ruler`, then the state card): Seoul 1500 (`37.57 126.98`) "It owes allegiance
   to the Ming Dynasty."; Bombay 1900 (the British Raj) "It is part of the British Empire."; Berlin 1970 (`52.52 13.40`)
   "It is a member of the Warsaw Pact (since 1955)."; Paris 2026 "It is a member of NATO (since 1949)."; Berlin 1950: no
   Warsaw Pact.
6. `/ee check all`: part 18, "Towns through time (step 29)", all OK. Totals: console 226, as a player 229 (2 known).

## Step 25 (new in step 30a): the technology atlas

1. "What new things are there here?" on the place card (`/ee talk at LAT LON topic place`, then the question):
   Hyderabad 1948 (`17.385 78.4867`, inside its knowledge pack: ask `lc_place_hyderabad tech`) "People here have
   electric light, picture houses, the railway ... A few rich people have radio and motor cars. Nobody here has
   television yet."; Cusco 1500 (`-13.52 -71.97`) "People here have paved roads. Nobody here has printed books, iron
   or horses yet."; Edo 1850 (`35.68 139.76`) "... Nobody here has the telegraph, the railway or steamships yet."; Edo
   1880: the railway and the telegraph; London 1700 (`51.507 -0.128`) printed books, flintlocks, telescopes, newspapers;
   Moscow 1700 (`55.75 37.62`) "Nobody here has printed newspapers yet."; Rome 100 (`41.9 12.49`) aqueducts and paved
   roads.
2. Vehicles: stand somewhere and run `/ee vehicle test`: the vehicle is the fastest in use there and then (in Rome a
   horse in 1830 and a train in 1870; in Bombay a horse in 1850, a train from 1853).
3. Before contact: Cusco or Tenochtitlan before 1519: no iron, horses, carts, printed books; Sydney before 1788: none of
   them either.
4. `/ee check all`: part 19, "The technology atlas (step 30a)", all OK. Totals: console 233, as a player 236 (2 known).

## Step 26 (new in step 30b): reading, scripts, measures, wealth, holy places and festivals

The place card has four new questions; ask them with `/ee talk at LAT LON ask lc_place_<id> read|measure|wealth|holy`.
1. Reading: Hyderabad 1948 (`17.385 78.4867`) "About 23% of people here can read and write: one man in 3, one woman
   in 9. They write Telugu in the Telugu script."; Cusco 1500 (`-13.52 -71.97`) knotted cords (quipu); Istanbul 1900
   and 1950: Turkish in Arabic letters, then Latin (the script of the language follows the year).
2. Measures: Hyderabad 1900 kos, gaz, seer, maund, bigha, tola; Hyderabad 1970 "The law says metres and kilograms
   (since 1956), but in the market people still speak of the seer ..."; Moscow 1900 versts and poods; New York 2000
   miles and pounds; Rome 100 the Roman mile.
3. Rich or poor: India 1900 poor farmers; Berlin 1923 inflation; New York 1932 the Depression; Harare 2008.
4. Holy places and festivals: Hyderabad 1948 Charminar and the Mecca Masjid, Diwali and Eid, the pilgrimage to Varanasi;
   Varanasi 1800 "Pilgrims come here from far away"; `/ee date 2024 4 10` in Cairo "It is Eid al-Fitr"; `/ee date 1900
   12 25` in London "Today is Christmas"; Rome in 100 the Saturnalia; Tokyo 1850 the pilgrimage to Mount Kōya.
5. `/ee check all`: part 20, "Reading, scripts, measures, wealth, holy places and festivals (step 30b)", all OK.
   Totals: console 240, as a player 243 (2 known).


## Turn 218: the first real run of the built mod (step 61's live record)

Environment: Forge 1.20.1, Gradle 8.8, Java 17.0.12, terra++ 2.0.0-alpha, one player in first person.

**Ran (the run's own words):** `/ee time set 1948 12 12` in Hyderabad: "Your world: 1948-12-12",
Operation Polo on the standing, TradeDesk wheat sales at world prices, the money-changer (Osmania
sicca) minting coins from metal held, paper bought and sold. `/ee check all`: **434 passed,
4 FAILED, 11 known limits.** The four FAILs and their fixes are in `logs/step61_notes.md` part 8
(famine exposure, disaster supplement count, the prices licence exception, the size budget).

**Triage of the run's other observations (test record):**

| Observation | Where it lands |
|---|---|
| First spawner cycles 2,392 / 4,856 ms "finding places", then self-tuned under the 3,000 ms tick budget | expected worst case after a 500-year jump; steady state is fine (the 434 passing checks read through it) |
| "UUID of added entity already exists: HumanNpcEntity" x20 after the jump | real-repo follow-up: the mover re-added humans the spawner kept; the engine de-duplicated, nothing broke |
| EventChainEngine "Triggered event" x76 at once on the 1948 jump | by design (the seed chain fires every year the jump passed) but noisy; a candidate to spread over ticks in the real repo |
| Missing outfit texture lines on the client | cosmetic skins not in the build's asset set; real-repo known-problems list |
| The check's "Known problems" prose (temple finish as bare wood, coin ringing the same everywhere, head-tax/bangles only when the record says, desert/dance misread, and the unfinished rows: slavery, human sacrifice, the well, the village's own fountain) | the real repo's own list, not in this workspace; fold-in notes in `logs/step61_notes.md` part 8 (the temple-finish row can already close: LIVE_LOOKS wants brass/gold/silver/copper by weight) |

**Sandbox sweep after the four fixes:** 102 probes in the list, 95 green in-sandbox, 7
environmental (probe_tiles/trade/towns/moneyworld/technology/culture need the gradle runtime
classpath; probe_step44 needs the Allen-Unger master unpacked under /tmp/fc via fetch_prices.sh).
The phantom `probe_step53f.sh` LIST entry is removed. Probes covering the fixed code all pass:
step42b 31/0 (RulerRegister + the renamed rulers pack), step42e 122/0, step43 a-d green, span 100/0,
step46 a-g green, step49 depends 43/0 (the renamed events_world pack), step61d 469/0, life/lifetable
reports green. Syntax gate clean over 492 files; the edited check lines attribute cleanly (only the
pre-existing stub gaps remain in the sandbox attribution attempt).

## Turn 219: the verification run - 438 passed, 0 failed (the fixes confirmed live)

Two fresh worlds (New World 40 and 41), rebuild with all fixes, `/ee check all`:
**end of check: 438 passed, 0 failed, 12 known limits** (was 434 / 4 / 11). All four fixed
lines now read OK in the live game:

| Fixed line | Live wording |
|---|---|
| famine exposure | "on the Kanki famine of AD 1229 the grower goes hungry before the buyer: food 0.3 against 0.6" |
| disaster supplement | "the disasters load: 27008 disasters ... 79 written by hand, 68 set aside" |
| prices licence | "none forbids commercial use except the one named exception" + the KNOWN line printing Allen-Unger every run (the 12th known limit, by design) |
| size budget | "131 files, 52.3 MB: size and SHA-256 match the list" and "the data stays within its size budget (64 MB)" |

The renamed packs all load (present_kamareddy/hyderabad_metro/telangana.json.gz, events_world.json.gz,
deccan_events.json.gz; ruler register 78,495 places / 244,393 spans from deccan_rulers.json.gz +
world_rulers.json.gz). Game play around the check: the money-changer, wheat sales at 53 then 26 pai
per 16 sheaves (the price halves after 64 sold per merchant), the notebook from Vepari Kistamma
Siddiqui for 19, and Operation Polo counting actions (1 to 4, force 0.3 to 1.0) while the player
stood in Hyderabad 1948.

Triage of this run's observations:

| Observation | Where it lands |
|---|---|
| TradeDesk prints the same sale line 3-4 times per click | working as designed: one click sells the tray in 16-sheaf lots ("goods sell a lot at a time" is a check line); 4 lines = 64 sheaves. The wording could say "16 of 64" - cosmetic, real-repo polish |
| First spawner cycle 11.1 s in world 40, 3.2 s in world 41 ("finding places" the whole cost) | the same cold path as before; both worlds settled afterwards |
| "EventChainEngine Triggered event" x76 on each jump to 1948 | known noise, by design |
| "memory now: 3776 MB used of 4096 MB" in the check | watch item: the heap ran high during the check on a 4 GB allocation; the tile budgets passed (24.5 of 48 MB); watch for stalls and raise -Xmx if needed |
| Accented names come through the pasted log damaged (Pétain "P tain", Alemán "Alem n", Shōgun "Sh?gun", the jump arrow "?") | the paste path loses non-ASCII; the strings are right in the jar. Needs a real screen glance at a name like Pétain or Alemán |
| No "UUID of added entity" warnings and no missing outfit textures in this run | the turn-218 occurrences stay recorded as intermittent; not seen twice |

## Turn 220: step 62 part 1 - the reading you can now see (`/ee here`)

The wiring phase starts here, after the user's plain verdict on the last two builds: *"i don't see
any difference from now and previous version"*. The check runs changed wording only; the new
systems were probe-proven but had no player-facing door. Part 1 puts a door on the registers.

**What to run in the real game after rebuilding:**

| Do | Expect |
|---|---|
| Stand anywhere and run `/ee here` | A page: "It is {year}." then the place ("You stand at Golconda, a city of this year."), the town's own lines (people, founding, province, head), the ruler ("The ruler the data names here is ... (1556 to 1740)"), up to 3 event lines with distances, the border line |
| `/ee year set 1500` (then 2500 BC, then 2026) | "Year set to 1500 CE" and at once the one-line form: "It is 1500. {Place}, under {Ruler}." (admin, forward only; `/ee date` still moves back) |
| `/ee here` in the mid-Sahara, inland Siberia, or the Ohio valley in 1200 | "Nobody the data records lives near here in ..." and "The register names no ruler here in ..." - nobody, said as nobody |
| `/ee here` in Delhi in 1650 | "You stand at Shahjahanabad" - the name of that year |
| `/ee year set 3000` and `/ee here` at a big city | No "About ... people" line (nothing projected), any ruler named says "a span the register marks as an estimate" |
| `/ee help` | Lists "/ee here - What the record says of where you stand this year" |

**What is checked here, not live** (`probe_here.sh`, 371 checks, 0 failed): determinism, the
year-first rule, nobody as nobody at the three empty places, somebody at the plan's test places
(Hyderabad 1500/1700/1948/2026, Delhi 1650, Rome AD 100, London 1700, Beijing 1500, Cusco 1500,
Ur 2500 BC, Mohenjo-daro 2500 BC), every estimate marked, the AD 3000 guardrail, tidy names
("golconda" reads "Golconda", "mohenjo_daro" reads "Mohenjo Daro"), year words in spans ("3400 BC
to 2251 BC"). `probe_step61d.sh` still 469 checks (the `EventNews` stub change is regression
tested); `syntax_gate.sh` 493 files clean.

**NEEDS_A_REAL_SCREEN additions (rows for Findings' style):** (1) the page's line lengths in chat
at the GUI scale the user plays at; (2) the one-line form after `/ee year set` where the player
actually stands; (3) two registers beside each other (Hyderabad 1700 ruler says Mughal Empire
while the border line says maratha) reads as honest, not as a bug - confirm by eye.

**Named limits:** the page is text only (nothing acts yet, parts 2-4 to come); event lines are the
harvest's sentence names; border civ ids print raw ("india", "maratha"); the command paths need
the real rebuild to be live (17 past build errors were the same story). Full record:
`logs/step62_notes.md`.

## Turn 221: three doubts from the latest run (fixed; rebuild to see them)

| Doubt | Why it happened | What changed |
|---|---|---|
| **1. NPCs at 17.4346, 78.5016 in 3000 BC** | Two layers disagreed. The named-record layer (sites, towns) says **nobody** there in 3000 BC (verified at the exact point: first named neighbour is Kondapur, AD 1). But the spawner also reads the **HYDE 3.2.1 population raster** ("everywhere, thinly settled land"), which counts a thin modelled presence on the Deccan tiles in 3000 BC - historically fair (Neolithic Deccan), but `/ee here` did not know that layer, so the page said "nobody" while people stood in front of you | `HereAndNow` now reads the same grid the spawner reads. The page at that point now says: "Nobody the record names lives near here in 3000 BC, but the population grid (HYDE 3.2.1) counts a thin presence on this land: a modelled presence, not a measurement." The people and the page now agree, and the estimate is marked |
| **2. Most NPCs not moving** | `settleDistant` settled **everyone** in reach (`presenceSettleGoals` default true), removing the stroll goal from all of them - which broke its own rule: "in somebody's sight: let them walk for real". Distant people were fine (cheap routine hops); people near you stood still because the goal that lets them walk had been taken away | Only the **frozen** (far, or on bad ground) are settled now; people near you walk for real. Sellers keep their stand (directions stay true), event NPCs still move, distant crowds still freeze for performance. The drawn crowd figures stay no-AI by design ("a body and nothing else") and amble only along their day route in the crowd cycles - they are the background, the living few are the people you meet |
| **3. Few interaction options** | Talk options for "Who rules here?" and "What is this place?" appeared **only where a knowledge card existed** - so the empty places, exactly where players ask the most, offered the fewest options | Both questions are now always offered, and when no card answers, the **registers** do ("the land answers to Vijayanagara Empire", the place line of the year). A new question is always there: **"Where am I, and what year is it?"**, answered with the reading's one-line form plus the ruler line |

**To see it after rebuilding:** stand at 17.4346, 78.5016 in 3000 BC and run `/ee here` (the marked
grid line); watch people within 32 blocks walk while distant ones stay put; talk to any villager and
count the options - the three register-backed questions are there even in the middle of nowhere.

**Checked here:** `probe_here.sh` **391 checks, 0 failed** (the doubt-1 spot is now a probe spot; the
empty-place rules accept the marked grid presence and demand its mark); `syntax_gate.sh` clean on
the three edited files. **Not checked live:** the two Minecraft-side edits (`PresenceLocalSpawner`,
`TalkService`) need the real rebuild, like every past round.

**Limits that stand:** the crowd figures are still furniture by design (researched, in
`CROWD_DECISION` docs) - if you want them walking too, say so and we will price it; interaction is
still ask/look/trade, not hire/follow/fight (those are their own parts); and the spawner's population
number for grid-only land is the resolver's FLOOR/GRIDDED band ("a presence, not a measurement").

## Turn 222: the runtime test program (built; rebuild to run it)

The user's brief: runtime tests of **every aspect**, input `/ee test` / `/ee check`, a world file as
the fixture. Their choices: singleplayer, in-game only. Built as `testing/RuntimeSuite.java`:

| Run | Expect |
|---|---|
| `/ee test everything` | Phases run in chat as usual (check all + test all), then one summary: "Runtime suite: N passed, M failed, K known limits, L needs more", every FAIL named; **`eternal_runtime_report.json` and `.txt` written beside the world's state file** (next to `backups/`) |
| `/ee test movement`, wait 5 s, again | First call: "Sampled N people near ..."; second: "X of N people ... walked more than 2 blocks in five seconds (furthest Y)". The doubt-2 regression as real motion |
| `/ee check all` | Unchanged, still writes no files |

The report grades PASS / FAIL / KNOWN / LIMIT (never silent: a LIMIT names what would settle it:
era-route buildings = your eyes, multiplayer = a second player, movement motion = the two-run
test). The places phase re-runs the reading's rules at the plan's place-years in **this** world,
including the doubt-1 spot at 3000 BC.

**To hand over the world file:** zip the world save folder and drop it in the chat. It is read in
the sandbox before the suite runs, and its facts are baked into the expectations.

**Checked here:** syntax gate clean on the three edited files. **Not checked live:** needs the
rebuild like every Minecraft-side round. Known first-run risks: `WorldStateManager.getStateFile()`
null (report falls back to chat-only and says so), and `/ee test all`'s verdicts stay in its own
summary line until its counters are exposed (a LIMIT says exactly that).

## Turn 223: the test camera (the runtime suite shoots its own screenshots)

The user's correction: **"I SAID YOU TAKE THE SCREENSHOTS when testing in runtime."** Built:

| Command | What happens |
|---|---|
| `/ee test photos` | Two frames of your view right now: `etest_now_<lat>_<lon>_<year>_a.png` / `_b.png` in the game's screenshots folder |
| `/ee test photos route` | The full era route (31 stops, FINAL_TEST R1-R31): the suite sets the year, teleports you, waits 8 s for Terra++ to build the year around you, shoots two frames per stop (`etest_r07_rome_ad0100_a.png` style), then writes `eternal_photo_report.txt` / `.json` beside the world state. About seven minutes |
| `/ee test photos stop 7` | One stop only (1 to 31) |

The report per stop: the two filenames, the packs' own watch line ("aqueducts, paved roads, the
Roman mile" at R7; R11 and R12 carry their known-problem warnings), and the data reading at that
place-year (`/ee here`'s one-line form). The second frame is 1.25 s after the first, so a walking
person is caught mid-stride.

**New files (rebuild all):** `testing/PhotoRoute.java`, `testing/RuntimeSuite.java` (phase 5 now
names the camera), `client/TestCamera.java`, `network/packets/TestPhotoPacket.java`,
`network/EternalEnginePacketHandler.java`, `commands/EternalEngineCommands.java`.

**Checked here:** syntax gate clean on the six files. **The one mapping gamble:** vanilla's
`Screenshot.grab(File, String, int, int, Framebuffer, Consumer)` in `TestCamera` (the same call F2
makes). If the rebuild reports it, paste the error and it is a one-line fix like the 17 before.
**Honest note:** the teleporting is the test's job; `/ee date` semantics are copied exactly
(operators only, TimeTravel judge first, Terra++ day count when Terra time is on).

## Turn 224: screenshots are the agent's eyes (the user's rule)

**The rule (user): "if you want to see anything use screenshots to achieve it."** So whenever the
work says "I want to see X in the game", the answer is always a test command that photographs it.
No visual question is ever answered by asking the user to look and report.

New shutter topics behind the rule (all in `/ee test photos ...`):

| Topic | Frame it takes | What it settles |
|---|---|---|
| `book` | `etest_book_accents.png` of a test book page (Pétain, Ürümqi, wrapping line, digits) opened on screen | Findings 11 + 30: accented names in GUIs, wrapping, GUI scale |
| `sky` | `etest_sky_day.png` + `etest_sky_night.png`, clock put back after | the atmosphere pack's day and night look, at any year (set the date first) |
| `shoot <label>` | `etest_<label>_<year>.png` | the general "I want to see X" escape hatch |
| `route` / `stop <n>` / plain | as in turn 223 | era look, current view |

**Rebuild list adds:** `testing/PhotoRoute.java` (job queue + three new topics),
`commands/EternalEngineCommands.java` (photos: book, sky, shoot). Syntax gate clean. The
`ServerLevel.setDayTime` call in `sky` is the second mapping gamble alongside `Screenshot.grab`;
both are one-line fixes if the rebuild names them.

**Honest remainder:** what no picture can carry - frame rate, input lag, true multiplayer, hours of
play feel. Everything else in the "needs eyes" lists is now a screenshot the test takes.

## Turn 225: one command only (the photos commands are gone)

**The user: "no need separate command like /ee test photos."** So the camera folded into the one
test command. **`/ee test everything` now ends with the camera pass** (`PhotoRoute.fullRun`), and
there is nothing else to run or remember:

1. your view (two frames a second apart),
2. the sky at noon and midnight (clock put back after),
3. the 31 era stops (two frames each, people caught mid-walk),
4. the screens book page last (etest_book_accents.png; close the book after the shot).

The pass writes `eternal_photo_report.txt` / `.json` beside the runtime report. The book is always
last because its open screen would otherwise fill every later frame. **The commands from turns 223
and 224 (`/ee test photos ...`) are removed** - the tables above those sections are history, not
runbook. `/ee test movement` is unchanged. For any other century of sky or view: set the date and
run `/ee test everything` again.

Rebuild: `testing/PhotoRoute.java` (fullRun + job queue), `testing/RuntimeSuite.java` (calls it;
screen phase reworded), `commands/EternalEngineCommands.java` (photos subtree deleted). Syntax
gate clean on all three.

## Turn 226: the pilot (the test walks you; systems get exercised where you stand)

**The user: the player control is "for testing at multiple areas and time other features and
system."** So the camera pass does not teleport and freeze any more: at every era stop the test
**walks you through it** (a 48-block loop at walking speed, ~9 s, covering the whole settle time),
and the frames are taken **mid-stride**, so the world is caught with motion in it. While you walk,
every system that reacts to a walking player is exercised at that place-year: crowds, spawners,
talk prompts, chunk streaming, frame feel.

**The stop line in the photo report grows a systems reading**, four live reads per stop, each in
its own try so one broken system reports itself and never stops the run:
`systems: wheat=<Prices sentence or 'no market within reach'> credit=<rate or 'no row on record'>
ruler=<name at place or 'nobody on record'>` (plus the HereAndNow place line already there). That
is the prices, credit and ruler registers queried at 31 area-years, 3000 BC to AD 1900.

**The pilot's rules:** it only moves when the test asks; **any movement key press cancels it
instantly** ("you took the controls"); it walks with the world's own physics (walls stop it, the
ground holds it up, one-block hop when stuck). It cannot be steered into the void: the walk is a
local loop around the arrival point, and the route stops the pilot before each next teleport.

**Rebuild adds:** `client/TestPilot.java` (the legs), `network/packets/TestWalkPacket.java` (the
walk order: waypoints as dx,dz offsets + speed; empty list = stop), registered in
`EternalEnginePacketHandler`; `testing/PhotoRoute.java` (walk loop per stop + the systems line).
Syntax gate clean on all five touched files. **Mapping gambles now three, all one-line fixes if the
build names them:** `Screenshot.grab`, `ServerLevel.setDayTime`, and the pilot's client fields
(`options.keyUp` family, `yBodyRot`/`yHeadRot`).

## Turn 227: the wall items get in-run alternatives

**The user: "take alternatives for what I cannot do and do it by using /ee test everything."**
The agent's honest wall was: cannot watch the screen, cannot feel the framerate, cannot change
anything mid-session, cannot sit for hours of play, cannot be a second player. Every one now has
an in-run alternative except the last:

| The wall | The alternative inside `/ee test everything` |
|---|---|
| Watch the screen | the camera pass (turns 223-226): frames at every era stop, mid-stride |
| Feel the framerate | **measured, not felt** (new): every shot writes its numbers to `etest_perf.txt` (fps now/avg/min + client tick ms avg/worst over the last 5 s), and every era-stop line carries server tick ms (50 ms is healthy). New `client/TestWatch.java` |
| Change anything mid-session | the suite is the mid-session actor: it sets years, teleports, walks you, opens the book - always giving time back after |
| Hours of play | **the day-pass** (new, in the living phase): borrow one full day round (the calendar moves to tomorrow), ask every system again while standing there, then give the day back. Verdict: the world still answers on the far side of the day |
| Be a second player | honest LIMIT: the run exercises talk and trade with NPCs as counterparty; a real second human is the one thing no in-run alternative can fake |

**Rebuild adds:** `client/TestWatch.java`, `client/TestCamera.java` (one call), `PhotoRoute.java`
(tick timing + per-stop `tick:` line), `RuntimeSuite.java` (day-pass phase, phase-5 reworded).
Syntax gate clean on all four. **Mapping gamble #4:** `Minecraft.getFps()` in TestWatch (wrapped so
a missing counter degrades to "?", but the name must compile; one-line fix if named).

## Turn 228: build errors 4, fixed 4 (the first real-game compile)

The user pasted `compileJava` output; four errors, all small, all fixed in the workspace:

1. **`TestCamera`: `Screenshot.grab`** - the build named the real overload
   `grab(File, String, RenderTarget, Consumer)`; the 6-arg width/height form does not exist in
   this Forge 1.20.1. Fixed: dropped the two int args. (Gamble closed, not guessed.)
2. **`PhotoRoute`: `TestWalkPacket` cannot find symbol** - missing import (the packet itself
   compiled fine). Fixed: `import com.eternalengine.network.packets.TestWalkPacket;`.
3. **`PhotoRoute` (same two lines)** - same missing import, same fix.
4. **`RuntimeSuite`: `HereAndNow.Reording`** - a typo'd record name in the places phase's
   determinism re-read (the real record is `HereAndNow.Reading`). My syntax gate cannot catch
   misspelled type names (they look like unresolved symbols). Fixed.

**What this build PROVED** (no errors in them): `TestPilot`'s whole client API surface
(`options.keyUp` family, `yBodyRot`/`yHeadRot`, `setDeltaMovement`), `TestWatch`'s `getFps()`,
the day-pass clock calls (`TerraTimeBridge.setDayCount`, `KnowledgeDate.nextDay`,
`WorldCalendar`), `TestWalkPacket`'s encode/decode, and `ServerLevel.setDayTime`. Every mapping
gamble is now closed by evidence. **Re-copy these 3 files and rebuild:** `client/TestCamera.java`,
`testing/PhotoRoute.java`, `testing/RuntimeSuite.java`.

## Turn 229: the first real run, and the /tpll fix

**The user's flaw: "try using /tpll instead of /tp."** The route was landing the player with a raw
teleport at coordinates read from a chunk Terra++ had not built yet (the log shows the world still
warming up around every destination). Fixed: `PhotoRoute.arrive` now issues Terra++'s own
`/tpll <lat> <lon>` through the command dispatcher (the same call the checks tell players to use),
with the direct teleport kept only as a fallback so the route never dies. Rebuild: `PhotoRoute.java`.

**What the first real run proved (log of 2026-10-22 02:12-02:23):**
- The suite ran end to end: **19 passed, 0 failed, 0 known limits, 7 needs more**; reports written.
- `/ee check all` = **438 passed, 0 failed, 12 known limits** live again.
- The camera worked: shots `etest_r1_ur` through `etest_r6_pataliputra` taken, chat lines and all.
- The safety valves worked: the run stopped cleanly when the player left ("the photographed player
  is gone; the run stops here"), and the tick watchdog throttled population on its own.
- **Real pace under load: one to two minutes per stop** (Terra++ builds each new place while the
  route stands there; the server fell 3,674 ticks behind at the worst). The full 31-stop route is
  therefore about 30-60 minutes, not five. The chat copy now says so.

**New findings from the run (to fix or guard):**
1. **"UUID of added entity already exists"** spam when a stop's people spawn (worst at Pataliputra):
   the NPC registry is colliding on UUIDs during mass spawn. Real bug, next fix.
2. **Spawner cycles 1.7 s to 63.8 s** ("finding places" is the cost) - the known cold-start watch,
   now measured in the wild; worst at Athens.
3. Named NPCs at the previous stop die "killed by magic" when the player leaves (presence cleanup
   at teleport) - looks by design, confirm it should not fire for settled people.


## 2026-10-22 (turns 230-235): the Secunderabad arc, restored, and the autonomous test build

**Loss notice first.** The workspace snapshot cap (see PROGRESS turn-155 rule and turn-234
budget) silently dropped the turn-232 versions of `RuntimeSuite.java`, `PhotoRoute.java` and
this file's turn-230..234 entries. Found at turn 235 by grep; everything below is rebuilt and
verified. Lesson now mechanical: **after every edit, grep-verify; after every turn with code
edits, re-grep before trusting the file.**

**Turn 230-231 (condensed):** the user found market-town NPCs at Secunderabad in 3000 BC. Root
cause: `HistoricalPresence.rank()` fell through to `SettlementRank.VILLAGE`, dressing a forager
band as a village. Fix at the source: `SettlementRank.COUNTRYSIDE` (roles `{"forager"}`),
`rank()` now answers COUNTRYSIDE when the evidence is silent, `PopulationResolver` gives open
country the HYDE model (no 200-person village floor; the "250 people" was that floor), rendered
caps 1-4, no news-seller in a camp. The test `nobody-before-their-time` computes expectations
from the record's evidence fields and FAILS if rank fabricates. Working method written in
`worldfill/WORKING_RULES.md` (turn 233): world claims first, the one-second glance, ordinary
cases first, defaults claim the least, fix the answer not the listeners, sibling sweeps.

**Turn 232 (condensed):** "why did the USER find it?" - the program only looked at the player's
feet and famous places in famous years. Probes at fixed map points (claim-* in the living phase)
and ordinary route stops (R32 Secunderabad 3000 BC, R33 Central Australia 3000 BC, R34 Swiss
farmland 1200) added - and now restored after the loss.

**Turn 234 (condensed):** workspace budget: 119 MB / 2,332 files after deleting 453 JVM crash
dumps and a culled JDK; regenerable tools live in snapshot-excluded dirs (`worldfill/
bootstrap_jdk.sh` -> `build/jdk17`).

**Turn 235: the autonomous build ("my task is only to use /ee test").** The user's verdict: I
build every direct and indirect test into the game under `/ee test`; the user only runs the
command; `tpll` and time jumps are the test's own to make. Built this turn:
- `PhotoRoute.Stop` gains a **claim** ("settlement" / "open" / "any") on all 34 stops: famous
  places claim settlement evidence must exist; R16 Sahara and R32/R33 claim open country; the
  rest claim the universal invariant only.
- `PhotoRoute.claimCheck` judges each stop **physically**: presence evidence + rank + a scan of
  who actually stands near the player (town dress forbidden on unproven land). The verdict
  travels with the frames: `| claim: PASS (rank COUNTRYSIDE, 3 people (0 in town dress), 4
  figures; open country as claimed)`. Summary line in the photo report.
- `RuntimeSuite.worldClaimsPhase` (phase 3b): the same claim table checked **without moving**
  (query level, every run), plus **120 deterministic random looks** - ten ordinary land regions
  times twelve years -3000..2000, applying the invariant "rank answers countryside iff the
  evidence is silent". This is the automated version of "one random look at one random place".
- The living-phase `claim-*` probes (Secunderabad 3000 BC regression included) restored.

**What `/ee test everything` now does, end to end:** engines (check counters), commands, places
readings, **route-claims** (34 declared claims at query level), **world-sampling** (120 random
ordinary looks), living world at the player (walking, nobody-before-their-time, claim probes),
day pass, then the camera route: the test teleports the player (`/tpll`) and jumps time itself
across 34 place-years, and at every stop judges the world claim against the people standing
there, before the frames are taken. The user runs one command and does not interfere.

**Still queued (the "everything" remainder):** scenario E (economy day) then P; step 63 then T/X;
EeCommandSelfTest counter wiring; spawner cold/heap watch; the in-game `/ee audit` sampler as a
separate command if wanted; regression guards for the Findings rows.


**Turn 235 addendum (free will, used):** the user pointed out that everything in the workspace is
already authorized - no more asking. Done this turn without asking: (1) the real ForgeGradle
build launched as a background process (`GRADLE_USER_HOME=/home/user/build/gradle`, JDK
`/home/user/build/jdk17`, Gradle 8.8 wrapper) and it reached the Minecraft transformation stages
(downloadMCMeta, applyBinpatches, renameSrg2Mcp) live in `eternal/build/`; (2) scenario E, the
economy day, built into the suite as `economy-day-hyderabad-1948` and `economy-day-london-1800`:
100 loads of wheat sold through the merchant's own offer engine over as many days as his budget
and appetite allow - purse must add up, no day may sell past twice his want, the trade words must
speak the local money. Next in the same lane: scenario P (famine week), then the build result
drives the GameTest/server run.


**Turn 235c: the loop closed - built, ran and tested the game in my own workspace.** No asking,
just doing. Evidence:
1. **The real ForgeGradle build works here** (Gradle 8.8, official mappings, JDK 17): first
   attempt OOM-killed the daemon -> 3 GB swapfile added; second attempt compiled everything and
   found exactly ONE error (variable shadowing in livingPhase; the gate now catches "is already
   defined"); third attempt BUILD SUCCESSFUL, jar 57.4 MB with all shipped data.
2. **The Forge server runs here** (peaceful, RCON on 25575, `worldfill/rcon.py` is my console).
   First boot found a REAL latent bug: `SimulationEngine` read Forge config values during
   commonSetup, before configs load - dev environments crash on it (production hides it today).
   Fixed at the source (`EternalEngineConfig.server(value, fallback)` guard, 12 reads) and swept
   siblings. Second boot hit OutOfMemory on the 55 MB of data -> run JVM gets `-Xmx1600m`.
   Third boot: clean, mod logs its own systems live.
3. **`/ee check all` on the live server: 435 passed, 0 failed, 12 known limits** (the two FAILs
   of the OOM run were partial-load artifacts and did not reproduce).
4. **`/ee test everything` on the live server: 21 passed, 0 failed, 8 needs more** (the LIMITs
   are the player-and-frames items). Highlights: route-claims PASS (all 34 claims at query
   level), world-sampling PASS (120 random ordinary looks, rank never contradicted evidence),
   economy-day Hyderabad 1948 PASS (100 loads for 275, "4 annas 5 pai for 16 sheaves of wheat"),
   economy-day London 1800 PASS ("5 pence 2 farthings for 16 sheaves"), and
   place-hyderabad-outskirts-3000-bc PASS with "only the population grid counts a few people,
   with no ruler the register names" - the Secunderabad fix speaking for itself. Reports copied
   to `worldfill/runtime/last_sandbox_run/`.
5. **Small findings for later:** the command self-test marks `/ee year set -3000` FAIL although
   the refusal is correct behavior (test expectation bug); Terra++ has no projection config in
   the sandbox (terrain generation warns); the tick watchdog flags compass at 16 ms; dev-only
   netty reflection warnings are noise. The server keeps running for the next turn's work.

**Archived examples (2026-11-03):** the historical sample server logs above are now `.txt.xz`; verify or restore their original paths with `archived_history_reports.py` subject to its storage/no-overwrite guard. They are not current test results.

Storage note: the historical generated `PRODUCT_ATLAS_TABLE.md` is archived as `.md.xz`. Use `python3 worldfill/archived_history_reports.py PRODUCT_ATLAS_TABLE.md --print` to read verified bytes, or `--restore` when space permits. Generators still write the original path; the archive does not overwrite it.
