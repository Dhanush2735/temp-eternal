# Weapons research: how a player gets weapons to change history

Written 13 Oct 2026, after the question "to change history player should need weapons. i can add weapon mods but how will a player obtain it?"

Nothing in the mod was changed. This is research only.

---

## 1. Short answer

- The mod already notices when you change history by fighting. But every soldier in every year carries the same iron sword. There is also no way to get weapons apart from normal crafting.
- History shows five ways people got weapons. We can use all five:
  1. the army gave them;
  2. people brought their own;
  3. they bought them from a smith;
  4. they took them in fights;
  5. they got them as gifts.
- Rules differed by place and time:
  - some places made men own weapons;
  - some banned them for ordinary people;
  - some needed a licence;
  - in wartime, weapons were smuggled.
- Good weapon mods exist for your game (Forge 1.20.1), covering every age from bronze to modern guns.
- Missing: there is no mod with Indian weapons (talwar, katar), and none with a matchlock gun.

---

## 2. What the mod has today (code facts)

| What | Where | Today |
|---|---|---|
| Noticing a history change | `player/InWorldInterventionDetector` | Counts enemy fighters beaten at the event's place and time (weight 1) and key people removed (weight 1). Killing villagers or players counts 0. The total must cross a threshold, and one stray kill is never enough. |
| Taking a ruler's place | `vip/VipTakeoverMethod` | DUEL, BATTLE, ASSASSINATION, MURDER. Only duel and battle count as fair fights. |
| Alternative timelines | `timeline/*` (TimelineManager, AlternativeTimelineEngine, DivergenceCascadeEngine …) | These exist. Config `enableAlternativeTimelines = true`. |
| Soldiers | `war/RegimentCohort` | Iron sword + shield, or bow. Same in every year. |
| Palace guards | `sovereign/RoyalCourtManager` | Iron sword + shield. The ruler holds a golden sword as a "sceptre". |
| Caravan guards / bandits / marines | `trade/CaravanEntityGroup`, `BanditAmbushEngine`, `MerchantShipConvoy` | Iron sword + shield / iron axe or bow / crossbow. |
| Story start | `chrononexus/ChronoNexusCampaignEngine` | Gives the player a stone sword. |
| Ages | `technology/TechEra`, `TechnologyTree` | Broad ages (Stone Age, Ancient, Medieval, Renaissance, Industrial, Modern) and 7 inventions per country. Not tied to real years or regions. |

So soldiers in 1948 Hyderabad hold iron swords, when real soldiers had rifles.

---

## 3. Which weapons existed when (by region)

Years are approximate starting points. "(check)" means the year is general knowledge that I have not yet checked against a source.

| Weapon kind | India | Middle East | Europe | China | Japan | Africa (south of Sahara) | Americas |
|---|---|---|---|---|---|---|---|
| Wood and stone: clubs, spears, bows, slings | always | always | always | always | always | always | always |
| Bronze: daggers, spears, axes | ~3300 BC (Indus) [B1] | ~3300 BC [B1] | ~3200 BC Aegean, ~2000 BC north [B1][B2] | ~2000 BC [B1] | ~300 BC, with iron (check) | no Bronze Age: stone, then iron [W1] | none; stone and obsidian (no iron economy) [W1] |
| Iron and steel swords, spears | ~1200 BC [W1] | ~1200 BC [W1][BR1] | ~1300 BC south-east, ~800 BC centre and west, ~500 BC north [W1] | ~600 BC [BR1] | ~300 BC (check) | ~500 BC, some places earlier [W1] | only after 1492 (Europeans) [W1] |
| Crossbow | rare (check) | (check) | common from ~1000 AD (check) | ~500 BC (check) | (check) | (check) | after 1492 |
| First guns: cannon, hand cannon | mentioned in Vijayanagara in the 1300s [BR2]; North India 1526 [W2] | Mamluks certainly by 1342 [W3] | 1326 Florence; used 1331; common in France by 1338 [W3] | fire lance 1259, hand cannon 1200s [W3][G1] | 1543 (check) | by trade, 1500s+ (check) | 1492+ |
| Matchlock (arquebus) | soldiers with them seen in Gujarat and the Bahmani kingdom, 1515–18 [IE]; Babur's matchlocks 1526 [W2] | Mamluks told to train with arquebuses in 1489 [W4] | late 1400s [W3] | 1500s (check) | 1543 (check) | 1500s+ (check) | 1500s+ |
| Flintlock | 1700s (check); the matchlock stayed common [MA] | 1700s (check) | ~1610 [F1][F2] | limited (check) | limited; Edo kept matchlocks (check) | 1700s by trade (check) | 1600s+ |
| Percussion cap, revolver, rifle bullet | 1850s (check) | 1800s (check) | cap 1807–1822; Colt revolver 1835–36; Minié bullet 1849 [F1][F3] | 1800s | 1860s (check) | 1800s | 1830s+ |
| Machine gun | 1880s+ | 1880s+ | Maxim gun 1884 [F3] | 1880s+ | 1880s+ | 1880s+ | 1880s+ |

### India and the Deccan, step by step (most important for your world)

| Year | What |
|---|---|
| ~3300 BC | Bronze, with the Indus cities [B1] |
| ~1200 BC | Iron (Painted Grey Ware culture) [W1] |
| 1300s | Firearms mentioned in the Vijayanagara empire of the Deccan [BR2] |
| 1515–18 | A Portuguese writer saw foot soldiers with arquebuses in Gujarat and the Bahmani kingdom [IE] |
| 21 Apr 1526 | Panipat: Babur's 12,000 men had matchlocks and 15–20 cannon, and the Delhi side had none. One of the earliest battles with guns in India [W2] |
| 1650–1818 | Maratha army: muskets, matchlocks, *firangi* swords, clubs, bows, spears, daggers [MA] |
| 1878 | Indian Arms Act: Indians needed a licence to own, make, sell or carry guns; Europeans were exempt [L1] |
| Jul–Sep 1948 | Hyderabad: the Nizam could not get new arms for 11 months. Sidney Cotton then flew them in secretly from Karachi, landing near Bidar. They included about 10,000 rifles, 1,200 Beretta and 3,000 other sub-machine guns, and mortars. [H1][H2] |

---

## 4. How people got weapons in history

| Where, when | How | Rule for the game |
|---|---|---|
| Maratha army, 1650–1818 | A *bargir* got his horse and weapons from the state. A *shiledar* brought his own. [MA] | When you join an army, it either arms you or expects you to bring your own weapons. |
| England, 1181 (Assize of Arms) | Every freeman had to own weapons according to his wealth. A knight needed mail, shield and lance; a poor freeman a lance and iron helmet. Selling them was forbidden. [A1] | In some places, owning weapons is a duty, so weapon makers sell to everyone. |
| Japan, 1588 (sword hunt) | Peasants were forbidden to own weapons, and their weapons were taken away. [J1] | In some places, ordinary people can't carry weapons. Joining the warrior class or the army is the way. |
| British India, from 1878 | A licence was needed for guns. [L1] | Get a licence from the official, or use the black market. |
| Hyderabad, 1948 | Weapons were smuggled in by air during the crisis. [H1][H2] | In wartime there are smugglers, with high prices and some risk. |

---

## 5. Weapon mods for your game (Forge 1.20.1)

All versions were checked today on Modrinth for "1.20.1 + Forge".

| Mod | Times it fits | Newest 1.20.1 Forge version | Also needs | Licence | Notes |
|---|---|---|---|---|---|
| **Spartan Weaponry** | ancient to medieval: swords, spears and polearms, bows, crossbows, throwing weapons, in many metals | 3.2.1 (3 Aug 2025) | nothing | Apache-2.0 | Very popular (61 M downloads) [S1] |
| **Epic Knights** | medieval: armour, weapons, shields, heraldry; adds steel | 10.15 (20 Sep 2026) | Architectury API, Cloth Config | all rights reserved | [K1] |
| **Epic Knights: Antique Legacy** | antiquity: 20 weapons, 71 armour pieces, 5 shields | 1.13 (22 Feb 2026) | Epic Knights | all rights reserved | Bronze is made from copper + tin, and tin needs another mod. |
| **Age of Weapons – Reforged** | stone age, antiquity, middle ages, Edo Japan, pirate age, modern | v.1.3.2c (5 May 2025) | nothing | MIT | Also has "future" and "legendary" fantasy items, which we would lock away. [AW] |
| **Chinese Ancient Blade** | China: Tang *hengdao*, ring-pommel *dao*, *yanling dao*, *miao dao* | 1.7.79 (11 Mar 2026) | playerAnimator, Geckolib | ISC | optional |
| **Musket Mod** (ewewukek) | 1600s–1800s: musket, pistol, blunderbuss, scoped musket, bayonet | 1.5.4 (12 Oct 2024) | Cloth Config | MIT | Can give skeletons and pillagers guns; switch that off in its settings. [M1] |
| **Scorched Guns 2: Flintlocks** | 1300s–1800s: hand cannon, flintlock, musket, blunderbuss | 0.1.0 (16 Aug 2025) | Geckolib, Curios | GPL-3.0+ | Early version; guns are made at its own Gun Bench. |
| **TaCZ** | 1870s to now: from the Springfield 1873 rifle to modern guns; extra gun packs | 1.1.8-hotfix2 (2 Oct 2026) | nothing | GPL-3.0 | Guns are made at its own gun table; data in JSON files. [T1] |
| **Vic's Point Blank** | modern guns | 2.2.0 (11 Sep 2026) | nothing | all rights reserved | An alternative to TaCZ. |

**My pick:**
- Spartan Weaponry;
- Epic Knights + Antique Legacy;
- Musket Mod;
- TaCZ;
- optional: Chinese Ancient Blade.

**Gaps:**
- **No Indian weapons for Java 1.20.1.** I found only a Bedrock add-on (talwar, *pata*, *tabar*), which can't be used, and a small unfinished mod (khopesh, katar). [IW] Two fixes are possible:
  - (a) the same item gets the local name, so a saber sold in India is called a "talwar";
  - (b) later, the mod adds a few Indian weapons of its own.
- **No matchlock mod.** India's main gun from the 1500s to the 1700s was the matchlock. A musket can stand in for it under a local name.
- **Each gun mod has its own ammunition,** which must follow the year rules too.

---

## 6. Proposed design

1. **The place-and-year table gets two new answers:**
   - which weapon kinds exist there (section 3);
   - the weapon rules: free, must own, licence or banned for ordinary people, plus whether the army arms you or you bring your own (section 4).
2. **Soldiers, guards and bandits carry weapons of their own place and year,** taken from the installed mods. With no weapon mods, they use normal Minecraft weapons. Beaten fighters sometimes drop them.
3. **Weapon makers at markets** (blacksmith, armourer, bowyer, gunsmith) sell what exists there, as the law allows. Licences come from officials; smugglers sell in wartime or under bans. This uses the step 19 money.
4. **Joining a side:** an army, rebels, palace guard or caravan guards. They give weapons and pay where the army armed its men. Elsewhere they expect you to bring your own.
5. **Crafting follows the year rules.** That includes the gun mods' own tables (TaCZ, Scorched Guns).
6. **A weapon from another time still works,** but its ammunition can't be bought or made there.
7. **Names by region:** the same item can be a "talwar" in India and a "scimitar" in Persia.
8. **The story start** gives a simple weapon of the time instead of a stone sword.

### Technical notes (for building)

- **A weapon list** `config/eternalengine/weapons_by_year.json` gives each item (or item tag) a kind, and each kind its region years.
  - Defaults ship for the mods above.
  - Unknown modded weapons are guessed from their names (bronze, iron, steel, musket, flintlock, pistol, rifle …), and the guess is logged so it can be fixed.
- **Replace the hard-coded `Items.IRON_SWORD` / `BOW` / `CROSSBOW` / `IRON_AXE`** in `RegimentCohort`, `RoyalCourtManager`, `CaravanEntityGroup`, `BanditAmbushEngine` and `MerchantShipConvoy` with one lookup: "weapon for (place, year, role)".
- **Forge has no simple "cancel crafting" event.** So:
  - empty the result slot when it holds a locked item;
  - stop the gun mods' tables from opening before their years.
- **New `/ee check all` lines:**
  - every role gets a weapon in sample years;
  - no weapon appears before its first year.

### Build order

1. Weapon list by year, plus the lookup.
2. Soldiers, guards and bandits use it, and drop weapons.
3. Weapon makers, licences and smugglers (needs the step 19 money).
4. Crafting and ammunition locks, including the gun tables.
5. Joining a side (needs the war system review, group 5).

---

## 7. Decisions for the user

1. **Mods:** my pick above, or a different set?
2. **Indian weapons:** local names on similar items now, and the mod's own talwar and katar later?
3. **Weapon laws** (licences, bans, smugglers): include them?

---

## 8. Sources

- [W1] Wikipedia, "Iron Age": https://en.wikipedia.org/wiki/Iron_Age
- [W2] Wikipedia, "First Battle of Panipat": https://en.wikipedia.org/wiki/First_Battle_of_Panipat
- [W3] Wikipedia, "Hand cannon": https://en.wikipedia.org/wiki/Hand_cannon
- [W4] Wikipedia, "History of gunpowder": https://en.wikipedia.org/wiki/History_of_gunpowder
- [MA] Wikipedia, "Maratha Army": https://en.wikipedia.org/wiki/Maratha_Army
- [A1] Wikipedia, "Assize of Arms of 1181": https://en.wikipedia.org/wiki/Assize_of_Arms_of_1181
- [J1] Wikipedia, "Toyotomi Hideyoshi": https://en.wikipedia.org/wiki/Toyotomi_Hideyoshi
- [B1] Bronze Age dates (Wikipedia copy): https://en-academic.com/dic.nsf/enwiki/2464
- [B2] Bronze Age by region: https://scienceinsights.org/what-is-the-bronze-age-history-facts-collapse/
- [BR1] Britannica, "Iron Age": https://www.britannica.com/event/Iron-Age
- [BR2] Britannica, "Gunpowder empires": https://www.britannica.com/topic/gunpowder-empires
- [IE] Indian Express, "500 years of Mughals": https://indianexpress.com/article/explained/explained-history/mughals-500-years-first-battle-of-panipat-babur-ibrahim-lodi-10646794/
- [G1] Hand cannon history: https://boisegunclub.com/handbook/hand-cannon
- [F1] Firearms timeline (archived): https://web.archive.org/web/20151222090129/http:/www.firearmsadvantage.com/history_of_firearms.html
- [F2] Flintlock, Marin le Bourgeoys c.1610–1615: https://grokipedia.com/page/History_of_the_firearm
- [F3] Percussion cap, revolver, Maxim gun: https://www.usa-gun-shop.com/the-history-of-firearms/
- [L1] Indian Arms Act 1878: https://www.iasgyan.in/daily-current-affairs/indian-arms-act
- [H1] The Hindu, "The day Hyderabad surrendered": https://www.thehindu.com/society/history-and-culture/the-day-hyderabad-surrendered/article24968823.ece
- [H2] Hyderabad History Project, "Operation Polo … diplomatic cables": https://medium.com/@hyderabadhistoryproject/operation-polo-how-the-indian-govt-played-its-hand-through-diplomatic-cables-before-the-annexation-6d13836d58f8
- [S1] Spartan Weaponry: https://www.curseforge.com/minecraft/mc-mods/spartan-weaponry/files/5597663
- [K1] Epic Knights: https://www.curseforge.com/minecraft/mc-mods/epic-knights-armor-and-weapons
- [AW] Age of Weapons: https://www.curseforge.com/minecraft/mc-mods/age-of-weapons
- [M1] Musket Mod 1.20.1 Forge: https://www.curseforge.com/minecraft/mc-mods/ewewukeks-musket-mod/files/5669759
- [T1] TaCZ: https://minecrafthub.io/mods/timeless-and-classics-zero
- [IW] Small weapons mod (khopesh, katar): https://mcreator.net/modification/105960/better-weapons-and-items ; Bedrock add-on: https://www.9minecraft.net/ancient-weaponry-addon-mcpe/
- Mod versions, dependencies and licences: Modrinth API (api.modrinth.com), checked 13 Oct 2026.
