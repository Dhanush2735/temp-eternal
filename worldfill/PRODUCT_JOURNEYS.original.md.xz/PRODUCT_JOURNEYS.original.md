# Product journeys: the life of every product planned for the mod

Written 13 Oct 2026, after the question: "can you do research on every product lifecycle or its journey. products which are plan to add in project?"

Nothing in the mod was changed. This is research only.

- Sources are listed at the end. They are for design only: no source names appear in the game (turn 56 rule).
- "(check)" marks a point that is general knowledge and has not yet been checked against a source.

---

## 0. The products

| # | Product | Planned in |
|---|---|---|
| 1 | Newspaper, and the older forms of news | step 19 |
| 2 | Map, and the older forms of maps | step 19 |
| 3 | Money: coins and paper notes, plus the money-changer | step 19 |
| 4 | Goods you sell to merchants (the mod's 13 trade goods) | step 19 |
| 5 | Weapons | weapons plan |
| 6 | Ammunition: arrows, gunpowder, bullets | weapons plan |
| 7 | Armour and shields | weapons plan (Epic Knights) |
| 8 | Weapon licence | weapons plan |
| 9 | History book (your notes) | step 20 |
| 10 | Tracker compass | step 20 |

Every product has two lives:

- **Life in history:** when it first appears, when it becomes common, and when it fades.
- **Journey of one item:** source → maker → transport → seller → buyer → use → wear → end.

---

## 1. Newspaper

### Life in history

| When | What |
|---|---|
| always | News by word of mouth. Indians traditionally got news "from friends and contacts" [N4] |
| 1580s | Europe: trade-fair news sheets, twice a year [N3] |
| 1605 | Strasbourg: the first newspaper, the *Relation* [N3] |
| Jan 1780 | India's first newspaper, *Hicky's Bengal Gazette* (Calcutta): 4 pages, printed on Saturdays, **Re 1** a copy. The governor stopped the post office from carrying it [N3][N4] |
| 1857–1860 | Hyderabad: the first Urdu journal (medical, *Risala-i-Tababat*, 1857); *Aftab-e-Deccan* (1860) was the first Urdu paper [N5][N6] |
| 1883 | *Khursheed-e-Deccan*, called by some the first true newspaper of Hyderabad [N5] |
| 1926 | *Golconda* (Telugu) [N7] |
| 1927–28 | *Nizam Gazette*, *Subah-e-Deccan*: on the Nizam's side, and published his royal orders (*firmans*) [N5][N6] |
| 1948 | Many new papers in Hyderabad: *Imroz*, *Humdum*, *Aghaaz*, *Iqdaam* … [N6] |
| 1949 | *Siasat* and *Rahnuma-e-Deccan* begin [N6] |
| until the late 1980s | **Urdu newspapers were written by hand** by calligraphers (*katibs*), then printed [N1][N2] |
| today | Papers are still sold in India, and old ones are sold as scrap (*raddi*) [N8] |

### Journey of one paper (Hyderabad, 1948)

1. **News comes in:**
   - reporters in the city;
   - the telegraph and news agencies from far away (check);
   - royal orders, which every paper had to print [N5].
2. **Control:** the government watched critical papers. *Rayyat* was stopped (1928); the editor of *Imroz* was murdered in 1948 and the paper closed [N5]. After 18 Sep 1948, the Indian military governor closed *Rahbar-e-Deccan* because it had backed an independent Hyderabad [N7].
3. **Writing:** Urdu pages were written by hand by *katibs*, then printed. One mistake meant rewriting the whole page. The one surviving handwritten daily takes 2–3 hours per page [N1][N2][N9].
4. **Printing:** overnight or in the morning. Evening papers were also sold.
5. **Transport:** hawkers in the city at dawn, and trains to other towns, so the news is about a day late there (check).
6. **Sale:** hawkers and stands. The price is about 1 anna (an estimate; the preview uses it).
7. **Reading:** one paper is read by many people. It was shared and read aloud at tea shops (check).
8. **End:** kept at home, then sold by weight to the *raddiwala* (scrap dealer) → wholesaler → paper mill → recycled paper [N8].

### What it means for the game

- **A new paper each morning,** made in the city where the press is. A town without a press gets city papers a day late.
- **Paper is not for every place and time:**
  - before 1780 in India (1605 in Europe), news comes as talk, criers or handwritten newsletters (step 19 plan);
  - Urdu papers look handwritten until the late 1980s.
- **What gets printed is controlled:** the ruler's orders are printed, and critics can be closed. This matters for forks: if history changes, different papers survive.
- **Old papers have value:** they can be sold to the *raddiwala* by weight. That is a tiny income, and a reason to keep them.
- **The mod today:** no newspaper item; day-by-day news only in the Hyderabad 12–30 Sep 1948 pack.

---

## 2. Map

### Life in history

| When | What |
|---|---|
| ~600 BC | Map-making in Babylon [M3] |
| Roman times | Road lists: stops and distances (check) |
| 1570 | The first modern atlas (Ortelius, Antwerp): 53 maps engraved on copper plates [M2] |
| 1767 | The Survey of India is set up [M1] |
| 1802–1852 (to 1871) | The Great Trigonometrical Survey, measuring India with a half-tonne theodolite [M1][M4] |
| 1831–1906 | Detailed topographic sheets (1 inch to 1 mile), standard from 1906 [M4] |
| today | Phone maps and GPS (check) |

### Journey of one map

1. **Survey:** chains, theodolite, years of work [M1].
2. **Drawing:** the map-maker draws it.
3. **Engraving:** copper plates, later stone (lithography) [M2].
4. **Printing,** sometimes hand-coloured.
5. **Sale:** booksellers, and the survey's map offices (check).
6. **Use:** travellers, officials, the army.
7. **Ageing:** new roads, railways and towns make it outdated.
8. **End:** kept as a record, or thrown away.

### What it means for the game

- **The map shows the land as it was surveyed,** not as it is today. An old map lacks new roads and railways.
- **Era forms:** road lists (old times) → rough printed maps (from the 1500s) → survey sheets (1800s) → road maps (1900s).
- **A map can go out of date.** The mod already has dated towns and roads to draw from.
- **The mod today:** no map item. Dated towns (cities, ancient places, Chinese county seats) and roads with years exist in the data.

---

## 3. Money (coins, notes) and the money-changer

### Life in history (India, with Hyderabad)

| When | What |
|---|---|
| before ~600 BC | No coins: goods are swapped, or paid in weighed silver (step 19 research) |
| from ~600 BC | Coins appear (step 19 research) |
| Mughal times | Every mint had a *sarraf* who checked the purity of silver and coins [C4] |
| 1918 | Hyderabad paper notes (10 and 100 rupees) under the Hyderabad Currency Act, because silver was short in the First World War [C1] |
| 1919–1926 | 1- and 5-rupee notes, a nickel 1-anna coin, 1,000-rupee notes [C1][C2] |
| later | Notes printed at the Nashik press. A 1-rupee note was printed by Hyderabad's prison press, and the 1,000-rupee note in London [C1][C3] |
| 1950 | The Indian rupee circulates alongside the sicca: **7 Hyderabad rupees = 6 Indian rupees** [C1] |
| 1951 | The Hyderabad rupee stops being issued [C1] |
| 1959 | The Hyderabad rupee is no longer legal money. The date is given as 1 April [C3] and 30 June [C5], so this needs checking |

The notes are dated in the **Fasli year**: add 589 to get the AD year. They are written in Urdu, with the value also in Marathi, Telugu, Kannada and English [C1]. Later coins show the Charminar [C2].

### Journey of one coin or note

1. **Metal is mined** (silver, copper, nickel), or notes are printed at a press.
2. **A mint or press makes it,** and a *sarraf* checks the purity [C4].
3. **The treasury pays it out:** wages, payments to soldiers.
4. **It passes from hand to hand:** markets, shops, rent, taxes.
5. **Money-changers** test coins, catch fakes, swap one coin for another at a rate, and send money far away with *hundi* (bills of exchange) [C4][C6].
6. **Wear:** worn coins and torn notes.
7. **End:** recalled and melted (coins) or destroyed (notes). When a currency ends, as in 1959, people must swap it in time.

### What it means for the game

- **The money-changer (*sarraf*) is a real old job.** He tests coins, swaps money and sends money far away. That fits step 19 exactly.
- **1948 detail:** notes show the Fasli year (1948 is about Fasli 1358, by the +589 rule).
- **Money can end:**
  - after 1950, sicca and Indian rupees both work (7 to 6);
  - after 1959, the sicca is dead, and only the money-changer takes it, at a loss.
- **The mod today:** no player money (only country treasuries).

---

## 4. Goods you sell to merchants (the mod's 13 trade goods)

The mod's trade list: wheat, bread, timber, stone, coal, iron ingot, copper ingot, wool, wine, silk, spices, gold ingot, emerald.

### The general journey

source (farm, forest, quarry, mine) → maker (miller, smith, weaver) → transport (on foot, donkey, caravan, ship, train, truck; all already in the mod with speeds) → market → buyer → used up.

### Each good, with what the Deccan had

| Good | Journey | Deccan / Hyderabad | Game rule |
|---|---|---|---|
| **Grain** (wheat; locally jowar, rice) | sow → harvest → thresh → village market → grain merchant → mill | Monsoon crops (rice, cotton …) are sown in Jun–Jul and harvested Sep–Nov. Winter crops (wheat, gram) are sown Oct–Dec and harvested Feb–May [G1][G2] | Cheapest right after harvest, dearest before it. A famine (already in the mod) makes it scarce |
| **Bread** | flour → baker → shop | At home, flatbread (roti). In the city, bakeries and Irani cafés: the **Osmania biscuit**, named after the Nizam, was a hospital snack in the 1940s and is sold with Irani tea [G3] | City bakeries buy flour and sell bread and biscuits; villages bake at home |
| **Timber** | forest → woodcutter → cart or river → sawmill → builder | teak forests (check) | Needed for building; the price rises when the town grows |
| **Stone** | quarry → mason → building | Deccan granite (check) | |
| **Coal** | mine → railway → engines, factories | **Singareni:** coal found 1871, first mined 23 Dec 1889, its own railway from 1888, majority bought by the Hyderabad State in 1945 [G4][G5] | Coal exists to sell only after 1889 here; the railways need it |
| **Iron and steel** | ore → furnace → smith | **Wootz steel** from South India, made before the Common Era, was carried as ingots to Damascus for the famous swords [G6][G7] | Old Deccan iron is famous; smiths buy iron |
| **Copper** | mine → coppersmith (pots, coins) | (check) | |
| **Wool** | sheep → shearing → spinning → weaving | **Gongadi (kambal):** blankets of black Deccani sheep wool by Kuruma shepherds. Women spin and men weave; a blanket lasts over 10 years and was used by the army [G8][G9] | Shepherds sell wool; weavers sell blankets |
| **Wine** (locally toddy) | palm tree → tapper → depot → licensed shop | Toddy (*kallu*) is tapped by the **Goud** community; there are more than 8,000 licensed toddy shops in Telangana today [G10] | "Wine" in the Deccan is toddy; the licensed shop is the seller |
| **Silk** | silkworm → reeling → weaving | Telangana ikat weaving; Pochampally became a centre in the 1950s [G11] | Silk cloth is a town product, sold by cloth merchants |
| **Spices** | farm → dry → market → trader | turmeric and chillies (check) | Seasonal, like grain |
| **Gold** | mine → refine → goldsmith | **Hutti** (then in Hyderabad State): mined about 1,900 years ago; the Nizam's company took 7.41 t of gold in 1902–1918; closed 1920, reopened 1947–48 [G12][G13] | Gold comes from Hutti in some years and not others |
| **Gems** (the mod has emerald) | mine → sorting → gem market | **Golconda diamonds** (see below) | In the Deccan, the gem is the diamond |

**Golconda diamonds:**
- Until the early 1700s, the Golconda area was the world's main diamond source [G14][G15].
- The **Kollur mine** opened around 1619. In 1621 it had 20,000–30,000 workers, later up to 60,000 [G16].
- The king owned the mines and leased them to merchants. He took rent, 2% of sales, and every stone over 10 carats [G16].
- Miners were often paid in **food instead of money** [G16].
- The Koh-i-Noor and the stone later cut as the Hope diamond came from Kollur [G15][G16].

### What it means for the game

- **Local goods with local names:** jowar and rice, toddy, gongadi blankets, diamonds in Golconda's time, coal after 1889, Hutti gold.
- **Seasons move grain prices.** The harvest months above are a simple rule.
- **Supply can be cut:** war, blockade, famine or a closed mine means scarce goods and high prices.
- **The mod today:**
  - 13 goods with fixed prices;
  - caravans and ships carry cargo;
  - crops by region (rice, wheat and barley) and famine.
  - The full supply chain belongs to the trade review (group 6).

---

## 5. Weapons (details in `WEAPONS_RESEARCH.md`)

### Journey of one sword or gun

1. **Ore → furnace → steel.** South Indian wootz was famous [G6][G7].
2. **Smith:** blade, hilt, sheath. Guns need a gunsmith.
3. **Seller or arsenal:** market smiths, or the state's stores. A Maratha *bargir* was armed from the state's stock [W1].
4. **Use:** training, war, guard duty.
5. **Care:** sharpening, cleaning, repair (check).
6. **Changes hands:** inherited, sold, captured, or taken by law (Japan 1588; licences in India from 1878) [W2][W3].
7. **End:** broken, melted down (Japan melted the confiscated swords for a temple [W2]), or kept as a family or museum piece.

### What it means for the game

- Weapons wear out and need repair, so smiths have steady work.
- Captured weapons change hands after fights.
- A ban takes weapons away, and a confiscation can melt them.

---

## 6. Ammunition

| Kind | Journey | Note |
|---|---|---|
| Arrows | wood + feathers + iron or bronze heads → fletcher (check) | always, until guns take over |
| Gunpowder | **saltpetre** + sulphur + charcoal → powder works | Bihar was the main saltpetre source in 1600–1850, with Patna the centre of its export. It was sold mostly to the Dutch and English companies; Mughal-era Indian buyers had little use for it [A1][A2] |
| Bullets, cartridges | lead + powder + paper (later brass) → arsenal | (check) |

**For the game:** gunpowder depends on saltpetre. If the supply is cut by war or blockade, guns become useless, as Hyderabad found in 1948 when it could not get arms or ammunition for 11 months (`WEAPONS_RESEARCH.md`).

---

## 7. Armour and shields

**Journey:** metal or leather → armourer → soldier → repair → passed on.

Armour fades once guns are common (check). In the game, Epic Knights armour should follow the same year rules as weapons.

---

## 8. Weapon licence (India, from 1878)

1. **Apply** to the district official.
2. **The police check you.**
3. **The licence is issued** for one kind of weapon.
4. **Renew** it every 3 years.
5. **It can be refused or taken away.** Europeans were exempt under the 1878 Act [W3].

Later the 1959 Arms Act replaced it (check).

**For the game:** a paper item with a holder's name, a weapon type and an end date. Guards check it. Without it you go to the black market.

---

## 9. History book (your notes)

| When / where | What people wrote on |
|---|---|
| South India, for centuries | **palm leaves** [P1][P2] |
| North India | **birch bark** [P2] |
| 1089 | The earliest Sanskrit paper manuscript (Kashmir) [P2] |
| 1180–1224 | Paper manuscripts in Gujarat [P2] |
| 1289 | Paper-making in Delhi is mentioned [P2] |
| 13th century on | Paper slowly replaces palm leaf and bark [P2][P3] |

**Journey:** material (leaf, bark, paper) → bound or tied → written → kept → worn → copied or lost.

**For the game:** the history book could look different by era: palm-leaf bundle, bark, or paper book. It is optional decoration. Its contents stay the same.

---

## 10. Tracker compass

| When | What |
|---|---|
| Han China, 1st–2nd century AD | A spoon of lodestone (natural magnet), used for fortune-telling [K1] |
| about 1040–1117 | Chinese sailors use a needle compass at night or in fog [K1][K2] |
| about 1190 | The first European description [K1][K2] |
| 1232 | The first mention in the Muslim world [K2] |

**Journey:** lodestone → needle rubbed on it → floated in water or set on a pin → box → sailor or traveller.

**For the game:**
- before compasses, the "tracker" is a person who points the way (the villager points, already planned) or the sun and stars;
- an ordinary compass comes after those dates;
- the "tracker compass" that points to a person is a game helper, so it could be explained as a guide's directions in old times.

---

## 11. The pattern, and what to build when

Every product follows the same chain:

**source → maker → transport → seller → buyer → use → wear → end (or recycle)**

The mod already has some links in that chain:

| Link | Already in the mod |
|---|---|
| Transport | Seven transport kinds with speeds: on foot 10 km a day, donkey 20, caravan 30, ship 120, truck 350, train 500, air 2,500. Caravans and ships carry cargo |
| Source | Crops by region and famine; ways of life; dated towns and roads |
| Seller and buyer | Classes (rich, poor); villagers with jobs (planned) |
| Disruption | Wars, events, famine |

### My advice: keep step 19 small

**Step 19 builds only the parts the player touches:**
- sellers and makers in town (paper seller, money-changer, merchant, smith);
- a new paper each morning;
- old papers sold as scrap;
- grain prices that follow the harvest months;
- old money swapped at the money-changer.

**Later, the trade review (group 6)** builds the full hidden chain: mines and farms feeding the shops, caravans and trains moving goods, blockades and wars cutting supply.

---

## Sources

Newspaper:
- [N1] Wikipedia, "Urdu alphabet": https://en.wikipedia.org/wiki/Urdu_alphabet
- [N2] Wikipedia, "Urdu": https://en.wikipedia.org/wiki/Urdu
- [N3] Wikipedia, "History of newspaper publishing": https://en.wikipedia.org/wiki/History_of_newspaper_publishing
- [N4] Indian Express, "India's first newspaper": https://indianexpress.com/article/explained/explained-history/world-press-freedom-day-india-first-newspaper-9306034/
- [N5] Anveshi, "Urdu press in the princely state of Hyderabad": https://www.anveshi.org.in/broadsheet-on-contemporary-politics/archives/broadsheet-on-contemporary-politics-vol-2-no-1011/urdu-press-in-the-princely-state-of-hyderabad/
- [N6] Gawah, "Hyderabad and Urdu Journalism": https://gawahweekly.com/hyderabad-and-urdu-journalism/
- [N7] "The origin of the Urdu press in Telangana" (PDF): https://ouinterface.wordpress.com/wp-content/uploads/2016/07/venkateshwarlu.pdf ; Media in Hyderabad: https://grokipedia.com/page/Media_in_Hyderabad
- [N8] Raddiwala recycling: https://www.scrapregister.com/news/168/recycling-in-india-a-revenue-generating-business-model ; https://medium.com/devika-kher/what-connects-the-raddiwalas-to-the-newspaper-publishing-houses-72319db507a0
- [N9] Wikipedia, "The Musalman": https://en.wikipedia.org/wiki/The_Musalman

Maps:
- [M1] Wikipedia, "Survey of India": https://en.wikipedia.org/wiki/Survey_of_India
- [M2] Wikipedia, "Abraham Ortelius": https://en.wikipedia.org/wiki/Abraham_Ortelius
- [M3] NOAA, "Maps Through History": https://sos.noaa.gov/catalog/datasets/maps-through-history/
- [M4] Cambridge Digital Library, Survey of India maps: https://cudl.lib.cam.ac.uk/collections/surveyofindiamaps

Money:
- [C1] Wikipedia, "Hyderabadi rupee": https://en.wikipedia.org/wiki/Hyderabadi_rupee
- [C2] Coinage under Mir Osman Ali Khan (PDF): https://oldror.lbp.world/UploadedData/14701.pdf
- [C3] State Bank of Pakistan museum, Hyderabad State notes: https://www.sbp.org.pk/museum/crncyHydrbd.htm
- [C4] "Seths, Shroffs and the Hundi System": https://adichshahane.substack.com/p/seths-shroffs-and-the-hundi-system
- [C5] Wikidata, Hyderabadi rupee: https://www.wikidata.org/wiki/Q1139143
- [C6] "Shroff" word history: https://www.etymology.life/word/shroff

Goods:
- [G1] Kharif and rabi seasons: https://elysiumagrico.com/blog/kharif-vs-rabi-crops/
- [G2] Kharif and rabi crops: https://vajiramandravi.com/upsc-exam/kharif-and-rabi-crops/
- [G3] Times of India, Osmania biscuits: https://timesofindia.indiatimes.com/life-style/spotlight/unwrapping-the-legacy-of-osmania-biscuits/articleshow/110537339.cms
- [G4] Singareni Collieries: https://en.bharatpedia.org/wiki/Singareni_Collieries_Company
- [G5] Hans India, history of Singareni: https://www.thehansindia.com/posts/index/Telangana/2015-12-23/A-peek-into-history-of-Singareni-Collieries/195017
- [G6] Wootz steel (Illinois): http://dtrinkle.matse.illinois.edu/MatSE584/articles/wootz_advanced_material/wootz_steel.html
- [G7] Srinivasan and Ranganathan, wootz steel: https://docslib.org/doc/297267/the-significance-of-wootz-steel-to-the-history-of-materials-science-sharada-srinivasan-and-s-ranganathan
- [G8] "Unweaving the Gongadi": https://rranetwork.wordpress.com/2018/12/01/unweaving-the-gongadi/
- [G9] Hans India, Gongadi: https://www.thehansindia.com/posts/index/hans/2014-11-29/telanganas-own-gongadi-exhibition-is-back/118673
- [G10] Times of India, toddy in Telangana: https://timesofindia.indiatimes.com/city/hyderabad/Telanganas-green-drive-promises-more-toddy-down-the-line/articleshow/53166878.cms
- [G11] Pochampally ikat: https://rooftopapp.com/blogs/textiles-from-south-india-pochampally-ikat-from-te
- [G12] Hutti gold mines: https://entri.app/blog/hutti-gold-mines-history-facts/
- [G13] Moneycontrol, Hutti: https://www.moneycontrol.com/news/india/gold-hunt-karnataka-s-hutti-mines-eyes-four-sites-for-mining-feasibility-study-soon-12893729.html
- [G14] Golconda diamonds: https://skyjems.ca/pages/encyclopedia-golconda
- [G15] "The Fabled Diamonds of Golconda": https://www.amusingplanet.com/2021/08/the-fabled-diamonds-of-golconda.html
- [G16] Wikipedia, "Kollur Mine": https://en.wikipedia.org/wiki/Kollur_Mine

Weapons and ammunition:
- [W1] Wikipedia, "Maratha Army": https://en.wikipedia.org/wiki/Maratha_Army
- [W2] Wikipedia, "Toyotomi Hideyoshi": https://en.wikipedia.org/wiki/Toyotomi_Hideyoshi
- [W3] Indian Arms Act 1878: https://www.iasgyan.in/daily-current-affairs/indian-arms-act
- [A1] Indian Express, Patna and the saltpetre trade: https://indianexpress.com/article/research/patna-collectorate-bihar-history-dutch-trade-6883841/
- [A2] "The Nitrate That Shaped the World": https://queensu.scholaris.ca/items/1bced4d8-4dc5-4409-966a-22fb5e353e97

Book and compass:
- [P1] History of paper technology in India: https://www.infinityfoundation.com/mandala/t_es/t_es_tiwar_paper.htm
- [P2] Wikipedia, "History of paper": https://en.wikipedia.org/wiki/History_of_paper
- [P3] Delhi Sultanate manuscripts: https://banotes.org/india-c-1206-1707/delhi-sultanate-artistic-expressions-murals-manuscripts/
- [K1] Origins of the compass: https://blog.historiqly.com/blog/origins-compass
- [K2] "The Origins of the Compass": https://historyrise.com/the-origins-of-the-compass-navigational-breakthroughs-from-china/
