> **Storage note (2026-10-29):** The historical `*java_after.tar.gz` snapshot files mentioned below are consolidated into `legacy_java_snapshots.tar.xz` and `legacy_java_snapshots.manifest.json`. Restore with `python r2_wikipedia/archive_java_snapshots.py restore` from the workspace root. Each original gzip checksum is checked; restore requires compatible GNU gzip and sufficient workspace. The active source and game files were not replaced.

# World fill: recorded history first, then believable estimated life

This folder builds the history packs that keep the mod's map from being empty between events. It
follows the plan agreed on 2026-10-11:

1. **Step 1: Wikipedia offline.** Done; see `harvest/FIXES.md`. Fixed harvester, 19,368 events
 installed (after step 3's duplicates were left out).
2. **Step 2: long-lasting places as dated sites.** Done.
3. **Step 3: wars, treaties, the missing battles and sieges, and borders.** Done.
4. **Step 4: population-based estimated presence.** Done.

Raw downloads go to `~/.cache/srcdata` (main disk, never snapshotted). The JDK goes to
`~/.cache/jdk17`. `/tmp` is a RAM disk here and is wiped on restart.

## Step 2: what was added

`python3 fetch.py places && python3 build_places.py` writes three packs (gzipped) into the mod and
lists them in `history/index.json`.

| Pack | Source (licence) | Sites | Years | Rank |
|---|---|---:|---|---|
| `places_pleiades.json.gz` | Pleiades gazetteer (CC BY 3.0) | 18,677 | attested range, 5000 BC…AD 640 | 1,428 city, 10,937 town, 6,312 village |
| `places_chgis.json.gz` | CHGIS V6 county seats (CC0) | 10,446 | 763 BC…1911, open to the present if still standing in 1911 | town |
| `places_reba.json.gz` | Reba et al. 2016 urban population (CC BY 4.0) | 1,787 records (1,433 cities) | first recorded population … next survey year after the last | city |

**What was left out:**
- **Pleiades** (42,493 places): 21,141 that are not places people live, such as rivers, mountains,
 roads and tombs; 1,270 without a location; 684 undated; 514 known only after AD 640; 1 known only
 before 5000 BC.
- **CHGIS** prefecture points: they have their own EULA, so they were not used.

**Rules:**
- **Curated sites win.** Any of the 227 dated sites in the region packs takes priority: a new place
 within 10 km loses exactly the years the curated site covers. This dropped 251 Pleiades places,
 51 CHGIS seats and 104 Reba cities, and trimmed others.
- **Ancient names in antiquity.** A Reba city that Pleiades also names (within 5 km) starts after
 AD 640, so the ancient name shows in antiquity and the modern name afterwards.
- **civHint is always an authored civilization**, so a site claims a polity only in years that
 polity existed; in other years the presence code falls through to the next layer.
 - China uses the dynasty of the record's years.
 - Everywhere else, `Civs.pick` weighs how much of the place's life the civ existed, whether its
 name maps to a real name pool, and how close its capital is.
 - It is a heuristic. Known misses: Antioch and Alexandria get *nabataea*, and Rome after 1500
 gets *naples*. Step 3 can replace it with Cliopatria's polity for each place and year.
- **`"estimatorAnchor": false`.** The settlement-year estimator does not pull undated places toward
 these sites. Without this flag, 14,900 of the 14,902 estimated founding years of present-day
 Telangana places moved, by a median of about 500 years earlier. With it they are byte-identical to
 before.

## What it changes in the game

Measured with the mod's own `HistoryGazetteer` (`probe.sh`; full output in `probe_results.md`) on
the same 400 random land points as `DensityProbe`. "Someone here" means a site, an estimated
countryside village, or an empire box:

| Year | before | after |
|---|---:|---:|
| 2500 BC | 1.0% | 3.0% |
| 1500 BC | 0.8% | 4.0% |
| 500 BC | 1.3% | 6.3% |
| AD 1 | 3.3% | 12.0% |
| 500 | 1.8% | 14.3% |
| 1000 | 0.3% | 5.3% |
| 1300 | 0.8% | 7.0% |
| 1500 | 1.8% | 5.8% |
| 1700 | 2.8% | 10.0% |
| 1850 | 2.5% | 11.3% |
| 1900 | 1.3% | 10.3% |
| 1944 | 1.3% | 8.3% |
| 2000 | 5.3% | 13.0% |

Most of the gain comes from the estimated hinterland: unnamed countryside villages within 80 km of
a dated town or city, which the mod already labels as estimated. Some examples:
- Trier in 300 gives a Pleiades town.
- Rural Sichuan in 1500 gives a Ming county seat.
- A Nile delta village in 1500 BC gives an estimated countryside village of Tell el-Moqdam.
- The middle of the Sahara, Siberia and the Ohio valley in 1200 still give nobody.

## Java changes (both files are in the gazetteer harness)

`HistoryGazetteer.java` and `SettlementYearEstimator.java` were changed. The harness used by
`harvest/verify.sh` and `probe.sh` compiles both together with the real load path. The full mod was
not compiled: the ForgeGradle setup needs more than this sandbox's 2 GB of RAM.

- **Latitude skip.** `beyondByLatitude()` skips any site or event whose latitude alone puts it out of
 range, before computing the haversine distance. This is exact: a great-circle distance is never
 shorter than R × |Δlat|. It applies in `nearestOccupied`, `estimatedHinterland`, `nearestEvent`,
 `eventsNear` and the estimator.
- **Latitude-banded anchors.** The settlement-year estimator receives only the anchors in its latitude
 band, in their original order.
- **The `estimatorAnchor` flag**, read per pack.

**Effect, checked by running before and after on the same data:**
- Load time with 46,864 sites dropped from 106.5 s to about 1–2 s; it was 2.2 s with the old 15,954
 sites.
- A presence query takes about 0.5 ms instead of up to 8.8 ms.
- Every estimated year is identical, and so is every presence answer.

## Step 3a: the Wikidata events the mod did not have

`python3 build_wikidata.py` → `events_wikidata_more.json.gz` (6,040 events). WDQS answers are cached in
`~/.cache/wd_cache`.

| Kind | New in the survey | Installed | How it is placed |
|---|---:|---:|---|
| battle | 4,431 | 3,725 | 11 by own coordinates, 3,714 by a specific P276 location |
| siege | 874 | 845 | 1 own, 844 by location |
| treaty | 1,186 | 907 | 66 own, 841 by the place of signing |
| war | 1,130 | 563 theatres (533 wars) | one pin per cluster of the war's own located battles |

- **Placement.** A P276 location is used only if it is a specific place. Countries, states, provinces,
 regions, seas, archipelagos, rivers, and anything over 20,000 km² are never used. This rejected
 670 battle locations.
- **Left out:**
 - battles: 645 that could not be placed and 61 without an English label;
 - wars: 594 with no located battles. Nobody guesses a theatre from a country's centre.
- **War theatres.** Each theatre is a cluster of battles within 800 km of each other:
 - centre: the battles' mean;
 - radius: farthest battle + 25 km, between 60 and 300 km;
 - years: those of its own battles, inside the war's years.

 Example: the Hundred Years' War, 1337–1454, has 88 battles in one theatre around northern France.
 The Seven Years' War has 6 theatres.
- **Wikipedia duplicates.** After this pack went in, the Wikipedia pack was re-installed: 455 bullets
 that were the same events were left out. War theatres are never used for that matching.

## Step 3b: rulers for the whole world (Cliopatria)

`python3 build_rulers.py` (38 s) → `world_rulers.json.gz` (0.4 MB).

**How it is built.**
- Every plain polity polygon in Cliopatria v0.2.1 (12,064 rows; parenthesised alliances, allegiances
 and composite empires left out) is rasterised onto 0.5-degree cell centres.
- For each cell and year, the smallest polity wins. That is the Deccan record's rule ("a sultanate
 beats the empire it sat inside").
- 290 polity rows too small to cover any cell centre get the cell holding their centroid, so no polity
 disappears.

**What it holds.** 62,647 places, 8,451 timelines, 185,770 spans and 1,544 polities.

**Checked against the Deccan register** (same source and rule; it uses village points instead of cell
centres): the same ruler in 97.1% of sampled place-years (every 25 years, 3000 BC–2024). The rest are
borders crossing a 55 km cell.

**Java changes:**
- `RulerRegister` reads `deccan_rulers.json` and `world_rulers.json.gz` into one index. The nearest
 place wins, and world place ids start with `cell_`.
- Each polity's extent (years and centre) feeds `CivSynthesis`. Only the 30 Deccan polities are
 synthesised, as before: every synthesised civilization becomes a region that the population,
 economy and migration engines iterate.

## Step 4: estimated people (HYDE 3.2.1)

`pip install zipfile-deflate64; python3 hyde_grid.py; python3 build_hyde_resource.py`
→ `population/hyde_density.bin.gz` (0.9 MB).

**The data.** HYDE's population grids (5 arc-minutes) for 28 slices, 3000 BC to AD 2017. They are read
straight out of the 5.3 GB DANS zip with HTTP range requests (`remotezip.py`), about 200 MB transferred,
then summed into 0.5-degree cells and stored as 8-bit log densities (median error 1.4%). World totals
are reproduced within 0.1%: 44 million in 3000 BC, 232 million in AD 1, 503 million in 1500, 7.4 billion
in 2017.

**Java changes:**
- **New `HydeGrid`.** Density is interpolated log-linearly between slices.
 - At 2 or more people per km², every spot has people.
 - Below that, a fixed share of 0.05-degree tiles does (density ÷ 2), chosen by a hash of the tile, so
 the same spots have people on every machine.
 - Below 0.01 per km², nobody.
- **`HistoricalPresence`:**
 - "Estimated people" is the last presence layer, and a world-record ruler counts as presence only
 where the model has people. Deccan rulers count as before.
 - `/ee who` prints `estimated people: ~17 people/km2 (HYDE …)` or, under a ruler, "no one on this
 spot this year by the population model".
- **`PopulationResolver` T4 GRIDDED.** The documented, unwired hook is now wired. A village with no
 curated figure gets people per km² × 10 km², tried after the district apportionment, so Telangana
 figures are unchanged. Towns and cities keep the era band.
- **`VillagerNameDatabase.cultureFor`** knows the common Cliopatria polity names, so NPCs under a world
 ruler get regional names. The share of world cell-years that fall back to generic names drops from
 56% to 8%. Two existing misroutes were fixed: Songhai and Ghana drew East Asian names ("song", "han").

## Every Java change in one place

`java_changes.patch` is a unified diff of every Java change in steps 2–4, against the files as they
were before this plan:
- `HistoryGazetteer`, `SettlementYearEstimator`, `RulerRegister`, `HistoricalPresence`, `CivSynthesis`;
- `PopulationResolver`, `VillagerNameDatabase`;
- the new `HydeGrid`.

These files are untracked in the mod's git, so git cannot show the changes. To undo them all, run
`patch -R -p1 < ../worldfill/java_changes.patch` inside `eternal/`. Then remove `world_rulers.json.gz`
and the `*.json.gz` packs from `history/index.json`, because the old code cannot read `.gz` packs.

## The result

Measured on the same 400 land points (full output: `probe_results_world.md`). "Before" is today's
packs before this plan's steps (the gazetteer layers with the old packs); "after" is the mod's real
`HistoricalPresence` answer with everything above:

| Year | before (gazetteer only) | after steps 2–4 | of which: estimated people / world ruler with people |
|---|---:|---:|---:|
| 2500 BC | 1.0% | 14.5% | 11.5% / 0.0% |
| 500 BC | 1.3% | 23.0% | 15.5% / 1.3% |
| AD 1 | 3.3% | 24.5% | 9.8% / 2.8% |
| 1000 | 0.3% | 25.3% | 9.8% / 10.3% |
| 1500 | 1.8% | 30.0% | 10.8% / 13.5% |
| 1900 | 1.3% | 36.5% | 1.0% / 25.3% |
| 2000 | 5.3% | 44.0% | 0.8% / 30.3% |

The rest of the land points are places where the model says nobody lived: deserts, ice, high mountains
and deep forest, or spots on thinly settled land that fall outside the inhabited share.

**Examples** (`/ee who`-style output in `probe_results_world.md`):
- Mid-Sahara in 1000: nobody.
- Upper Egypt in 1500 BC: a Pleiades city, ruler New Kingdom of Egypt, about 10 people/km².
- Rural Poland in 1600: ruler Polish-Lithuanian Commonwealth, about 17 people/km², a village of about 170.
- Siberia in 1900: ruled by the Russian Empire, but nobody lives there.

**Checks:**
- The whole mod compiles (`tools/gradle_compile.sh`, guarded so the 2 GB sandbox cannot freeze).
- The gazetteer harness (`harvest/verify.sh`, `probe.sh`) gives unchanged answers.
- Telangana's 14,902 estimated years are unchanged.
- One presence query takes 0.5–0.9 ms. The first query loads everything in about 2 s.

**Limits:**
- HYDE is a model: it spreads each country's estimated population over suitable land. It is not a
 record of who lived where.
- Cliopatria's borders are drawn at a few points in time, and are coarse at 0.5°.
- Stateless people get civ `neutral` (generic names).
- Nothing here was run inside Minecraft. Watch the first in-game session: NPC counts, `/ee who` text,
 and log size from CivSynthesis.

## Step 5: the categories under 50% (Wikipedia primary, other sources secondary)

**Offline Wikipedia (`wpdump.py`).** The Wikimedia APIs allow about 10 requests a minute
without contact details. So this step reads the public dump files instead:
- the 2026-10-01 multistream index, redirects, geo_tags and page_props;
- a local SQLite database, `~/.cache/wpdump/wp.sqlite` (2.3 GB, built in 11 minutes, not
 snapshotted): 19.3 M titles, 12.5 M redirects, 1.26 M article coordinates, 10.5 M Wikidata
 ids and short descriptions;
- page text fetched from the 27 GB dump by HTTP range requests, one ~100-page block at a time.

Rebuild everything with:
```
python3 wpdump.py build
python3 build_regional.py
python3 build_hazards.py
python3 build_wars.py
python3 coverage_recount.py
bash probe_events.sh
```

| Pack | Events | What |
|---|---:|---|
| `events_wikipedia_regional.json.gz` | 21,910 | Year-page lines the v2 harvest skipped (8,748 local, 13,162 regional news) |
| `events_hazards.json.gz` | 26,998 | Earthquakes 11,815; eruptions 6,849; plague 5,090; tsunamis 2,111; famines 398; pandemics 339; floods 267; epidemics 129 |
| `events_wars.json.gz` | 2,397 | Wars from the "List of wars" pages (regional news) |

**How lines are placed (`build_regional.py`).**
- Every link is tried, most specific first: a city or site (Wikipedia's own article
 coordinates), a district, a region, then a state or country.
- A state's place is its Cliopatria extent that year, with its centre weighted by HYDE people.
- A modern country named in an old event becomes the state that ruled its populated centre
 then, using the mod's 60 km register rule. Ancient Egypt lines land on the Early Dynastic
 Period or the Old Kingdom, not on modern Egypt.
- A second pass finds region and state names in unlinked text. The names are learned from the
 pages' own links, choosing the meaning used within 300 years ("Roman" means the Republic
 before 27 BC and the Empire after).
- Cliopatria gives the Republic of China and the People's Republic the same Wikidata id
 (Q148); the larger state is taken.

**Hazards (`build_hazards.py`).**
- A generic wikitable reader handles rowspans and stacked headers.
- One-off events (earthquakes, tsunamis, eruptions) use their article's coordinates first.
- Epidemics, famines and floods get one event per named place, up to 5.
- Secondary sources are added only where no Wikipedia row of the same kind is close. That means
 within 150 km and one year, or for plague within 30 km and the same year. A country-wide
 Wikipedia quake row takes NOAA's or the Smithsonian's exact spot.

**Wars (`build_wars.py`).**
- A war is placed by the war article's infobox location (1,886 wars), else by the defeated or
 victorious side's state that year (1,058).
- War articles' infoboxes are cached in `~/.cache/wpdump/war_infoboxes.jsonl.gz`.

**Java (`java_changes_step5.patch`; reverse with `patch -R -p1` in `eternal/`).**
- `HistoryGazetteer` gains `REGIONAL_CONFIDENCE`, `isRegional`, `nearestLocalEvent`, and a
 `nearestEvent` that prefers local pins.
- `PlayerActionDetector` uses `nearestLocalEvent` for interventions.
- `EventNews` words regional pins as news from afar.
- `HistoricalPresence.describe` marks them.
- The whole mod compiles (`BUILD SUCCESSFUL`). This sandbox's first ForgeGradle setup needed
 `TOOL_XMX=300m DAEMON_XMX=440m METASPACE=280m bash tools/gradle_compile.sh`.

**Result.** All measured events went from 26% to about 83%; per category, see
`survey/COVERAGE.md`. Still at 0%: famous people, king and queen names, ways of life, trade
routes, languages, religions.

## Step 6: the 0% categories, from data already in the workspace (2026-10-11)

The user's plan: "implement the existing data in the workspace into the project and delete them".
No new downloads. Every builder writes into the mod and re-reads what it wrote.

| Script | Reads (all already on disk) | Writes | Result |
|---|---|---|---|
| `build_ucdp.py` | UCDP GED 25.1 csv zip | `events_ucdp.json.gz` (in `index.json`) | 28,639 local conflict spots 1989–2024, 92% of recorded deaths; kind `conflict` (never stoppable) |
| `build_people.py` | cached year pages (Births, Deaths) | `famous_people.json.gz`, plus a people cache for the next script | 72,594 people placed in 849 states |
| `build_polity_facts.py` (uses `wikitext_clean.py`) | cached state infoboxes; installed accession lines; people cache | `polity_facts.json.gz` | 1,185 states: languages 997, religions 911, capitals 1,043, named rulers 913 (4,824 reigns) |
| `build_decades.py` | wiki_test decade/century pages | `events_wikipedia_decades.json.gz` (in `index.json`) | 1,763 new events |
| `cleanup_step6.py` | – | `CLEANUP_STEP6.md` | raw copies deleted; snapshot 111.9 → 77.9 MB; hidden cache 4.6 → 1.1 GB |

Java (`java_changes_step6.patch`, 651 lines added and 5 changed; reverse with `patch -R -p1` in `eternal/`):
- new: `LeaderRegister` and `FamousPeople`;
- `RulerRegister.Hit.wikidata()`;
- `HistoryGazetteer` per-year event index (same answers, about 240× faster);
- `HistoricalPresence.describe` adds rulers, state facts, famous people and the estimated way of life;
- `EventNews` adds the talk lines;
- `CurrentAffairsEngine` adds them as briefing facts;
- `PresenceLocalSpawner` gives town talk, 1 in 20 per cycle per town NPC.

Checks:
- `BUILD SUCCESSFUL` (`tools/gradle_compile.sh` with `TOOL_XMX=300m DAEMON_XMX=440m METASPACE=280m`).
- `probe_events.sh`: 122,432 events, 0 rule violations, 0.00 ms per query.
- `probe_index.sh`: identical answers before and after the index.
- `probe_talk.sh`: what `/ee who` and villagers say at the test spots.

Not done:
- Trade routes: no data on disk.
- The builders cannot be re-run without downloading their sources again, because the raw copies are gone.

## Step 7: fetching the 0% categories from new sources (2026-10-11)

| Script | Downloads (to `~/.cache`) | Writes | Result |
|---|---|---|---|
| `wpdump.py build` | Wikipedia dump index files, about 1 GB | `~/.cache/wpdump/wp.sqlite` | the offline Wikipedia copy, rebuilt in 649 s |
| `build_ways_of_life.py` | ArchaeoGLOBE consensus table and region map (CC0) | `ways_of_life.json.gz` | 146 regions × 10 dates |
| `build_notable_people.py` | Sciences Po notable people, 262 MB (CC BY-SA) | merges into `famous_people.json.gz` | 183,754 people, 148,586 with exact birthplaces |
| `build_local_languages.py` | Glottolog 5.3 points (CC BY 4.0); SIL ISO 639-3 table | `local_languages.json.gz` | 6,709 living languages |
| `build_religion_shares.py` | CoW World Religion Data (citation) | adds `relY` to `polity_facts.json.gz` | 219 states, 1945–2010 |
| `build_state_leaders.py` | 62 Wikipedia "List of state leaders" pages | reigns into `polity_facts.json.gz` | 15,324 reigns; ruled land with a named ruler 58–99% depending on period |
| `build_trade_routes.py` + `build_wiki_routes.py` | Itiner-e roads, 78 MB (CC BY 4.0); 10 Wikipedia route articles | `trade_routes.json.gz` | 14,769 road sections; 10 routes, 364 towns |

Java (`java_changes_step7.patch`, 874 lines added and 26 changed; reverse with `patch -R -p1`):
- new: `WaysOfLife`, `LocalLanguages` and `TradeRoutes`;
- `LeaderRegister` faith shares;
- `FamousPeople.bornNear`;
- `EventNews`: culture, famous, trade, road and way-of-life lines;
- `/ee who` lines;
- two briefing facts.

Checks:
- `BUILD SUCCESSFUL`.
- `probe_events.sh`: 0 violations.
- `probe_talk.sh`: lines at 12 test spots.

## Step 8: filling the gaps a player would notice (2026-10-12)

| Script | Downloads (to `~/.cache`) | Writes | Result |
|---|---|---|---|
| `fix_state_ids.py` | nothing (offline Wikipedia copy) | `world_rulers.json.gz`, `polity_facts.json.gz`, `famous_people.json.gz` | 92 map states had another thing's Wikidata id (Han China had the Chauhan dynasty's, South Korea shared North Korea's, Rome the Byzantine Empire's). Fixed by hand-checked article titles; 829 reigns moved by date; 77 new state entries with their own infobox languages, religions and capital; 30,574 famous people re-tagged |
| `fill_rulers.py lists` | nothing (cached state-leader pages) | `polity_facts.json.gz` | the century "List of state leaders" pages again, only for the repaired states; states that shared an id in the same years split by name |
| `fill_rulers.py targeted` (+ `ruler_lists.py`) | ~160 Wikipedia ruler-list pages from the dump (cache `~/.cache/wpdump/ruler_list_pages.json.gz`) | `polity_facts.json.gz` | 100 lists used as the authority, 17 only for empty years, 20 without a list. Pharaohs, Babylon, Assyria, Hittites, Roman consuls (one row a year: "C. Julius Caesar and M. Calpurnius Bibulus"), Roman and Byzantine emperors, Chinese monarchs by dynasty, Zhou states, Indian dynasties (Satavahana, Gupta, Pala, Kakatiya, Golconda, Mughal, Nizams …), Korea, Japan, Vietnam, Burma, Sri Lanka, caliphs, Iran, Europe's monarchies |
| `fill_rulers.py colonies` | same cache | `polity_facts.json.gz` | 27 colonies get their home country's heads of state (British, Spanish, Portuguese, French, Dutch, Danish, German, Italian, Belgian); 3 dominions (Pakistan, India, Ceylon) get the British monarch for their dominion years; French Indochina gets its governors-general |
| `tidy_state_facts.py` | - | `polity_facts.json.gz` | language and faith items cleaned ("initially Latin" → "Latin") |
| `build_religion_shares.py` (again) | CoW tables | `polity_facts.json.gz` | faith shares now per country for states that shared an id (the two Koreas) |
| `add_estimated_routes.py` | 4 Wikipedia route articles | `trade_routes.json.gz` | Dakshinapatha, Uttarapatha, Amber Road, Indian Ocean trade; years ESTIMATED from each article's history (marked "estimated:"); places that only carry the name today dropped |
| `fill_famous_gaps.py` | one QLever export of Wikidata people with an English Wikipedia article and a birthplace, 31 MB (CC0) | `famous_people.json.gz` | 439 people for lands that had nobody famous in a period; 3,582 of the 4,152 gaps have nobody in Wikidata either |
| `gap_rank.py`, `coverage_people.py` | - | `ruler_gaps_*.json`, `coverage_people.json` | the measures |

Why QLever: the step-7 source (Sciences Po) now sits behind an anti-bot proof-of-work page, which this
build does not get around. The Wikidata Query Service allowed one query a minute (an outage rule), so
the per-gap queries were stopped; QLever answered the whole question in one 12-second export.

Java (`java_changes_step8.patch`, 1 file; reverse with `patch -R -p1`):
- `RulerRegister.rulerAt`: when the nearest grid place has no ruler that year, the nearest place that
 has one wins if it is at most `NEIGHBOUR_KM` (20 km) farther. Rome lies exactly between a Roman cell
 and an empty coastal one, and the tie went to the empty one, so `/ee villager who` in Rome said nothing
 for all of antiquity. The Python twin in `build_polity_facts.Register` follows the same rule.

Result (share of all the world's people whose ruler is named; HYDE grid, `coverage_people.json`):

| Year | 1500 BC | 500 BC | AD 1 | 500 | 1000 | 1500 | 1700 | 1850 | 1900 | 2000 |
|---|---|---|---|---|---|---|---|---|---|---|
| before | 3% | 14% | 24% | 37% | 53% | 59% | 78% | 64% | 81% | 93% |
| after | 4.6% | 18% | 51% | 59% | 57% | 62% | 81% | 86% | 95% | 95% |

Checks:
- `BUILD SUCCESSFUL` (compileJava).
- `probe_step8.sh`: 39 spots, for example Rome 59 BC (the consuls), Chang'an AD 1 (Emperor Ping of Han),
 Warangal 1280 (Rudrama Devi), Golconda 1600 (Muhammad Quli Qutb Shah), Calcutta 1850 (Victoria),
 Seoul/Pyongyang/Taipei/Beijing 1990 (four different leaders), Paithan AD 100 (Dakshinapatha).
- `probe_talk.sh`: the 12 standard spots unchanged (Aurangzeb, Trajan, Akbar, Louis XVI, Lincoln, Horemheb …).
- `probe_events.sh`: 0 rule violations.

Known limits:
- Groups that never had one ruler stay unnamed: the Indus Valley, Greek city-states, Sumer, the Maya.
- Kings with no dated reigns in Wikipedia stay out: the Kalabhras, the Sangam-era Cholas, Pandyas and
 Cheras, the Hyksos, the Third Dynasty of Egypt.
- Hyderabad 1799–1946: the border map itself (Cliopatria) puts the city under the British Empire / Raj,
 so the villager names the British monarch, not the Nizam. Showing the princely ruler as well would
 need a Java change.

Clean-up after step 8 (2026-10-12): every data set is in the mod (`/ee` registers and history packs);
the raw downloads were deleted after the build, and the sandbox's `~/.cache` (offline Wikipedia copy,
page caches, JDK, Gradle caches) no longer exists. Removed the two intermediate gap rankings; the
final one is `ruler_gaps_after.json`. Kept: the builders and probes, the notes, the test checklist, and
the reports the notes take their numbers from. To build again here, first run `libs/get_jdk17.sh`;
Gradle and `wpdump.py build` then download what they need.

## Step 9: the runtime tests inside the game, in `/ee check` (2026-10-12)

(Step 10 below replaced the single checks of this step - `verbose`, `list`, `live`, `history`, one part,
`goto <1-15>` - with one command, `/ee check all`.)

The user's request: "integrate all the runtime tests you planned to do in /ee check". Until now these
tests ran only outside the game (the probes above) or by hand (`TEST_CHECKLIST.md`). `/ee check` now runs
them on a live server, after its five original sections.

| What | Where |
|---|---|
| The checks themselves, with no Minecraft classes, so the sandbox and a server run the same code | `eternal/.../civilization/HistoryChecks.java` (new) |
| `/ee check` sections 6-13, a background thread, the report file, `list`, `goto <1-15>`, one part at a time | `eternal/.../commands/EeOperationalCheck.java` |
| `/ee check` command tree and one help line | `eternal/.../commands/EternalEngineCommands.java` |
| Small read-only counters for the checks (`all()`, `source()`, `size()`, `routes()`, `routesNear()` …) | `LeaderRegister`, `FamousPeople`, `WaysOfLife`, `LocalLanguages`, `TradeRoutes` |
| The same checks outside the game | `probe_check.sh` + `probes/CheckProbe.java` |
| The `/ee check` commands through Minecraft's own command dispatcher (no server, no player) | `probe_commands.sh` + `probes/CommandHarness.java` |
| Every Java change of this step (reverse with `patch -R -p1` in `eternal/`) | `java_changes_step9.patch` |

Which planned test went where:

| Planned test | `/ee check` part | What counts as a pass |
|---|---|---|
| `TEST_CHECKLIST.md`, 15 places | `places` | the state, the head of state and the trade route are the hand-checked ones |
| `probe_step8.sh`, 39 places | `rulers` (the 25 not in the checklist) | the same; 3 documented limits are KNOWN, not failures |
| `probe_talk.sh`, 12 places | `talk` | the right ruler, no invented ruler on stateless land, the expected words (languages, routes, roads, ways of life) |
| "how often villagers repeat themselves" (checklist) | `talk` | 10 villagers over 10 minutes (the spawner's own seed) say at least 4 different lines; none is over half the talk |
| `probe_events.sh` | `events` | 0 rule breaks in 10,422 lookups (11 event places + 400 land points x 13 years) |
| `probe_index.sh` | `index` | the per-year index and a full search give identical answers in 7,551 lookups |
| `probe.sh` / PresenceProbe, WorldProbe, the Telangana estimated years | `coverage` | the same gazetteer answers at 400 land points x 13 years; "anyone here" nowhere lower (Terra++'s map cache can only add people); the 15,727 estimated founding years unchanged (hash) |
| "lag when you arrive somewhere new" (checklist) | `speed` | first load under 15 s; one place's full answer under 5 ms on average and 50 ms at most |
| the registers and packs load (every step's "Checks") | `data` | at least the step-8 counts, and every pack in `index.json` loads (the gazetteer skips a broken pack without a word) |
| new: UCDP conflict spots cannot be "stopped" | section 4 | `conflict` is not a stoppable kind |
| new: what villagers here can say | "Here and now" | the lines for the player's own place and year (only when a player runs it) |

How it runs in the game:
- Sections 1-5 run at once, as before.
- The history parts run on a background thread named `EE-Check`, so the server keeps ticking. Results
 come back to the server thread for printing.
- One check runs at a time. A check older than 5 minutes counts as dead, for single player worlds that
 were closed in the middle of one.
- Chat shows the summaries and every problem; `verbose` or a single part shows every line.
- The report file is `<world>/eternalengine/checks/ee_check_<date>_<time>.txt`, and the log gets one
 summary line.

Checks of this step:
- `BUILD SUCCESSFUL` (compileJava, Forge 1.20.1).
- `probe_check.sh` against the Gradle classes: 73 checks, 70 OK, 0 failed, 3 known limits (about 17 s
 with first loading).
- The command tree run through Minecraft's own command dispatcher, as an operator with no player
 (`probe_commands.sh`; it asks Gradle once for the Minecraft and Forge classpath):
 - `/ee check list` prints the parts and places;
 - a non-operator is refused, and an unknown part is a syntax error;
 - `/ee check goto 3` without a player explains itself;
 - `/ee check places` and `/ee check talk` print every line;
 - `/ee check` gives section 1 FAIL ("the simulation is not running", correct: there is no server in
 the harness) and then all 8 history parts with a correct summary.
 - Not covered by the harness, because they need a running server and a player: `goto` moving the
 player, the report file, and the "Here and now" lines.
- Mutation test: a corrupt `events_wars.json.gz` placed first on the classpath turns `data` into 2
 failures ("Not in GZIP format", and the event count), and the exit code into 1.
- The name matching treats "Republic of Korea" and "the Democratic People's Republic of Korea" as
 different, and "Ichijō" and "Ichijo", or "Kim Il-sung" and "Kim Il Sung", as the same. "Ramesses III"
 does not count as "Ramesses II".

When the data is changed on purpose later: run `probe_check.sh`, check the new answers by eye, then
update the expected values at the top of `HistoryChecks.java` (the minimum counts, `GAZETTEER_BASELINE`,
`ANYONE_BASELINE`, `ESTIMATED_YEARS_*`).

Also corrected: Part 12 of the mod's history README and `survey/COVERAGE.md` said 1,164 states with named
rulers. `polity_facts.json.gz` holds 1,165 (counted again from the file), and that is what the game counts.

## Step 10: one command, `/ee check all` (2026-10-12)

The user's request: "i dont want single checks. can you do /ee check all ?"

What changed:

| What | Where |
|---|---|
| `/ee check all` runs every check: the live sections 1-5, "Here and now" for a player, and history sections 6-13. `/ee check` alone does the same | `eternal/.../commands/EeOperationalCheck.java` |
| The single checks are gone: `verbose`, `list`, `live`, `history`, `<part>`, `goto <1-15>` are now syntax errors | same |
| Chat shows one line per check, with details only for failures. The report file has every line | same |
| The report path in chat copies on click; the path is shown without `./world/./` | same |
| Section 7 (the 15 places) adds, in the report, every other villager line there and the `/tpll` and `/ee year set` commands to go and look (it replaces `goto`) | `eternal/.../civilization/HistoryChecks.java` |
| In a new world, the event chain and story checks say what to do: `/ee data install`, `/ee data load`, then rejoin | `EeOperationalCheck.java` |
| Speed (section 13): each place's best of three tries. One try also measured the compiler warming up; on a just-started server that once failed with 7.2 ms on average | `HistoryChecks.java` |
| Help line and comment | `eternal/.../commands/EternalEngineCommands.java` |
| A real dedicated server for the sandbox (new) | `tools/run_test_server.sh` |
| The checklist, rewritten for `/ee check all` | `TEST_CHECKLIST.md` |
| A full report from the real server | `sample_ee_check_all_report.txt` (replaced in step 15 by `sample_ee_check_all_log.txt`) |
| Every Java change of this step (reverse with `patch -R -p1` in `eternal/`) | `java_changes_step10.patch` |

Checks of this step:
- `BUILD SUCCESSFUL` (compileJava, Forge 1.20.1).
- `probe_check.sh`: 73 checks, 70 OK, 0 failed, 3 known limits.
- `probe_commands.sh` (Minecraft's own command dispatcher, no server): a non-operator is refused;
 `list`, `places`, `goto 3` and `all extra` are syntax errors; `/ee check all` runs everything, with
 section 1 FAIL ("the simulation is not running", correct without a server).
- New: a real Forge 1.20.1 dedicated server with the mod and Terra++ (`tools/run_test_server.sh`; flat
 world, no player, console commands):
 - a new world: 85 passed, 2 failed (event chain and stories, "no installed foundation data yet");
 - after `/ee data install` and `/ee data load`: the event chain passes (76 events); the stories say
 "installed after this world started";
 - after a restart: `ALL 87 CHECKS PASSED (3 known limits)`;
 - sections 6-13 ran on the background thread in about 14 seconds while the server kept ticking, and
 came back to the server thread for printing;
 - a second `/ee check all` during a run: "A check is already running";
 - the report file is written to `<world>/eternalengine/checks/`;
 - `/ee check goto 3`: "Incorrect argument for command".
- Not tested, because it needs a player in the game: the "Here and now" lines, clicking the report path,
 and how the chat looks.

Found on the way, not changed (it is not part of this step):
- In a development run (`gradlew runServer`) the mod stops the server at start-up:
 `SimulationTickScheduler` reads server config values during common setup, before Forge has loaded the
 world's `serverconfig/eternalengine-server.toml`. Forge only throws in development. In the real game it
 silently uses the defaults, and `updateInterval()` is never called, so changing the update intervals in
 that file has no effect on the schedules. `run_test_server.sh` passes `-Dproduction`, Forge's own
 switch, so the test server behaves like the real game.

## Step 11: the mod installs its own data into a world (2026-10-12)

What happened: the first report from the user's game (Hyderabad, 1948) failed only the stories check,
because the data had been installed while the world was running and stories are read at start. The second
report, after "rejoin", failed both the event chain and the stories with "this world has no installed
foundation data". Nothing in the mod deletes that data (checked: no code removes `eternalengine/` files
except `civ_synthesis.json`), so that report almost certainly came from a different world (a new one or a
copy), where step 0 had never been done. A manual step that must be repeated in every world, in the right
order, with a rejoin, is a trap; so it is now automatic.

What changed:

| What | Where |
|---|---|
| A world without the foundation data gets the shipped copy when it starts, exactly what `/ee data install` does. A world that has its copy (the event pack and the civilization table) is left untouched | `eternal/.../data/FoundationDataInstaller.java` (`installIfMissing`, `lastAutomatic`) |
| Called at world start, before the installed data is loaded and the stories are read | `eternal/.../core/SimulationEngine.java` (`start`) |
| The report's second line names the world (and its folder when different), so a report shows which world it comes from; section 2 says when the data was installed at start; if the event chain or the stories still FAIL, the line says why the install did not work | `eternal/.../commands/EeOperationalCheck.java` |
| `running()` no longer takes a just-stopped (zombie) server for a running one | `tools/run_test_server.sh` |
| Step 0 is gone from the checklist (kept for older builds) | `TEST_CHECKLIST.md` |
| Every Java change of this step (reverse with `patch -R -p1` in `eternal/`) | `java_changes_step11.patch` |

Checks of this step (the sandbox's JDK and Gradle caches had been reset, so first set up again):
- `BUILD SUCCESSFUL` (compileJava, Forge 1.20.1).
- `probe_check.sh`: 73 checks, 70 OK, 0 failed, 3 known limits. `probe_commands.sh`: as in step 10.
- Real dedicated server (`tools/run_test_server.sh`):
 - a new world, no commands typed: the log says "This world had no foundation data; installed the
 shipped copy: copied=24 skipped=0 failed=0"; `/ee check all`: ALL 87 CHECKS PASSED, with
 `· this world had no foundation data when it started, so the mod installed it then (24 files)`;
 - the event pack deleted while the server was stopped: the next start copied only that file
 (copied=1 skipped=23), all checks passed;
 - a plain restart: nothing installed, all checks passed, no install line.
- Confirmed in the user's game (2026-10-12, world "New World", folder "New World (32)", Hyderabad 1948):
 `ALL 88 CHECKS PASSED (3 known limits)`, with `· this world had no foundation data when it started, so
 the mod installed it then (24 files)`. The folder name confirms the cause of the earlier failures: the
 tests ran in new worlds, each without the data.

## Step 12: a fact check of the history data (2026-10-12)

Read-only: nothing in the mod changed. `FACT_AUDIT.md` explains the results in plain words.

- `fact_audit.py` runs the rules over everything the mod uses: rulers and heads of government, border-map
 state names, events, famous people, places, trade routes, languages and faiths, and the small
 foundation files (read by hand; those findings are in its `MANUAL` list). It writes:
 - `fact_audit_findings.csv.xz`: 4,005 rows (area, rule, how sure, seen in game, item, details);
 - `fact_audit_summary.json`: the counts, the examples, the people-weighted share of wrong lines by
 year, and the wrong lines that reach the most people.
- `fact_audit_wd.py` holds the Wikidata look-ups through QLever (CC0): the lifetimes of the ruler names,
 the years of the states behind the map's names, which namesakes are states, and the jobs of the
 matched people. They are saved in `fact_audit_wikidata.json.gz`, so `python3 fact_audit.py` runs offline
 in about a minute. To fetch again: `python3 fact_audit_wd.py all`, then `python3 fact_audit.py fetch-extra`.
- Result:
 - 1,543 wrong, 333 likely wrong, 1,253 odd and 876 missing.
 - A wrong ruler, language or faith line reaches under 2% of the world's people before 1700, 12–18% in
 1850–1900 (Russia's prime ministers named as rulers; "Kingdom of Great Britain" after 1801), 7% in
 1950, and under 3% in 2000 and 2020.
 - Places and trade routes: no problems found.

## Step 13: how well the mod uses its data (2026-10-12)

Read-only: nothing in the mod changed. `DATA_USE.md` explains the results in plain words.

- Code reading: which system reads which data, and what each world system runs on.
- `data_use_sample.py`: HYDE-weighted sample points (1,500 per year, 14 years) in
 `~/.cache/data_use/points.tsv`.
- `probes/DataUseProbe.java` with `probe_data_use.sh` (needs the Gradle classes): the mod's own lookup
 code at those points and over all 122,432 events. Output: `data_use_probe.json`.
- `data_use_counts.py` writes `data_use_counts.json`: which rulers, people, languages and faiths can ever
 be said.
- Result:
 - The history data drives who appears where, what villagers say, the alternative timeline and the AI
 briefings.
 - The simulation systems (war, disease, trade, economy, farming, religion, technology, climate,
 dynasties, buildings) run on the 133-civilization table and lists in the code, or on commands.
 - Four installed files (religions, technologies, climate, templates) are never read.

## Step 14: the core reviewed and fixed (2026-10-12)

- `WORLD_SYSTEMS.md` lists all 69 world systems; `CORE_REVIEW.md` reviews the core under them (engine, clock,
 scheduler, world state and saving, data installer, Terra++ bridge) and lists what step 14 fixed.
- The user chose all fixes (A safety, B control, C speed, D data updates) and "pause when nobody is online".
- What changed for a player, in short:
 - a restart keeps wars, outbreaks, trade routes, world flags and the event history (nothing replays);
 - one failing system no longer stops the others or the autosave;
 - `/ee pause`, `/ee resume`, history pauses while nobody is online, `/ee reset` (with confirm) and
 `/ee reload` really work, `/ee data status` and `/ee performance` say what is going on;
 - config intervals work, VIP speed votes count, big events slow history down, the clock says how fast it is;
 - after a mod update a world gets fixed data files, edits are kept.
- Files: `java_changes_step14.md` (every Java change), `step14_java_after.tar.gz` (the touched files after
 step 14, for an exact diff next time), `tools/quick_javac.sh` (type check in seconds), `probe_core.sh` +
 `probes/CoreProbe.java` (votes, Terra++ day rounding, safety net), `sample_ee_check_all_report.txt` (the
 step-14 report: 91 passed on the sandbox server; replaced in step 15 by `sample_ee_check_all_log.txt`).

## Step 15: `/ee check all` writes no files, everything goes to the Minecraft log (2026-10-12)

The user: "dont create new files when /ee check all is used, show everything in minecraft log."

What `/ee check all` wrote before, and what it does now:

| Before | Now |
|---|---|
| A report file in the world folder every time: `eternalengine/checks/ee_check_<date>_<time>.txt` | No file. Every line goes to the Minecraft log, `logs/latest.log`, one log line per line, each marked `[EE check]` |
| The save check saved the world (`state.json`), which also made a backup when the newest one was over 30 minutes old, and created `state.json` in a new world | The save check only reads. It builds in memory exactly what a save writes and compares it with the running world, then reads the last save on disk (`state.json`). The autosave and leaving the world still do the saving |
| The last chat line: the report path, click to copy | The last chat line: the log's path, click to copy |

- A player still gets the same chat as before (one line per check, details of every problem). The log has every line,
 including what villagers say at the 15 checklist places and how to go there.
- Run from the server console (or RCON), the console gets two short lines ("Every line of this check goes to the log…"
 and "All checks done: …") and the log gets the rest, so no line shows twice there.
- The last log line is `[EE check] end of check: <n> passed, <n> failed, <n> known limits`.
- The save check now says one of: "not on disk yet" (a new world before its first save), "the last save on disk reads
 back (saved 3 min ago)", the same with "it is from before this mod version, and the next save updates it" (a world
 converted at its first start with step 14), or FAIL "the last save on disk reads back" when `state.json` cannot be read.
- The number of checks is unchanged: 91 on the test server, 92 expected in the user's game.

Files:
- Java: `EeOperationalCheck.java` (the log, no report file, the read-only save check), `WorldStateManager.java`
 (`previewStateJson()`: what a save would write, built by the same code as the save, without writing or counting a
 save), `HistoryChecks.java` (three texts that named the report file), `EternalEngineCommands.java` (the `/ee help`
 line no longer says "full report saved"). Exact patch: `java_changes_step15.patch` (reverse with `patch -R -p1` in
 `eternal/`); the four files after step 15: `step15_java_after.tar.gz`.
- `tools/run_test_server.sh check` reads the `[EE check]` lines from `run/logs/latest.log` and keeps a copy in
 `~/.cache/ee_server/reports/` (the sandbox side only; the mod writes nothing).
- `sample_ee_check_all_log.txt`: the lines one check wrote to the log on the test server (replaces
 `sample_ee_check_all_report.txt`).
- `TEST_CHECKLIST.md` Step 1: where the log is and how to find the lines; `probe_commands.sh` and
 `probes/CheckProbe.java`: comments.

Checks of this step:
- `BUILD SUCCESSFUL` (compileJava, Forge 1.20.1). `tools/quick_javac.sh` OK.
- `probe_check.sh`: 73 checks, 70 OK, 0 failed, 3 known limits (unchanged). `probe_core.sh`: 11 of 11.
- `probe_commands.sh "ee check all"` (Minecraft's own command dispatcher, no server): the harness's "chat" got exactly
 the two short lines, the log 252 `[EE check]` lines; no `eternalengine/` folder was created.
- A real Forge 1.20.1 dedicated server (flat test world, no player), the server folder listed (every file and folder,
 with size and time, logs excluded) before and after each of 7 checks:
 - a new world without `state.json`: ALL 91 PASSED, "not on disk yet", about 290 lines in the log;
 - after `/ee backup` (which saves on purpose): "the last save on disk reads back (saved 3 s ago)";
 - `state.json` set to data version 1: passes, "from before this mod version, and the next save updates it";
 - `state.json` broken: 90 passed, 1 failed, "[FAIL] the last save on disk reads back" with the reason and the path;
 - after a restart: passes, "saved 51 s ago", and "restored at this world's start: 0 war(s), …";
 - the final run: ALL 91 PASSED, about 290 lines;
 - every time: no file or folder created or changed, no `checks/` folder, no new backup.
- Not tested, because it needs a player in the game: the chat and the click on the log path. The chat is the same
 as before except for three lines of wording (the last line now gives the log's path instead of the report's).

## Step 16: the crowd spawner's crash, found by the user's /ee check all (2026-10-12)

The user's game with step 15 (Hyderabad 1948, a new world, Terra++ time): every line of the check was in the log
as planned, and 91 passed, 1 failed: "no world system has failed since this world started" -- `spawner failed 7x,
latest: java.lang.IllegalArgumentException: Start element (9223367638808264704) is larger than end element
(-9223372036854775808)`. The step-14 safety net kept every other system running and the step-14 check said so.

**The cause.** `CrowdFigures.occupiedInChunk` built its search box as `new AABB(x1, x2, y1, y2, z1, z2)`, but
AABB takes `(minX, minY, minZ, maxX, maxY, maxZ)`. The box ran from the player's chunk east to x = 536,870,911.
Minecraft's entity search walks a box one 16-block slice of X at a time, and past x = 33,554,416 the slice key
it packs into a long overflows (2^63 - 2^42, then -2^63: the two numbers in the error). Every call walked 1.5 to
2.1 million empty slices (10 to 85 ms) and then threw, in every world, so the drawn crowd never stood in any
game. The file was never committed; the line comes from the earlier crowd work, not from these steps.

**Fixed, and four more crowd bugs that only showed once the crowd ran** (all in `population/CrowdFigures.java`):

| | What was wrong | Now |
|---|---|---|
| 1 | The search box (above) | `occupiedBox(chunkX, chunkZ)`: the chunk and 8 blocks round it, at every height |
| 2 | Moving a figure to another place called `setUUID` on an entity already in the world. Minecraft finds entities by UUID and the client is never told: after a 60-block walk 605 of 690 figures could not be found by their own UUID, 4 UUIDs stood twice | that place's own person is stood up there and the figure leaves (the same jump on screen) |
| 3 | A place whose figure had walked off along its day counted as free, so the same person was stood up again: 684 "UUID of added entity already exists" warnings in about 80 seconds | a held place counts as taken, and `stand()` never adds a person who already stands |
| 4 | The surplus figures were sorted so that the nearest ones in view were released (the comment says the opposite) | the ones out of view, farthest first, leave first |
| 5 | Kept figures were re-placed towards the player on every cycle, also while walking (the comments say a seen crowd stays put) | on the move each keeps its own place; standing still, each keeps its own place when it is still wanted |

**A new check in `/ee check all`** (section 4, only when a player runs it and figures stand around them): "the
crowd around you is sound: N figures within 160 blocks, each found by its own UUID, nobody twice". Read-only.

**Tests.**
- `probe_crowd_box.sh` (`probes/CrowdBoxProbe.java`): Minecraft's own `EntitySectionStorage` with test people at
 the user's chunk (629378, -126959), at chunk 0,0 and near the world border. The box as it was fails with the
 user's exact message (68 ms, 1,467,775 slices; at 0,0: 84 ms, 2,097,153 slices); `occupiedBox` finds exactly the
 people in and around the chunk, at any height, in under 4 ms. 8 of 8.
- A real test server with a sandbox-only helper mod (`testmod/`, `tools/build_test_helper.sh`,
 `EE_TEST_HELPER=1 tools/run_test_server.sh run`): a Forge fake player at a place, and `CrowdFigures.ensure` every
 40 ticks as the spawner calls it. The sandbox's older Terra++ jar puts the ground at the real elevation and its
 public `fromGeo` disagrees with the generator's `toGeo`, so the helper finds the block by Newton steps and lays
 grass at Terra++'s ground height (Kolkata, 9 m: y 72..82). It never goes into the mod jar.

| Run | Result |
|---|---|
| Old code, the user's block in Hyderabad, 1948 | the user's error word for word, every cycle (17 of 17), 0 figures, 11 to 40 ms per failing call |
| Box fixed, Kolkata 1850, 400,000 people, standing still | 0 failures; 349 figures in about 25 s; 6 ms per 2-second cycle; 1.7 ms per server tick |
| Box fixed, walk 60 blocks east | 690 figures, 686 distinct UUIDs, 605 figures not findable by their UUID, 684 warnings (bugs 2 and 3) |
| All fixes, walk 60 east, stand, walk back | 0 warnings, 0 lost, every UUID once; 352 -> 758 -> 765 figures; 360 -> 845 -> 859 different figures (walking back met the same people); 1.8 to 4.5 ms per server tick |
| `/ee check all` as the fake player / from the console | ALL 94 PASSED (with the crowd check: 765 figures) / ALL 91 PASSED |

- `BUILD SUCCESSFUL`; `probe_check.sh` 73/70/0/3 and `probe_core.sh` 11/11 unchanged.
- Not tested: the client side (how 400 figures look, their skins, your frame rate); that needs the game.

**Open, for the user to decide:** figures a player walks away from stay standing (a decision of the earlier crowd
work: "coming back found strangers"); they go only when the year changes or the place has no people.
In the walk test the count grew from 352 to 758 over 60 blocks. Since step 16 every figure's identity is fixed by
its place, so clearing far figures would bring back the same people on return.

Files: `java_changes_step16.patch` (CrowdFigures.java and EeOperationalCheck.java; reverse with `patch -R -p1` in
`eternal/`), `step16_java_after.tar.gz`, `probes/CrowdBoxProbe.java` + `probe_crowd_box.sh`, `testmod/` +
`tools/build_test_helper.sh`, `run_test_server.sh` (`EE_TEST_HELPER=1`), `sample_ee_check_all_player_log.txt` (a
player's check in the log), `TEST_CHECKLIST.md` (Step 5: the crowd).

## Step 17: the core's last blemishes, and group 2 (people and places) reviewed and fixed (2026-10-12)

The user: "if core works perfectly, then we will go for next system (2. People and places)."

**The core.** In the user's game every core check passed; the one failure was the crowd (a group-2 system),
fixed in step 16. Two small blemishes from the user's log, fixed now:
- The state was saved twice at every shutdown. Now once (checked in the server log).
- A new single-player world paused history for about a second before its player joined. Single player now waits
 15 s before a "nobody is online" pause; dedicated servers pause at once, as before.

**Group 2.** `PEOPLE_REVIEW.md` reviews the 12 systems with a live run, for the first time with a player in a
town: the sandbox-only helper puts a fake player in the level (`eetest player join`), and `eetest people`,
`eetest player jump` and `eetest crowd walk` drive it. The user skipped the choice of fixes, so the recommended
ones were done (A, B, C, and clear far crowd figures; D, the new talk lines, is left for later):

| | Problem found | Fix | Result |
|---|---|---|---|
| A | A place forgot its people: Minecraft's despawn deleted townspeople every tick, unremembered, before the spawner's own remembering rule (every 2 s) could run. After a walk away and back, 17 of 37 were the same | townspeople are out of Minecraft's despawn; the spawner checks all its people every 2 s and remembers anyone past 128 blocks from every player | jump away and back: 33 of 37 the same |
| B | Names from the wrong region: every state id containing "india" got the Deccan's Telugu names (Kolkata: "Ryot Kishtaiah Setty"); British Raj and European empires got Greek-Roman names; unknown states got the placeholder list ("Alex Stone") | names follow the language spoken at the place (from 1500 on), else the ruling state; India, British Raj and the East India Company get the Indian list | Kolkata: "Karigar Durga Gupta"; `probe_name_pools.sh` 11/11 |
| C | The first villager loaded the history data on the game's thread (1.3 s freeze; "Avg: 270ms" in the user's log), and crowd sound recounted people 20 times a second (0.80 ms per tick, the costliest system) | background load at world start (the spawner and crowd sound wait); crowd counted once a second | spawner's worst 1,290 → 116 ms; crowd sound 0.80 → 0.054 ms; mod average 3.28 → 0.48 ms per tick |
| Crowd | figures piled up behind a walking player (352 → 758 over 60 blocks) | figures past 128 blocks from every player are taken out; they come back the same | 352 → 36 near the start while away, the same people again on return |

Checks: `BUILD SUCCESSFUL`; `probe_core.sh` 11/11, `probe_check.sh` 73/70/0/3, `probe_crowd_box.sh` 8/8 (all
unchanged); new `probe_name_pools.sh` 11/11; the test server as a fake player in Kolkata 1850: `/ee check all`
ALL 94 PASSED (new counted line: "the history data loaded in 3.9 s in the background when this world started");
from the console 91 passed. Still limited: walking slowly through new ground still invents people (districts follow
the player where no town centre is in range); the name lists are thin. Both are in `PEOPLE_REVIEW.md`.

Files: `PEOPLE_REVIEW.md`, `java_changes_step17.patch` (9 Java files; reverse with `patch -R -p1` in `eternal/`),
`step17_java_after.tar.gz`, `probes/NamePoolProbe.java` + `probe_name_pools.sh`, the helper's new commands in
`testmod/`, `TEST_CHECKLIST.md` (after step 17).

## Step 18: talking with villagers, the knowledge core and the talk screen (2026-10-13)

The user approved preview 2 (`npc_knowledge_ui_preview.html`): "its perfect. i liked it. start implementing it".
Step 18 builds its first part in the mod: what villagers know (dated, by job, with distances), and the talk
screen. The goods (newspaper, map, trade screen, purse) are step 19; the history book and the tracker compass
are step 20.

**What a player sees.** Right-click a villager: the talk box opens at the bottom of the screen with the
villager's face, name and job, and today's date in the game. The villager opens with today's news. Names in
gold can be clicked (or picked with keys 1–9); "Ask about…" lists the names heard; a text box finds a name
typed in; Backspace goes back; Esc closes; walking away closes it. No source names anywhere (turn 56): people
say how they know in their own words. Everyone nearby sees the opening line as a speech bubble.

**What villagers know.**
- **Knowledge packs** (`data/eternalengine/eternal/knowledge/`): checked, dated cards for a place and time.
 The first pack is Hyderabad from 15 August 1947 to 31 December 1948 (450 km around the Deccan): the 28 cards,
 12 news lines and 6 newspapers of preview 2, converted from the preview.
- **Dates to the day:** answers change with the day (13 September: Naldurg; 17 September: the ceasefire), and
 nobody knows the future (on 12 September nobody has heard of the police action).
- **Who knows what:** street people (level 1) know news and everyday things. Court clerks, scholars, priests,
 commanders and advisors (level 2) also know court business. A street villager asked about the prime
 minister says "That is court business. I wouldn't know. Ask the clerks at King Kothi Palace", with the
 way there ("about 3.5 km north of here").
- **Distances from the villager:** "Naldurg fort, about 240 km west of here" is measured from where the
 villager stands, not written into the text.
- **Everywhere else:** basic cards from the history data (ruler, place, life, famous people, news of the
 year), with the same lines as before. Their quality is still the turn-51 spot check (1 answer in 10 wrong).
 The data fix still waits for the user's OK.
- **Notes:** each name heard and each answer (the date, who said it, the question) is kept per player in
 the world save (`eternalengine_knowledge`), ready for the history book in step 20.

**New commands.**
- `/ee date`: today's date in the game.
- `/ee date <year> <month> <day>` (admin): go to that day and pause history so the day stays; `/ee resume`
 lets time run again.
- `/ee talk [at <lat> <lon>] [level 1|2] [ask <card> <question> | card <card> | topic <topic> | free <words>]`
 (admin): what a villager would say, as text, for testing.
- `/ee check all` has 5 new lines in section 5: the packs load; every link leads to a card; the Charminar on
 14 September 1948; court questions; no knowledge of the future.

**A clock fix found by the test.** When the speed changed (for example the Cold War slowdown, 10x to 5x, which
starts with the year 1948), the clock kept its tick count, so the day inside the year jumped: 14 September read
as early May. The clock now keeps the same point in the year when the speed changes. `/ee date` also holds the
exact day while the clock is paused, because at very fast speeds a year has fewer ticks than days.

**Checks.**
- `BUILD SUCCESSFUL` in a fresh sandbox (the JDK and Gradle caches were set up again).
- New `probe_knowledge.sh`: 33/33. It covers the dated answers, distances, court referrals, no future
 knowledge, 728 answers (every card, question, day and level), no source names, 5 places outside the pack,
 44 BCE, the packet round trip, saving notes, and Back.
- Old probes unchanged: `probe_core.sh` 11/11, `probe_check.sh` 73/70/0/3, `probe_crowd_box.sh` 8/8,
 `probe_name_pools.sh` 11/11.
- Test server:
 - `/ee check all` from the console: 96 passed, 0 failed, 3 known limits (91 + the 5 talk lines).
 - `/ee date 1948 9 14` held the day through the Cold War slowdown and a restart; after `/ee resume`, about
 3 s later, it was 18 September.
 - The fake player right-clicked a summoned merchant (street news) and a court clerk (court news) in
 Mancherial. `/ee talk` worked at the Charminar, at King Kothi and in Paris.
 - Crowd figures (who have no name) now get a stable name from the place's name list.

**Not tested here.** The screen itself: there is no game window in the sandbox. It compiled against Minecraft
1.20.1, and everything behind it ran on the server. The look in the game is the first thing to check.

**Seen, not yet looked into.** In the second test-server run (after a restart), the townspeople of Mancherial did
not come back within a minute; only crowd figures stood there. The first run had 5. This may be a sandbox effect
(force-loaded chunks and a fake player) or real; it belongs to the people review. Hyderabad's ground (506 m) is
above the flat test world's height limit (320), so the sandbox tests used Mancherial (150 m), inside the pack.

Files: `java_changes_step18.patch` (20 files: 6 changed, 12 new Java files, 2 data files; it applies to the
step-17 state, reverse with `patch -R -p1` in `eternal/`), `step18_java_after.tar.gz`,
`probes/KnowledgeProbe.java` + `probe_knowledge.sh`, the helper's new `eetest talk` in `testmod/`,
`TEST_CHECKLIST.md` (step 7).

## Step 18b: the user's game log after step 18: the date with Terra++ time, no early news, walls (2026-10-13)

The user sent the Minecraft log of their game with step 18, without words: read it and fix what it shows.

**What the log showed.**
- The new mod was installed ("Registered 15 packets": the 13 from before plus the 2 talk messages).
- `/ee check all` in the game: ALL 99 CHECKS PASSED, 3 known limits, including the 5 new Talk lines.
- The world runs on Terra++ time at 1x: one Minecraft day is one day of history. The player went to 1948; the
 world's day count was 1,806,020, which is 1 January 1948.
- **Problem 1, the date.** The Talk line said "Thursday, 1 July 1948". Step 18 did not read the day out of
 Terra++ time and used the middle of the year (day 183). Villagers talked as on 1 July, whatever the day.
- **Problem 2, early and stale news.** In the history data, events have a year, not a day. So on any day of
 1948 a villager in Hyderabad could bring up the police action (13-18 September) as this year's news, even in
 January. Some pack lines said "yesterday" or "this morning" and were still said days later.
- **Problem 3, deaths in walls.** Two townspeople "suffocated in a wall". Terra++ puts buildings into a chunk
 after its ground, in the background and again after a time jump (the `OWNERSHIP_COMMIT` lines), so someone
 standing in the open can end up inside a new wall.
- Harmless: a Terra++ reflection error (`f_95522_`), Xaero map version warnings, "Can't keep up" while Terra++
 rebuilt the world after the time jump, and once, right after joining, the mod's "Tick budget exceeded"
 (63 ms on average) at the same moment. No error from the mod.

**Fixes.**
1. **The date with Terra++ time.** The day is now read from the Minecraft day count, the same way Terra++ reads
 the year: Terra++ year = -3000 + day count x speed / 365, and the day in the year is what is left over.
 Day 1,806,020 is 1 January 1948; 257 days later is 14 September. Terra++ years have 365 days, so a leap
 year like 1948 has no 31 December (its last day shows as 30 December).
 - `/ee date 1948 9 14` with Terra++ time sets the Minecraft day count and keeps the time of day. A different
 year first makes the normal Terra++ time jump.
 - History is not paused: at 1x a day already lasts 20 real minutes. At faster Terra++ speeds one Minecraft
 day covers several days, so `/ee date` goes to the nearest day that exists ("the nearest day this Terra++
 year has").
 - With the Eternal Engine clock nothing changed: it pauses, as in step 18.
2. **Nobody knows the future, and old news is not "today's".**
 - Inside a knowledge pack (Hyderabad, 15 August 1947 to 31 December 1948, 450 km), this year's events from
 the history data are left out, because the pack knows the days. On 1 January, 1 July or 1 October 1948 a
 villager at the Charminar says "Good day to you. This is Hyderabad."
 - A line that says "today", "yesterday" or "this morning" is said only on its own day (32 lines). New lines
 fill the days after: 15 September (Latur and Suryapet), and plain-date versions from 18-19 September ("On
 18 September an Indian armoured column came into the city..."). The news lines of 18 September end on
 30 September. Day-by-day news is in the pack for 12-30 September 1948; on other days villagers greet the
 player and still answer questions.
 - The pack check (and `/ee check all`) also proves: no day word on the wrong day, and once a question has
 an answer, it has one on every day after (no silent days).
3. **Walls.** A wall never hurts a townsperson. Someone inside a wall steps to the nearest spot with ground
 under the feet and room for the head: beside first (up to 4 blocks), then up (up to 32 blocks). A crowd
 figure inside a wall is taken away, because the spot it stood on is built over.
4. Small: place names written in small letters are capitalised in the place line; the greeting is "Good day
 to you. This is X."

**Checks.**
- `BUILD SUCCESSFUL`.
- `probe_knowledge.sh`: 45/45 (was 33). New:
 - the Terra++ day sums (1,806,020 = 1 January 1948, +257 = 14 September; at 25x it lands on the nearest day);
 - every answer on every day of the pack (505 days, 18,733 answers): no day word on the wrong day, no silent
 days;
 - no early news inside a pack (1 January, 1 July and 1 October 1948), and places outside the pack
 unchanged (1 March 1949: "News from afar this year: Telangana Rebellion.").
- Old probes unchanged: `probe_core.sh` 11/11, `probe_check.sh` 73/70/0/3, `probe_crowd_box.sh` 8/8,
 `probe_name_pools.sh` 11/11.
- Test server:
 - `/ee date 1948 7 1`, then `/ee talk` at the Charminar: "Good day to you. This is Hyderabad."
 - 15 September: "The fighting goes on. They say the army has taken Suryapet in the east." "Where is it
 now?": Latur in the west, Suryapet about 120 km east.
 - 25 September, "When did it happen?": "It began on 13 September, and the fighting stopped with the
 ceasefire on the evening of 17 September."
 - Wall test in Mancherial: stone at a merchant's feet and head; within a second he stood on the next free
 block, health 20 of 20. Boxed in by 36 stone blocks, he climbed out on top (y 208 to 211), still 20 of 20
 nine seconds later. A crowd figure put in stone was taken away (18 figures to 17). No "suffocated" line.
 - `/ee check all` from the console: ALL 96 PASSED, 3 known limits (the same count; the future line now also
 checks 1 July).
- **Not tested here:** the Terra++ day count itself, because the sandbox's Terra++ has no time feature. Its sums
 are in the probe. To try in the game: `TEST_CHECKLIST.md` step 7.

**Still a limit.** Outside the packs, news comes by the year: in Paris on 1 July 1789 a villager may already
talk about the storming of the Bastille (14 July). News by the day everywhere is step 22 (event time).

Files: `java_changes_step18b.patch` (10 files: 9 Java, 1 data; it applies to the step-18 state, reverse with
`patch -R -p1` in `eternal/`), `step18b_java_after.tar.gz`, `probes/KnowledgeProbe.java` (sections 13-15),
`TEST_CHECKLIST.md` (step 7).

## Step 18c: the talk box fits every screen, and the date line at the top of the screen (2026-10-13)

The user: "the ui right side went out of screen. and project dont have month and date. whould we add it or not?"

**Why the box went off the screen.** Minecraft draws its screens in GUI units: a 1920 x 1080 screen with the
automatic GUI scale is 480 x 270 units. The step-18 box began at 30% of the width, so its body was 258 units
wide. After a question the button row is Back, Other topics, the name box, Ask and Goodbye: about 282 units.
Goodbye ended at 483, past the right edge (480). (Measured with Minecraft's own font. Before a question, with
no Back button, the row just fitted: 462.) Two smaller faults: the grey hint "Ask about a name…" ran into the
Ask button (Minecraft does not shorten it), and with a longer name or job the date was left out of the header.

**Month and date.** The approved preview had a date line at the top of the screen ("Tuesday, 14 September
1948", the place below it). Step 18 left it out. The date itself has been right since step 18b (the real
Terra++ day).

**What changed.**
- `client/gui/TalkLayout.java` (new): where everything in the box goes, for any screen size. It is plain Java,
 so a probe can test it without the game.
 - The box keeps the approved place (from 30% of the width to near the right edge, above the hotbar) when that
 leaves room. Otherwise it grows to the left: at 480 x 270 it starts at 102 instead of 144. At most 520 wide.
 - The date goes beside the name when it fits, otherwise on its own line. It is never left out.
 - Questions in two columns; a question too long for half the width gets a whole row, so no question is cut.
 - The buttons wrap onto a second row when needed. Names and labels end in "…" only if a whole row is too short.
 - The grey hint in the name box is "Ask about a name…", "Type a name…" or "Name…", whichever fits.
 - A screen too low for everything: the box first covers the hotbar, then packs its rows tighter, then shows only
 some lines of the villager's words (the mouse wheel scrolls them), and last of all the whole box scrolls.
 Small arrows show when there is more.
- `client/gui/TalkScreen.java`: draws what TalkLayout says, plus mouse-wheel scrolling. Keys, colours and the
 talk itself are unchanged.
- The date line (new):
 - `knowledge/DateSync.java` (server): once a second it sends each player the date and the name of the place
 they are in (as villagers say it: "This is Hyderabad"), only when either changes. The place is looked up again
 every 5 seconds, only after moving 64 blocks, and never before the history data has loaded.
 - `network/packets/DatePacket.java`: the message. Network version 3 (16 messages; 15 before).
 - `client/DateHud.java`: draws it like the preview: the date in yellow, the place in white below it, on a light
 dark band. Top right by default (Xaero's minimap sits at the top left by default), below any potion effect
 icons. Hidden with F1, with F3 and while talking (the talk box shows the date).
 - Settings in `config/eternalengine-client.toml`, section `hud`: `showHuds` (on or off), `hudScale` (0.5 to 2)
 and `hudPosition` (TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT). These settings existed before, unused.
- `/ee date` typed by a player adds "The date line on your screen: Tuesday, 14 September 1948 | Hyderabad".

**Tests.**
- New `probe_talk_layout.sh` (`probes/TalkLayoutProbe.java`). Text is measured as Minecraft measures it, from the
 game's own font pictures.
 - 7 talk screens (5 real ones from the Hyderabad pack and Paris, plus a made-up worst case) at 15 screen sizes
 from 320 x 240 (the smallest Minecraft allows) to 1920 x 1080. Nothing goes off the screen or out of the box,
 nothing overlaps, the date always shows and every label fits. 9 of 9 checks pass.
 - The real screens never scroll and no real question is cut. Only the tallest answers on screens 240 units
 high cover the hotbar. The made-up worst case (9 long questions, 8 long names) fits 320 x 240 by scrolling.
 - Pictures drawn with the game's font: `probes/out/talk_*.png` and `probes/out/hud_480x270_dateline.png`.
- Test server: 16 messages registered (15 before).
 - `eetest dateline` (new in the sandbox helper) at the test spot near Mancherial gave "Tuesday, 14 September
 1948 | Kothapalle", 3 km east "Mancherial", and on 15 March 44 BCE only the date. A lookup takes about 1 ms
 (12.6 ms the first time).
 - `/ee check all` ALL 96 PASSED, 3 known limits. `probe_knowledge.sh` 45/45.
- **Not tested here:** the screen itself (the sandbox has no game window). To try in the game:
 `TEST_CHECKLIST.md` step 7, items 11 and 12.

Files: `java_changes_step18c.patch` (7 files: 4 new, 3 changed; it applies to the step-18b state, reverse with
`patch -R -p1` in `eternal/`), `step18c_java_after.tar.gz`, `probe_talk_layout.sh`, `probes/TalkLayoutProbe.java`,
`testmod/src/eetest/helper/EeTestHelper.java` (`eetest dateline`), `TEST_CHECKLIST.md` (step 7).

## Step 18d: one calendar: the date follows the Minecraft days, and only /ee date moves it back (2026-10-13)

The user wanted the date (day, month, year) to work with the Minecraft days, despite time skips and the mod's
other systems. Their rule, chosen when asked: **only `/ee date` may move the date back.**

**What was wrong.**
- With Terra++ time (the user's game, 1x) the date is Minecraft's day counter, so it already followed the days.
 - `/time set day` puts that counter back to day 0, which with Terra++ time is 3000 BCE.
 - `/ee speed` kept the year but moved the day to 1 January (step 14's code, written before days mattered).
 - `/ee year set` and `/ee morph jump` could go back.
- The Eternal Engine clock (no Terra++ time) counted years per Minecraft day: at 10x a year passed every 2 minutes,
 so a day lasted 0.3 seconds and could not follow the sun. `/ee date` had to pause history to hold a day.

**What changed.**
- New `clock/WorldCalendar.java`, the one place the date comes from. `KnowledgeDate.today()` (villagers, the date
 line, news) asks it.
 - With Terra++ time: Minecraft's day counter, read the way Terra++ reads its year (unchanged).
 - With the Eternal Engine clock: a saved starting point (the date at the start of one Minecraft day) plus the
 Minecraft days since, times the speed. A world from before this step starts on the day its old clock showed.
 - The date changes when Minecraft's day does (6 in the morning), with both clocks.
- **Speed is now days of history per Minecraft day** with both clocks (the same number as the Terra++ scale): 1x,
 5x, 10x, 25x, 50x. A new speed keeps the date. The event slowdowns stay limits on that number (the Cold War: at
 most 5x). New worlds start at 1x (`defaultSpeed = 1`; an existing config file keeps its own value).
- The rules:

| What happens | The date |
|---|---|
| A Minecraft day passes | the next date, at 6 in the morning (at 1x) |
| Sleeping | the night is skipped: the next morning is the next date |
| `/time add` | moves forward the same amount |
| `/time set` | goes forward to the next time that hour comes (at night `/time set day` = the next morning); never back |
| Day/night cycle off | stops with the sun |
| History paused (`/ee pause`, nobody online) | the day/night cycle is switched off with it (now with both clocks), so sun and date stop together |
| Anything else that puts Minecraft's day back (another mod, an older level.dat) | put right at the start of the next tick; logged as "[Calendar] Minecraft's day went back" |
| `/ee year set`, `/ee morph jump` | forward only; an earlier year is refused with "Only /ee date moves the date back" |
| `/ee date` | any date, earlier too; the sun stays where it is; history is no longer paused |
| `/ee reset confirm`, a new story campaign | start history over at the start year (they exist to do that) |
| `/ee speed` with Terra++ time | the same day, or the first later one the new speed can show (14 September at 1x -> 5x is 17 September) |

- How `/time set` is changed: the mod registers the same command shape (`time set day|noon|night|midnight|<time>`),
 which Minecraft's command tree merges onto vanilla's, so only what runs changes; who may use it stays vanilla's.
 `/time add` and `/time query` are vanilla's. `/ee check all` checks that `/time set` is still the mod's.
- Saved in `state.json` under `"calendar"` (starting point, speed, and the last date the guard saw, so a counter
 that went back while the server was off is put right too).
- `/ee date` explains the rule. `/ee check all` has one new counted line: "the date follows the Minecraft days and
 only /ee date moves it back" (the rules on made-up times, `/time set` still the mod's, the date has a value).
- Files: `WorldCalendar` (new), `SimulationClockManager`, `KnowledgeDate` (the old "pin" for fast speeds is gone),
 `TerraTimeBridge` (`setTimeScaleKeepingDate`, `dayKeepingDate`, `recalculate`), `SimulationEngine` (the pause),
 `WorldStateManager` (the save), `EternalEngineCommands`, `EeOperationalCheck`, `EternalEngineConfig`.

**Tests.**
- New `probe_calendar.sh` (`probes/CalendarProbe.java`), the mod's real code on made-up times: 13 of 13 pass.
 - 1x over three years: one date change per Minecraft day, exactly at 6 in the morning; leap days right.
 - 5x to 50x: n Minecraft days = n x speed days, never back; speed changes at odd hours keep the date.
 - `/ee date` reads back for 29 February, 31 December, 44 BCE, 3000 BCE, years 0 and 1, at every speed.
 - `/time set`: 23,040 pairs of hours, always forward, less than a day, on the hour asked for.
 - Terra++ `/ee speed`: 5,195 cases (every day from December 1947 to 1949, every pair of speeds) keep the date or
 the first later one.
 - A world saved before this step starts on the day its old clock showed; the save reads back.
- `probe_knowledge.sh` 45/45 (its `/ee date` check now uses the calendar).
- Test server (Eternal Engine clock; nobody online, so history and the day/night cycle were paused, which kept the
 clock still for exact tests):
 - `/ee date 1948 9 14`: no pause any more. `/time set night` then `/time set day`: 15 September, "The date moves
 on to …". `/time add 24000`: the 16th. `/time set 0`: the 17th (before: back to the 14th).
 - `eetest settime 5000` (past `/time`, as another mod would): put right within one tick, still the 17th. A small
 step back over 6 in the morning: undone exactly. A step back inside the same day: allowed (same date).
 - `/ee year set 1900` and `/ee morph jump 1900`: refused. `/ee year set 1950`: 1 January 1950. `/ee date 1948 9 14`:
 back, and the guard took it.
 - `/ee speed set 10`: the Cold War limit made it 5x; the date stayed; a Minecraft day then moved it 5 days.
 - Restart: the calendar came back from the save (19 September 1948), and the day/night cycle the mod had paused
 was switched back on. Then the date changed by itself at 6 in the morning (19 -> 20 September). A night and a
 wake-up (the clock jumped to the next morning, as sleeping does): the 21st, nothing put right.
 - The date line: "Monday, 20 September 1948 | Kothapalle". `/ee check all` ALL 97 PASSED, 3 known limits.
- **Not tested here:** Terra++ time itself (the sandbox's Terra++ has no time), real sleeping, other mods. To try
 in the game: `TEST_CHECKLIST.md` step 8.

Files: `java_changes_step18d.patch` (9 files: 1 new, 8 changed; it applies to the step-18c state, reverse with
`patch -R -p1` in `eternal/`), `step18d_java_after.tar.gz`, `probe_calendar.sh`, `probes/CalendarProbe.java`,
`probes/KnowledgeProbe.java` (the `/ee date` check), `testmod/src/eetest/helper/EeTestHelper.java` (`eetest settime`,
`eetest calendar`), `TEST_CHECKLIST.md` (step 8), `NPC_PLAN.md` (row 18d).

## Step 18e: the user's game log after step 18d: the stand-still after joining, Terra++'s own time commands (2026-10-13)

The user sent the Minecraft log of their game with step 18d, without words: read it and fix what it shows.

**What the log showed.**
- The good part: a new world ("New World (35)") near Hyderabad with Terra++ time at 1x. The calendar started ("Terra++
 time: one Minecraft day is one day of history"), the user went to 1948 with Terra++'s own `/terra timejump 1948`
 (forward, so the calendar took it without a word), and `/ee check all` gave **ALL 100 CHECKS PASSED**, including the
 new calendar line, with `/time set` confirmed as the mod's in their game. Today read 1 January 1948, a Thursday.
- The game stood still about 8 seconds, 2 seconds after joining: "Tick budget exceeded! Avg: 464ms" and "Can't keep up!
 Running 8312ms". The warning only measures the mod's own systems, so one of them ran about 9 seconds, but it did not
 say which.
- At every start: "[Clock] Speed changed: 10x -> 1x (Base speed)". Misleading: 10 was only the field's first value.
- The user uses Terra++'s own time commands. Read in `terra3/` (not changed): `/terra timejump <year>` goes to any
 year, earlier too, and rebuilds the loaded chunks for it; `/terra timescale 1x|10x|25x|50x` changes the speed without
 keeping the date (1948 at 1x would be a year past 9000 at 10x, which Terra++ caps at its last year). A jump back with
 `/terra timejump` would have been undone by the calendar's guard after Terra++ had already begun rebuilding chunks.
- Also found: `/ee date` to another year (through `TerraTimeBridge.jumpToYear`) did only part of Terra++'s jump, so the
 land around the players kept the old year until it was loaded again. Now that `/ee date` is the only way back, it
 must do the whole jump.
- Not ours: Terra++'s own reflection error at the experimental-settings screen, and its long chunk rebuilds after the
 time jump (`REFRESH_ENGINE tick: spent=6985ms`).

**What changed.**
1. **Which system was slow, in the log** (`core/SystemRunner.java`, `core/SimulationEngine.java`). A world system that
 takes 1 second or more in one tick is logged by name ("World system 'spawner' took 9104 ms in one tick", at most
 once a minute per system), and "Tick budget exceeded!" ends with "slowest in one tick: <system> <ms>".
2. **Where the people spawner's time goes, in the log** (`villager/PresenceLocalSpawner.java`). A cycle of 250 ms or
 more writes one line, at most once a minute: "[Spawner] One cycle around <player> took N ms: finding the place, the
 people already here, the district, how many people live here, keeping people in the district, townspeople, the
 drawn crowd, an event scene", each with its ms.
3. **The stand-still** (same file). The first run of these logs on the sandbox server (a player arriving in 1948):
 spawner 834 ms, of which "the district" 777 ms. To choose where the crowd gathers, the spawner turned the named
 place's centre into a block position *with its ground height*, and that read loads or builds the chunk there.
 The centre is usually beyond the spawn distance, and then a district near the player is used, so it was mostly
 for nothing. With Terra++'s real terrain, building that chunk is what took the 8 seconds. Now only the map position
 is used (projection maths); the height is read only when that chunk is already loaded, and the player's height
 stands in otherwise. After the fix: no slow cycle, spawner peak 71 ms (`/ee performance`), and the same 5
 townspeople and crowd appear.
4. **Terra++'s own time commands follow the calendar's rules** (`clock/WorldCalendar.java`, checked before they run).
 - `/terra timejump <year>` to this year or an earlier one: refused, "Only /ee date moves the date back: /ee date
 <year> 1 1 …" (this year: "It is already …, so /terra timejump … would go back to 1 January"). Also through
 `/execute … run`. A later year runs as Terra++ wrote it.
 - `/terra timescale <n>x` runs as `/ee speed set <n>`, which keeps the date.
5. **`/ee date` (and `/ee year set`, `/ee morph jump`, starting over) do Terra++'s whole time jump**
 (`terrabridge/TerraTimeBridge.java`): after the exact day, the steps of Terra++'s own `/terra timejump`, in its order
 and by reflection: new refresh generation, jump audit, rebuild queues emptied, boundary ring marked, every loaded
 chunk queued for rebuilding (nearest first), the half-loaded rescan after 10 seconds, Terra++'s time saved. A step
 this Terra++ does not have is skipped. Logged: "[TerraTimeBridge] Year jump to <year>: 7 of 7 Terra++ time-jump
 steps done; N loaded chunks queued for rebuilding".
6. **No misleading "Speed changed" at start** (`clock/SimulationClockManager.java`): the effective speed starts from the
 base speed, so the line only shows when a slowdown or lock really changes it.

**Tests.**
- The sandbox had been reset (no JDK, Gradle cache or build): `libs/get_jdk17.sh`, the first Gradle build (4 min 38 s),
 the classpath file and resources again (the `prepare` step of `tools/run_test_server.sh`), `tools/build_test_helper.sh`.
- `probe_calendar.sh` 13/13, `probe_knowledge.sh` 45/45.
- Test server (fresh world, history running, `/ee date 1948 9 14`, then the test player joining near Mancherial):
 - Before the fix: "Tick budget exceeded! Avg: 209ms … slowest in one tick: spawner 830 ms", then "[Spawner] One cycle
 around eetest_watcher took 834 ms: … the district 777 ms …".
 - After: no warning, spawner peak 71 ms, 5 townspeople within 128 blocks as before.
 - No "Speed changed" line at start.
 - `/terra` through stand-ins with Terra++'s shape (new in the sandbox test helper; the sandbox's Terra++ has no time):
 `timejump 1900` refused (also via `/execute`), `timejump 1948` refused (same year), `timejump 1950` let through,
 `timescale 10x` ran as `/ee speed set 10` (5x under the Cold War limit) with the date unchanged, `timescale 1x` back.
 - `/ee check all` ALL 97 PASSED, 3 known limits.
- **Not tested here:** Terra++'s whole time jump from `/ee date` (needs Terra++ time), and how long joining takes in
 the user's world now. To try in the game: `TEST_CHECKLIST.md` step 8, items 9 to 11.

Files: `java_changes_step18e.patch` (6 files, all changed; it applies to the step-18d state, reverse with
`patch -R -p1` in `eternal/`), `step18e_java_after.tar.gz`, `testmod/src/eetest/helper/EeTestHelper.java` (stand-in
`/terra timejump` and `/terra timescale`), `TEST_CHECKLIST.md`, `NPC_PLAN.md` (row 18e).

## Step 18f: the date line removed (2026-10-13)

The user: "i dont like date, month, year and etc at top right of the screen. remove it". The date line of step 18c (the
date in yellow and the place below it, top right) is gone.

**What changed.**
- Deleted: `client/DateHud.java` (the drawing), `knowledge/DateSync.java` (the server sending the date and place every
 second) and `network/packets/DatePacket.java` (the message).
- `network/EternalEnginePacketHandler.java`: the message is no longer registered (15 messages, 16 before). It sat in the
 middle of the list, so the messages after it moved up one: network version 4 (3 before), so a game and a server of
 different versions refuse each other cleanly. Single player updates both sides by itself.
- `/ee date` no longer prints "The date line on your screen: …".
- Kept: the talk box still shows the date (approved in preview 2), and the world's calendar (steps 18d and 18e) is
 unchanged. The client settings `showHuds`, `hudScale` and `hudPosition` in `eternalengine-client.toml` are unused again,
 as they were before step 18c.
- Sandbox only: `eetest dateline` removed from the test helper; `probe_talk_layout.sh` no longer draws the date-line
 picture (`hud_480x270_dateline.png`).

**Tests.** Gradle build OK (the three classes are gone). `probe_talk_layout.sh` 9/9 (the talk box still fits every
screen size and shows its date), `probe_calendar.sh` 13/13, `probe_knowledge.sh` 45/45. Test server: "Registered 15
packets", `/ee date` works, the test player talked to a townsperson ("Have you heard? The Indian Army has entered the
state. … They fought at Naldurg yesterday." on 14 September 1948), `/ee check all` ALL 97 PASSED, 3 known limits.

Files: `java_changes_step18f.patch` (5 files: 3 deleted, 2 changed; it applies to the step-18e state with `patch -p1 -E`,
reverse with `patch -R -p1` in `eternal/`), `step18f_java_after.tar.gz` (the 2 changed files), `TEST_CHECKLIST.md`
(step 7 item 12), `NPC_PLAN.md` (row 18f).

## Step 19a: the purse (2026-10-13)

The user approved the step-19 plan (turns 73-81) and said "ok start implementing". Step 19 is split into 19a-19f; 19a
is the purse.

**What a player sees.** `/ee purse`, in Hyderabad on 14 September 1948, the first time:

 You start with 1 rupee (Osmania sicca), about a day's pay here.
 Your purse: 1 rupee (Osmania sicca), about 1 day's work here.
 Money here: the Osmania sicca. 1 rupee = 16 annas, 1 anna = 12 pai. A day's work pays about 1 rupee.
 Also taken here: the Indian rupee (7 O.S. rupees = 6 Indian rupees).

A paper (1 anna) is a sixteenth of a day's pay and a map (8 annas) half a day, as in the approved preview. Money of
another place or year stays in the purse and shows as "Not taken here: 3 dams (Mughal rupee)."; the money-changer
comes in 19b. Where people had no money, the purse holds "goods worth about 1 day's work".

**How it works.**
- `money/MoneyTable.java` reads `data/eternalengine/eternal/economy/money_table.json` (written by
 `build_money_table.py`, which explains the file's rules): 41 kinds of money, 69 place rows, 12 fixed rates. A row
 says which money a place used in which years: by the ruler in 1947 (Hyderabad State: the ruler register has the
 British Raj there 1859-1946), by the ruler of the year (the Mughals, the Delhi sultans, the Deccan sultanates and
 Vijayanagara, the Marathas, the British Raj, India, Rome, Byzantium, the Ottomans), or by a box on the map; the
 highest priority wins. Every place and year has an answer: barter before 600 BCE and where there were no coins
 (the Americas before 1500 except cacao in Mesoamerica, Africa south of the Sahara except cowries in West Africa,
 Australia, the far north), "silver and copper coins" and "local money" (amounts told in days of work, no coin names
 claimed) where no row names the money.
- Each money has units (largest first, some only in some years: the kurus not before 1688) and a day's pay by year
 (anchors, read in straight lines). Most numbers are estimates; the file marks them, the game never says so and never
 names a source.
- India in detail: Osmania sicca 1918-1959 (1948: 16 annas a day), Hali sicca 1858-1917, sicca rupee from 1724, the
 Indian rupee in annas, pice and pies (1835-1956), naye paise (1957-1963) and paise; the Mughal rupee of 40 dams;
 the tanka of 48 jitals; the hun, fanam and kasu; the pana of the Arthashastra. The world: weighed silver
 (Mesopotamia: a shekel of 180 grains, 6 grains a day), copper deben and kite (Egypt), drachma, denarius, solidus,
 dirham, toman, akce and kurus, pounds-shillings-pence, livre, franc, euro, thaler, mark, peso, copper cash, mon and
 yen, dollar, ruble, cacao beans, cowries.
- `money/PlayerPurses.java`: the purses, saved with the world (`eternalengine_purses`), one number per kind of money
 in its smallest unit; the start money once; never below nothing.
- `money/MoneyFormat.java`: amounts in words ("1 rupee 4 annas 6 pai", "1 shilling 8 pence", "6 grains of silver",
 "goods worth about half a day's work") and typed amounts back ("4 annas", "1.5 rupees", "2 days"; accents not
 needed). `money/PurseService.java`: the lines a player reads, the start money, and a self-test.
- Commands: `/ee purse` (everyone); admins: `/ee purse [at <lat> <lon>] [add <amount> [unit] | reset]` and
 `/ee money [at <lat> <lon> [year]]` (which row answered, the coins, a day's pay, a paper and a map there).
- `/ee check all`, section 5: three new lines (the table loads and checks out; Hyderabad in 1948 and a world grid from
 3000 BCE to now; the purse's sums, words and save), and "Purse here and now" for a player.

**Tests.** `probe_purse.sh` (new, `probes/PurseProbe.java`): 72/72, with the real ruler register (46 places and years
from Uruk 3000 BCE to Hyderabad 1970, units and words, the start money, a world grid of 378,144 lookups at about 3
microseconds each). `probe_calendar.sh` 13/13, `probe_knowledge.sh` 45/45, `probe_talk_layout.sh` 9/9. Test server
with a fake player at Mancherial on 14 September 1948: start money 1 rupee, no second start money, 4 annas in, 100 rupees
out refused, the purse kept over a restart, the Mughal rupee in 1700 and "Not taken here" back in 1948. `/ee check all`
from the console ALL 100 PASSED (97 + 3), as the player ALL 103; the user's game should show 103. Sandbox only: the
test helper has `eetest as <command>` (a command as the fake player, every line it is told written to the log).

Files: `java_changes_step19a.patch` (7 files: 2 changed, 5 new; it applies to the step-18f state with `patch -p1` in
`eternal/`), `step19a_java_after.tar.gz`, `build_money_table.py`, `probe_purse.sh`, `probes/PurseProbe.java`,
`testmod/src/eetest/helper/EeTestHelper.java`, `TEST_CHECKLIST.md` (step 9), `NPC_PLAN.md` (rows 19a-19f, decisions).

## Step 19b: earning money (2026-10-14)

The user asked whether to go on to 19b; the verdict was yes (19a passed every check here, and 19b only adds to the
purse), and the user said "go".

**What a player sees.** In Hyderabad on 14 September 1948 a merchant's first choice is "I have goods to sell.":

 I buy wheat, bread, logs, stone, coal, iron, copper, wool, gold and emeralds. I pay 4 annas 5 pai for 16 sheaves
 of wheat, 1 rupee 1 anna 11 pai for 16 loaves of bread, 8 annas 11 pai for 16 logs, 5 annas 7 pai for 64 blocks
 of stone, … 1 rupee 14 annas 9 pai for a bar of gold, 2 rupees 4 annas 4 pai for an emerald. Full price for the
 first few of each, half for more. Today I can still pay out 8 rupees.
 1. Sell 100 sheaves of wheat: 1 rupee 6 annas 11 pai
 2. Sell 40 logs: 1 rupee 6 annas 4 pai

After a sale the grey line says "Sold 100 sheaves of wheat for 1 rupee 6 annas 11 pai. Your purse: 2 rupees 6 annas 11
pai (Osmania sicca)." (the first sale also gives the start money). The money-changer ("Can you change my money?")
names his cut, the money taken here and a quote for everything in the purse: "for your 3 dams (Mughal rupee) I give 10
annas 9 pai (Osmania sicca); for your 1 pound (pound sterling) I give 15 rupees 3 annas 10 pai (Osmania sicca)", with
buttons "Change your Mughal rupee: 10 annas 9 pai". Anyone else answers "Who buys goods here?" with names and
directions: "Ask Vepari Sailu Reddy, a merchant, about 25 m north-east of here. To change money, see Setty Rahmat Raju,
the money-changer, about 10 m north of here."

**How it works.**
- `money/GoodsTable.java` reads `economy/goods.json` (written by `build_goods_table.py`, which explains the rules): the
 13 goods of the trade engine, their names ("sheaf of wheat"), the Minecraft items that count (logs and wool by item
 tag, charcoal counts as coal), how many items make one engine unit, how many a merchant takes a day at full price,
 and where and when nobody buys a good: no wheat or bread in the Americas before 1520 or in Australia before 1788; no
 iron before 1200 BCE (China 700 BCE, Korea 400 BCE, Japan 300 BCE, southern Africa 300 CE, the Americas 1500); no
 metal, wool or gems in Australia before 1788. Wine, silk and spices have no item yet (product atlas).
- `money/MarketService.java`: a good's price is the trade engine's price (`CommodityPricingEngine`, the running one
 when the simulation runs) × a twentieth of a day's work per unit, ÷ the items in a unit, × the day's pay of the place
 and year: so a sheaf of wheat is a fortieth of a day everywhere, 3.36 pai in Hyderabad 1948 after the merchant's 70
 in 100. A merchant pays full price for the first lot of a good in a Minecraft day, half for as many again, then has
 enough, and pays out at most 8 days' pay a day. The money-changer swaps all of a money for the money of the place
 (or the money of the place for money also taken there): with a fixed rate (directly or through one money) he keeps
 2 in 100, otherwise he values it by a day's pay and keeps 10 in 100 (old money, far-away money). The four numbers
 are settings (`[market]` in `eternalengine-common.toml`). Sales and swaps are written to the log as `[EE market]`.
- `money/MarketLedger.java`: what each merchant bought today, saved with the world (`eternalengine_market`), so leaving
 and coming back does not refill his money. A merchant's day is a Minecraft day, whatever the speed of history.
- The money table has 13 new fixed rates (25 in all): the rupee and sterling 1835-1970 (Rs 10, then Rs 15 = 1 pound;
 1 shilling 6 pence a rupee from 1917, kept at independence; Rs 21 after June 1966, Rs 18 after November 1967),
 sterling and the dollar (4.8665 on gold, 4.03 in 1940-1948, 2.80 from 1949, 2.40 from 1968) and the dollar and the
 rupee (Rs 3.31 in 1940-1948, Rs 4.76 from 1949, Rs 7.50 from June 1966). Rough where the notes say so (1873-1898,
 1917-1926).
- `knowledge/MarketTalk.java`: the talk screen's trade views. Selling and swapping are actions of their own ("sell",
 "swap"): they happen once, and the view kept is the list they came from, so Back never repeats a sale. Each button
 carries the offer it shows; if the offer changed in between (the player sold some already, his money ran low), the
 merchant says "That offer has changed. Here is what I pay now." and shows the new list. Button labels are kept short
 so they fit at 480 x 270 (a 1920 x 1080 screen at the automatic GUI scale).
- People: where a place has merchants and money (not barter), `HistoricalPresence.Result.spawnRoles` adds one
 money-changer, and `SettlementDensity.roleSlots(budget, roles)` gives him one place (none below three people). He
 dresses and is titled like a merchant; his job reads "money-changer".
- Also: `/ee reset confirm` empties every purse and the merchants' days (the reset message says so); `/ee reload` reads
 the money and goods tables again; `/ee market [at <lat> <lon> [year]]` (admin) lists what a merchant pays there and
 what nobody buys; `/ee talk` takes `role <role>`, and its `sell` and `swap` really trade for the player who runs it
 (for testing).
- `/ee check all`, section 5: three new lines (the goods table; the market's sums; a money-changer among the people)
 and "Market here and now" for a player.

**Tests.** `probe_market.sh` (new, `probes/MarketProbe.java`): 62/62 (prices in 18 places and years from Babylon 1750
BCE to Hyderabad 1948, 6,506 prices over a world grid, a merchant's day, 11 swaps, money-changers in the crowd, the talk
views). `probe_talk_layout.sh` 9/9 with two new views (the merchant after a sale, the money-changer): 135 layouts fit.
`probe_purse.sh` 72/72, `probe_knowledge.sh` 45/45, `probe_calendar.sh` 13/13. Test server, fake player at Mancherial
on 14 September 1948: the sales, offers and money-changer swaps above; a stale offer refused; the 8-rupee day limit
(22 of 40 logs); the next Minecraft day his money back; the inventory and purse right. In Bombay the crowd held 1
money-changer, 10 merchants, 10 farmers and 10 craftsmen among 40 people. `/ee reset confirm`: "emptied 1 purse(s)".
`/ee check all` from the console ALL 103 PASSED, as the player ALL 106; the user's game should show 106.

**Known limits.**
- A good is worth the same number of days of work everywhere: spices are not yet cheap in Kerala and dear in London
 (scarcity comes with product atlas part B).
- Only merchants buy; farmers and craftsmen do not trade yet, and villages have no merchants.
- Between two monies with no fixed rate, the money-changer goes by a day's pay, which undervalues the money of rich
 countries (a dollar in 1920 buys very few rupees). The new rates cover the rupee, sterling and the dollar for most
 of 1835-1970; others (franc, mark, yen ...) still go by a day's pay. A very long round trip through three places
 could gain a little; the 10 in 100 cut makes the nearby ones lose.
- `/ee reload` reads the tables from the mod jar again, which changes nothing in a game unless the jar changed.

Files: `java_changes_step19b.patch` (20 files: 15 changed, 5 new; it applies to the step-19a state with `patch -p1` in
`eternal/`), `step19b_java_after.tar.gz`, `build_goods_table.py` (new), `build_money_table.py` (the new rates),
`probe_market.sh`, `probes/MarketProbe.java`, `probes/TalkLayoutProbe.java` (two views), `TEST_CHECKLIST.md` (step 10),
`NPC_PLAN.md` (row 19b, decisions).

## Steps 19c to 19f: sellers, the trade screen, newspapers, the crier, maps, old money and the new history (2026-10-14)

The user said "Go for next. i will test after completing step 19". So 19c, 19d, 19e and 19f were built one after the
other with my defaults (listed in `NPC_PLAN.md`), tested here, and are reported together.

**What a player sees (Hyderabad, 14 September 1948).**
- Each town and city has a paper seller, each village a town crier, and before print a city has a newsletter writer.
 Anyone answers "Where can I get the news?" with a name and a direction. Sellers (merchants, the money-changer and
 the news people) stand still at their spot, so the directions stay true. No stand blocks are placed.
- "Show me your papers and maps." / "Show me your goods." opens the trade screen of the approved preview: the trades on
 the left (picture, short name, price; "you have it", "sold out today"), the picked one on the right (big picture,
 name, price, a few words, the purse), Buy, the seller's words ("Papers and maps! Have a look.", a receipt, a
 refusal), "‹ Back to …" and Goodbye. A sale plays the villager's yes, a refusal the no.
- The paper seller sells "The Evening Herald, 14 Sep 1948" for 1 anna and the "Map of Hyderabad State" for 8 annas. The
 paper keeps its news on the item; right-click opens it: masthead, "HYDERABAD · TUESDAY, 14 SEPTEMBER 1948 · 1 ANNA",
 the pack's stories of the day (names in blue), events still going on and last year's, who rules ("Hyderabad State:
 The Nizam, Mir Osman Ali Khan."), what merchants pay today, and "MAPS OF HYDERABAD STATE · for travellers · at the
 paper stand". Reading it puts its names into the player's notes (the history book of step 20) and its places onto
 every map the player carries.
- The map shows the pack's 24 towns and the two roads of September 1948, a white square where you stand, a coloured
 mark for each paper's day, a compass, a scale bar and the title. Click a town: what your papers said about it. "Add to
 Xaero's map" uses Xaero's own share link (untested here: Xaero is not in the sandbox); without Xaero it writes x and z
 in the chat. Elsewhere a map shows the gazetteer's towns of its year, one in each part of the map first, and the
 roads and trade routes of the year (around Rome in 100: 40 towns and 485 road pieces).
- Merchants sell what they buy at full worth (16 sheaves of wheat for 6 annas 5 pai; they buy them for 4 annas 5 pai), a
 few lots a day, and things made here: Osmania biscuits (8 for 1 anna, from 1940), toddy, a gongadi blanket (3 rupees);
 coal is "Singareni coal" in Telangana from 1889.
- The town crier calls "Hear ye! …" over his head now and then; "What is the news today?" tells three stories free.
- Step 19f: sellers take the money of the place, or money it also takes (Indian rupees in Hyderabad, at 7 for 6,
 rounded up). Old money: "That is 2 annas 5 pai. That old Mughal rupee is not taken any more. A money-changer will
 change it for you." Foreign money: "We don't take the … here." On another road of history (a fork), papers start
 with "History took another road in 1948. This paper prints the news of the new history." and the record of the new
 history ("Operation Polo (Hyderabad) did not happen."); a pack's papers stop when the change happened inside its
 land. Papers bought before keep their old news.

**Prices** (estimates, in days of work, turned into the money of the place; rounded to the biggest coin no more than
an eighth of the price):

| What | Price | Hyderabad 1948 | London 1800 | Rome 100 |
|---|---|---|---|---|
| Printed paper | 1/4 of a day's pay before 1830, 1/12 to 1899, 1/16 from 1900 | 1 anna | 5 pence | (handwritten only) |
| Handwritten newsletter | a day's pay | 1 rupee | - | 1 denarius 3 asses |
| Map | half a day's pay printed, 3 days' drawn by hand | 8 annas | 10 pence | 3 days' pay |
| Goods | the full worth (merchants buy at 70 in 100) | wheat: 6 annas 5 pai for 16 | | |

**Who brings the news** (`news/NewsEras.java`; the year printed papers reach a region's cities; towns 50 years later,
an estimate; villages and other places with a ruler: a crier):

| Region | Printed papers in cities | Handwritten newsletters in cities |
|---|---|---|
| North-west Europe | 1620 (Strasbourg 1605, Amsterdam 1618, London 1621) | 1566 to 1619 (avvisi) |
| Italy / Spain and Portugal | 1640 / 1661 (estimates) | from 1566 |
| Russia | 1703 | - |
| Egypt / Anatolia / Persia | 1828 / 1831 / 1837 | - |
| South Asia | 1840 (estimate; the first was Calcutta 1780) | 1574 to 1839 (the Mughal news-writers) |
| China / Japan and Korea | 1872 / 1870 | China: 713 to 1871 (court gazettes) |
| North America / Mexico / South America | 1704 / 1722 / 1808 | - |
| Southern Africa / Australia | 1800 / 1803 | - |
| The Roman world | - | 59 BCE to 235 (copies of the Acta) |
| The rest of the world | 1870 (estimate) | - |

**Only checked news.** A pack's own papers on their days (6 days in September 1948); on other days the pack's news
line of the day ("News of the day"); otherwise the history data's events still going on and last year's, never this
year's (the data has years, not days, so they might not have happened yet). Long event names are cut to a short
headline; a name that starts with another year ("1898: Mandingo Wars …" dated 1850) is left out as a slip in the data.

**New and changed files.**
- New: `news/` (`NewsEras`, `NewsService`, `MapService`, `PaperView`, `MapView`, `NewsItems`, `NewspaperItem`,
 `MapItem`), `money/ShopService.java`, `money/TradeView.java`, `knowledge/NewsTalk.java`, three packets
 (`TradeViewPacket`, `PaperViewPacket`, `MapViewPacket`; network version 5), the screens (`client/gui/TradeScreen`,
 `PaperScreen`, `MapScreen`, `GuiCanvas`) and their painters (`client/gui/paint/`: `Canvas`, `Rich`, `TradePainter`,
 `PaperPainter`, `MapPainter`, pure Java so the probe can draw them), `commands/NewsCommands.java` (`/ee shop`,
 `/ee paper`, `/ee map`).
- Changed: `TalkService` ("trade", "buy", "show"), `TalkActionPacket`, `ClientKnowledge`, `KnowledgePacks` (a pack's
 `paperName` and `map`), `HistoricalPresence` (the news person), `SettlementDensity` (one place each for the
 money-changer and the news person), `PresenceLocalSpawner` (sellers keep their stand; the crier's calls),
 `KnowledgeLevels`, `SkinPainter`, `SkinPoolDatabase`, `VillagerNameDatabase`, `TradeRoutes` (`roads()`),
 `EternalEngineCommands` (`/ee talk trade|buy`, `/ee reload` reads the product cards), `EeOperationalCheck` (4 new
 checks and "News here and now"), `EternalEngineMod` (the items).
- Data: `economy/products.json` (product atlas part A, 13 cards), `knowledge/hyderabad_1948.json` (`paperName`, and the
 `map` with 24 towns and 2 roads), item models, textures (`textures/item/newspaper.png`, `newsletter.png`, `map.png`)
 and names.
- Records: `java_changes_step19c_to_19f.patch` (40 files: 16 changed, 24 new; checked with `patch -p1` and `cmp`) and
 `step19f_java_after.tar.gz` (the newest base for those files).

**Tests here.**
- `probe_screens.sh` (new): who brings the news in 8 places, shop prices and paying (Indian rupees taken, Mughal money
 and pounds refused), today's paper in Hyderabad on 14 and 15 September 1948, in 1700, in Rome in 100 and in London in
 1800 and 1851, the crier, the Hyderabad and Rome maps; then the trade screen, the newspaper, the newsletter and the
 map drawn with the game's own font at 480 x 270, 320 x 240 and 640 x 360 (`probes/out/screen_*.png`): everything on
 the screen. All passed. Other probes: purse 72, market 62 (two checks updated for the new choices), knowledge 45,
 calendar 13, talk layout 9.
- Test server (fake player in Mumbai and Kothapalle, 14 September 1948): see TEST_CHECKLIST "Steps 19c to 19f".
 `/ee check all`: console 107, as the player 110, all passed.

**Known limits.**
- The three screens were checked in pictures, not in a real game window. Xaero's waypoint is untested.
- The ruler line outside a pack comes from the ruler register ("Republic of India, ruled by George VI" for Mumbai in
 1948: wrong; the history data fix is still waiting for your yes). Inside the Hyderabad pack the pack's checked
 answer is used.
- Papers outside packs only know years, so they print events still going on and last year's.
- The crier's gender and names come from the name lists as before.
- Prices are the same in days of work everywhere (no scarcity yet; that is product atlas part B).

## Product atlas, part B: what is made where, and when (2026-10-14)

The user said "Next". Part B of `PRODUCT_ATLAS_PLAN.md` (planned "right after 19") was built with my defaults and
tested here. The years are estimates for whole areas; `PRODUCT_ATLAS_TABLE.md` shows them all for checking by eye.

**What it does.** For any place and year, each of 129 products (14 families: staple food, other food and drink,
animals, cloth, building, fuel and light, metals and tools, weapons, transport, writing, money, medicine, luxury,
papers and permits) is one of:
- **made here**: it is made in the area by then; the people of the region do what it needs (farm, herd, live in towns,
 or anything but only hunt and gather; from the ways-of-life survey up to 1899, every place after that); and one of
 each group of its inputs is here (a printed book needs paper or parchment, and ink);
- **brought from far**: it comes by trade by then, or it is made elsewhere in the area while people here cannot make it
 but trade (they farm or herd at least commonly, or have towns);
- **not here yet** (and the year it comes, or never);
- **gone** (replaced: stone tools, bronze weapons, palm-leaf books, gas light …).

**Areas.** The 17 large areas of the ArchaeoGLOBE survey the mod already uses for ways of life (146 regions): northern,
middle North America, Central America and the Caribbean, South America, Europe, eastern Europe (with Russia and
Siberia), western Asia, northern Africa, western, middle and southern, eastern Africa, central, southern, eastern,
south-eastern Asia, Australia with New Zealand and Melanesia, Micronesia and Polynesia. A point just off the outlines
(a coast, like Mumbai) takes the region a step away; the open sea takes a rough box. When the survey date is older than
the product in that area (the survey's 1500 is before horses reached Mexico), the survey cannot know, so a need it
says is unmet counts as met where people trade.

**Examples** (all checked by `/ee check all` and the probe):

| Place and year | Made here | Brought from far | Not here yet |
|---|---|---|---|
| Harappa, 2500 BCE | wheat, cotton, fired bricks, copper, bronze | tin | iron, coins, paper, sugar, chillies, tea |
| Rome, 100 | wheat, bread, wine, oil lamps … | pepper, silk | paper, sugar |
| London, 1850 | newspapers, gas light, machines, beer, bread | tea, cotton | electric light, telephone, cars, plastics |
| Hyderabad, 1948 | railways, electric light, mill cloth, cement … (103) | kerosene, petrol, radios (10) | television, nylon, plastics (11) |
| Tenochtitlan, 1500 | maize, cacao, chillies, cotton | - | wheat, iron, horses, coins, carts |
| Sydney, 1500 / 1850 | wild food, fish, hides / wheat, sheep, wool, iron | - / tea | wheat, iron, cattle / - |

Choices I made: Europe always brought cotton and never grew it (Lancashire's mill cloth is its own product); South
Asia brought kerosene (from 1870), petrol (1910) and radio sets (1927; made there from 1955); the Andes have their own
wool (llamas and alpacas); iron years match the goods table.

**Merchants.** After their goods and the part A cards, merchants sell up to 8 holdable products of the place (each
merchant his own kinds, picked by who he is), 2 lots of each a day: made here at its days of work in the money of the
place, brought from far at twice that ("Brought from far away, so it costs more."). 21 products have items: potatoes,
sugar, honey, cacao beans, eggs, leather, blue dye, mud bricks, fired bricks, glass bottles, torches, oil lamp and
kerosene lamp (a lantern called so), candles, flint for tools, iron axe, saddle, palm leaves (paper called so), paper,
ink, printed book. One offer per item: a kerosene lamp replaces the oil lamp when both are there. In Mumbai on 14
September 1948 a merchant sold 16 × Paper for 4 annas 3 pice.

**Commands and checks.**
- `/ee products [here | at <lat> <lon> [year]]`: the area and region, the counts, the people's ways of life and which
 needs are met, the food, cloth, fuel and light here, and the lists (made here; brought from far, since when; not here
 yet, the next 15 to come; gone, since when).
- `/ee reload` reads the atlas again.
- `/ee check all`: 3 new lines: "Products: 129 products … none is here before its first year; Harappa in 2500 BCE, Rome
 in 100, London in 1850 and Hyderabad in 1948 have what they should", "Products: every input is made or brought where
 and when it is used (705 links)", "Products: food, cloth, fuel and light in all 146 regions in 15 years from 3000 BCE
 to 2000"; for a player also "Products here and now …".

**New and changed files.**
- New: `build_product_atlas.py` (the data, with its own checks; writes the JSON and `PRODUCT_ATLAS_TABLE.md`),
 `economy/products_world.json`, `money/ProductAtlas.java`, `probe_atlas.sh` + `probes/AtlasProbe.java`.
- Changed: `civilization/WaysOfLife.java` (each region's area, the region at a point in any year, a region's reading by
 name, the list of regions), `money/ShopService.java` (the atlas lots), `commands/NewsCommands.java`
 (`/ee products`), `commands/EternalEngineCommands.java` (the command; `/ee reload`), `commands/EeOperationalCheck.java`
 (3 checks and "Products here and now").
- Records: `java_changes_atlas_part_b.patch` (6 files: 5 changed, 1 new; checked with `patch -p1` and `cmp`) and
 `atlasB_java_after.tar.gz` (the newest base for those files).

**Tests here.**
- `probe_atlas.sh` (new): 31 passed (the data checks, the plan's examples, 9 more places, Mumbai on the coast, the open
 sea, what merchants may sell in Hyderabad 1948 and Rome 100, each merchant's own kinds). Other probes unchanged:
 market 62, purse 72, knowledge 45, calendar 13, talk layout 9, screens all passed.
- Test server (fake player in Mumbai): `/ee check all` console 110, as the player 113, all passed; `/ee products here`,
 `/ee products at 30.63 72.86 -2500`, a merchant's list, a purchase (16 paper in the inventory, stock 2 lots then 1),
 `/ee reload` ("product atlas: 129 products in 14 families and 17 areas (21 sold as items)").

**Known limits.**
- Years are for whole areas (the earliest corner of each), so a product made in one corner shows as made everywhere in
 that area where people meet its needs; part C (about 400 kinds, region by region, India first) refines this.
- Prices: days of work, twice for brought goods; no other scarcity yet.
- "Made here" does not look at the land itself (mines, coasts, rivers): only the area, the year and how people live.

## Step 19g: somebody buys in every settled place (2026-10-14)

The user asked (turn 87) how a player earns money in every place and year, and how old money becomes new money. The
answer showed gaps: only cities had a buyer, only 10 kinds of goods sold, no money-changing outside cities, coins were
useless where people swap, and two hints were wrong. The user approved the fixes A to D ("ok and next", turn 88).

**Who buys where.**
- City: the merchant, as before (70 in 100 of the worth, 8 days' pay a Minecraft day), and the money-changer where
 there is money.
- Town: a **trader** (new role). He pays 60 in 100 and has 4 days' pay a day; he changes money too, keeping 10 in 100
 whatever the money (a city money-changer keeps 2 where the rate is fixed). Where people swap, he swaps, and he takes
 coins as metal for goods, by what they buy ("Coins are only metal here.").
- Village with money: a **pedlar** (new role). He pays 50 in 100 and has 2 days' pay a day; no money-changing.
- Where people swap and nobody trades for a living (a barter village, a camp of hunters): **anybody** (not a crier)
 swaps a little: 50 in 100, 1 day's pay a day ("I have goods to swap.", "I can swap a little.").
- Nobody lives there (deep forest, desert, open sea): nobody buys; walk to where people live.
- The terms come from the four merchant settings: trader = buy share −10 and half the money; pedlar = −20 and a
 quarter; anybody = −20 and an eighth (at least a day's pay). No new settings.
- The trader and the pedlar stand once in a crowd (like the money-changer), keep a stand, dress and are titled like a
 merchant. Order in a village: farmer, pedlar, town crier.

**What buyers take.** The 10 goods with items, as before, and now the **atlas products** people here make or bring in
(18 kinds in Mumbai in 1948): potatoes, sugar, honey, cacao beans, eggs, leather, blue dye, bricks, glass bottles,
torches, lamps, candles, flint, iron axes, saddles, palm leaves, paper, ink, books. A buyer pays his share of what a
seller asks: made here, its days of work; brought from far, twice that (so carrying goods from where they are made to
where they are scarce pays). He takes two lots a day at full price, then half price, as with goods. Buyers count them
in their own words ("16 sheets of paper", "an iron axe"; new `one` and `many` fields in `products_world.json`). The
talk list shows at most 9 "Sell …" buttons; with more, he says "Sell me these first; then I will look at the rest".

**What they sell.** The trader sells like a merchant (the goods, and 6 kinds of atlas products instead of 8). The
pedlar sells 4 kinds of small atlas products (no bulk goods, no bricks, glass or saddles); his trade screen is "…'s
pack".

**Words.**
- "Who buys goods here?" names the nearest merchant, trader or pedlar ("Ask Ravi, a trader, about 30 m north of here.
 He changes money too.").
- No buyer near: "Nobody near here buys goods. Every town and city has a market, and pedlars go round the villages."
 (was "Merchants keep to the towns and cities").
- No money-changer near: "Nobody near here changes money. A money-changer in a city will, or a trader in a town
 market." (was "Try a bigger town").
- "Tell me about yourself": "I am Ravi, a trader. I buy and sell for the market of this town, and I change money."

**Commands and checks.**
- `/ee shop [merchant|trader|pedlar|paper_seller|news_writer]`.
- `/ee market`: also "Who buys here (village): a pedlar (50 in 100, 2 days' pay a day)." and the atlas products a
 merchant takes, with prices.
- `/ee check all`: 3 new lines ("Buyers: somebody buys in every settled place (2853 sample places in 4 years: 812 town
 traders, 1879 village pedlars, 13 where anybody swaps …)", "Buyers: merchants take 18 atlas products in Bombay in
 1948, always for less than they ask", "Buyers: a town trader changes money keeping 10 in 100 …; where people swap he
 takes coins for goods"); for a player also "Buyers here and now". Console 113, as a player 116.

**New and changed files.**
- Changed: `money/MarketService.java` (roles, terms, `withTrader`, `swapsALittle`, atlas goods, checks),
 `knowledge/MarketTalk.java` (the trader, the pedlar, anybody swapping, atlas goods, the hints),
 `knowledge/TalkService.java`, `money/ShopService.java` (the trader's and pedlar's stock), `money/ProductAtlas.java`
 (`one`, `many`), `civilization/HistoricalPresence.java` (the trader or pedlar of a place), `news/NewsEras.java`,
 `population/SettlementDensity.java`, `villager/PresenceLocalSpawner.java`, `knowledge/KnowledgeLevels.java`,
 `skin/SkinPoolDatabase.java`, `skin/SkinPainter.java`, `villager/VillagerNameDatabase.java`,
 `commands/NewsCommands.java`, `commands/EternalEngineCommands.java` (`/ee market`), `commands/EeOperationalCheck.java`;
 `build_product_atlas.py` and `economy/products_world.json` (`one`, `many`).
- New: `probe_buyers.sh` + `probes/BuyersProbe.java`. `probes/MarketProbe.java`: the merchant's words now go on to the
 atlas products.
- Records: `java_changes_step19g.patch` (16 files, checked with `patch -p1` and `cmp`) and `step19g_java_after.tar.gz`
 (the newest base for those 16 files).

**Tests here.**
- `probe_buyers.sh` (new): 32 passed. Other probes: market 62, purse 72, atlas 31, knowledge 45, calendar 13, talk
 layout 9, screens all passed.
- Test server: `/ee check all` console 113, as the player 116, all passed. In Mumbai 1948: a trader's and a pedlar's
 stock; a pedlar bought 32 sheets of paper for 4 annas 2 pice 2 pies (paper gone from the inventory, the purse up). On
 1 January 1966 a trader changed the old anna rupees (1 rupee 4 annas 1 pice 2 pies) into 1 rupee 14 paise (10 in 100
 kept). In Kothapalle in 3000 BCE a farmer swapped 20 wheat for goods worth a quarter of a day's work, and a trader
 took the player's rupees as metal (goods worth three quarters of a day's work).

**Known limits.**
- In the sandbox's flat test village (Kothapalle 1948) only drawn crowd figures stood, no living people, so the pedlar
 was spawned by command for the test; the village's people list does have the pedlar. Please look for him in a real
 village in your game.
- The pedlar changes no money; old money in a village waits for a town or a city.
- No wages yet (later, with villager jobs).

## Step 20: the history book and the tracker compass (2026-10-14)

The user said "ok and next" (turn 88): after step 19g, the next planned step. The book follows the approved preview 2.

**The history book** (new item `eternalengine:history_book`, given once to every player when they join; `/ee book give`
for more). Right-click opens your notes, kept with the world (any copy of the book is the same book):
- Left page: "Find a name in your book…" (just type), then every name you have heard, in groups (Events, People,
 Groups, Families, States, Places, then other kinds), each with its number of notes, or grey when you only heard the
 name. "N names heard so far".
- Right page, tabs **Notes**, **Journal** and (for a family, or a person of one) **Family tree**:
 - Notes: the kind, the title, and each note with its day, who said it ("Saleem, paper seller", or the paper's name)
 and what they said, the names in it coloured; a name only heard says so and who would know ("Anyone in the street
 can tell you", "The palace clerks would know"); **Track on the compass** with the distance ("about 3.5 km north of
 you"); the linked names you have heard (they open) and how many you have not heard yet.
 - Journal: what you did, by the day: "Learned about The Nizam from Saleem.", "Read The Evening Herald: its names are in
 your book.", "Sold 16 sheaves of wheat for 4 annas 5 pai.", "Bought 16 × Paper for 4 annas 3 pice from Saleem.",
 "Changed … into …", "Set the compass to King Kothi." (200 lines kept).
 - Family tree: the people of the family you have heard of, once someone has told you about the family.
- What comes later shows only with the new setting `historyBook.historyBookTimeTraveller` (off): "Time traveller view".
- The mouse wheel scrolls the page it is over; the arrow keys the right page.

**The tracker compass.** "Track on the compass" in the book, or "Track it on my compass" after a villager says where
something is ("Where does he live?"): your compass points there (Minecraft's own lodestone needle, no lodestone needed)
and is called "Tracker compass: King Kothi Palace". The first time, if you have no compass, you are given one; later any
compass works. While you hold it the action bar says "King Kothi Palace: about 190 km south-west" (once a second), and
"You are at …" when you arrive. "Tracking · Stop" turns it back into a plain compass.

**Commands and checks.**
- `/ee book [card <id> | journal | tree <id> | track <id> | untrack | give]`: opens the book and tells it as text.
- `/ee check all`: 2 new lines ("History book: a player's notes make the book …", "History book: the tracker compass
 can point to King Kothi (about 3.5 km north of Charminar …)"); for a player also "Your history book: N names, M notes,
 K journal lines; tracking …". Console 115, as a player 118.
- **Network version 6** (2 new messages): the game and the server need the same new build (single player does this by
 itself).

**New and changed files.**
- New: `knowledge/BookView.java`, `knowledge/BookService.java`, `news/HistoryBookItem.java`,
 `network/packets/BookViewPacket.java`, `network/packets/BookActionPacket.java`, `client/gui/BookScreen.java`,
 `client/gui/paint/BookPainter.java`; the item's model, picture (from the preview's book icon) and name.
- Changed: `knowledge/PlayerKnowledge.java` (journal, compass target, gifts; saved as format 2, old saves still load),
 `knowledge/TalkService.java` (the journal line, "Track it on my compass"), `news/NewsItems.java`,
 `news/NewsService.java`, `money/MarketService.java` and `money/ShopService.java` (journal lines),
 `network/EternalEnginePacketHandler.java`, `client/ClientKnowledge.java`, `player/PlayerDataManager.java` (the book on
 joining), `core/SimulationEngine.java` (the compass words each second), `config/EternalEngineConfig.java`,
 `commands/NewsCommands.java`, `commands/EternalEngineCommands.java`, `commands/EeOperationalCheck.java`.
- Probes: new `probe_book.sh` + `probes/BookProbe.java`; `probes/ScreenProbe.java` draws the book (notes, the end of a
 long page, a search, the journal, a family tree, an empty book) at 3 screen sizes.
- Records: `java_changes_step20.patch` (21 files: 14 changed, 7 new; checked with `patch -p1` and `cmp`) and
 `step20_java_after.tar.gz` (the newest base for those 21 files).

**Tests here.**
- `probe_book.sh` (new): 11 passed. `probe_screens.sh`: all passed, with 18 new book pictures (`probes/out/screen_book_*`).
 Other probes: buyers 32, market 62, purse 72, atlas 31, knowledge 45, calendar 13, talk layout 9.
- Test server (fake player in Kothapalle, 14 September 1948): reading the day's paper put 5 names in the book (Operation
 Polo, the Nizam, the Razakars, Aurangabad, Suryapet) with notes from "The Evening Herald"; tracking the Nizam gave a
 compass ("about 192 km south-west of you"); the journal had both lines; "Stop" made it a plain compass again; a
 villager's "Where?" answer offered "Track it on my compass", and it worked. `/ee check all` console 115, as the player
 118, all passed.

**Known limits.**
- The sandbox's fake player does not "join" like a real player, so the gift on joining was tested with `/ee book give`;
 please check that you get the book when you join your world.
- The screen and the needle were drawn and checked here without a game window; please look at them in your game.
- Family trees list the people of the family you have heard of; who is whose son is not in the data yet.
- Only names from the knowledge packs (Hyderabad 1948 so far) have a place to track; more come with the card pipeline
 (step 21).

## Turn 89: the user's game log after step 20: the 7.5-second freeze after joining (2026-10-14)

The user sent the Minecraft log of a new world near Hyderabad with steps 19g and 20, without words.

**What the log showed.**
- Good: the history book was given on joining ("You have a history book…"), so the gift on joining works in a real game.
 20 network packets registered (protocol 6), the new settings were written, `/terra timejump 1948` took the date to
 1 January 1948, `/ee check all` gave **ALL 118 CHECKS PASSED** (8 merchants and a money-changer within 96 blocks), and
 the user bought a paper for 12 pai and a map for 96 pai from a paper seller. No error from the mod.
- Bad: the game stood still 7.5 seconds about 9 seconds after joining: "[Spawner] One cycle around dhanush2735 took
 7560 ms: … townspeople 7540 ms … Stood up 4 townspeople; 25 crowd figures", and "World system 'spawner' took 7561 ms".
 The drawn crowd in the same cycle took 11 ms.
- Not tried in that log: selling, swapping, the book screen, tracking (checklist steps 13 and 14).
- Still there: "This land belongs to the Republic of India, ruled by George VI" at Hyderabad on 1 January 1948 (the
 history data fix still waits for a yes).

**The cause.** Every ground look-up of the mod (`TerraBridge.getSurfaceY`, used for people, buildings and armies) went
through `probe()`, which also asks Terra++'s land-cover map what grows there (`getWorldCoverClass`). That call waits up
to half a second (`getClassBlocking(…, 500 ms)`) while the land-cover tiles download. The height never used that
answer. The spawner's first cycle made about 15 such look-ups while the map was still downloading: 15 × 0.5 s = 7.5 s.
By the drawn-crowd part the tiles had arrived, so it took 11 ms. The sandbox showed the same thing: Terra++'s "Elev:"
lines came exactly half a second apart until the land-cover header arrived.

**What changed.**
1. `terrabridge/TerraBridge.java`: the ground height reads only Terra++'s terrain column, never the land-cover map. The
 reflective look-ups (the public API's `surfaceAt`, the density functions' `classify`) are found once instead of on
 every call. `probe()` still asks the land-cover map, for the debug commands only.
2. `villager/PresenceLocalSpawner.java`:
 - one cycle spends at most 50 ms standing people up (the first group is always placed; the rest come in the next
 cycles, 2 seconds apart), so one slow look-up can never cost a whole crowd's wait again;
 - the slow-cycle line now says where the townspeople time went and how long the ground look-ups took: "Townspeople:
 the roles N ms, the crowd plan N ms, finding places N ms, standing people up N ms … N ground look-ups took N ms
 (the slowest N ms)".
3. Test helper (`testmod/…/EeTestHelper.java`, sandbox only): `eetest ground <lat> <lon> <count>` times the new
 look-up against the old one.

**Tests here.**
- Before the fix (the same join near Kothapalle at 3000 BCE): "Can't keep up! Running 8019ms", and the look-ups during
 the join came half a second apart.
- `eetest ground` at a place nobody had visited (16 spots): new way 630 ms in all, the old way with the land-cover map
 2094 ms (the slowest single call 592 ms). The new way's time there was Terra++ loading its height data for a place
 no chunk had been built in yet; around a player that data is already loaded.
- After the fix:
 - joining: the land-cover map was not opened, the same 4 townspeople stood up, no slow spawner cycle; after
 `/ee date 1948 1 1`: no slow cycle, 5 people of 1948;
 - final build, joining and six jumps of 3 km: the land-cover map was never opened and no cycle was slow;
 - one cycle in between, right after a 3 km jump, took 915 ms in "townspeople", but its 126 ground look-ups took
 0 ms, so it was not the look-ups. It did not come back in the six jumps of the final build (most likely a
 one-off pause of Java in this small sandbox). The new breakdown in the line will show it if it happens in a game;
 - `/ee check all`: console 115, as the player 118, all passed.
- Records: `java_changes_turn89_freeze.patch` (2 files, checked with `patch -p1` and `cmp`) and
 `turn89_java_after.tar.gz` (the newest base for `TerraBridge.java` and `PresenceLocalSpawner.java`).

**Known limits.**
- The sandbox's Terra++ build is older than the user's. If the user's build has the public `surfaceAt` method, the mod
 uses that instead, and its speed cannot be measured here. If a freeze still happens, the new "[Spawner]" line says
 where the time went.
- The later "Can't keep up" lines after the time jump (6.6 s and 4 s) were not named in the log. If they were the mod's
 look-ups they are fixed too; if they were Terra++ rebuilding chunks for 1948, they are Terra++'s own.

## Step 21: people stay while you talk or trade, with four fixes from the plan (2026-10-14)

Turn 97, the first "next" after the defaults of turn 96. Step 21 of `SYSTEMS_PLAN.md` part 5, with the small fixes
planned beside it:
- map positions (known problem 2);
- Minecraft's own mobs (D19, default 10);
- first years for technologies and vehicles (known problem 3);
- the slow refill after a long jump, looked into (known problem 5);
- a slow crowd cycle, found and fixed (known problem 6).

**What changed.**
1. People stay while you talk or trade (`knowledge/TalkHold.java`, new):
 - **How long:** a person is held from the right-click until Goodbye, until you are more than 8 blocks away, or after
 2 minutes of game time without an action in the talk or trade screen. Logging out lets go too.
 - **Removals:** every way the spawner removes people goes through one place (`PresenceLocalSpawner.remember`), which
 now leaves a held person alone. That covers the vanilla despawn, the district's edge, a place where nobody lives,
 another year's people, an event's end, and being far from every player. The person goes on a later cycle if the
 reason still holds.
 - **Facing:** a held person stops and looks at you (with its AI on, through the look control; a figure is turned
 directly).
 - **Crowd figures:** a figure you talk to becomes a townsperson at once (`PresenceLocalSpawner.adoptFigure`):
 - it keeps the same body, face and place, and gets the name you hear;
 - its AI is switched on, it is no longer invulnerable, and it is tagged with its year and district;
 - it stands where you met it, so the district's edge does not take it;
 - it leaves the way townspeople leave, into the place's memory;
 - the crowd code handles figures only, so it never moves this person again, and a figure that is somehow held is
 skipped by the crowd too.
 - **No doubles:** the same person never stands twice. A remembered person whose UUID already stands in the world is
 not put back (`standPerson`, `VillagerVirtualizer`); this can happen when a met person's place in the crowd stands
 them up again as a figure.
 - **Never a silent close:**
 - if the person is gone, the talk box says "… has left." and offers only Goodbye (`TalkView.ended`, `TalkLayout`,
 `TalkScreen`, `TradeScreen`, `ClientKnowledge`);
 - the server answers an action for somebody gone or out of reach the same way (`TalkActionPacket`);
 - walking away closes the box, with "You walked away from …" on the action bar;
 - network protocol 7.
2. Map positions (`terrabridge/TerraBridge.java`):
 - map position → block now uses the world's own projection first: Terra++'s density functions, which the generator
 builds the land with. Terra++'s public API is used only if its answer survives a round trip.
 - `toGeo` also asks the density functions first, and the reflective look-ups are found once, not on every call.
 - Everything that turns a map position into a block was wrong in the user's game and is now right: the people of a
 named place (the site's centre), the tracker compass, the map's waypoints, a VIP's arrival, a capital.
 - One visible change: within 128 blocks of a named site, the townspeople now gather at the site itself, as step 17
 meant. Until now the site always seemed thousands of km away, so the district near the player was used.
3. Minecraft's own mobs (`population/MinecraftMobs.java`, new):
 - **Settings:** `[minecraftMobs]` in `eternalengine-common.toml`: `minecraftMonsters`, `raidsAndPatrols` and
 `wanderingTraders`, all false.
 - **Stopped before they exist:** the natural spawner never picks a monster.
 - **Stopped as they spawn:** patrols, a raid's waves, phantoms, zombie sieges, reinforcements, structure monsters,
 the skeleton trap horse, and the wandering trader with his llamas.
 - **No raids:** nobody gets the Bad Omen, so no raid can start.
 - **Not touched:** spawn eggs, spawners, `/summon`, breeding and conversions; the Nether and the End.
4. First years (`technology/`, `vehicle/`):
 - The 7 technologies of the old engine have their first known year and place, and are never unlocked earlier:
 agriculture 9500 BCE, writing 3200 BCE, steel 1800 BCE, the printing press 1440, steam power 1712, electricity
 1882, computing 1945.
 - Moving the date back takes later technologies away.
 - `/ee tech list` shows the years, and `/ee tech unlock` refuses an early one.
 - Vehicles have first years too: steamship 1807, train 1825, car 1886, lorry 1896, aeroplane 1903, motor cargo ship
 1912, tank 1916, helicopter 1936.
 - The industrial era now begins in 1800. It began in 1500, which allowed a train in 1600.
5. The slow refill after a long jump (known problem 5), looked into:
 - once the ground is there, the spawner stands a city's 40 people in 6 seconds (3 cycles); the wait is for the
 chunks.
 - New: one line per cycle about the townspeople, in the log when `debugLogging` is on. Example: "[Spawner]
 Townspeople around …: have N of M; stood up K …; spots refused: chunk not loaded …, a player's bubble …, no ground
 …, too close to another group …".
6. The slow crowd cycle (known problem 6), found and fixed (`population/CrowdFigures.java`):
 - **The cause:** a refused place did not use up the cycle's budget of 32. So wherever there is no ground (a lake,
 the sea; in the sandbox, land beyond the laid ground), every place of every chunk in view was looked up each
 cycle, and a place with no ground was looked up once more for every figure waiting to be moved.
 - **The fix:** each place is looked up once, places with no ground are skipped for 5 minutes, and a cycle gives up
 after 256 refused places.
7. Also fixed: on a dedicated server, the client dressed everybody for the year 400. It has no clock, and it did not
 read "year_1948". Figures now carry their year too (`client/SkinTextures.java`, `CrowdFigures.stand`).
8. `/ee check all`: 4 new lines.
9. Test tools (sandbox only):
 - new helper commands: `eetest hold figure|person`, `held`, `bye`, `mobs`, `jumpground`, `refill`;
 - `run_test_server.sh` takes `EE_SPAWN_MONSTERS=1`;
 - `probes/TalkLayoutProbe.java` checks the closing view on 15 screen sizes.

**Tests here.**
- Build: Gradle OK.
- Probes:
 - buyers 32, book 11, market 62, purse 72, atlas 31, knowledge 45, calendar 13, screens all passed;
 - talk layout 10 (was 9): the new check is the closing view on 15 screen sizes, picture
 `probes/out/talk_480x270_has_left.png`.
- `/ee check all`: console 119, as the player 122 (121 when no crowd figures stand around the player), all passed.
 The new lines:
 - the talk hold rule;
 - map positions: 435 places (35 named on every continent, 400 random) go to a block and back within 1 m. Charminar is
 block 10,071,572, −2,022,547 and King Kothi 10,070,410, −2,026,016, exactly the blocks measured outside the game in
 turn 93;
 - Minecraft's mobs: made-up spawn events posted on Forge's bus (a zombie, a patrol pillager, a wandering trader, a
 spawn-egg zombie, a Bad Omen);
 - technology over the 7 years of the world-wide test set.
- Test server, fake player at Bombay (18.94, 72.83) in 1948:
 - the helper's position check: "the mod reads block 9431681 −1894966 as 18.9400, 72.8300". Before, it needed Newton
 steps to work around the mismatch.
 - Talking to a crowd figure (Sam Stone):
 - it became a townsperson at once (figure false, townsperson true, met, AI on, not invulnerable) and was held;
 - 20 s later (10 cycles, the player standing still) it was still there, moved 0.0 blocks, head 0° off facing the
 player.
 - `/ee date 1949 1 1` while held: still there. After Goodbye it left on the next cycle (a 1948 person in 1949), and
 the place remembered it.
 - A townsperson held and left alone: after 2,400 game ticks (about 3 minutes here) no longer held, and still standing
 there.
 - Refill after a plain 3 km jump (no ground laid there, as in turn 89):
 - first cycle: "no district yet" (chunks loading);
 - every cycle after: "no ground 13", so nobody stood up, not even figures.
 - After `eetest jumpground` (ground laid as Terra++ would build it): 14, 28 and 40 townspeople at +2, +4 and +6 s;
 32 more figures each cycle.
 - Monsters (a second session with `EE_SPAWN_MONSTERS=1`, Normal difficulty, midnight):
 - setting off: 0 monsters after 60 s (741,914 natural spawn attempts refused);
 - setting on: 71 monsters in 45 s (creepers, skeletons, spiders, zombies, endermen);
 - off again: 0 after 45 s;
 - the 40 townspeople were not touched by Peaceful, and `/summon minecraft:zombie` worked with the setting off.
 - The slow cycle:
 - session 1 (before the fix) had one cycle of 257 ms right after the player moved 40 blocks: "the drawn crowd
 254 ms … 20803 ground look-ups took 156 ms … 0 crowd figures stood up";
 - session 2 (after the fix), with the same moves and a jump to land without ground: no slow cycle; the spawner
 averaged 0.066 ms per tick.
- Records:
 - `java_changes_step21.patch`: 27 files, 2 new, checked with `patch -p1` and `cmp`;
 - `step21_java_after.tar.gz`: the newest base for those files.

**Known limits.**
- Not seen here: the talk and trade screens (the fake player has no screen). "… has left.", walking away and the
 turning are for the final test (`TEST_CHECKLIST.md` step 15); their server side was tested.
- The test server removes villager-type mobs itself (`spawn-npcs=false`), so a summoned wandering trader vanished there.
 That is the server setting, not the mod.
- Every dimension is read with the prime projection: a mirror universe would turn east and west the wrong way for the
 mod (step 51).
- Crowd figures' names fall back to an English list where the language map has no answer: a figure on the Bombay coast
 in 1948 was "Sam Stone" (step 30b, step 38).
- After a long jump in a real game, townspeople come once Terra++ has built the chunks. How long that takes can only be
 measured with the user's Terra++ (step 57).

## Step 22: the history book is bought from villagers, in the form of the place and year (2026-10-14)

Turn 98, "next". Step 22 of `SYSTEMS_PLAN.md` part 5 (system E13), from the turn-90 wish "the history book bought from
a villager".

**What it does.**
- A new player gets **no** book. The chat says once: "What people tell you and what you read goes into your notes. To
 read them, buy a history book from a seller in the market; anybody can tell you where." The setting
 `historyBookOnJoin` (under `[historyBook]`, default `false`) gives the book on joining, as in step 20.
- The notes are kept with or without a book. Reading them (right-click, `/ee book`, the book's buttons) needs a history
 book anywhere in the inventory. Operators may always read them (for tests).
- The book comes in the form people keep notes in at that place and year: 13 forms, one item each. All of them read the
 same notes. The name is "<form> (history book)", e.g. "Papyrus roll (history book)", with its own picture and
 description.

| Form | Where and when (examples) | Price in days of pay |
|---|---|---|
| Notebook (paper) | China from about 105, the Islamic world from 751–794, Spain 1150, France 1300, northern Europe 1350, India, Mexico from 1521; everywhere by 1900 | 1 before 1800, 0.3 to 1900, 0.1 after |
| Parchment book | Europe, West Asia, North Africa, Ethiopia | 3 |
| Palm-leaf book | South and South-East Asia (first choice in south India and Sri Lanka until 1850) | 0.3 |
| Birch-bark book | Russia (Novgorod), Kashmir and Gandhara (first choice until 1600); never south of 23°N | 0.1 |
| Bark-paper book | Mexico and Central America, 75–1600 (new atlas product) | 0.5 |
| Papyrus roll | Egypt, the Greek and Roman world | 1 |
| Bamboo slips | China, about 1250 BCE to 400 (new atlas product) | 0.5 |
| Wax tablets | West Asia from 1300 BCE, Greece and Rome, Europe until 1600 (new atlas product) | 0.5 |
| Clay tablets | Mesopotamia and its neighbours; Crete and Greece 1800–1200 BCE | 0.1 |
| Rune sticks | Scandinavia 800–1400; the Norse farms of Greenland 985–1450 | 0.05 |
| Knotted cords | the central Andes (2600 BCE to 1900) and the Pacific islands, where nobody writes | 0.1 |
| Message stick | Australia, where nobody writes | 0.05 |
| Tally stick | anywhere else where nobody writes | 0.02 |

- **How the form is chosen** (`news/BookForms.java`): the product atlas says whether the material is made or brought at
 the place and year (paper, parchment, papyrus, palm leaf, birch bark, clay tablets, and the three new ones). On top
 of that come 13 local rules for what the atlas's 17 areas are too coarse for:
 - writing side: the Norse farms of Greenland; Crete and Greece; Scandinavia; south India and Sri Lanka; Kashmir and
 Gandhara; no birch south of 23°N; paper going north in Europe (Spain 1150, France 1300, the north 1350); inland
 eastern and southern Africa (more than 2° from both coasts) writes only from 1880 (the Swahili coast and Ethiopia
 long before); the West African forest kingdoms from 1800 (the Sahel towns long before); the court of Kongo writes
 Portuguese 1500–1699;
 - memory aids: the Andes outline (knotted cords); Australia (message stick); the Pacific (knotted cords).
 The best form is the most book-like: paper, then parchment, palm leaf, birch bark, bark paper, papyrus, bamboo, wax,
 clay.
- **Who sells it** (`ShopService.bookLots`):
 - a merchant or trader sells up to 3 forms (always including the cheapest);
 - a pedlar sells the cheapest;
 - a paper seller sells the notebook (the best form where there is no paper yet);
 - a newsletter writer sells the best form of the place (the notebook in most places, a palm-leaf book in south India
 before 1850);
 - where nobody writes, they sell the memory aid.

 The price is days of pay × a day's pay, in round money of the place. The book comes in the list right after the
 goods, before the local products, so it always fits in the 24 offers. A form you carry shows as owned ("You have
 that already.").
- **Asking where** (`NewsTalk.notesView`): people who sell nothing get a new question while you have no book, right after
 "Tell me about yourself.": "Where can I get something to keep notes in?". The answers:
 - you have a book: "You have your notebook already.";
 - a seller within 96 blocks: "Vyapari Suresh Trivedi, the merchant, sells notebooks, about 30 m east of here." (and
 the hint line);
 - nobody near: they give you the memory aid of the place: "Nobody near here sells such things. In the towns they
 sell notebooks. Take this tally stick: cut a notch for each thing you want to keep. That is how we remember." It
 goes into your journal too.
- **Commands:** `/ee book forms [lat lon year]` lists the forms, sellers, prices and the memory aid (where you stand,
 or anywhere; also from the server console). `/ee book give [form]` is for operators. `/ee book` without a book says
 "You have no history book. Your notes are kept (… names); buy a book from a seller to read them."
- **Atlas** (`build_product_atlas.py`): now 132 products (21 with items). New: bark paper (Mexico and Central America,
 75–1600), bamboo slips (East Asia, 1250 BCE to 400), wax tablets (West Asia, Europe, North Africa). Paper in Mexico
 is now brought from 1521 and made from 1580 (it was "made from 500 BCE", which mixed it up with bark paper).
- **Pictures:** 12 new 16×16 item pictures in the style of the step-19/20 items, drawn by `tools/draw_book_forms.py`
 (run it again to redraw them).

**Files.**
- New: `news/BookForms.java` (476 lines: the forms, the rules, the sellers, the prices in days, 32 test places, a
 census of random places).
- Changed:
 - `news/HistoryBookItem.java` (one class for every form) and `news/NewsItems.java` (13 items);
 - `knowledge/BookService.java`: no gift on joining; `give(player, form)`, `carried`, `carries`, `mayRead`, `noBook`;
 - `knowledge/NewsTalk.java` and `knowledge/TalkService.java`: the question and its answers;
 - `money/ShopService.java`: book offers, price, "Bought a papyrus roll (history book) …";
 - `commands/NewsCommands.java` (`forms`, `give <form>`, the read rule), `network/packets/BookActionPacket.java` (the
 read rule);
 - `config/EternalEngineConfig.java` (`historyBookOnJoin`);
 - `commands/EeOperationalCheck.java`: 3 new check lines.
- Resources: `lang/en_us.json` (13 names), 12 item models, 12 pictures, `products_world.json`.
- Tests: `probes/BookFormsProbe.java` + `probe_bookforms.sh` (new); `probes/TalkLayoutProbe.java` (the notes answer
 drawn on 15 screen sizes); the test helper's new commands `eetest plain <command>` (as a player without operator
 rights), `eetest book [welcome|drop]`, `eetest shop [buy]`, `eetest notes`.

**Tests.**
- Probes (no server): book forms **40 passed, 0 failed** (13 forms, 32 test places, 2,800 random place-years all with
 a form at 0.03 ms each, writing at 22 of 400 points in 3000 BCE and 400 of 400 in 1948, 17 seller cases, prices,
 edges such as the poles, the date line and no place at all). Unchanged: atlas 31, book 11, market 62, buyers 32,
 purse 72, knowledge 45, calendar 13, talk layout 10, screens all OK.
- The first run of the new probe found three mistakes, fixed before the server test:
 - Great Zimbabwe 1300 got a notebook (the atlas's East Africa area includes the Swahili coast): now a tally stick,
 with the inland rule;
 - Norway 1200 got paper (the atlas has paper in all of Europe from 1150): paper now goes north slowly;
 - London 1800 still sold wax tablets: they end in Europe in 1600.

 A look at more African places then found the forest kingdoms (Benin, Ife, Kumasi) with notebooks and the court of
 Kongo with nothing; both rules were added, with Benin, Kano and Mbanza Kongo as new test places.
- Test server, session 1 (setting off):
 - `/ee check all` from the console: **122 passed, 0 failed**. As the player with crowd figures around: **125
 passed, 0 failed**.
 - New player: no book, the welcome logged once ("eetest_watcher is new: told where to buy a history book (none
 given)"); a second welcome did nothing.
 - `/ee book` as a player without operator rights: refused with "You have no history book. Your notes are kept (0
 names) …".
 - Bombay 1948, merchant Vyapari Arjun Yadav: offer 11 of 19 (right after his 10 goods) "Notebook (history book)" for 1
 anna 2 pice 1 pie. Bought: "Bought a notebook (history book) for 1 anna 2 pice 1 pie. Your purse: 14 annas 2 pies
 (Indian rupee). Right-click it to read your notes." Then `/ee book` opened ("History book, your notes, Thursday,
 1 January 1948"); the offer showed "owned"; buying again: "You have that already."
 - Asking a money-changer: with the book, 8 questions and "You have your notebook already."; without it, 9 questions
 with the new one as number 7, and "Vyapari Suresh Trivedi, the merchant, sells notebooks, right here."
 - With every seller near turned into a farmer (`/data`): "Nobody near here sells such things. In the towns they sell
 notebooks. Take this tally stick: cut a notch for each thing you want to keep. That is how we remember." The tally
 stick was in the inventory and opened the notes.
 - Rome AD 100: merchant Emporos Nikos Cornelius sold a parchment book (3 denarii 2 sestertii), a papyrus roll (1
 denarius 3 asses) and wax tablets (2 sestertii 2 asses). With Indian rupees: "We don't take the Indian rupee
 here. A money-changer will change it for you."
 - Cahokia 1100: a citizen had the question as number 4 of 6 and sent the player to "the merchant, sells tally sticks,
 about 5 m north-west of here"; the merchant's list had "Tally stick (history book)" for "goods worth less than a
 quarter of a day's work".
- Test server, session 2 (a fresh world, `historyBookOnJoin = true`):
 - the new player got the notebook; `/ee book give papyrus` worked, `give scroll` listed the 13 forms;
 - from the console: `/ee book forms` for Cusco 1500 (knotted cords), Ur 2500 BCE (clay tablets, 1 grain of
 silver), London 1300 (parchment book 5 pence 1 farthing, wax tablets 1 penny), Sydney 1700 (message stick), Benin
 1500 (tally stick, 4 cowries); `/ee book` from the console: "Only a player has a history book.";
 - `/ee check all` from the console: **122 passed, 0 failed** (the first line then says "given on joining").
- No errors in either session's log apart from Terra++'s usual startup notice.
- Records:
 - `java_changes_step22.patch`: 25 text files, 13 of them new; checked with `patch -p1`, then compared with the new
 files;
 - `step22_java_after.tar.gz`: all 37 files, the pictures included.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 15–19).
- The item pictures, the tooltips and the welcome line can only be seen in a real game (the fake player has no screen).
- The forms follow 17 atlas areas plus 13 local rules. A finer spread (paper in Tibet, Korea or Java; Maya books by
 city) comes with the technology atlas (step 30a).
- The talk box shows 9 questions. A money-changer in Bombay used all 9 with the new one; a person with news on top would
 lose the last question ("Where can I get the news?"). Step 24 moves trading to Minecraft's screen, which frees room.
- Seen on the way, for later steps:
 - in Rome AD 100 the townspeople's civilization label was "republic_of_italy" (names, dress and money were right):
 step 25;
 - nobody lives at Sydney in 1700 (the settlement data starts in 1788): step 38;
 - Cahokia's people had names like "Citizen Rauha of Cusco" and "Sam Stone" (known problem 8): steps 30b and 38.

## Step 23a: real money for every region and era (2026-10-14)

Turn 99, "next". Step 23 of `SYSTEMS_PLAN.md` part 5 has two halves, and this is the first: system E2, "real money where
the data has only placeholder money", for every region at once. The second half, money you can hold (coins, notes,
shells, weighed metal as items, paying with them), is step 23b, the next "next". The data had to come first: the
items need to know which money and which coins each place and year had.

**What was wrong.** The money table (step 19a) knew 41 kinds of money: India, the ancient Near East and the
Mediterranean, western Europe, China, Japan, the USA, Spanish America before 1860, West Africa's cowries and a few
more. Everywhere else it said "silver and copper coins" (600 BCE to 1799) or "local money" (from 1800): Italy, the Low
Countries, Scandinavia, Poland, the Balkans and Persia before 1800; Brazil, Argentina and most of Latin America after
1860; the Soviet Union and the countries after it; Pakistan, Bangladesh, Sri Lanka, Burma; all of Africa after 1800;
South-East Asia; the Middle East after the Ottomans; Canada, Australia's dollar, the Pacific. Measured with the new tool
(below), **41.5% of all people** over the years, and **51.7% of the world's people in 2026**, got a placeholder.

**What it does now.**
- **401 kinds of money** (was 41) in **1,006 rows** (was 69), with **124 fixed rates** (was 25). Every region and era
 has its money, with its coins and a labourer's day's pay:

| Region | Examples (money, and a day's pay) |
|---|---|
| Europe before 1800 | Viking weighed silver (0.3 ørtug); the Scandinavian mark (Oslo 1200: 5 penninge); homespun cloth in Iceland (2 ells); the Italian lira of account (Venice 1400: 10 soldi), the Neapolitan ducat, the Papal scudo; the Castilian maravedí, the Aragonese diner, the Portuguese real; the Dutch guilder (Amsterdam 1700: 16 stuivers); the Polish grosz and złoty; the Hungarian denár; the Rus' grivna (Kyiv 1100: 1 rezana) and the Muscovite denga |
| Europe from 1800 | every currency to today: the lira, peseta, escudo, franc, mark (East and West), schilling, krone, krona, markka, złoty, koruna, forint, dinar, drachma, lek, lev, leu; the Soviet ruble (Moscow 1970: 4 rubles) and all 15 currencies after it; the euro with each new member (Croatia 2023, **Bulgaria 1 January 2026**) |
| Middle East and North Africa | the Persian siglos (Persepolis 500 BCE: 6 grains of silver) and drachm; the Carthaginian shekel; the Maria Theresa thaler; the Egyptian, Syrian, Lebanese and Palestine pounds; the Israeli pound and shekels; the dinars, riyals and dirhams of the Gulf; the Iranian rial; the Turkish lira (old and new); the Algerian budju, Tunisian rial and Moroccan mithqal before the francs |
| Africa south of the Sahara | manillas (Calabar 1800: 3 manillas, cowries taken as small change); nzimbu shells in Kongo; salt bars and thalers in Ethiopia; cut silver in Madagascar; the Cape rixdollar; the West African pound, CFA franc, East African shilling, Congo franc, escudos, rand, and every currency since independence to the naira (Lagos 2026: 6000 naira) and Zimbabwe's ZiG (2024) |
| Asia | Pakistan's rupee in annas, then paisa; the taka; the Ceylon rupee; Nepal's mohur; the Tibetan tangka (Lhasa 1900: 1 sho 6 skar); Burmese weighed silver and the kyat; the Siamese tical with cowries (Bangkok 1800: 1 salueng); Vietnamese cash (Hanoi 1500: 40 văn), the piastre, the đồng; Korean mun, yang and won (Seoul 1800: 3 jeon); the Taiwan, Hong Kong and Macau monies; the Bukharan tanga; Javanese mas, the Indies guilder and the rupiah |
| The Americas | colonial Brazil's réis (Rio 1750: 2 tostões 10 réis) and every Brazilian money to the real; the Plata, Chile, Peru, Bolivia, Colombia, Venezuela (to the bolívar digital), Ecuador (the dollar from 2000), Central America and the Caribbean; Canada (the made beaver of the Hudson's Bay posts, the Halifax pound, the dollar); Hawaii; Russian America |
| Oceania | the Australian and New Zealand pounds and dollars; the kina, the Fijian dollar, the CFP franc, the vatu |

- **No money at all** is an honest answer too: barter where people swapped (the Inca, the steppe, Australia before
 1788, Joseon Korea before copper cash spread in 1678), and Cambodia under the Khmer Rouge (1976–1979), which
 abolished money.
- **A day's pay of the place.** A money used by richer and poorer places (the euro, the US dollar abroad, sterling,
 francs, marks and lire in the colonies, Australian money in the Pacific) now pays what people earned where they used
 it: 75 rows carry their own wages. Bulgaria 2026 pays €38 a day, not the €110 of the old members; Quito 2010 pays
 $9.38; Colombo 1850 pays 4–6 pence in sterling.
- **2025 and 2026.** The ruler register stops in 2024. Later years now ask it about 2024, so the money of 2024 carries
 on, and changes after it are their own rows (the euro in Bulgaria from 2026).
- `/ee check all` has a new line: "Money of the world: 401 kinds of money in 1006 rows; 121 test places right (Oslo
 1200 the Scandinavian mark, Lhasa 1900 the Tibetan tangka, Calabar 1800 manillas, Bangkok 1800 the Siamese tical,
 Phnom Penh 1977 no money, Lagos 2026 the naira, Sofia 2026 the euro...); 704 settled random answers in 10 years: 499
 real money, 205 barter, 0 placeholder; 105 kinds of money met; in 61 ms".

**How it was built.**
- `money_world.py` (new) holds the world layer; `build_money_table.py` merges it, checks that every ruler name exists
 in the register, and checks units, rates and wages. Rows match by the register's ruler where it is reliable, by box
 where it is not (colonies lumped together, gaps), and by both where one ruler name covers several monies ("British
 Africa", "French Africa", the Portuguese colonies).
- Unit systems and dates follow Wikipedia's currency articles (checked for the less known ones: old Siam, old Burma,
 Nepal, Tibet). All 1,729 currencies of Wikidata with their dates were downloaded once (`sources/money/`), and the new
 monies were compared with them: 229 have a same-named Wikidata currency; 87 differed, of which 5 were real mistakes
 (fixed: the Solomons, the British West Indies dollar, Sudan before 1834, South West Africa before 1923, Equatorial
 Guinea's ekwele) and the rest were old and new forms merged under one name or a later legal date.
- `money_coverage.py` (new) asks the table, the way the game does, for every land cell of the register in 24 years,
 weighted by land and by people (the HYDE grid): **placeholders for people went from 41.5% to 0.0%** (at most 0.2%
 in any one year; 2026 from 51.7% to 0.0%); **for land from 45.8% to 0.1%**: lakes and empty islands, which keep the
 fallback on purpose, like the open sea. The report is `money_coverage_report.json`.
- Day's pay numbers are estimates (marked so in the data). Hyperinflations are followed only by yearly anchors.

**Mistakes the checks found and fixed during the step.**
- Rows that matched "this ruler or this box" gave the box the ruler's high priority: Algeria's box beat Morocco's ruler
 at Casablanca, Burma's box covered Bangkok, Uruguay's box covered Buenos Aires, Poland's box covered Prague. The box
 part of such a row is now a row of its own at box level, and a smaller box beats a larger one.
- The register names the Soviet Union for occupied Eastern Europe in 1946 and for Czechoslovakia from 1968 to 1991;
 Soviet money now applies only inside the Soviet Union's borders, and those places keep their own money.
- The register gives Saxony to the Polish–Lithuanian Commonwealth under its Saxon kings (Leipzig kept the thaler), and
 Palestine in 1940 to "British Africa" (it had the Palestine pound); both fixed with boxes. Geneva and Basel, whose
 half-degree cells are French, have small boxes of their own; Lhasa under the Qing keeps the Tibetan tangka.
- Seven fixed rates had wrong units (the Australian and New Zealand pounds to dollars, hwan to won, the Halifax pound,
 the Cypriot pound and the Maltese lira to the euro, the first CFA franc).
- French overseas places kept the old franc after 1959; Amsterdam got the wages of Java (the Dutch Indies row); the
 grivna had no unit below the rezana (the veksha, 150 to the grivna, was added); the open sea in the Atlantic fell
 inside the Americas' barter box.
- At two changes of money the wages did not meet (Romania 2005, Peru 1991); the probe now checks 32 changes of money
 at their places across the official rate.
- The world map (`pictures/money_world.png`, drawn by `tools/draw_money_map.py`: every land cell coloured by its money
 in 1300, 1800 and 2026) showed three over-reaches, fixed after the server session: Sakhalin had no money named (now
 barter); all of Australia had sterling in 1800 (now New South Wales and Van Diemen's Land only, the north barters
 until 1869); Algeria's budju covered the Sahara (now the coastal Regency).

**Files.**
- Mod: `money/MoneyTable.java` (the 2024 rule, a day's pay per row, one shared way of reading pay anchors);
 `money/MoneyPlaces.java` (new: 121 test places, the census of settled random points, the self-test);
 `commands/EeOperationalCheck.java` (the new check line); `data/eternalengine/eternal/economy/money_table.json`
 (rebuilt, 478 KB).
- worldfill: `money_world.py` and `money_coverage.py` (new), `build_money_table.py` (merges and checks),
 `money_coverage_report.json`, `sources/money/wikidata_currencies.tsv` and `.rq`, `tools/draw_money_map.py` and
 `pictures/money_world.png`, `probes/MoneyWorldProbe.java` +
 `probe_moneyworld.sh` (new), `probes/PurseProbe.java` (Oslo 1200 and 900, Leipzig 1800), `probes/MarketProbe.java`
 (at least 25 rates), `logs/step23a_server_session.txt`.

**Tests.**
- Probes (no server, on the final table): money world **14 passed, 0 failed** (the table, its own check, 121 places,
 the census with 0 placeholders, 2025 and 2026, all 1,006 rows pay a day in words, 173 rate pairs there and back, 32
 changes of money);
 purse **74** (2 new places); market 62, buyers 32, book forms 40, atlas 31, book 11, knowledge 45, calendar 13, talk
 layout 10, screens all OK.
- Test server:
 - `/ee check all` from the console: **123 passed, 0 failed**; as the player: **126 passed, 0 failed** (the session
 ran on the table before the three map fixes: 1,004 rows, 501 real money and 203 barter in the census).
 - `/ee money at …` for 28 places: Oslo 1200, Iceland 1100, Venice 1400, Amsterdam 1700, Kyiv 1100, Moscow 1970,
 Varna 2026, Persepolis 500 BCE, Calabar 1800, Antananarivo 1850, Addis Ababa 1600 and 1900, Lagos 2026, Bangkok
 1800, Hanoi 1500, Phnom Penh 1977, Lhasa 1900, Seoul 1800, Rio 1750, Buenos Aires 1990, York Factory 1750, Montreal
 1950, Quito 2010, Port Moresby 2000, Karachi 1955, Batavia 1750: all as in the table above.
 - With the player and real townspeople: Ikeja (Lagos) 2026, 41 townspeople, a merchant with 19 offers in naira (bread
 600, a notebook 600, an iron axe 4800); the start money "You start with 6000 naira (Nigerian naira), about a day's
 pay here."; Varna 2026 in euros (a notebook €3.80); Oslo 1200 in penninge (rune sticks 1 penning); Calabar 1800 a
 pedlar in manillas; Rio 1750 in réis (bread 1 vintém 1 real); Moscow 1970 in rubles (bread 40 kopeks). With naira
 in the purse elsewhere: "You have nothing people here take."
- Records: `java_changes_step23a.patch` (the 4 files of the mod, 1 new; checked with `patch -p1`, then compared) and
 `step23a_java_after.tar.gz`.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 20–24).
- The register's half-degree cells cannot tell some twin cities apart (Kinshasa and Brazzaville are 5 km apart, both
 get the CFA franc); Geneva and Basel are fixed by hand.
- Other parts of the game still see the register's odd names (the Soviet Union in Prague 1980, "British Africa" in
 Jerusalem 1940); the money rows work around them. The history data fix is step 25.
- Hyperinflations (Germany 1923, Hungary 1946, Zimbabwe 2008, Venezuela 2018) jump between yearly anchors.
- Commodity money is coarse: at Calabar a day is 3 manillas, so small things cost 1 manilla. Smaller pieces come with
 the items (23b) and swapping goods with the trade screen (24).
- One money per place (with a few "also taken"); ports where rupees, thalers and dollars passed side by side show the
 main one.

## Step 23b: money you can hold (2026-10-14)

Turn 100, "next". The second half of step 23 in `SYSTEMS_PLAN.md` part 5: system E1, "money as things you carry".
Until now the purse was a number. Now money is **pieces in the inventory**: coins, notes, cowries, cacao beans, cut
silver, manillas, salt bars, cloth, beaver pelts. People pay with them, get change back, are paid in them, and change
them at the money-changer. This is what the user asked for in turn 90 ("physical money for every location and time"),
and turn 96 default 8 ("loose coins").

**What the player sees.**
- The start money (a day's pay of the place) comes as pieces: in Bombay in 1948, "You start with 15 annas 3 pice
 (Indian rupee)", as six pieces: 8 annas, 4 annas, 2 annas, 1 anna (nickel coins), 2 pice and 1 pice (copper).
- Each piece is an item with its own name and picture: "1 anna (Indian rupee)", "20 euros (euro)", "3 manillas",
 "100 mon (Japanese mon)", "1 shekel of silver". Equal pieces stack (up to 64). The tooltip names the money.
- Buying hands pieces over and gives change. The notebook in Bombay 1948 costs 1 anna 2 pice 1 pie: the player pays
 1 anna, 2 pice and 1 pice, and gets 2 pies back. In Varna 2026 the €3.80 notebook is paid with the €5 note alone
 (€1.20 back), not with €2 + €1 + €5.
- Selling to a merchant brings pieces: 16 sheaves of wheat in Bombay 1948 bring 4 annas, 1 pice and 1 pie.
- The money-changer takes all pieces of one money and gives pieces of another: in Moscow 2026, 38 euros become
 373 rubles (200 + 100 + 50 + 20 + 2 + 1). The shop there first says "That is 120 rubles. We don't take the euro here. A
 money-changer will change it for you."
- `/ee purse` lists the pieces: "Pieces you carry: 1 x 8 annas (Indian rupee), ...". `/ee purse add` gives pieces;
 `/ee purse reset` also takes the pieces away.
- Where people swap goods (barter) there is no money to hold: the purse stays a written tab, "goods worth about 1 day's
 work". Swapping goods for goods comes with the trade screen (step 24).
- Pieces are real items: they can be dropped, put in chests, lost when you die, and given to other players.

**Which pieces a money has** (`money/Denominations.java`). For each money and year the pieces follow its own units:
- For each unit a run of 1, 2, 5, 10, 20, 50 of it. Where the next unit is a power of two of it the run is 1, 2, 4, 8
 (16 annas to the rupee). Where it is 12 the run is 1, 2, 3, 6 (12 pence to the shilling, 12 pai to the anna). A run
 never reaches the next unit.
- Nothing above 20 days' pay before 1914, nor above 5 days' pay from 1914. Each unit itself always has a piece (a gold
 daric, a load of cacao).
- Pieces worth less than 1/2000 of a day's pay are left out (the kobo, and the 1 and 2 naira, in Lagos 2026). So is a
 smallest piece that does not go into every bigger one (20 lipa next to 50 lipa). Prices, the start money, merchants'
 offers and the money-changer's offers are rounded to the smallest piece. So every amount can be paid exactly and
 change always comes out exact.
- Weighed money also gets tenths of its smallest weight (0.1, 0.2 and 0.5 kite of copper in Egypt).

**What a piece looks like.** 16 looks, one item each, drawn by `tools/draw_money_items.py` (our own pixel art, no
photos of real coins). Ordinary coins and notes follow the value in days of pay and the time:
- **Before 1914:**
 - gold for named gold coins (aureus, solidus, daric, mohur, ducat...) and, from 1500, for a unit worth 6 days or
 more and its multiples;
 - silver for an eighth of a day or more, copper below. All pieces of the smallest unit share its metal (2, 3 and 6
 folles stay copper; 2 thalers stay silver);
 - paper from 1800, for 20 days or more.
- **From 1914:** paper for more than two-thirds of a day (the rupee note, not the 8-anna coin); from 1980 for 1/25 of a
 day or more. Below that, nickel or steel coins down to 1/500 of a day (from 1914 to 1979, 1/20), and copper below.

Some monies have a look of their own:

| Look | Where and when |
|---|---|
| Cowrie shells | China before the Qin, the Maldives trade, West Africa; the bia of old Siam |
| Cacao beans | Mesoamerica |
| Manillas | Calabar and the Bight of Biafra |
| Shell money | the nzimbu of Kongo |
| Salt bars | the amole of Ethiopia |
| Homespun cloth | the vaðmál of Iceland |
| Beaver pelts | the made beaver of the Hudson's Bay posts |
| Bullet coin | the pod duang of Siam before 1860 |
| Holed coin | the cash of China, Japan (mon), Korea (mun) and Vietnam (văn); in Song and Yuan China a string of cash and more is paper money |
| Silver by weight | weighed silver (Mesopotamia, the Norse mark, Burma, Madagascar, Chinese taels) and units "of silver" (Persian grains) |
| Copper by weight | the Egyptian deben |

The sheet with all 16 looks is `pictures/money_items.png`.

**How it works inside.**
- `money/Wallet.java` (new) is what a player pays from and is paid into. In the game it is `money/CoinPurse.java` (new):
 - the pieces in the inventory, with change worked out by `Denominations.plan`: the exact sum when the pieces allow,
 else the one piece or set of pieces that needs the least change;
 - a written tab for barter and for money counted in days of work;
 - written purse money of a money that has pieces (the start money, purses from before this step) becomes pieces when
 the purse is next used. The log says so: "[EE money] ...'s written purse money became pieces: 15 annas 3 pice".
- The checks with no world keep the old purse of numbers (`Wallet.PurseWallet`), so the old self-tests still run
 unchanged.
- `money/MoneyItem.java` (new): the item. The money id, the value in the smallest unit, the name and the money's name
 ride on the stack. `money/MoneyItems.java` (new) registers the 16 items.
- Changed:
 - `ShopService`: paying from a wallet; prices rounded to the smallest piece;
 - `MarketService`: selling pays pieces; the money-changer swaps pieces; offers in whole pieces (`payable`);
 - `PurseService`: the start money rounded to the smallest piece (`startAmount`: $9.38 in Quito 2010 is $9.40);
 - `MarketTalk`: the money-changer reads the pieces; the sale buttons are in whole pieces;
 - `/ee purse` and `EeOperationalCheck`: the new check line "Money you can hold";
 - `EternalEngineMod`: registers the items.
- At most 2,304 pieces (36 stacks) change hands at once. A bigger change is refused ("That is more than you can carry.
 Change less at a time.").

**Mistakes the checks found and fixed during the step.**
- **Venezuela 2020:** a day's pay took 1,707 pieces. The 1-bolívar piece was kept while everything up to 5,000 bolívars
 was dropped, so the rest came as 1-bolívar coins. Tiny pieces are now dropped whatever unit they are. The worst day's
 pay in any money and year is now 9 pieces.
- **Croatia 2008:** 60 lipa could not be made from 20s and 50s. The smallest piece must now go into every other piece.
- **Quito 2010:** a day's pay of $9.38 could not be held in pieces whose smallest is 5 cents. The start money is now
 rounded to the smallest piece.
- **Wrong metals:** Persian grains of silver were silver coins (now cut silver); 2, 3 and 6 folles were silver (now
 copper); 2 thalers, 10 sho and 2 mil-réis were gold (now silver, like their unit).
- **Modern top pieces:** a 2,000-euro and a 100,000-naira note existed, and the €5 piece was a coin. Now the top piece is
 5 days' pay from 1914, and notes start at 1/25 of a day from 1980.
- **In the server session:**
 - The 8-anna piece in Bombay 1948 was a note (a day there is 189 pies, just under two 8-anna pieces). Paper now
 starts above two-thirds of a day. Checked again in a second session.
 - The money-changer offered "335 rubles 78 kopeks" and paid 335 rubles, because kopeks have no pieces in 2026. His
 offers and the merchants' are now in whole pieces ("373 rubles"; "16 sheaves of wheat: 336 rubles"). Checked again.

**Files.**
- **Mod, new:** `money/Denominations.java`, `money/MoneyItem.java`, `money/MoneyItems.java`, `money/Wallet.java`,
 `money/CoinPurse.java`.
- **Mod, changed:** `EternalEngineMod.java`, `money/ShopService.java`, `money/MarketService.java`,
 `money/PurseService.java`, `knowledge/MarketTalk.java`, `commands/EternalEngineCommands.java`,
 `commands/EeOperationalCheck.java`.
- **Assets:** 16 pictures in `textures/item/`, 16 models in `models/item/`, and 16 names in `lang/en_us.json`.
- **worldfill:**
 - `tools/draw_money_items.py` and `pictures/money_items.png` (pictures for people live in `pictures/`: folders
 named `out` are not kept with the workspace);
 - `probes/MoneyItemsProbe.java` + `probe_moneyitems.sh` (new);
 - `testmod/.../EeTestHelper.java` (new `eetest coins`, `eetest sell`, `eetest change`);
 - `logs/step23b_server_session.txt`.

**Tests.**
- **Probes** (no server):
 - money items, new: **10 passed, 0 failed**:
 - the pieces' own check: Hyderabad and Bombay 1948, London 1800, Lagos 2026, Rome 100, Constantinople 1000, the
 own looks, and paying with change;
 - all 398 monies with coins have pieces in their first, middle and last years, in all 16 looks, with at most 15
 pieces in one money and year;
 - a tour of 32 places from Ur 2000 BCE to Hyderabad 2026, each paying a newspaper from a day's pay with exact
 change;
 - all 1,194 money-years: a day's pay in at most 9 pieces, always exact, every price payable, no crumbs left with
 the seller;
 - all unchanged: purse 74, market 62, buyers 32, book forms 40, money world 14, atlas 31, book 11, knowledge 45,
 calendar 13, talk layout 10, screens all OK.
- **Test server**, two sessions:
 - `/ee check all`: from the console **124 passed, 0 failed** (one new line, "Money you can hold"); as the player
 **127 passed, 0 failed** in Edo (126 in Sydney 1500, where nobody lives near).
 - Bombay 1948 (Indian rupee): start money as six pieces; a notebook bought with change; wheat sold for pieces.
 - Calabar 1800 (manillas): start money "2 manillas" + "1 manilla"; a notebook for 1 manilla.
 - Varna 2026 (euro): 20 + 10 + 5 + 2 + 1 euros; the notebook paid with the €5 note.
 - Moscow 2026 (ruble): euros refused at the shop; changed at the money-changer; a notebook for 120 rubles paid with
 100 + 20; 16 wheat sold for 336 rubles.
 - Oslo 1200 (Scandinavian mark): start money a silver "5 penninge" (no seller near the test spot).
 - Sydney 1500 (barter): "You start with goods worth about 1 day's work to swap", no pieces, the tab kept.
 - Edo 1700 (mon): 150 mon as holed pieces of 100 and 50; a notebook for 150 mon.
- **Records:** `java_changes_step23b.patch` and `step23b_java_after.tar.gz` (with the pictures, models and names).

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 25–29).
- The looks follow a rule of thumb by value and era, not every real coin. A 5-penninge piece in 1200 never existed (only
 pennies did), some brass coins show as silver, and modern coins and notes differ from country to country.
- `/ee reset confirm` and `/ee purse reset` cannot take pieces from players who are offline, or out of chests: pieces
 are items.
- Barter keeps a written tab. Goods-for-goods swapping and paying with metal by weight come with the trade screen
 (step 24).
- The money-changer changes all of one money at once. Changing part of it comes with the trade screen (step 24).
- Not money: a merchant in Edo 1700 has a Chinese name ("Liu Wang"). Name pools by region are for a later step.

## Step 24: Minecraft's trade screen (2026-10-14)

Turn 101, "next". Step 24 in `SYSTEMS_PLAN.md` part 5: system E3, "Minecraft's trade screen: buy, sell, change
money, swap goods, old money", and the trade part of J1 (screens). This is the user's turn-90 wish: "a Minecraft-like
trade UI for money change and many more". It also fixes known problems 18, 27 and 28, and most of 23 and 24.

**What the player sees.** Trading now happens on Minecraft's own villager trade screen, with real slots:

- **Opening it.** In the talk box a merchant, trader or pedlar offers "Let's trade." first. A money-changer offers
 "Can you change my money?". Where people swap goods, a farmer offers "Let's swap goods.". A paper seller still offers
 "Show me your papers and maps.".
- **The trades are on the left**, as with a villager: what you give, an arrow, what you get. A small "+" means more
 kinds of pieces than the two pictures show. A cross on the arrow means "not today" (sold out, or you have it
 already). Hovering over a trade shows its name, price, a few words and how many are left today.
- **Click a trade** and the screen moves the right things from your bag into the two slots, as Minecraft does with
 emeralds. For money it picks the best one or two kinds of pieces: exact if it can, otherwise with the least change.
 You can also put anything into the slots by hand.
- **The thing appears in the slot on the right** when the slots pay for it. Take it, and the trader takes what he needs
 from the slots. Change goes into your bag. Shift-click to trade again and again while the slots still pay. Close the
 screen and whatever is left in the slots goes back into your bag.
- **Above the screen** is what the trader says, with the date. **Below it** is what the slots do right now and the money
 you carry. Examples:
 - "You pay 2 annas. Your change: 1 pice 2 pies."
 - "It costs 8 annas. That old sicca rupee is not taken any more. A money-changer will change it for you."
 - "For 5 euros (euro) I give 49 rubles (Russian ruble)."
- **"‹ Back to …"** (next to the inventory label) goes back to the talk. The screen closes by itself when the person
 leaves or you walk more than 8 blocks away, and the talk box says why ("Lakshmi has left.").

**The kinds of trade.**

| Trade | Who | What happens |
|---|---|---|
| Buy | every seller | Any mix of money taken here pays, in two kinds of pieces: the money of the place; money also taken here at its fixed rate (Indian rupees in Hyderabad at 7 for 6); or the small change beside it (cowries beside manillas). Change comes back in pieces. Old money and money from far away are refused, with the reason. |
| Sell | merchant, trader, pedlar | Your goods for his money, a lot at a time (16 sheaves of wheat in Bombay 1948: 4 annas 1 pice 1 pie). He pays full price for his first few of a good each day and half price after that, and never more than his day's money. A sale only shows for goods you carry. |
| Change | money-changer, town trader | **As much as you put in** of one money for another; he keeps 2 in 100 at a fixed rate, 10 in 100 otherwise. Moscow 2026: one 5-euro note brings 49 rubles, and the other euros stay yours. |
| Bigger / smaller pieces | money-changer, town trader | The same money in fewer or smaller pieces, for nothing (a 2,000-ruble note becomes two 1,000s). |
| Swap | where people have no money | His goods for yours, at what he would pay for yours. A trader also takes coins, as metal, by what they buy. What you give too much he owes you (the written tab), and the tab pays first. He never takes his own good for itself. Cahokia 1150: 64 blocks of stone for 6 lumps of coal, 3 logs and the rest of the tab. |

**Cowries, the small change of Calabar** (known problem 23).
- Calabar's money is the manilla, and a day's pay is 3 manillas. Until now even a candle cost a whole manilla.
- Now anything under 4 manillas is priced in cowries, the small change taken beside them. A manilla is worth about 295
 cowries in 1800 (by what each buys).
- Examples: a notebook costs 266 cowries, paid with one manilla and 29 cowries back. 8 sheaves of wheat sell for 88
 cowries.
- Only Calabar has a small change like this: the checks look through every row that also takes another money. Salt
 bars, homespun cloth and the made beaver have no small money in the data yet.

**When two slots are not enough.** A price that needs three or more kinds of pieces (nearly all of a day's pay in
small pieces) cannot go into two slots. Then the slots stay empty and he counts it out of your purse, with change. The
words under the slots say so.

**What changed in the talk box** (known problem 18). The talk no longer lists one "Sell …" option per good, or one
"Change …" option per money: that is all on the trade screen. A merchant keeps one question about prices, "What do you
buy?". That frees room among the nine options the talk box shows.

**How it works inside.**
- `money/TradeMenu.java` (new) is a real Minecraft container, laid out like the villager's trade screen. It has two
 slots to pay with, one to take from, and the inventory. Each slot is shown in the same place as Minecraft's.
 `money/TradeMenus.java` registers it.
- `money/TradeDesk.java` (new) is the server side:
 - it builds the trades (from the shop's wares, the goods you carry and the money you hold);
 - it fills the slots when a trade is clicked;
 - when you take the thing, it does the trade: the stock for the day, the merchant's day's money, the journal of the
 history book, and the log line `[EE market]`.
- `money/TradeRules.java` and `money/Tender.java` (new, pure Java) are the rules. What the two slots are worth for a
 trade; the best one or two kinds of pieces; the change; the words. Because they need no world, the checks run them.
- `money/TradeView.java` (rewritten) is what the server sends. The pictures carry the coin's data, so the game shows a
 piece's own name ("2 annas (Indian rupee)") in its tooltip.
- `client/gui/TradeMenuScreen.java` (new) and `client/gui/paint/TradeMenuPainter.java` (new) draw the screen. They use
 Minecraft's own picture of the villager trade screen and its buttons (resource packs change them too). The probe draws
 the same through its own canvas.
- Every change of the slots sends a fresh view, so the words under the slots are always right. The network version is
 now 8.
- Removed: the step-19c trade screen (`client/gui/TradeScreen.java`), the talk's sell and change options, and
 `MarketService.sell`/`swap`. `ShopService.buy` stays for the admin command `/ee shop ... buy`.
- Small fixes found on the way:
 - "3 manillas (manillas)" is now "3 manillas"; a money is not named twice;
 - a notebook just bought shows as owned while it is still in your hand;
 - he no longer asks logs for logs.

**Pictures** (drawn by `probe_trade.sh` with the game's own textures and font, at the user's 1920 × 1080 screen):
- `pictures/trade_bombay_1948.png`: a merchant in Bombay; the notebook picked; a 2-anna piece in the slot; "You pay 2
 annas. Your change: 1 pice 2 pies.";
- `pictures/trade_calabar_1800.png`: a pedlar in Calabar; the notebook for 266 cowries paid with a manilla;
- `pictures/trade_hyderabad_changer_1948.png`: a money-changer in Hyderabad; two O.S. rupees become Indian money.

**Files.**
- **Mod, new:** `money/TradeMenu.java`, `money/TradeMenus.java`, `money/TradeDesk.java`, `money/TradeRules.java`,
 `money/Tender.java`, `client/gui/TradeMenuScreen.java`, `client/gui/paint/TradeMenuPainter.java`.
- **Mod, rewritten:** `money/TradeView.java`.
- **Mod, changed:** `EternalEngineMod.java`, `client/EternalEngineClientRenderers.java`, `client/ClientKnowledge.java`,
 `client/gui/GuiCanvas.java`, `client/gui/paint/Canvas.java`, `client/gui/paint/TradePainter.java`,
 `network/EternalEnginePacketHandler.java`, `network/packets/TalkActionPacket.java`, `money/ShopService.java`,
 `money/MarketService.java`, `money/PurseService.java`, `knowledge/TalkService.java`, `knowledge/MarketTalk.java`,
 `knowledge/NewsTalk.java`, `commands/EeOperationalCheck.java`.
- **Mod, removed:** `client/gui/TradeScreen.java`.
- **worldfill:**
 - `probes/TradeProbe.java` and `probe_trade.sh` (new);
 - `probes/ScreenProbe.java` (draws Minecraft's trade screen with the game's textures);
 - `probes/MarketProbe.java` and `probes/BuyersProbe.java` (the new talk options);
 - `testmod/.../EeTestHelper.java`: new `eetest trade` (`with <who>`, `pick`, `put`, `take`, `shift`, `empty`,
 `show`, `back`, `away`, `close`), which drives the real trade menu on the server, and `eetest give`. The old
 `eetest sell` and `eetest change` are gone, and a fake player is alive again after `eetest player join`;
 - `pictures/trade_*.png`; `logs/step24_server_session.txt` and `logs/step24_server_session2.txt`.

**Tests.**
- **Probes** (no server):
 - trade, new: **16 passed, 0 failed**. It covers:
 - the rules' own check;
 - all 1,194 money-years paying 7 prices from a fiftieth of a day to a whole day out of one and three days' pay:
 16,643 prices, 16,242 from the two slots, 401 out of the purse, none unpaid, all change in whole pieces;
 - small change only in Calabar;
 - a lot of wheat selling for whole pieces in 8 places;
 - 8 money-changers changing a day's pay and a single piece;
 - bigger and smaller pieces for every money with two or more pieces;
 - the three pictures, on the user's screen and on the smallest common one (426 × 240);
 - updated: market **62**, buyers **32**;
 - unchanged: purse 74, money items 10, money world 14, book forms 40, atlas 31, book 11, knowledge 45, calendar 13,
 talk layout 10, screens all OK, history checks 70 OK + 3 known limits.
- **Test server**, two sessions (the fake player drives the real menu with `eetest trade`):
 - `/ee check all`: from the console **125 passed, 0 failed** (one new line, "Trade screen"); as the player **128
 passed, 0 failed**.
 - **Bombay 1948:**
 - the notebook bought with a 2-anna piece, 1 pice 2 pies back; 16 eggs bought with a shift-click;
 - 16 wheat sold for 4 annas 1 pice 1 pie, then 16 more (the lot left after that was 8);
 - an O.S. rupee refused ("We don't take the Osmania sicca here"), and an old sicca rupee refused ("not taken any
 more"). With an O.S. note and 4-anna pieces in the slots, the 4-anna pieces paid and the note stayed;
 - the money-changer changed an O.S. rupee for 13 annas 1 pice 1 pie and broke an 8-anna piece into two 4s;
 - with only Soviet rubles in the bag: "We don't take the Soviet ruble here"; 520 of them became 22 rupees 2 annas
 3 pice.
 - **Calabar 1800:** a pedlar's prices in cowries; the notebook for 266 cowries paid with a manilla (29 cowries
 back); wheat sold for 88 cowries; candles for 89 cowries.
 - **Cahokia 1150** (people swap): logs, stone and honey for the start tab; 64 blocks of stone for 6 coal, 3 logs and
 the rest of the tab.
 - **Moscow 2026:** euros refused; a bar of gold sold for 2,310 rubles; bread for 120 rubles with change from 200;
 5 euros changed alone for 49 rubles; a 2,000-ruble note broken into two 1,000s.
 - **Edo 1700:** the notebook for 150 mon (100 + 50).
 - Walking away closes the screen and lets go of the person. Closing gives back what was in the slots.
- **Records:** `java_changes_step24.patch` and `step24_java_after.tar.gz`.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8).
- The screen itself can only be seen in a real game; the fake player has no screen. Its look was checked from pictures
 drawn with the game's own textures and font. The real look, the sounds and the tooltips are for your final test.
- Old money is changed by what it bought in its day, not by its silver: a sicca rupee of 1857 brings about 8 O.S. rupees
 in 1948.
- Ports where several foreign coins passed side by side (Spanish dollars, Maria Theresa thalers) still list only a few
 "also taken" monies. The trade screen takes every money the data lists, and the money-changer changes any money.
- Small change exists only for manillas. Salt bars, homespun cloth and the made beaver are still coarse.
- Not trade: the names in Cahokia 1150 ("Isabel of Tenochtitlan") borrow from other American peoples, as in problem 29.
 And at Hyderabad 1948 the test world stood nobody up after a jump: all 13 spots were inside a player's bubble.

## Step 25: the history data fix (2026-10-15)

Turn 102, "next". Systems C1 (states, borders, rulers) and C25 (the data fix) of `SYSTEMS_PLAN.md`, and known problems 4,
15 and 21. My default since turn 96: Wikipedia first, every change listed and reversible, checked on every place and
year (part 9).

**What was wrong.**
- The step-12 fact check (`FACT_AUDIT.md`) found 4,005 problems, 1,543 of them sure. A wrong line about who rules, or about
 the language or faith, reached 12% of the world's people in 1850 and 18% in 1900: Russia named its prime ministers as
 rulers, France its prime ministers and claimants, Britain was "Kingdom of Great Britain" until today.
- The turn-51 spot check (`TALK_SPOT_CHECK.md`) found 1 answer in 10 wrong, mostly in colonial India.
- Found on the way: the border map stopped in 2024, so in 2025 and 2026 nobody ruled anywhere (townspeople in Washington
 took the old label "mississippian"); map squares whose centre is in the sea had no state in most years (Sydney, Baku,
 Aden); Bombay and Madras were Mughal and Dutch in 1700.

**What changed in the data.** One script, `fix_history_data.py`, reads the shipped files and fixes them in groups. Every
change is a line of `step25_changes.csv` (file, rule, item, before, after, why): 8,680 lines. `step25_changes.json.gz`
holds the exact old values: `python3 fix_history_data.py --undo` puts every file back, checked against a hash of each
original (tested: the fact check then gives the old 4,005 findings, byte for byte). Running the script again first undoes
its last run, so it is safe to re-run.

| Group | What | Changes |
|---|---|---:|
| S1 | The states of 2024 go on to 2026 (Cliopatria stops in 2024; no border changed since) | all timelines |
| S2 | Names by period: Kingdom of Great Britain → United Kingdom of Great Britain and Ireland (1801) → United Kingdom (1923); Dominion of India 1947–1949; Dominion of Pakistan 1947–1955; Portugal after the Estado Novo (1974); Kingdom of Denmark, Sweden–Norway and Norway after Denmark–Norway (1814); Kingdom of Greece and the Second Hellenic Republic; Republic of Haiti; Republic of Mali and Senegal after the Mali Federation; Kingdom of Sweden after the Swedish Empire; Libyan Arab Jamahiriya and Libya; Democratic Kampuchea, Khmer Republic, State of Cambodia; Kingdom of Bulgaria (1908), Kingdom of Romania (1881), Grand Duchy of Tuscany (1569), the Zhou dynasty for "Later Zhou" before AD 1, and 20 more | 3,055 |
| S3 | Occupations are not annexations: the "Soviet Union" in Czechoslovakia 1969–1990, Poland 1945–1952, Hungary, Romania, Bulgaria and Austria 1945–1946, northern Iran 1942–1946 (each takes the state the record names next), Allied-occupied Germany 1945–1948; the Electorate of Saxony under its Saxon kings; Mandatory Palestine, the Emirate of Transjordan and Iraq instead of "British Africa"; British colonies named British Empire, not the kingdom | 1,070 |
| S4 | The Nizam's Hyderabad State until 17 September 1948 (it was shown as British 1799–1946), inside its 1909 borders: Telangana, Marathwada, Raichur, Gulbarga and Bidar | 269 |
| S5 | Bombay (English from 1668) and Madras (English from 1640) get their own place: a map square is bigger than either | 2 |
| S6 | 944 coastal squares take the state that at least 3 of their 8 neighbours share, only in their empty years | 944 |
| S7 | A state that was gone is not named (the "Sultanate of Malacca" after 1511 outside Johor) | 28 |
| R1 | 368 prime ministers, chairmen of ministers and grand pensionaries moved out of "ruled by" (into the head-of-government list); in the Soviet Union the party's General Secretary is the ruler | 368 |
| R2–R7 | Claimants, titles, states, periods and non-rulers (Sun Tzu in Qi) removed; impossible years corrected (Tan'gun 2333 BC, Otto V of Bavaria 1347–1379); reigns end when the ruler died; guessed end years corrected; quoted nicknames and dates taken out of names; doubles merged | 152 |
| R8 | 427 reigns from Wikidata's office holders (CC0, `fix_history_wd.py`, saved in `sources/step25_offices.json.gz`), only in years the Wikipedia lists leave empty: V. V. Giri, Suharto, Beatrix (Queen), Khomeini, Cipriano Castro, Gustáv Husák, Karl Renner, Donald Trump in 2025–2026 … Longest terms first, so an acting holder never hides the holder of the year | 427 |
| R9 | Rows from Wikipedia: the 15 Tokugawa shōguns (the emperor in Kyoto is listed as the figurehead), the Habsburg monarchs 1521–1806 (Leopold I, not the archdukes' "Leopold VI"), Iran's Supreme Leaders, Bierut in Poland, Gaddafi, Democratic Kampuchea | 24 |
| L1–L7 | Sign languages, scripts and leftover words removed ("Korean Sign", "Chosŏn'gŭl", "None at the federal level"); the faith of the year for England (Anglican from 1534), Scotland, Sweden, Denmark, Norway, Saxony, Brandenburg, Holland, Lithuania and Champa; "The court follows Islam; most people here follow Hinduism" for the Mughals, the Indian sultanates and Hyderabad State; 8 faith surveys that contradict the rest dropped (the Soviet Union "75% Catholic"); 32 more points for big languages (German in Vienna, Hindi in Delhi and Varanasi, Estonian in Tallinn, Azerbaijani in Tabriz) | 178 |
| E1–E5 | 150 disasters dated by their day of the month now dated by their year; 105 year-page lines given their own year ("AD 8 – Ovid is banished" no longer in AD 1); 947 news lines with no English name removed (Wikidata has none either); 715 lines tidied (a leftover day number, a table bar, an empty bracket); 50 unreadable lines removed | 1,968 |
| P | 130 famous people with impossible lifetimes, 3 that were not names, 13 broken descriptions | 146 |
| M1 | Money rows follow the new names (the same land under its right name) | 46 |
| F1 | Chandragupta II born about 345 (his reign began about 375) | 1 |

**What changed in the Java code** (`java_changes_step25.patch`):

| What | Where |
|---|---|
| The faith of the year (`relP`) and the people's faith beside the court's (`relFolk`); years after 2026 keep 2026's head | `civilization/LeaderRegister.java` |
| Years after the record's last year are answered as that year (the states of today go on) | `civilization/RulerRegister.java` (`lastYear`) |
| The faith sentence uses both; deaths are news only within 1,500 km and the people talked about come from within 600 km when there are any; towns live from mills and offices from 1850 in Europe and North America, from 1900 elsewhere; "Merchants of the Hanseatic League trade here" (its towns include trading posts such as London's Steelyard) | `civilization/EventNews.java` |
| Part 14 of `/ee check all`: 28 places with a corrected ruler, 6 language and faith lines, and 5 rules that keep the old mistakes out (no prime minister as ruler, no claimant, no news line named by a number, no 110-year lives, the map reaches today); new minimum counts | `civilization/HistoryChecks.java`, `FamousPeople.java` (`all`) |
| Known problem 15: a remembered townsperson comes back only among the same people and within 100 years of when they were met; within the same people they take the land's name now | `villager/PresenceLocalSpawner.java`, `PeopleMemory.java`, `VillagerVirtualizer.java` |

**Results.**
- The fact check (`fact_audit.py`, the same rules; it now also knows the faith of the year, and that a Council of State's
 chairman or a junta's president is a head of state): **4,005 → 1,549 findings; "wrong" 1,543 → 44**; "likely wrong"
 333 → 207; "odd" 1,253 → 455; "missing" 876 → 843.
- People who would hear a wrong line (share of the world's people; picture: `pictures/history_fix_wrong_lines.png`):

| Year | 500 BC | AD 1 | 1000 | 1300 | 1500 | 1700 | 1800 | 1850 | 1900 | 1950 | 2000 | 2020 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Before | 0.9% | 0.2% | 0.3% | 1.6% | 0.9% | 1.8% | 5.3% | 12.1% | 17.6% | 7.1% | 2.7% | 2.5% |
| After | 0% | 0.04% | 0.1% | 0.2% | 0.7% | 1.5% | 0.5% | 0.2% | 0.03% | 0.1% | 0.01% | 0.04% |

- People who hear a state named: up 1–1.5 points in every year (1950: 96.5% → 98.0%).
- "People here talk about X" names someone born more than 1,000 km away: 34–44% → 1–5% of the picks.
- The turn-51 spot check's 12 wrong lines are all fixed: Hyderabad 1850 is the Nizam's (Nasir-ud-Daula, Asaf Jah IV) and
 lives by crafts and trade; Delhi and Varanasi speak Hindi, with "most people here follow Hinduism"; Madras and Bombay
 1700 are English; London 1600 is Anglican and no longer "a town of the Hanseatic League"; Vienna 1700 speaks German,
 ruled by Leopold I.
- The world sample of part 9 (400 land points, `probe_historyfix.sh world`): the places with people are exactly the same in
 every year; empty land still says nobody lives here (every point); a ruler is named at 97% of peopled points in 1900
 (was 95%), 95% in 2000 (was 93%) and 96% in 2026 (was 0%: no state at all before the fix).

**Checks of this step.**
- `probe_historyfix.sh brief|full|world` (new, `probes/HistoryFixProbe.java`): 97 places on every continent and in
 every era, before and after (`logs/step25_probe_before.txt`, `logs/step25_probe_after.txt`), and the world sample.
- `probe_check.sh`: 112 checks, 110 OK, 0 failed, 2 known (was 73: 70 OK, 3 known; the Hyderabad 1900 limit is fixed).
- Unchanged and passing: trade 16, market 62, buyers 32, purse 74 (Kinshasa 1500 now pays in nzimbu shells: its empty
 square takes the Kingdom of Kongo's), moneyitems 10, moneyworld 14, bookforms 40, atlas 31, book 11, knowledge 45,
 calendar 13, talk_layout 10, screens all OK. (`probe_name_pools.sh` has the same 3 old failures as before the step.)
- Test server (`logs/step25_server_session.txt`): `/ee check all` from the console **165 passed** (was 125), as the
 player **168** (was 128); money in game: Gulbarga 1900 hali sicca and Aurangabad 1930 Osmania sicca (now inside
 Hyderabad State), Prague 1980 koruna, Jerusalem 1940 Palestine pound, Dresden 1750 thaler, Warsaw 1946 złoty; the state
 cards: "Dominion of India, ruled by George VI", "Hyderabad State, ruled by Nasir-ud-Daula, Asaf Jah IV", "Czechoslovakia,
 ruled by Gustáv Husák", "Mandatory Palestine, ruled by George VI", "United States of America, ruled by Donald J. Trump";
 Rome in a new world: AD 100 all 33 townspeople "rome", then 2026 all 41 "republic_of_italy", then AD 100 again all
 "rome" (the same Romans came back).

**Records:** `step25_changes.csv` and `step25_changes.json.gz` (every data change; undo), `fix_history_data.py`,
`fix_history_wd.py`, `sources/step25_offices.json.gz` and `sources/step25_event_labels.json.gz` (the saved Wikidata
answers), `java_changes_step25.patch` (checked with `patch -p1`, then compared), `step25_java_after.tar.gz`.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 34–36).
- The fact check still finds 44 "wrong" lines. Most are names it cannot confirm: it compares a corrected name with the
 old state's dates (the Restored Toungoo Kingdom after 1599, the post-Angkor Kingdom of Cambodia), or names such as
 "Tibet". Also 821 runs of years with no ruler named, mostly before 1800 where Wikipedia has no list.
- Years are whole years: in 1948 Hyderabad is the Nizam's all year (the annexation came on 17 September), and the year a
 ruler changes may name either.
- "People here speak …" still uses one point per language plus the 32 added; a village far from every point of its own
 language can name a neighbour's.
- Seen in the session: Italians in Rome 2026 get names from the Mediterranean list, some of them Greek (problem 35).

## Step 26: foundations for big data (2026-10-15)

Turn 103, "next". Systems A1 (the key), A3 (the data pipeline), A4 (storage that streams by region and era), A5 (the
"recorded" or "estimated" mark), A7 (licences and credits), I6 (memory) and K4 (delivering data) of `SYSTEMS_PLAN.md`,
plus known problem 20 (border cities) and more state fixes found on the way (S8, S9). Step 27 needs this first: its
card pipeline will bring millions of people (2,376,851 famous people born before 1950), which cannot all sit in memory.

**1. The key (A1).** Every answer depends on four things: the place, the date, the timeline and the universe. They are
now one object, `core/WorldKey`, and every game system asks one door, `core/WorldQuery`:
- the townspeople spawner, the talk, the market talk, the news, the crowd sounds, the current affairs, the money
 table, the civilization lookup and the operator commands (13 places in the code) ask with a key; only the checks ask
 the layer below on purpose;
- the timeline: an event a timeline prevented is gone in that timeline and its children, and only there. The key's own
 timeline is asked, not "whichever is active", so the main timeline can be read while a branch is active;
- the universe: decision 3 says universes are dimensions. The overworld is the prime universe, where recorded history
 lives; any other dimension has no recorded history yet (until systems H give a broken universe its own);
- `/ee villager who` shows the key it asked with ("key: 36.2000, 37.1600 in 2026-01-01, timeline main, universe prime").

**2. Recorded or estimated (A5).** Every answer now carries the mark. Players never see it (no sources in play, turn 56);
the operator's `/ee villager who` and the checks do:
- the border map: recorded until 2024 (the source stops there); 2025 and 2026 carry 2024's states forward, marked
 estimated; 7,358 stretches of years are marked: where a coastal square took its neighbours' state, and the 89 border
 cities below (their history comes from a neighbouring square);
- reigns: 217 reigns whose list gives no end (the builder guessed start + 25 years) are marked;
- places with estimated founding years, the population model (HYDE) and the ways of life were already marked;
- example: Aleppo 2020 "ruler: Syria ... [recorded]", Aleppo 2026 "[estimate: the record ends in 2024; its states
 carried forward]", Sydney 1900 "[estimate: taken from the neighbouring squares]".

**3. Tiles (A4).** Data is cut into tiles by region and century, each compressed on its own (`build_tiles.py`,
`data/TileStore`, `data/TileCache`). Only the small compressed file stays in memory; a tile opens when a question needs
that land and era, and the least used tiles close when the budget (48 MB) is full. First user: the famous people.

| | Before (one big file) | After (tiles) |
|---|---:|---:|
| Memory | 40.2 MB | 7.9 MB |
| Loading | 718 ms | 14 ms |
| A question | 1.11 ms | 0.16 ms |

The answers are exactly the same, in the same order: `probe_tiles.sh` asked 47,376 questions (the 400-point world
sample and 23 cities, 14 years from 3000 BC to 2026: who is alive, who died that year, who was born nearby) and got
1,215,116 people, with 0 differences. The master file stays in the source tree for the scripts and is left out of the
mod (`build.gradle`).

**4. The data list, licences and credits (A3, A7, K4).** `build_manifest.py` writes `manifest.json`: every data file
with its size, SHA-256, rows, role, sources, licences, mark, builder script and pack ("core": everything ships inside
the mod, decision 5). The credits file `DATA_CREDITS.md` is written from the same list and travels inside the mod
(never shown in play), so a new source cannot come in without its credit. On the way: the OpenStreetMap credit (ODbL)
for the Telangana and Hyderabad place packs was missing; it is there now. No data file forbids commercial use.
`/ee check all` reads every shipped file and compares size and hash with the list (59 files, 29.7 MB).

**5. Memory (I6).** Measured per register (`probe_memory.sh`): 160.3 MB → 128.0 MB, loading 3.97 s → 2.97 s. The
places and events (70 MB) and the border map (26 MB) are the next to become tiles (steps 28 and 34). Budgets checked by
`/ee check all`: opened tiles 48 MB, compressed tiles 16 MB, all data 64 MB.

**6. More state fixes (S8, S9, M2), in `fix_history_data.py` like step 25** (each change a line of
`step25_changes.csv`, all undone with `--undo`):

| Group | What | Changes |
|---|---|---:|
| S8 | Rebels and occupiers are not the state: northern Syria 2014–2026 ("Mujahideen") stays Syria; Afghanistan 1979–2005 ("Mujahideen", "Taliban") stays Afghanistan with its list of rulers (Najibullah, Rabbani, Mullah Omar, Karzai); the Second World War: lands held by Germany, Italy, Japan, Bulgaria or Hungary keep their own state (Denmark, Norway, the Netherlands, Belgium, Greece, Yugoslavia, Albania, Czechoslovakia, Poland, the occupied Soviet lands, Vichy France for both French zones, the Dutch East Indies, Malaya, Hong Kong, the Philippines, occupied China), so do Iceland, Greenland and Iran under Allied troops; the British, American and French zones of Germany 1945–1949 are Allied-occupied Germany; Austria's Second Republic from 1945 | 1,972 |
| S8 | Squares that named the wrong land: Moldova was "Russian-occupied territories" from 1944 (now the Soviet Union, then the Republic of Moldova); St Croix carried St Kitts's history (now Danish 1733–1916, American from 1917); "Éire" is Ireland, with its 10 presidents from Douglas Hyde to Catherine Connolly | 4 |
| S9 | Border cities follow their own country (known problem 20): Wikidata's 4,074 cities of 100,000 people or more and the capitals of all states were compared with the map; 89 were told they were in another country: Kinshasa (14.6 million people) in the Republic of the Congo, Tijuana, Ciudad Juárez, Mexicali and Reynosa in the United States, Johor Bahru and Batam in Singapore, Vientiane in Thailand, Irbid in Israel, Sidon and Tyre in Israel, Lille and Ghent across the Belgian border, Basel in Germany, Geneva and Nice in France and Monaco, Maseru in South Africa. Each now has a place of its own with the history of the nearest square of its own country (marked estimated); 16 twin cities across the border (San Diego, El Paso, Detroit, Brazzaville, Monaco...) got a place of their own too, keeping their answer | 105 |
| M2 | Money of the lands S8 names: the Reichsmark in Allied-occupied Germany until 1948 (Cologne and Munich paid in Dutch guilders and Austrian schillings), the Deutsche Mark in the western zones from June 1948; the Polish złoty until 1945 (Warsaw 1942 had only "local money") | 3 |

**Results.**
- The fact check: 1,549 → 1,329 findings ("wrong" 44, "likely wrong" 207 → 199; the 213 guessed end years are now
 marked estimates instead of findings).
- People who hear a state named: 2020 98.27% → 98.37%. The world sample (400 points): unchanged, 96–97% of peopled
 points name a state and a ruler from 1900 on; empty land still says nobody lives here.
- In the game: Copenhagen 1942 "the Kingdom of Denmark, ruled by Christian X"; Paris 1942 "Vichy France, ruled by
 Philippe Pétain"; Cologne 1946 "Allied-occupied Germany" (pays in marks); Kabul 1990 "Afghanistan, ruled by Mohammad
 Najibullah"; Dublin 2026 "Ireland, ruled by Catherine Connolly"; Aleppo 2026 "ruled by Ahmed al-Sharaa".

**Checks of this step.**
- Part 15 of `/ee check all` (new, 14 checks): the key gives the record's answers at all 64 test places; another
 universe has no recorded history; a timeline that prevented an event does not hear of it while the main timeline
 does; the marks (recorded until 2024, coastal squares, 217 reigns); the tiles open and answer; the opened tiles stay
 in budget; every data file is the one that was built (size and SHA-256); every file names its sources and licences;
 the credits name every source; the size budgets. Part 14 gained 21 places (S8, the Second World War, S9).
- `probe_check.sh`: 147 checks, 145 OK, 2 known (was 112). New probes: `probe_tiles.sh` (above), `probe_memory.sh`.
- Unchanged and passing: trade 16, market 62, buyers 32, purse 74, moneyitems 10, moneyworld 14, bookforms 40, atlas 31,
 book 11, knowledge 45, calendar 13, talk_layout 10, screens all OK (`probe_name_pools.sh`: the same 3 old failures).
- Test server (`logs/step26_server_session.txt`): `/ee check all` from the console **200 passed** (was 165), as
 the player **203** (was 168); money in game: Kinshasa 2026 Congolese franc (was the CFA franc of Brazzaville), Tijuana 2026 Mexican peso, Cologne 1946 and Munich 1947 the mark, Cologne 1948 the Deutsche Mark, Warsaw 1942 the złoty, Athens 1942 the drachma, Batavia 1943 the Netherlands Indies guilder, Basel 1700 the gulden, Nice 2026 the euro; the state cards: "the Kingdom of Greece, ruled by George II" (Athens 1942), "the Democratic Republic of the Congo, ruled by Felix Tshisekedi" (Kinshasa), "Mexico, ruled by Claudia Sheinbaum" (Tijuana), "the Principality of Monaco, ruled by Albert II", "Dutch East Indies, ruled by Wilhelmina" (Batavia 1943), "Ireland, ruled by Catherine Connolly"; `/ee villager who` at Kinshasa shows "[estimate: taken from the neighbouring squares]" for 1950 and the key line; townspeople: Rome AD 100 32 "rome", Bombay 1948 40 "india" (at Kinshasa the sandbox world had no ground where the district's spots fall, "no ground 13", as in known problem 33; 40 people were wanted).

**The change list and undo.** `step25_changes.csv` now has 11,025 lines: 8,680 from step 25 and 2,345 from step 26
(S8 1,976, A5 219, S9 105, Ireland's name and presidents, money). `python3 fix_history_data.py --undo` was tested again:
the new marks, the added money row and the added places go too. Two runs in a row now write byte-identical files (no
time stamp inside the .gz files), so the data list's hashes stay valid when the script is run again.

**Records:** `step25_changes.csv` and `step25_changes.json.gz` (now steps 25 and 26; undo), `fix_history_data.py`,
`build_tiles.py`, `build_manifest.py`, `sources/step26_cities.json.gz` (the saved Wikidata cities),
`java_changes_step26.patch` (checked with `patch -p1`, then compared), `step26_java_after.tar.gz`.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 37–40).
- Only the famous people are tiles so far; places and events (70 MB) and the border map (26 MB) still load whole.
- Between a border city and its twin, the answer follows the nearer city: a straight line, not the real border.
- Palestine's towns keep the record's answer (the West Bank is named "State of Israel"), and Crimea is left as it is.
- Occupied lands now name their own state, but nobody says "under German occupation" yet: occupation in talk and news
 comes with the cards (step 27) and the events (step 28).

## Step 27: knowledge cards for every place: famous people and groups (2026-10-15)

Turn 105, "next". Systems C10 (famous people: births, deaths, homes, offices, deeds), C12 (organisations: companies,
guilds, armies, parties, universities, newspapers) and C22 (knowledge cards for every place: who, what, when, where,
links) of `SYSTEMS_PLAN.md`. Until now only Hyderabad 1948 had a real knowledge pack; everywhere else a villager had four
plain cards with no names to follow.

**1. Who gets a card.** From Wikidata (QLever's endpoint), every human with two or more Wikipedia articles and a
birthplace on the map: 1,959,134 people. Chosen: everyone with 12 or more articles, at most 300 for one 5-degree box of
the map and one century, and in every box and century at least the 30 best known there are (so a quiet land keeps its
own names). Organisations: 219,999 with a founding year and a place; the best known of each kind per box and century.
Left out: people with no English name, impossible lives, remains and mummies ("Ötzi"), and 3,210 "companies" that are
really towns (a municipal corporation counts as a business in Wikidata: Walla Walla, Schweinfurt, Kyoto).

| Cards | Count |
|---|---:|
| People | 148,510 |
| Schools and universities | 10,586 |
| Companies, banks, trading companies | 7,607 |
| Political parties | 2,528 |
| Newspapers | 2,189 |
| Armies, regiments, legions | 2,173 |
| Guilds, unions, learned societies, academies | 1,513 |
| Religious orders | 259 |
| **All** | **175,365** |

**2. What a card keeps.** The name, the short description, the years (birth and death, or founded and closed; "around"
when only the decade is known, 7,480 people), the home or seat on the map and its town (a hospital or a house is named
by its town: Kennedy "from Brookline", "died in Dallas", not the hospital), the death place, up to three offices with
their years (34,697 people; the best known office first: Clinton "President of the United States", not "Attorney General
of Arkansas"), up to three works with their year (6,338 people; the best known first: Mozart "The Magic Flute", "The
Marriage of Figaro", "Don Giovanni"), and links between cards: studied at, party, served in, worked for, member of,
founded / founded by (54,333 cards; 1,972 founders).

**3. Cross-checked with Wikipedia.** 65,416 people are also in the famous people master (the Wikipedia year pages) with
the same name and one year the same. Where the other year differs, the Wikipedia year is used (turn 12: Wikipedia
first); 1,560 birth years and 464 death years differed by more than a year.

**4. Nobody knows the future.** Every answer is worded for the date of the talk:
- people are talked about from about age 30 (earlier with a dated office or work), groups from their founding;
- an office counts from its first year, a work from its year, a death from the year it happened;
- a description that names an office, a rank or a later honour waits for it (22,165 people): "president of the United
 States" is said of Kennedy from 1961 ("the president" while he holds it, "a president" after), "queen of the United
 Kingdom" of Victoria from 1837; before then only the part that was already true is said ("Napoleon is a French
 military leader" in 1800, "a French military leader, French Emperor" in 1810); years written in a description
 ("from 1837 to 1901", "(1564–1642)", "born 1950") are taken out, and "former" goes;
- example, Kennedy in 1962: "John F. Kennedy is the president of the United States. He was born in Brookline in 1917, so
 he is about 45 now." What has he done: "He has been President of the United States since 1961. He was United States
 representative from 1947 to 1953. He was United States senator from 1953 to 1960. He is known for Profiles in Courage
 (1955). He founded United States Navy SEALs in 1962." (his 1963 Berlin speech is not known yet).

**5. In the talk.**
- "Anyone famous from here?" names up to four people with cards: the living people talked about within 300 km (the
 best known, those from close by counting more); in a quiet land, the very famous of a wider land (1,000 km); with
 nobody alive, the people of long ago ("People here still tell of Pachacútec, Manco Capac, ... who lived long ago").
 A death this year still comes first ("Sad news this year: ...").
- "What is this place?" has a new follow-up, "What groups are there here?" ("People here know of The Times of India,
 University of Mumbai, Reserve Bank of India and Taj Mahal Palace Hotel"). It is a follow-up, not a new first
 question, so the nine questions the talk box shows stay the same.
- "Who rules here?" names the ruler as a link to the ruler's own card (Trajan, Akbar, George VI, Louis XVI, Kangxi,
 Andrew Johnson, Brezhnev ...): rulers are found by name and year (24,633 names of heads of states and governments).
- Every name is under "Ask about…"; a person's card answers "Who is he?", "What has he done?" and "Where is he from?"
 (with the distance, and "Track it on my compass"); a group's card "What is it?" (with its founders as links) and
 "Where is it?". A card's links open further cards, as deep as one likes.
- The history book finds these cards by their ids (`pc_<number>` for people, `oc_<number>` for groups), so a person or a
 group in the book can be tracked.
- No source names anywhere (turn 56): "co-founder of Wikipedia" says "an online encyclopedia".

**6. Storage.** One tile file (step 26's format), `cards/cards.tiles`, 8.5 MB, built by `build_cards.py` from the
exports of `fetch_cards_wd.py` (kept out of the snapshots in `build/cards/raw/`; the file itself is the record). Cards
are cut by 5-degree boxes and by the century people start to talk about them; an index finds any card by its number;
two small groups hold the people known far and wide and the rulers' names. In the game: 11.2 MB of memory (the
compressed file and its index), 47 ms to load, a place's lists 0.5 ms (about 0.6 ms the first time; at most about 0.1 s
the first time a talk opens in a new busy area). The data list now has 61 files (60 shipped, 38.2 MB of the 64 MB
budget).

**Results.**
- The world sample (400 land points), people to tell: 3000 BC 1, 1500 BC 10, 500 BC 53, AD 1 60, 800 109, 1200 133,
 1500 154, 1800 225, 1900 306, 1950 356, 2026 379. Before this step: no names with cards anywhere but Hyderabad 1948.
- At named places: Florence 1610 Galileo, Urban VIII, Marie de' Medici, Gregory XV; London 1700 Newton, Defoe, Halley,
 Queen Anne, and the East India Company, the Royal Society, the Bank of England; Bombay 1948 Homi Bhabha, Vinoba Bhave,
 Salim Ali; Kyoto 1600 Tokugawa Ieyasu, Toyotomi Hideyoshi; Beijing 1700 the Kangxi Emperor; Athens 400 BC Plato,
 Socrates, Aristophanes, Thucydides; Washington 1865 Buchanan, Harriet Tubman, Robert E. Lee, Frederick Douglass, the
 Republican and Democratic parties; Lagos 1990 Wole Soyinka, Obasanjo, the University of Lagos; Moscow 1980 Vysotsky,
 Sakharov, Pugacheva, Moscow State University, the Communist Party; Kinshasa 2026 Félix Tshisekedi, the University of
 Kinshasa; Reykjavik 1900 Einar Benediktsson.

**Checks of this step.**
- Part 16 of `/ee check all` (new, 9 checks): the card file loads; every card is found by its number; people with cards
 at 12 places from Athens 400 BC to Kinshasa 2026 (Florence 1610 names Galileo); groups (Bologna 1300 its university,
 London 1700 the East India Company); every card and every link known on its date, no source names, every answer fits
 the talk box; nobody knows the future (Galileo unknown in 1580, Kennedy not president in 1950 but in 1962, Victoria
 queen from 1837, Bologna's university unknown in 1000, the East India Company closed by 1880); the ruler's card at 6
 places; the world sample; the time. The memory check now counts both tile files (24 MB budget).
- New probe `probe_cards.sh` (48 checks): the above, the world sample in 11 years (7,444 cards worded, every one right
 for its year), the history book's lookup, the speed, the tile budget.
- `probe_check.sh`: 156 checks, 154 OK, 2 known (was 147). `probe_memory.sh`: 139.2 MB (was 128.1; the cards 11.2 MB).
- Unchanged and passing: knowledge 45, book 11, talk_layout 10, screens, tiles ("TILES OK"); `probe_name_pools.sh` the
 same 3 old failures.
- Test server (`logs/step27_server_session.txt`): `/ee check all` from the console **209 passed** (was 200), as the
 player **212** (was 203), 2 known; talks at Florence 1610 (Galileo's card, his deeds, where he is from with the
 compass), Rome 100 (Trajan linked from "Who rules here?", tracked on the compass), Bombay 1948 (George VI linked),
 Washington 1962 (Kennedy), Bologna 1300 (the university), Kinshasa 2026 (people and groups), Cusco 1500 (people of
 long ago), Delhi 1600 (Akbar).

**Records:** `fetch_cards_wd.py` (every query), `build_cards.py` (`--select`, `--positions`, `--places`, `--classes`,
`--build`, `--check`), `logs/step27_cards_report.json`, `logs/step27_server_session.txt`, `probes/CardsProbe.java`,
`probe_cards.sh`, `java_changes_step27.patch` (checked with `patch -p1`, then compared), `step27_java_after.tar.gz`.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 41–46).
- People are placed by their birthplace: someone born in Bombay who lived in England (T. H. White) is talked about in
 Bombay, and the famous of a city born elsewhere are not "from here" (offices and places of work come later).
- Names are today's: "Mahatma Gandhi" before 1914, "Queen Victoria"'s card name "Victoria"; descriptions may name
 today's countries ("a university in Bologna, Italy" in 1100).
- Wikidata's own mistakes stay: a few groups with impossible founding years (a tile company "founded" in 1600 in Delhi,
 the Egyptian Army "in 3400 BC"), an order that was dissolved but has no end year (the Humiliati in 1610); temples,
 mosques, libraries and hotels count as groups when Wikidata files them under a business.
- Some rulers have no card or another name (Cosimo II in Florence 1610, Emperor Go-Yōzei), so "Who rules here?" names
 them without a link; the famous people line of the year pages ("People here talk about Musa I of Mali") has no link
 when the cards have nobody alive there.
- About 0.1 s the first time a talk opens in a new busy area (the tiles open; later talks there take under a millisecond).
- The cards hold 148,510 of the 1,959,134 people with a mapped birthplace (at most 300 per box and century keeps the
 file at 8.5 MB): in busy lands the less famous are left out.

Problems 39 and 40 of step 26 (disputed land, "under occupation") were planned for this step, but they are events, not
cards: they move to step 28 (events, natural events, cause and effect), which comes next, then local rulers and
divisions (step 29) and families (step 41).

## Step 28: events, causes and effects, natural events, occupied and disputed land (2026-10-15)

Turn 106, "next". Systems C8 (events), C9 (cause and effect, the butterfly graph) and C21 (natural events) of
`SYSTEMS_PLAN.md`, and known problems 39 and 40 of step 26 (disputed land; "under occupation"), which step 27 moved here.

**1. Event cards (C8).** Every event of the history data with a Wikidata number now has a card of its own: battles,
sieges, wars, treaties, incidents and disasters (23,062 of the history data's events), plus the dated events their
links name (the wars they are part of, their causes and effects, what came before and after) and the natural events
below: **32,542 event cards** in `cards/events.tiles` (1.6 MB, the tile format of steps 26 and 27, built by
`build_event_cards.py` from `fetch_events_wd.py`). A card keeps the name, the description (years taken out), the first
and last year, the place and its name (6,370 events fought in many places, like the world wars, have no single point),
the country, the deaths (3,307 events), who took part (people and groups with cards; the other sides, mostly states, by
name: 8,692 events) and its links. The history data's own years win where Wikidata differs by more than a year (133
events); a war's "point in time" in Wikidata is often its last year (World War I, 1918), so the start time comes first.

**2. Cause and effect (C9).** The links are the butterfly graph: part of (17,404), its parts (8,670, the best known
eight per event), causes (2,346), effects (2,276), what came before (689) and after (686). Every link is stored on both
cards (a cause on its effect, the effect on its cause), so the graph can be walked either way; all 3,151 cause-and-effect
statements Wikidata has between two dated things are in it. Step 49 ("which later events depend on the change") walks
this graph.

**3. Nobody knows the future.** Every answer is worded for the date of the talk: an event is unknown before its first
year; "What came of it?" names only what began before this year (and not before the event itself); its parts count as
they happen; the death toll and the winner come after the end. The First World War in 1916: "World War I is a global
conflict. It began in 1914, and it is still going on ... It came about because of the Scramble for Africa (1885), the
Triple Entente (1892), the assassination of Archduke Franz Ferdinand (1914) and the Triple Alliance (1882). Among its
events so far: the Battle of Verdun (1916) ..."; in 1925: "... About 17 million people died. It lasted from 1914 to
1918 ... After it came the Russian Revolution (1917), the Russian Civil War (1917), the 1918–1920 flu pandemic ...".

**4. In the talk.**
- The news names an event with its card: "Word from nearby: [the Battle of Marignano]. Soldiers on the roads, not a
 new town." The news card gains "Who took part?" and "Why did it happen?" when the card knows them.
- An event card answers "What is it?", "When was it?", "Where was it?" (with the distance, and the compass), "Who took
 part?", "Why did it happen?", "What came of it?" and "What happened in it?" (a war's battles so far), each name a link.
- "What is this place?" has a new follow-up, "What happened here before?": the best known events within 25 km that
 were over before this year ("People here remember the Battle of Hastings (1066)" in 1200; Waterloo, Fleurus, Ligny
 and Quatre Bras in 1900; the three battles of Panipat in 1800).

**5. Natural events (C21).**
- Storms: NOAA's IBTrACS (every tropical cyclone since 1842, public domain): one event where a storm came ashore, or
 passed within 60 km of land, with tropical-storm winds or more: **5,884 events** from 13,238 storms
 (`history/events_storms.json.gz`): "Typhoon Haiyan (winds of about 310 km/h)", "Hurricane Katrina", "the hurricane of
 1900" (Galveston), Bhola 1970, Nargis 2008. 1,289 storms Wikidata knows by name and year carry its number, so their
 cards open from the news.
- Floods (649), wildfires (437), tornadoes (312), epidemics (134), landslides (111), heat waves (62), avalanches (52),
 famines (47) and droughts (40) from Wikidata: **1,844 events** (`history/events_nature.json.gz`); 178 that repeat an
 event already in `events_hazards.json.gz` are left out; 765 placed only by their country are news from the whole land.
- The history data now has 129,163 events (was 121,435).

**6. Occupied and disputed land (known problems 39 and 40).**
- Occupations of the Second World War: step 26 gave occupied lands back their own state; the occupation itself is now
 kept square by square (`history/occupations.json.gz`, 7,302 squares, read from the record before step 26's fix, so
 nothing is guessed) and said after the state: "This land belongs to the Kingdom of Denmark, ruled by Christian X.
 German troops have held this land since 1940." Also Paris, Oslo, Batavia ("Japanese troops"), Nanjing, Tehran
 ("British troops"), Warsaw, Manila, Pyongyang ("Soviet troops" 1946-47) - only in those years.
- Disputed land (`history/disputed_lands.json`, hand-written in the mod's own words, rough outlines): the West Bank, the
 Gaza Strip, the Golan Heights, Crimea, Northern Cyprus and Western Sahara say who holds the land and who claims it
 ("Russia has held this land since 2014. Ukraine claims it, and most countries agree it is Ukraine's.") instead of the
 record's "This land belongs to ...". Tel Aviv, West Jerusalem, Sevastopol before 2014, Limassol and Ramallah in 1960
 keep the record's line.

**Checks of this step.**
- Part 17 of `/ee check all` (new, 10 checks): the event file loads; every card is found by its number; the First World
 War through 1913, 1916 and 1925 (nobody knows the future); the causes of the Second World War with links; the graph
 stored both ways; Hastings remembered in 1200, not in 1050; the news naming Marignano, Katrina and Haiyan with their
 cards; the storms and other natural events in the history data; occupied land (Paris 1942, Batavia 1944, not Paris
 1946); disputed land (the West Bank, Crimea; not Tel Aviv).
- New probe `probe_eventcards.sh` (20 checks): the above, 2,503 sampled events worded in five years each (11,202
 wordings: no later year, every link known on its date, no source names), the graph both ways (7,862 of 7,863 links),
 six occupied and six disputed places and five beside them, the speed (a place's past 0.15 ms).
- `probe_check.sh`: 166 checks, 164 OK, 2 known (was 156). `probe_memory.sh`: 144.0 MB (was 139.2: the event cards 1.9
 MB, the occupations 0.3 MB, the new events 2.7 MB). Unchanged and passing: cards 48, knowledge 45, book 11,
 talk_layout 10, events (the report: 129,163 events, 0.01 ms a query).
- Test server (`logs/step28_server_session.txt`): `/ee check all` from the console **219 passed** (was 209), as the
 player **222** (was 212), 2 known; World War I in 1916 (what, why, its battles so far), Paris and Oslo in 1942 (German
 troops), Ramallah and Simferopol in 2020 (disputed), the news of Marignano 1515 and Haiyan 2013 with their cards,
 Hastings in 1200 ("What happened here before?").
- On the way: the two card files share the tile cache, and their tiles had the same names; the cache key now carries
 the file's name (found by the new check, which failed until then).

**The data list:** 66 files (65 shipped, 40.0 MB of the 64 MB budget), 23 sources (IBTrACS is new: public domain,
cite Knapp et al. 2010).

**Records:** `fetch_events_wd.py`, `build_event_cards.py`, `build_nature.py`, `build_occupations.py`,
`logs/step28_events_report.json`, `logs/step28_server_session.txt`, `probes/EventCardsProbe.java`,
`probe_eventcards.sh`, `java_changes_step28.patch` (checked with `patch -p1`, then compared), `step28_java_after.tar.gz`.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 47–52).
- The graph is thin: Wikidata has causes for 2,284 events and effects for 1,534; most battles only say which war they
 belong to. Step 49 adds rules where the data is silent.
- Sides are Wikidata's participants, best known first: the Second World War lists the United States, Mexico,
 Australia, the United Kingdom and Egypt (Germany and Japan come under "Axis powers").
- Natural events placed only by their country (765) sit at the country's middle point: a flood "in the United States"
 is told around Kansas.
- Storms come ashore where IBTrACS says; their winds are those at landfall (Mitch reached Honduras far weaker than at
 its peak), and storms before 1940 often have no winds (then they are left out).
- The outlines of disputed land are rough (a few kilometres out near their edges); occupations cover only the Second
 World War; other occupied land (Iraq 2003, the Baltic states 1940) says nothing yet.
- The event cards' years come from Wikidata, checked against the history data only for its own events (133 years taken
 from it); the linked events (wars, treaties) are not yet checked against Wikipedia.

The places and events in memory (73 MB) are still loaded whole (known problem 37): they become tiles together with the
places and the border map in step 34.

Next: step 29, local rulers, divisions, place names, towns' lives and population (C2–C6, C28).

## Step 29: towns through time, and the ties between states (2026-10-15)

Turn 107, "next". Systems C2 (local rulers and officials), C3 (divisions by era), C4 (place names by era), C5 (towns'
lives), C6 (how many people) and C28 (relations between states) of `SYSTEMS_PLAN.md`.

**1. The town list.** `history/towns.json.gz` (1.9 MB, built by `build_towns.py` from `fetch_towns_wd.py`) keeps
**30,151 towns**: every human settlement in Wikidata with a point and a population figure of 20,000 or more, every
settlement with a dated official name and 8 or more Wikipedia articles, the 4,112 cities of step 26, and the towns of
Wikipedia's "List of city name changes". 1,812 entries that are districts rather than towns, and 408 without a name in
Latin letters, are left out. For each town: its names by era, its population figures with their years (at most 12,
spread over the years), its founding year, the provinces and districts it lay in by era, and the office of its head.

**2. Names by era (C4).** Three layers, the last one wins: Wikipedia's list of city name changes (its dated lines, 104
towns; a coarse list, so it only fills years the next layer leaves open), Wikidata's official names with dates (one
name per stretch of years: English first, then languages written in Latin letters; Russian and Ukrainian names spelled
in Latin letters for towns Wikidata names in no Latin language), and a short table of famous renamings written from the
towns' own Wikipedia articles (47 towns: Byzantium and Constantinople, Edo, Calcutta, Rangoon, Saigon, Khanbaliq and
Beiping, Chang'an, Bangalore, Poona, Cawnpore, Benares, Baroda, Trivandrum, Allahabad, Cochin, Lourenço Marques,
Fort-Lamy, Stanleyville, Élisabethville, Gorky, Kuybyshev, Sverdlovsk, Alma-Ata, Frunze, Stalinabad, Tiflis, Breslau,
Stettin, Pressburg, Lemberg, Karl-Marx-Stadt, Smyrna, Angora, Adrianople, Bytown, York, New Amsterdam, Tenochtitlan,
Hanseong and Keijō ...). **3,892 towns** have names by era. A change in the first half of a year counts from that year.
- Every site of the history data that is a town of the list (by name, now or in an earlier era, within 30 km) takes the
 town's name of that year: "This is Bombay, year 1900" (the site's id is "mumbai"), "This is Mumbai, year 2026"; Edo
 1700 / Tokyo 1900; Léopoldville 1955 / Kinshasa 2000; Byzantium 500 BCE / Constantinople 1000 and 1800 / Istanbul
 1950; Petrograd 1920 / Leningrad 1950 / Saint Petersburg 2000; Stalingrad 1940; Danzig and Breslau 1900; Salisbury
 1970; Saigon 1960; Rangoon 1950; Christiania 1850 / Kristiania 1900 / Oslo 1950; Beiping 1935; Königsberg 1900;
 Batavia 1900; New Amsterdam 1650; Tenochtitlan 1450; Alma-Ata 1950; Bangalore 1990 / Bengaluru 2020. A site without a
 dated name takes the town's name today ("Wroclaw" is Wrocław, "Ho Chi Minh" Ho Chi Minh City); a site that is no town
 of the list keeps its own name (Pleiades' and CHGIS's old names stay).
- Where the history data has no site but a town of the list stands there by then, the place line names it ("This is
 Kigali, year 2000" instead of "People live around here"). Small renamings come too: "This is Pittsburg, year 1900"
 (the official spelling from 1891 to 1911).
- After a renaming people remember: "It was called Bombay until 1995." Another name in use: "Travellers also call it
 Bhagnagar." (Hyderabad, 17th century).

**3. People, founding, growth (C5, C6).** "About 780,000 people live in Bombay." from the census figures: a straight
line between two counts (no line across a gap of more than a century), never before the first count, at most 15 years
after the last (24,983 towns, 107,671 figures). "The town is growing fast." / "Fewer people live here than twenty years
ago." when both counts are known. "People say the town was founded in 1591." (Wikidata's founding years; 307 that are
refoundings - the town has older names or counts, like Istanbul's 1453 and Tokyo's 1868 - are left out; Hyderabad's
year is Wikipedia's 1591, Mumbai's 1507 left out). The HYDE estimates still answer where the town list has no count.

**4. Provinces by era (C3).** "Which province is this?" - a new question on the place card: "It lies in the Bombay
Presidency." (1900), "It lies in Bombay State." (1955), "It lies in Maharashtra." (2000), "It lies in Hyderabad
district, in Telangana." (2020), "It lies in the Khedivate of Egypt." (Cairo 1900). From Wikidata's "located in" with
dates (27,585 towns, 15,849 provinces): one province per stretch of years, the best kind first (a state or province,
then a colony or princely state, then a former province); a statement without dates counts from the province's own
founding (or 1990); a district names the province it lies in today. A province with the ruling state's own name
(Hyderabad State under the Nizam) is left to the ruler line.

**5. Who runs the town (C2).** "Who runs this town?" - a new question: "Anne Hidalgo is the mayor of Paris (since
2014)." "Michael Bloomberg is the Mayor of New York City (since 2002). David Paterson is the Governor of New York (since
2008)." "Revanth Reddy is the Chief Minister of Telangana (since 2023)." "Jim McGirr is the Premier of New South Wales
(since 1947)." From the offices of the town's head and its province's head (Wikidata P1313/P1906) and their holders
with years (P39): 3,724 offices, 30,206 holders. A holder is named only while the term lasts (or, without an end year,
until the next holder and at most 12 years). 15 general offices ("mayor", "governor", named by three or more places)
are left out, since their holders come from everywhere.

**6. Ties between states (C28).** "Which states is it tied to?" - a new question on the state card, from
`history/state_relations.json.gz` (538 ties, built by `build_relations.py`):
- Cliopatria's relation rows (the source of the ruler register, so the names are the register's): alliances (the
 Byzantine Empire and Khazaria 633-869), allegiance ("Joseon owes allegiance to the Ming Dynasty" 1395-1571), vassals
 ("the Kingdom of Bohemia is a vassal of the Holy Roman Empire"; from the other side: "The Kingdom of Bohemia is its
 vassal."), shared rulers (the Crown of Aragon and the Crown of Castile), and the larger realms a state belonged to
 ("It is part of the British Empire." for the British Raj and the Khedivate; "It is one of the Taifas of Iberia.").
- Members of 16 military alliances from Wikidata with the years of each membership: "It is a member of NATO (since
 1949)." (Italy 1960; France's Fifth Republic, since 1949, the year France joined), "It is a member of the Warsaw Pact
 (since 1955)." (East Germany 1970, not 1950), the Central Powers and the Allies of the First World War, the Axis, the
 Holy League, the League of Cognac, ANZUK, the CSTO and GUAM. A member is matched by its own Wikidata number, or else by
 its country (not the country's colonies).

**Checks of this step.**
- Part 18 of `/ee check all` (new, "towns", 7 checks): the town file loads; names follow the year (Bombay/Mumbai,
 Edo/Tokyo, Léopoldville/Kinshasa, Constantinople/Istanbul, Leningrad/Saint Petersburg); Calcutta's people in 1901
 (847,796, the census), 1950 (between two counts) and 1600 (unknown); provinces by year; town heads by year (nobody
 in New York in 1500); the place card's name and province (Bombay 1900); ties between states by year.
- New probe `probe_towns.sh` (10 checks; also runs both `--check`s): 42 renamed places all over the world (42 of 42),
 people counts for every town in every 13th year since 500 BCE (none zero or negative), 9 provinces and 5 heads by
 year, a sweep of 400 towns in 13 years (no town named before it is known, no name outside its years), the lookup
 speed (about 0.03 ms), a tour of 15 places with their place and state cards, ties by year.
- `probe_check.sh`: 173 checks, 171 OK, 2 known (was 166). `probe_memory.sh`: 155.6 MB (was 144.0: the towns 11.4 MB,
 the ties 0.2 MB; the town file loads in about 0.15 s, in the background load at world start). Unchanged and passing:
 cards 48, eventcards 20, knowledge 45, book 11, talk_layout 10, screens, tiles ("TILES OK"); `probe_name_pools.sh`
 shows 1 old failure (Bombay 1900's name list; nothing here touches the name lists).
- Test server (`logs/step29_server_session.txt`, two runs; the second on the final build): `/ee check all` from the
 console **226 passed** (was 219), as the player **229** (was 222), 2 known; talks at Bombay 1900 (the name, "Which
 province is this?", the British Raj "part of the British Empire"), Paris 2015 (people, founding, "Anne Hidalgo is the
 mayor of Paris (since 2014)"), Hyderabad 2026 (9.2 million people, the Chief Minister of Telangana), Léopoldville
 1955, Edo 1700, Joseon 1500 ("It owes allegiance to the Ming Dynasty"), Kigali 2000 (no history site: the town list
 names it), Leningrad 1950, East Germany 1970 (the Warsaw Pact), New York 2010 (the mayor and the governor; "It was
 called New Amsterdam until 1664").
- Both builders give the same bytes when run again.

**On the way (snapshot space).** The workspace snapshot was close to its limit (119 of about 128 MB). Three old big
files are now stored gzipped: `eternal/places_2026_2d.html.gz`, `eternal/places_increase_2d.html.gz` (unzip them to
open them in a browser) and `worldfill/step25_changes.csv.gz` (`fix_history_data.py` now writes it gzipped). Gradle's
project cache moved from `eternal/.gradle` to `~/.cache/eternal_project_cache` (the three tool scripts pass
`--project-cache-dir`). The workspace is now about 103 MB.

**The data list:** 68 files (67 shipped, 43.8 MB of the 64 MB budget), 23 sources (no new source: Wikidata, Wikipedia
and Cliopatria).

**Records:** `fetch_towns_wd.py` (every query), `build_towns.py` (`--wiki`, `--select`, `--divisions`, `--parents`,
`--offices`, `--build`, `--check`; the hand tables `HAND_NAMES`, `HAND_ALSO`, `HAND_FOUNDED`), `build_relations.py`
(`--fetch`, `--build`, `--check`), `logs/step29_towns_report.json`, `logs/step29_relations_report.json`,
`logs/step29_server_session.txt`, `logs/step29_towns_probe.txt`, `probes/TownsProbe.java`, `probe_towns.sh`,
`java_changes_step29.patch` (checked with
`patch -p1`, then compared), `step29_java_after.tar.gz`.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 53–60).
- Town heads are thin: 1,578 of 30,151 towns have a head with dated holders, and many lists have gaps (Mumbai's mayors:
 two); the province's head fills in where it is known. Zamindars, and nawabs and rajas of princely states that
 Wikidata does not tie to the town's province, are not named.
- Population figures are Wikidata's: some count the city, some the whole urban area (Hyderabad 9.2 million), and many
 big towns have only recent counts (Paris from 1990, Tokyo from 2005).
- Founding years are Wikidata's, said as "People say ..."; some refoundings may remain.
- Names by era cover towns Wikidata, Wikipedia's list or the hand table date (3,892); Greek, Arabic, Chinese and Japanese
 names are not spelled in Latin letters (Edo comes from the hand table); spellings (Peking, Canton) are not changed;
 the 20,000-people limit leaves most villages without names by era.
- Provinces come by town, not as areas between towns; a district's province is today's; some names are bare ("Seine"
 for the Seine department).
- Ties: Cliopatria's relation rows are few (385 rows, mostly before 1600) and military alliances are 16; tribute and
 trade partners are not in yet; a short alliance without membership years takes its own years (Greece among the Allies
 from 1914, though it joined in 1917). The old treaty simulation (`DiplomaticTreatyEngine`) is still not reviewed.

Moved on, not done in this step: residences and places of work for famous people (known problem 41 → step 38), ruler
cards and links for rulers without a card (44 → step 38), occupations other than the Second World War (51 → step 40),
card descriptions with today's place names (42 → step 30b).

Next: step 30a, the technology atlas (C16, `TECHNOLOGY_PLAN.md`).

## Step 30a: the technology atlas (2026-10-15)

Turn 108, "next". System C16 of `SYSTEMS_PLAN.md` (technology by place and era), as planned in `TECHNOLOGY_PLAN.md`
(turn 94): which technology is in use where, in every year, and how common it is there.

**1. The country of any point.** `history/countries.grid.gz` (89 KB, built by `build_country_grid.py` from Natural
Earth's countries, public domain): a grid of 0.1 degrees (about 11 km) over the 258 countries and territories of
today, and each country's biggest town (from step 29's town list; for China the old heartland at Luoyang instead of
Chongqing's huge municipality). A coastal point whose square is mostly sea takes the nearest land within about 35 km.
It puts Kinshasa and Brazzaville on the right sides of the river, Lesotho inside South Africa and San Marino inside
Italy. Later steps (economy, languages) can use it too.

**2. The atlas.** `history/technology_atlas.json.gz` (76 KB, built by `build_technology_atlas.py`) keeps **130
technologies** in 16 fields: farming (the plough, water mills, windmills, tractors ...), building (fired brick, cement,
lifts, tall steel buildings ...), metals (bronze, iron, steel, cast iron, coke ironworks, the steel processes), energy
(steam engines, electric light, gas lights, atomic power), land transport (wheeled carts, horses, chariots, camel
caravans, coaches, bicycles, the railway, trams, cars, buses, lorries, aeroplanes, motorways, high-speed trains),
water (the compass, steamships, motor ships), communication (the post, semaphore towers, the telegraph, the telephone,
radio, television, cinema, photographs, newspapers), writing (writing, the Indus script, paper, woodblock printing,
movable type, printed books, spectacles, clock towers, watches, telescopes), war (stirrups, crossbows, siege engines,
mail and plate armour, gunpowder, cannons, matchlocks, flintlocks, rifles, machine guns, tanks), medicine (smallpox
vaccination, anaesthesia, clean surgery, X-rays, penicillin, children's vaccines, scanners), textiles, crafts, the home
(fans, refrigerators, washing machines ...) and computing (computers, home computers, mobile phones, the internet,
smartphones, cash machines, bank cards). For each: its name, field, what it needs, what it replaces, and the year it
reached each of the 258 countries.
- **Recorded (3,499 country years):** written by hand from English Wikipedia's articles (turn 12: Wikipedia first;
 `technology_table.py`, the main article named for each): paper reached Samarkand in 751 and Baghdad in 793; the
 printing press Mainz 1440, Subiaco 1465 ... Goa 1556, Mexico City 1539, Moscow 1564, Cambridge (Massachusetts)
 1638; the railway Stockton 1825, Bombay 16 April 1853, Calcutta 1854, Madras 1856, Hyderabad (Wadi to Secunderabad)
 1874, Tokyo 1872, Vladivostok 1897; television from Berlin 1935 to Bhutan 1999.
- **From CHAT (226 country years):** the Cross-country Historical Adoption of Technology data (Comin and Hobijn, NBER;
 104 technologies in 161 countries, 1800-2008; public domain) for countries the table does not name: the first year a
 figure rises above zero after zeros.
- **Estimated (26,155 country years, marked):** the earliest arrival from any land that has it, at the speed of its era
 (3 km a year before 1000 BCE ... 150 km a year from 1850, 500 after 1950; half that for what a town must build), never
 earlier than what it needs, and never before the outside world reached a land: nothing from the Old World in the
 Americas before 1492 (the colonists' own tools came with them at contact: iron in Mexico 1519, Peru 1532), in
 Australia before 1788 or Iceland before its settlers in 874; technologies from Europe wait for Japan to open in 1853
 and Korea in 1876, and those of 1440-1800 for inland Africa until 1800; no carts or ploughs in tropical Africa before
 colonial times and no horses where tsetse flies live; things the record says were made only in a few lands
 (porcelain, high-speed trains, atomic power stations, war chariots, semaphore towers) are never estimated.
- **Losses:** writing in Greece's dark age (1100-800 BCE), the Indus script after 1900 BCE, wheeled carts in the Arab
 lands from 500 to 1850 (the camel took their place), bricks in Britain after the Romans, semaphore towers after the
 telegraph, chariots, plate armour.

**3. Inside a country.** A technology spreads from the places a record names (India's railway from Bombay, Calcutta,
Madras, Delhi and the Nizam's line at Hyderabad; Russia's from Saint Petersburg, Moscow and Vladivostok) or from the
biggest town, at the speeds of its era: what a town must build slower, what people buy faster; the town a record names
keeps its own year (Hyderabad's railway came in 1874, not with Bombay's spread). A Mesoamerican invention
stayed in Mesoamerica before the Spanish (no bark paper in the deserts of northern Mexico). A point outside its
country's own part of the world (French Guiana under France, Hawaii and Alaska under the United States) waits for its
own contact year. A household thing never comes before what the town must build for it (no television before electric
light at that very place).

**4. How common.** For things households have, CHAT's figures per person (radios, televisions, telephones, cars, mobile
phones, internet users, home computers, newspapers, card payments, children's vaccines), against a full level: motor
cars in Hyderabad in 1948 are for "a few rich people" (0.3% of homes in a city, from India's 0.06%), television in most
London homes in 1965. After CHAT's last year (2000-2008) a curve on to the top. Everything else follows a curve from
its arrival: half of the towns after so many years (the railway 40, radio 20, iron 300), cities in half that time,
villages in twice. A thing a town builds (the railway, gas lights, a clock tower) is in this town or not: a fixed draw
per town against the share of towns of its size that have it; the town a record names has it from that year. Heavy
industry stays rare (coke ironworks in at most 15% of towns). Steamships call only at ports. An older technology fades
as its newer one spreads (gas lights as electric light comes, feature phones as smartphones come).

**5. In the game.**
- "What new things are there here?" (a new question on the place card): Hyderabad 1948 "People here have electric
 light, picture houses, the railway, steam engines and vaccination against smallpox. A few rich people have radio and
 motor cars. Nobody here has television yet."; Cusco 1500 "People here have paved roads. Nobody here has printed books, iron
 or horses yet."; Edo 1850 "... printed books, iron, horses, a clock tower, cannons, surgery with anaesthesia and
 porcelain. Nobody here has the telegraph, the railway or steamships yet."; London 1700 "... the public post, horse
 carriages, printed books, flintlock muskets and telescopes. Many homes have printed newspapers."; Rome in 100 "...
 iron, horses, steel, paved roads, aqueducts and mail armour."; Moscow 1700 "... Nobody here has printed newspapers
 yet." (Russia's first came in 1702).
- Vehicles: the fastest way to travel follows the place (`VehicleType.fastestLandAt`; `/ee vehicle test` where the
 player stands): Bombay by horse in 1850 and by train in 1870, Kabul still by horse in 1900, Cusco 1500 on foot with
 llamas; as the test player in Rome a horse in 1830 and a train in 1870.
- `TerraTimeBridge.isInfrastructureAllowed(type, lat, lon, year)`: railways, power lines, runways, motorways, solar
 panels and wind turbines from the year the atlas gives the place (Terra++ does not call it yet; its own world-wide
 "no railways before 1825" rule is step 31's to check).

**Checks of this step.**
- Part 19 of `/ee check all` (new, "technology", 7 checks): the country grid (8 places, the river at Kinshasa, Lesotho,
 Bombay's coast); the atlas loads; the five places of the plan (14 of 14: Hyderabad 1948 has the railway, cars and
 radio but no television; Hyderabad 1500 paper but no printing; Cusco 1500 no iron, carts or horses; London 1700
 printing but no steam engines; Beijing 1100 printing and gunpowder); how common cars were in Hyderabad in 1948;
 nothing from the Old World in the Americas before contact or in Australia and New Zealand, nothing anywhere before its
 first year; the fastest way to travel by place; the place card's new question.
- New probe `probe_technology.sh` (11 checks; also runs both `--check`s): 12 places of the grid (coasts and enclaves),
 the plan's places, how common (cars, television, mobiles), 400 points in the Americas in 1491 and Sydney 1787 and
 Iceland 850 (nothing from the Old World), the spread inside India and Russia (Bombay 1853, Hyderabad 1874,
 Vladivostok 1897), a sweep of 500 land points in 13 years (206,414 technology-town-years, nothing before its first
 year), a tour of 18 places, vehicles, the speed (0.19 ms a talk line).
- `probe_check.sh`: 180 checks, 178 OK, 2 known (was 173). `probe_memory.sh`: 156.4 MB (was 155.6: the grid 0.3 MB,
 the atlas 0.5 MB). Unchanged and passing: towns 10, cards 48, eventcards 20, knowledge 45, book 11, talk_layout 10,
 screens, tiles ("TILES OK"). `probe_name_pools.sh`: 1 old failure (Bombay 1900's name list); the "3 old failures" of
 earlier steps came from the probe reading a stale or missing `build/resources/main` (its language data did not
 load); it now reads `src/main/resources`, as the other probes do.
- Test server (`logs/step30a_server_session.txt`, two runs; the second on the final code): `/ee check all` from the
 console **233 passed** (was 226), as the player **236** (was 229), 2 known; the new question at Hyderabad 1948 (in
 its knowledge pack) and 1880, Cusco 1500, Edo 1850, London 1700, Beijing 1100; `/ee vehicle test` as the player in
 Rome (horse in 1830, train in 1870). One data change came after the second run (running water became a thing a town
 has, not a household's: Hyderabad 1880 had said "Many homes have running water in homes"); `probe_check.sh` (the same
 checks offline) and `probe_technology.sh` were run again on it and pass.
- Both builders give the same bytes when run again.

**On the way.** `tools/restore_build_env.sh` (new): one command restores the JDK, Gradle's first compile, the runtime
classpath and the test helper after the sandbox loses `~/.cache` (it did at the start of this turn; it took about three
minutes in the background).

**The data list:** 70 files (69 shipped, 44.0 MB of the 64 MB budget), 25 sources (new: Natural Earth, public domain;
CHAT, public domain, cite Comin and Hobijn 2009).

**Records:** `technology_table.py` (130 technologies, every record with its note; groups, contact years, settlement
years, closed lands), `build_country_grid.py`, `build_technology_atlas.py` (`--check`), `logs/step30a_technology_report.json`,
`logs/step30a_technology_probe.txt`, `logs/step30a_server_session.txt`, `probes/TechnologyProbe.java`,
`probe_technology.sh`, `tools/restore_build_env.sh`, `java_changes_step30a.patch` (checked with `patch -p1`, then
compared), `step30a_java_after.tar.gz`.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 61-66).
- Only 11% of the country years are recorded (3,499 by hand, 226 from CHAT); the rest are estimates from the nearest
 land, so small or remote lands can get a technology too early (electric light in Botswana in the 1880s, television in
 Lithuania in 1939) or late.
- Inside a country the spread is distance and era speed only: lands that held a technology back (printing in Mughal
 India before 1800) are not modelled; rivers are not on the grid (steamboats on the Nile, the Mississippi or the
 Yangtze do not count).
- "How common" comes from CHAT for 10 household things and from a curve for the rest; the gap between cities and
 villages is a fixed rule.
- Not replaced yet: the old technology engine (7 technologies per civilization, with no place), the world-wide medicine
 steps, and Terra++'s own railway rule; buildings, weapons, tools and recipes (steps 33, 40, 45-47) will ask the atlas.
- 130 technologies, not the planned 150; the 7 old ones are not mapped to the atlas.
- The grid is 0.1 degrees: a town within a few kilometres of a border can get its neighbour's country.
- **`travel` mixes years with days, and is left that way** (found in step 37, turn 132). It turns the arrival
 *year* of a speed band into a number of days by multiplication, which is only right when a journey spans
 whole bands: a 4 km hop inside one band came out at 220 days, and Rome to Paris at 16 160. Step 37's news
 code does not call it - `NewsTravel` uses the new `daysToCross(year, km, factor)` and `eraSpeed(year)`
 beside it, which walk the bands carrying leftover kilometres. `travel` is left as it is because the
 130-technology spread above is built on it, and fixing it means re-checking that spread first.

Next: step 30b, economy, faiths and languages (C13, C14, C17, C26, C27).

## Step 30b: reading, scripts, measures, wealth, holy places and festivals (2026-10-15)

Turn 109, "next". Systems C13 (faiths: holy places, festivals, pilgrimages), C14 (languages and scripts), C17
(economy: wealth and hard times), C26 (weights, measures and distances) and C27 (reading) of `SYSTEMS_PLAN.md`.

**1. Who can read, and in which script (C27, C14).** `history/culture.json.gz` (54 KB, built by `build_culture.py`)
keeps literacy by country and year from Our World in Data (CC BY 4.0: UNESCO's census studies of 1953 and 1957,
Buringh and van Zanden 2009, van Zanden et al. 2014, the UNESCO Institute for Statistics): 211 countries with their own
figures, from 1475 for ten European lands; 40 more take their UN subregion's. Before a land's first figure the
technology atlas decides: nobody reads where there is no writing (Cusco 1500: "the officials keep their records on
knotted cords (quipu)"); before printing a few priests and scribes (about 2%; about one in ten in the Roman world, after
W. V. Harris); after printing, back from the first figure, falling by about a third every 50 years. Cities read more
(x1.4), villages less (x0.7); men more than women, the gap closing as more people read. The script each language is
written in, by years (97 languages, from each language's Wikipedia article): Turkish in Arabic letters until 1928, then
Latin; Azerbaijani Arabic, Latin, Cyrillic, Latin; Marathi in Modi until 1950; Vietnamese in Chinese characters until
1918; simplified Chinese from 1956; Korean hangul from 1446; English in runes before 650.
- "Can people here read and write?" (new on the place card): Hyderabad 1948 "About 23% of people here can read and
 write: one man in 3, one woman in 9. They write Telugu in the Telugu script."; Hyderabad 2026 "Nearly everyone here
 can read and write. They write Telugu in the Telugu script; the government writes Hindi in Devanagari."; Rome 100
 "About 11% ... Those who write, write Latin in the Latin alphabet."; Moscow 1700 "About 12% ... They write Russian in
 Church Slavonic Cyrillic."

**2. Weights, measures and distances (C26).** 35 systems by land and era, written from Wikipedia's articles on each
(Mesopotamian, Egyptian, Biblical, Persian, Greek, Roman, Byzantine, Islamic and Arabic, Ottoman, ancient and later
Indian, Chinese, Korean, Japanese, Vietnamese, Thai, Burmese, Malay, Russian, English and American, French, Spanish,
Portuguese, German, Dutch, Scandinavian, Italian, Polish, Inca, Aztec, Ethiopian), each with the years it held in each
land (Spanish measures in Mexico from 1521, English ones in Nigeria from 1861, Ottoman ones in Greece 1460-1830), and the
year each country began the metric system (Wikipedia's "Metrication" table for 74 countries, the countries' own
articles for 20 more, then the colonial power's time or 1970, marked as estimated).
- "How do people here measure things?": Hyderabad 1900 "People here count distance in the kos (about 3.2 km), measure
 cloth by the gaz (about 91 cm), weigh goods by the seer (about 930 g) and the maund (about 37 kg) and measure land by
 the bigha ... Gold and silver go by the tola (about 12 g)."; Hyderabad 1970 "The law says metres and kilograms (since
 1956), but in the market people still speak of the seer, the maund and the kos."; Hyderabad 2026 metres; Moscow 1900
 versts and poods; Cusco 1500 the Inca tupu; New York 2000 miles and pounds (the United States never went metric);
 Lagos 1800 "People here measure distance in days of walking ..." (no standard measures there).

**3. Rich or poor, and hard times (C17).** GDP per person from the Maddison Project Database 2023 (CC BY 4.0), 165
countries from year 1 to 2022 (65 more take their region's), in seven steps from "very poor: they grow their own food and
have little else" to "one of the richest lands in the world", with the change over 30 years ("Life is getting better
quickly"). And 26 hard times from Wikipedia: the hyperinflations (Germany 1921-23, Hungary 1945-46, China 1946-49,
Zimbabwe 2007-08, Venezuela 2016-21 ...) and the depressions (the Panic of 1873, the Great Depression, the post-Soviet
collapse of the 1990s, the Latin American debt crisis, the Asian crisis of 1997, the crash of 2008, Greece 2010-15).
- "Are people here rich or poor?": India 1900 "Most people here are poor farmers; a few landlords and merchants are
 rich."; Berlin 1923 "... Prices rise every day; people carry their wages home in baskets ..."; New York 1932 "...
 factories have closed, banks have failed, and many people have no work."

**4. Holy places, festivals, pilgrimages (C13).** `history/holy_places.json.gz` (433 KB): 19,828 places of worship from
Wikidata with 5 or more Wikipedia articles, each with its kind (mosque, Hindu temple, cathedral, Shinto shrine ...), its
faith and the years it stood (63 famous ones without a founding year in Wikidata dated from their Wikipedia articles:
the Masjid al-Haram 630, the Temple in Jerusalem 957 BCE to 70 CE, Kashi Vishwanath 1780 ...; the rest without a year
named only from 1900; ruins with neither a faith nor a year left out). 30 faith families, each with its great festivals
and pilgrimages with their years (Diwali from about 600, Vaisakhi from 1699, the Olympic Games 776 BCE to 394 CE, the
Hajj, Varanasi, Santiago de Compostela from 830, Lourdes from 1858, the Golden Temple from 1604, Mount Wutai, Mount
Kōya, Ise ...). The nearest holy journey of the faith is told (before 1900 only within about 3,000 km, except the Hajj).
The feast of the day by the calendar: Christmas and Easter (Western, and Orthodox by the Julian calendar), Ramadan, the
two Eids and Ashura (the tabular Islamic calendar).
- "What are the holy places and festivals here?": Hyderabad 1948 "The holy places here: Charminar (a mosque, built in
 1591), the Mecca Masjid (a mosque, built in 1694) and the Spanish Mosque (a mosque). Hindus here keep Holi, Diwali,
 Dussehra and Makar Sankranti; Muslims keep the fast of Ramadan, Eid al-Fitr and Eid al-Adha. Hindus here go on
 pilgrimage to Varanasi on the Ganges, about 1,000 km away."; Benares 1800 "... Pilgrims come here from far away for
 Varanasi on the Ganges."; Cairo on 10 April 2024 "... It is Eid al-Fitr: people here put on new clothes, pray
 together and visit their families."; London on Christmas Day 1900 "... Today is Christmas ..."; Rome in 100 "the Temple
 of Vesta ... People here keep the Saturnalia, the Lupercalia and the Floralia."; Tokyo 1850 "... Buddhists here go on
 pilgrimage to Mount Kōya, about 400 km away."; Beijing 1100 "... to Mount Wutai, about 300 km away."

**Checks of this step.**
- Part 20 of `/ee check all` (new, "culture", 7 checks): the data loads; who reads (India 1901, nobody in Cusco 1500)
 and the Turkish script change of 1928; measures (Hyderabad 1900 and 1970, New York 2000); wealth and hard times (India
 1900, Berlin 1923, New York 1932); holy places by year (the Mecca Masjid in 2000, not 1500) and pilgrims at Varanasi;
 feast days (Christmas 1900 in London, Eid al-Fitr 2024 in Cairo, Easter 2026 in Rome); the four new questions.
- New probe `probe_culture.sh` (9 checks; also runs `--check`): reading, scripts, measures, wealth and hard times, holy
 places, feast days (also Orthodox Christmas in Moscow on 7 January 2000), a tour of 16 places (64 of 64 answers), a
 sweep of 400 land points in random years (reading and measures known for all, 0.04 ms a point).
- `probe_check.sh`: 187 checks, 185 OK, 2 known (was 180). `probe_memory.sh`: 161.8 MB (was 156.4: the culture data 5.4
 MB, most of it the holy places). Unchanged and passing: technology 11, towns 10, cards 48, eventcards 20, knowledge
 45, book 11, talk_layout 10, screens, tiles ("TILES OK"); `probe_name_pools.sh` 1 old failure (Bombay 1900).
- Test server (`logs/step30b_server_session.txt`, two runs; the second on the final data): `/ee check all` from the
 console **240 passed** (was 233), as the player **243** (was 236), 2 known; Cairo on Eid al-Fitr 2024, Benares 1800,
 London on Christmas Day 1900.
- The builder gives the same bytes when run again.

**The data list:** 72 files (71 shipped, 44.5 MB of the 64 MB budget), 27 sources (new: Our World in Data's literacy,
CC BY 4.0; the Maddison Project, CC BY 4.0).

**Records:** `culture_table.py` (measures, scripts, faiths with festivals and pilgrimages, hard times, metric years,
reading before the figures, holy-place years), `build_culture.py` (`--fetch`, `--build`, `--check`),
`logs/step30b_culture_report.json`, `logs/step30b_culture_probe.txt`, `logs/step30b_server_session.txt`,
`probes/CultureProbe.java`, `probe_culture.sh`, `java_changes_step30b.patch` (checked with `patch -p1`, then compared),
`step30b_java_after.tar.gz`.

**Known limits** (also in `SYSTEMS_PLAN.md` part 8, problems 67-72).
- Reading before a land's first figure is a rule, and the gap between men and women a formula; the long reading
 traditions of East Asia and the Muslim world are only as high as the rule makes them.
- One system of measures per land and era; in truth the seer of Bengal was not the seer of Bombay; prices are not yet
 shown in these units (step 44).
- Wealth is national (65 lands take their region's figures); the gap between rich and poor inside a land, prices and
 wages, taxes and banks are not here yet (step 44).
- Holy places are Wikidata's famous ones; a village temple is not on the list; 7,000 without a founding year are named
 only from 1900.
- Feast days by the calendar only for the Christian and Islamic feasts (the Islamic dates by the tabular calendar can be
 a day or two off); Diwali, Holi, the lunar new year and Passover are named but not dated (step 37, local calendars).
- A place's faiths come from its state's record; the shares of an empire count the whole empire (London 1900 lists
 Muslims, from the British Empire's figures).

## Step 31: Terra++'s buildings and roads by year (B7)

**Checked, not changed.** Step 31 is a check, so nothing in the mod or in Terra++ was modified.
The check runs **Terra++'s own dating code** - out of `terra3/` - on today's OpenStreetMap around
the 31 places of the world-wide test set.

**How.** `terra_check.py --fetch` downloads what OSM maps today within 400 m of each test place
(buildings, highways, railways, historic, places of worship). `bash probe_terra.sh` compiles
Terra++'s real `OsmStructureIndex.parseElement()`, `StructureDateEstimator`,
`getPopulationFloor()`, `getTechnologyFloor()` and `HistoricalDateParser.isVisibleAt()` and runs
them outside Minecraft. Five classes that cannot compile without Forge are stubbed in
`probes/terra/stubs/`, each annotated with why it is safe; none of them touches dating. Full
output: `logs/step31_terra_report.txt`.

**Honest limit:** this exercises the **OSM-only** path. A real game also asks OpenHistoricalMap,
looks named buildings up in Wikidata over the network, and has three further building tiers below
OSM. Those add dates; they do not change the finding below.

### What Terra++ does

`HistoricalStructureManager`, in order: an explicit `start_date` on the way (used as-is - the
floors are **not** applied to explicit dates), then Wikidata by name, then
`StructureDateEstimator.estimate()`: the monument gravity model (dated structures within ~500 m
pull the year toward theirs, weighted by 1/d² × significance), clamped by a **population floor**
per world region and a **technology floor** per structure type.

The population floors are 14 latitude/longitude boxes, first match wins, global fallback **1800**:
Middle East −5000, North Africa −3000, South Asia −2500, Central Asia / East Asia / sub-Saharan
Africa −2000, Mesoamerica / Western Europe −1000, South America / Eastern Europe −500,
North America 1500, Siberia 1600, Oceania 1700, Arctic 1800.

The technology floors are sound and were verified to be enforced: railway 1825 (subway 1863,
tram 1881), motorway 1930, trunk 1920, cycleway 1885, suspension bridge 1820, cable-stayed 1950,
parking 1900, runway 1909, street lamp 1800, pylon 1880.

### What the check found

**1. Two test places can show nothing at all.** Cahokia 1100 (North America floor 1500) and
Greenland's Norse farms 1000 (floor 1800) show **0** of their 71 and 30 mapped features.

**2. Greenland falls through a hole between two boxes.** The Norse settlements are at longitude
−46, between the North America box (which stops at −50) and the Western Europe box (which starts
at −25). Nuuk (−51.7) gets 1500; Qaqortoq (−46.0) and Igaliku (−45.4) get the 1800 fallback. The
same hole takes Hawaii (21° N - the Oceania box stops at the equator): 1800, though settled
c. 1100. Fiji and New Zealand get 1700, though settled c. 1000 BC and c. 1350.

**3. 99.1% of mapped structures carry no date, and everything undated falls to the region floor - 
so today's map is drawn in antiquity.** Of **19,272 ways** at all 31 test places, **181** carry an
explicit `start_date` (**0.9%**).

| Place | Year | Ways | Dated | Shown | Median date Terra++ gives |
|---|---:|---:|---:|---:|---:|
| Ur | 2500 BC | 156 | 0 | **156** | −5000 |
| Mohenjo-daro | 2500 BC | 36 | 1 | **36** | −2500 |
| Anyang | 1200 BC | 178 | 0 | **178** | −2000 |
| Pataliputra (Patna) | 300 BC | 107 | 0 | **104** | −1620 |
| Rome | AD 100 | 1,776 | 5 | **367** | 321 |
| Teotihuacan | 500 | 95 | 0 | **95** | −1000 |
| Great Zimbabwe | 1300 | 21 | 0 | **21** | −2000 |
| Cusco | 1500 | 850 | 0 | **850** | −500 |
| Vijayanagara (Hampi) | 1520 | 250 | 0 | **250** | −2500 |
| Delhi | 1650 | 133 | 0 | **133** | −2500 |
| Edo (Tokyo) | 1700 | 181 | 0 | **181** | −2000 |
| Hyderabad | 1948 | 309 | 2 | **309** | 1592 |
| Lagos | 1960 | 1,087 | 0 | **1,087** | −2000 |
| Moscow | 1980 | 839 | 0 | **839** | −500 |
| São Paulo | 2020 | 1,175 | 10 | **1,175** | 1875 |
| Siberia (Yakutsk) | 1900 | 139 | 0 | **139** | 1600 |
| Paris | 1789 | 2,060 | 29 | 688 | 1862 |
| Giza | 2500 BC | 360 | 4 | 82 | 4 |
| Baghdad | 900 | 291 | 1 | 82 | 2017 |
| Timbuktu | 1350 | 1,078 | 1 | 196 | 2016 |
| Tenochtitlan | 1500 | 705 | 1 | 294 | 1987 |
| **Angkor** | 1150 | 192 | 5 | 104 | **1145** |
| London | 1700 | 1,820 | 21 | 137 | 1825 |
| New York | 1920 | 1,725 | 60 | 223 | 1952 |
| Chang'an (Xi'an) | 750 | 690 | 2 | **6** | 1383 |
| Athens | 430 BC | 1,440 | 10 | **6** | 1136 |
| **Sydney** | 1850 | 1,478 | 29 | **4** | 2021 |
| **Cahokia** | 1100 | 30 | 0 | **0** | 1500 (empty) |
| **Greenland's Norse farms** | 1000 | 71 | 0 | **0** | 1800 (empty) |
| **the Amazon** | 1500 | 0 | 0 | **0** | nothing mapped - correct |
| **the Sahara** | 1000 | 0 | 0 | **0** | nothing mapped - correct |

At **Pataliputra in 300 BC, 98 of the 104 features shown are roads**: the modern street grid of
Patna, 66 residential and 27 service roads. At **Rome in AD 100, 367 features** - 112 buildings,
184 footways, 71 roads, 60 flights of steps, median AD 321. At **Cusco in 1500, all 850 mapped
features**, 586 of them buildings; at **Lagos in 1960, all 1,087**; at **Moscow in 1980, all 839**,
dated to −500. The Amazon and the Sahara both answer "nothing mapped here" correctly.

Going the other way, **Sydney in 1850 shows 4 features** (2 buildings and 2 railways, two of
which predate Australia's first railway) because its 29 dated anchors are modern and pull the
city's median to **2021**.

**4. The two failure modes are opposite, and neither is right - except where the map is dated.**

- **No dated anchors nearby** (Ur, Mohenjo-daro, Anyang, Teotihuacan, Great Zimbabwe, Cusco,
 Vijayanagara, Delhi, Edo, Hyderabad, Lagos, Moscow, Yakutsk): everything drops to the region
 floor and is shown in *every* later year. Today's village is drawn as the ancient city - and
 today's Lagos is shown in 1960 dated to −2000.
- **Dated anchors present, but modern** (Athens, Chang'an, Baghdad, Timbuktu, Tenochtitlan,
 London, New York, Sydney): the gravity model pulls everything toward them. Baghdad's single
 dated anchor is a 2017 structure, so the whole city's median becomes **2017**; Sydney's 29 pull
 it to **2021**, leaving 4 features standing in 1850; Athens in 430 BC shows **6 features**.
- **Dated anchors present, and genuinely old - the one place that works.** **Angkor in 1150**:
 104 features, median **1145**, five years from the test year. It works because OSM carries real
 construction dates for the Angkor temples, so the anchors *are* the ancient monuments.

Both failures share one root cause: the population floor is a **lower bound** on when a structure
*could* exist, but it is used as the **estimate** of when a modern mapped structure *did* exist.
The floor says "people lived in the Middle East by 5000 BC"; it does not say "this house stood in
2500 BC".

**5. `OsmDateInferencer` (24 KB) is dead code.** Its main entry point `inferStartYear()` - 
explicit date → heritage clues → building subtype → material and height → road surface → OHM
neighbour → region fallback - is **never called anywhere**. Only
`inferFromBuildingSubtype()` is used, from `StructureDateEstimator.adjustBySubtype()`.
`HistoricalStructureManager` implements the same chain independently.

**6. Explicit dates skip both floors.** At Mohenjo-daro, 1 structure carries an explicit
`start_date` earlier than its region's population floor, and nothing catches it.

### The verdict

Requirement 1's line - *"in each test place and year, no building or road stands before its
time"* - is **not met** by Terra++ as it stands, and cannot be met by the OSM layer alone,
because the OSM layer has almost no dates.

The fix is not in the dating code; it is in **what Terra++ is allowed to show**. The mod already
knows how many people lived at a place in a year (HYDE grids, the 30,151 towns of step 29 with
population by year, the gazetteer, the settlement-year estimator). Feeding Terra++ a *"was this
place inhabited in year Y, and how densely"* query - the A12 link - turns the population floor
from a blanket permission into a real gate. And Angkor shows what the real fix is: dated
monuments. That is steps 32 and 33.

**Records:** `terra_check.py`, `probes/terra/TerraDatingProbe.java`, `probes/terra/stubs/`,
`probe_terra.sh`, `logs/step31_terra_report.txt`, and
`logs/step31_osm/osm_test_places.tar.gz` - the 31 Overpass files themselves (1.7 MB compressed),
kept because `build/` is not snapshotted and the mirrors are unreliable. Restore with
`tar xzf logs/step31_osm/osm_test_places.tar.gz -C build` and `probe_terra.sh --osm` then runs
with no network.

Next: step 32, famous buildings, walls and ruins by year (B8, B16, B19) - 720,735 dated
structures in Wikidata, 282,921 of them before 1900, plus Castlemap's 9,079 castles and forts.

---

## Step 32: famous buildings, walls and ruins by year (B8, B16, B19) - done in turn 114

XL, done in five parts over four turns. What the mod now has:

**A pack of 23,535 famous buildings, each with a point, a start year, and where Wikidata knows it,
an end year.** 561 KB gzipped, shipped in-mod and verified by the manifest like the other
73 data files. (Step 33 added two columns - the architectural style and the materials, where
Wikidata records them: 8,957 rows carry a style, 3,603 a material.) 2,569 carry a real end year; 555 are flagged as ruins whether or not the year they
fell was ever written down; 1,092 are walls, gates, citadels and forts; 12,451 are also holy
places. Loading takes **218 ms**, and a lookup is **10 µs** (20,000 in 204 ms) - fast enough to
call while the player walks.

**Where the dates come from.** Wikidata first: 720,735 dated structures, narrowed by class (46
classes in the end), by having a map point, and by notability. Then the mod's own gazetteer for
the ancient sites Wikidata cannot date - 1,330 from the site packs and 1,334 more from the
gazetteer's own places, **310 matched by name and 1,024 by location**. Every date taken that way
is marked estimated, and `/ee check all` asserts the count and the hash of that set.

**What it answers.**

```
 Here stand Colosseum (an amphitheatre, from 82), Roman Forum (an archaeological site,
Rome, AD 100 from 800 BC) and Palatine Hill (an archaeological site, from 753 BC).
 Its walls, gates and forts: Aurelian Walls (a city wall, from 271), Servian
 Wall (a wall, from 350 BC) and Porta Maggiore (a city gate, from 753 BC).
Rome, AD 300 Its walls, gates and forts: Aurelian Walls ...
Rome, AD 100 Its walls, gates and forts: Servian Wall ... (no Aurelian Walls: 271)
Hampi, 1600 In ruins here: Hampi (an archaeological site, from 1336 until 1565) and
 Vijayanagara (an archaeological site, from 1300 until 1336).
Hampi, 1400 In ruins here: Vijayanagara ... and Aihole ... (no Hampi: it still stood)
Mohenjo-daro, In ruins here: Mohenjo-daro (from 2600 BC until 1900 BC) and Great Bath,
1000 BC Mohenjo-daro.
Mohenjo-daro, (nothing - it stood then, and the register says so)
2500 BC
London, 200 Its walls, gates and forts: Ludgate, Newgate, Temple Bar Gate (all from 43).
Jerusalem, 100 Tower of David (a citadel, from 149 BC), Walls of Jerusalem (a city wall,
 from 18 BC) and Acra (a fortification, from 200 BC).
```

**Three decisions worth keeping.** *(1)* **A castle is not a city's defences**: `castle` is left
out of B16 in both the builder and the register, because a castle is a fortified house, it has its
own kind, and its 1,655 members bury the 26 city walls B16 exists to find. *(2)* **Ruin classes
never win the kind tiebreak**: `castle ruin` is narrower than `castle`, so the "fewest members
worldwide" rule renamed every ruined castle; `kind_of()` skips the ruin classes and falls back to
them only where nothing else applies. *(3)* **The `ruin` flag is a state, not a date**, so it never
feeds `standsIn`/`ruinedIn` - the Colosseum carries it, and "in ruins in AD 100" would be a lie.

**The hook.** `TerraOsmBridge.getFamousBuildings(lat, lon, year, km)` returns them in Terra++'s own
`OsmStructure` shape, so nothing downstream learns a second type. The javadoc is explicit that
these are not OSM structures: `osmId` is a hash of the name, `type` is `"famous"`, the geometry is
a point because Wikidata gives a point. What they carry that an OSM structure usually does not is a
year - `startDate` is always set.

**Checks.** `worldfill/probe_buildings.sh` → `logs/step32_buildings_report.txt`: **16 checks, 0
failures** (10 register, 6 hook), including *none of 3,088 buildings near the test places stands in
the year before it was built*. `/ee check all` asserts the four promises that matter - the
Colosseum in Rome in 100 and not 500 BC; Hampi in 1520 and not 1700; Hampi in ruins in 1600 and not
1400; the Aurelian Walls in 300 and not 100.

**Known limits.**

* **20,966 of 23,535 have no end year**, and `standsIn` reads "we do not know when it ended" as
 "it has not ended". 2,569 have a real end and 555 are flagged; the rest still stand forever. This
 is the register's biggest honest gap and it is not fixable from Wikidata alone.
* **Greenland Norse 1000, the Amazon 1500 and the Sahara 1000 answer nothing.** The last two are
 meant to be empty. The first is a gazetteer gap, unchanged from part 2: no Norse Greenland site,
 and nothing notable within 25 km of the Eastern Settlement's core.
* **Great Zimbabwe's wall is not a city wall in the pack** - the site carries `archaeological site`
 and nothing narrower, so B16 says nothing there.
* **Some end dates are Wikidata's, not history's**: the Palatine Hill "until 1453" is inherited
 from something else on the item. End years are estimates, not facts.
* **Nothing in play calls the register yet.** It loads, answers, and is checked; placement and the
 player-facing systems come with the Terra++ patch below.

**The Terra++ patch this enables, still not applied.** Decision 2 keeps Terra++ changes as a
separate listed patch on the user's own build (`/home/user/terra3`), so it is written down, not
done; nothing in `terra3/` was touched. Where Terra++ is about to place an OSM structure with no
`start_date`, it should ask the mod for the famous buildings at that point in the current year and
place one of those instead of falling through to the population floor. That is the fix for step
31's finding (0.9% of mapped structures carry a date, so today's map is drawn in antiquity) and it
is what makes Angkor's correctness the rule rather than the exception. Open for whoever applies it:
how far from an OSM footprint a famous point may be substituted for it, and what to do where both
exist at the same spot.

**Records:** `fetch_buildings_wd.py`, `date_undated.py`, `build_famous_buildings.py`,
`probe_buildings.sh`, `probes/BuildingsProbe.java`, `probes/BuildingsHookProbe.java`,
`probes/buildings/stubs/`, `com.eternalengine.buildings.FamousBuildings`,
`TerraOsmBridge.getFamousBuildings`, `logs/step32_buildings_report.txt`, and the part-by-part
notes `logs/step32_part1_notes.md` … `step32_part5_notes.md`.

Next: step 33, old towns - houses, insides, streets, materials, lights (B9, B11, B13, B20, E14,
E16, B25).

## Step 33: what a town is made of, by place and year (B9, B11, B13, B20, E14, E16, B25) - done in turn 117

XL, done in five parts over four turns. The question: *here, in this year, what is a house made of,
what are the lanes surfaced with, where does the water come from, what is it lit by after dark,
what is inside a home, and where do people trade?* Wikidata can say there was a qanat at Bam; it
cannot say that a house in Bam in 1600 had a windcatcher over its cistern, that its walls were mud
brick renewed after every rain, or that the lane outside was swept earth with a channel down the
middle. **B11 - what is inside a home - has no dataset at all.** So the half that no dataset can
give is written by hand, from English Wikipedia's articles, and dated.

**A pack of 109 building cultures covering 258 countries** (`history/building_culture.json.gz`,
22 KB gzipped, 1,705 country-slices, shipped in-mod and verified by the manifest like the other
data files). Each row names the house, its walls, roof and floor, how the town is laid out, what
the lanes are surfaced with, where the water comes from, what it is lit by after dark, what is
inside a home, where people trade, and how many storeys - and **every row names the article it was
written from** (77 articles, all checked to exist). It loads in **85 ms**; a lookup is a scan of
one country's slices.

**What the atlas knows is asked of the atlas, not written here.** Fired brick, cement, steel,
glass, paved and tarred roads, running water, candles, gas light, paraffin lamps and electric light
each have an arrival year for 258 countries and a share by the size of the town (step 30a). The
register asks for all ten and lifts its own words, so **the answer moves with the year and with the
size of the town inside one row**: a Bengal village of 1890 has lime and brick where its city
already has cement; Edo in 1700 is lit by paper lanterns and London in 1900 by gas; Sydney in 1850
has a tank off the roof and Moscow in 1980 has hot water from the district heating. The pack
carries only what no atlas can know.

**Which row wins where several reach the same point and year**, in this order:

1. a row carrying a box does not apply at all outside it, and one whose box holds the point beats
 one without a box;
2. the higher rank - 3 a country inside a country (South India, the Pueblo country, the Tibetan
 plateau, the Arctic), 2 a nation or a culture, 1 a continental era (Gothic Europe, the Iron
 Age), 0 the modern world and the two rows of prehistory;
3. the later start year;
4. the row covering fewer countries.

Under that rule **Cusco in 1500 is Inca and not a maloca** (the maloca's box was cut in two so it
cannot reach the Andes), **Lhasa in 1650 is Tibetan and not Ming**, **Delhi in 1650 is Mughal and
not Rajasthani**, **Greenland in 1000 is Norse and not Inuit** - the test place step 32 could not
answer at all - and Gothic Europe does not answer for a Polish village of 1300 whose houses were of
logs.

**What it answers** (the 31 test places, each in its own year):

```
Ur, 2500 BC a courtyard house of one storey; sun-dried mud brick; flat mud roof on palm
 beams; swept earth; the river and the canal; a wick floating in sesame oil
Rome, AD 100 an apartment in a block of several storeys; brick-faced concrete; stone slabs
 with raised footways; aqueducts, public fountains and the bath house
Greenland, 1000 a long house of turf and stone, with a byre under the same roof; rock and turf;
 a stream and a well; the fire, and a lamp of seal oil
Cahokia, 1100 a long house of bark over a frame of poles; earth, and the paths worn to the
 river; birch-bark buckets; fires down the middle and torches of pine
Timbuktu, 1350 a compound of mud-brick rooms; mud brick (banco), renewed every rainy season;
 swept sand; a well in the compound, and the river in the flood
Cusco, 1500 a one-roomed house of stone or adobe, thatched; a canal of stone and a fountain
Edo, 1700 a machiya: narrow to the street and three rooms deep; earth, raked and swept;
 a well shared by the block; paper lanterns (andon)
Moscow, 1980 a flat in a block of prefabricated panels; asphalt; running water, hot from the
 district heating; electric light in every room
```

**Also built in step 33:** `history/water_works.json.gz` - **1,634 water works with a point and a
year** (wells, stepwells, cisterns, qanats, aqueducts, fountains, reservoirs, water towers, bath
houses and hammams), fetched from Wikidata at a notability floor of 3 rather than 5, because
stepwells and qanats are too little written about for 5. And `buildings_famous.json.gz` gained two
columns from Wikidata (P149 style, P186 material): **8,957 of 23,535 buildings carry a style and
3,603 a material**.

**Three decisions worth keeping.** *(1)* **Nothing the atlas knows is stored twice** - a row that
mentioned concrete would go stale the moment the atlas's arrival year for cement moved, so the
register asks instead. *(2)* **Corrugated iron is keyed to Portland cement, not to the atlas's
"steel"**: steel is a craft, and in Zimbabwe or in India it arrived a thousand years before a rolled
iron sheet did, so Great Zimbabwe's thatch of 1300 would have become corrugated iron on that rule.
*(3)* **A rectangle cannot hold the Amazon**: one box big enough for the basin also held Cusco, so
the row was split into the western basin and the southern, east of the Andes. Boxes are coarse, and
the pins (Lhasa, Kathmandu, Leh, Kashgar, Tucson, Iquitos) were checked one by one against them.

**The hook.** `MaterialSet.forPlace(lat, lon, year, rank)` turns the row's words into the block
palette a generated building uses (mud bricks, packed mud, spruce planks, terracotta tiles,
thatch, deepslate tiles, concrete), and `MaterialSet.roadFor(...)` does the same for the lane
surface (B13). `EraBuildingPlanner.selectStyle(lat, lon, year, rank, type)` uses both, and `/ee
building plan-test` now calls it, so a house planned in the world is of the place and the year
rather than of a coarse era. Where Terra++ is absent the era form is used, exactly as before.

**Checks.** `worldfill/probe_towns_culture.sh` (no Forge, no gradle - the register is pure Java
plus Gson): **17 named places answered by their own culture, 0 of 5,418 country-years
unanswered**, and the same place changing with the year. `/ee check houses` is a new part of
`/ee check all`: each place answered by its own culture and not a neighbouring one; Rome in 100
against Rome in 1400; the size of the town deciding what the walls are; London's light in 1700
against 1900; and nothing falling through.

**Known limits.**

* **Two rows of prehistory carry 11–17% of the historical era** (`early_village`, `early_camp`) - 
 mostly small islands and territories, and the centuries before 1000 BC in lands whose rows start
 later. 100% of country-years have *an* answer; 82–89% of them name a real tradition.
* **Sanitation is barely there.** Wikidata has articles about sewers, not about individual ones:
 2 rows. Where a house's water comes from is written for all 109 cultures; what it does with the
 water afterwards is not.
* **Boxes are rectangles.** The Tibetan plateau, the eastern woodlands and the Arctic are drawn
 with four numbers. A place inside the wrong rectangle gets the wrong answer.
* **The present is one row.** `modern_world` (1900 on) describes every country the same way; a
 2026 favela, a Tokyo flat and a Norwegian house are not the same house. The atlas's shares
 separate them by the size of the town, nothing else does.
* **The atlas's own estimates are used as facts.** It says paved roads reached Mali by 1350
 (estimated from the nearest land that had them), so Timbuktu's lanes are "paved with stone or
 brick in the main streets". Where the atlas estimates, this estimates.
* **Nothing in the world generator calls it yet** beyond the plan-test command; the settlement
 generator still uses the era palettes.

**Records:** `building_culture_table.py` (the 109 rows, hand-written), `build_building_culture.py`
(the builder and its coverage report), `fetch_town_wd.py --water`, `build_water_works.py`,
`probes/BuildingCultureProbe.java`, `probe_towns_culture.sh`,
`com.eternalengine.towns.BuildingCulture`, `MaterialSet.forPlace`, `EraBuildingPlanner.selectStyle`,
`logs/step33_culture_report.json`, `logs/step33_part1_notes.md` … `step33_part3_notes.md`, `step33_part4_5_notes.md`. Step 34 so far: `logs/step34_part1_notes.md`.

## Step 34: roads, railways, waterways, industry and what lies under the ground (B12, B14, B15, B18, B24, B26) - done in turn 121

XL, done in six parts over four turns. The question this step answers is the one step 31 left open:
*here, in this year, did a railway exist? a road? a canal? a bridge, a port, a lighthouse, a
factory, a power station, a mine? and what is under the ground that people might one day dig?*
Terra++ draws the world from today's OpenStreetMap, and step 31 measured the cost: Sydney in 1850
was handed two railways, though Australia's first opened in 1854; Pataliputra in 300 BC was handed
98 modern roads; Ur in 2500 BC was handed all 156 of today's ways. Only 0.9% of mapped features
carry a start date. **This step is the dated answer, and it is built to be asked one question by
the map: may this be drawn here yet?**

**Three packs, all shipped in-mod and verified by the manifest.**

* **`history/ways.grid.gz` (184 KB)** - for each 0.1-degree square of land, the first year a
 railway, a dated road or a canal reached it: **124,240 squares**, 6,555 distinct year-triples,
 merged from three sources by the earliest year any of them gives. From
 **OpenHistoricalMap**'s ways carrying a `start_date` (1,076 tiles fetched, 103,514 squares - 
 the only open map of the past that is licensed to ship); from the mod's own **Itiner-e** Roman
 road network, which already ships as `trade_routes.json.gz` (14,769 segments, years −514…700 - 
 this is what carries the ancient grid, because OHM's first-millennium dates are unusable); and
 from this step's own dated works (66,342 rows). **Years now run −514…2026 and nothing outside
 that range ships**: a railway "opening" in 2033 is a plan and a canal dated −1800 is a misread
 `start_date`, so both are dropped at the one choke point all three sources pass through.
* **`history/ways_works.json.gz` (2.1 MB)** - **110,447 works** in 14 kinds: 77,184 stations,
 12,165 airports and airfields, 6,602 power stations, 3,831 bridges, 2,374 railway lines, 2,286
 lighthouses, 2,031 factories and steelworks, 1,949 dams, 737 ports, 445 mills, 384 canals,
 329 mines, 121 caravanserais and 9 Roman roads. **82,304 carry a year a source records;
 28,143 carry one the mod estimates** - where Wikidata gives no date at all, the year the
 relevant technology reached that work's own country, taken from `technology_atlas.json.gz`.
 Every estimated row is flagged as estimated and says so in its own description; 11,633 rows
 with no year and no technology were dropped rather than guessed at.
* **`history/minerals.json.gz` (2.3 MB)** - **143,302 deposit sites across 57 minerals**: the
 USGS Mineral Resources Data System clustered into 1-degree cells (142,971 sites, public
 domain), 122 famous deposits and coalfields written by hand from Wikipedia (Potosí, Laurium,
 the Kinta Valley, the Great Dyke, the Witwatersrand…), and Wikidata's 209 oil fields. 21,878
 carry the year mining began; 73,953 are worked or were.

**The plug-in design.** Nothing here replaces what the atlas or the gazetteer already know; each
register asks the register that owns the answer. The works' estimated years come from
`technology_atlas.json.gz`. Whether a road may be drawn *surfaced* is the atlas's
`paved_roads`/`tarmac`/`motorway` question. And the grid is deliberately a **permission model,
not a map**: where no source records a railway, the answer is no, because a missing year is not
permission - Ur, Mohenjo-daro, Cahokia, Angkor, Great Zimbabwe, Timbuktu, the Amazon, Yakutsk and
the Sahara all answer *nothing*, which is honest where today's map is not.

**What the test places answer.** Rome in AD 100: its Roman roads from −312, three bridges and two
ports, and **no** station, factory, airport or railway line. Edo in 1700: roads from 1603, canals
from 1659, no railway (1872). London in 1700: five mills, four works, a bridge, no station.
Sydney in 1850: a lighthouse, a port, a works - **and no railway**, because the gate holds at
1855. New York in 1920: 805 stations, 22 lines, 15 bridges, 14 lighthouses, 5 power stations,
4 airports, 16 works. Under Cusco: silver, salt, gypsum, nickel, copper, gold, lead. Under Athens:
nickel, gold, silver (Laurium), lead, bauxite. Under London, Paris, Moscow, Delhi, Hyderabad and
Lagos: nothing recorded - a real gap, written down rather than filled.

**Checks.** `worldfill/probe_step34.sh` → `logs/step34_ways_report.txt`: the register probe
answers all 31 test places in their own years (**1,722 works stand in the 31 places in their own
years; 0 places since 1850 where the grid and the works disagree; none of them stands in the year
before it was built**) and the hook probe runs the three public methods outside Minecraft
(**15 checks, 0 failures**). `/ee check ways` asserts the gate - Sydney 1850 without a railway,
Rome 100 with its roads and without a station, New York 1920 with more than 100 stations, Edo 1700
with canals and mills and no station - plus the minerals and a 400-place speed check. Loads:
grid 17 ms, works 564 ms, minerals 694 ms; 400 places × all three in under 1,500 ms.

**Known limits.**

* **25% of the works' years are estimated**, not recorded (28,143 of 110,447). They are the year
 a technology reached a country, applied to a work inside it - usually late, and never
 individual. They are flagged, and they are the register's weakest third.
* **The grid's coverage is Europe- and North America-heavy**, because OpenHistoricalMap is.
 Lagos in 1960 is offered a power station and one station; that is what the sources say, not
 what the city had.
* **A "no" from `waysAllowed` means "no source we can ship says yes"**, not "there was nothing".
 Where it matters - Rome's roads, Edo's canals - the pre-1000 grid rests on Itiner-e and
 Wikidata, and everything else is silent.
* **B26, rest houses, is thin**: 121 caravanserais worldwide. No dataset covers them; this is
 what Wikidata has.
* **The minerals are US-heavy** (the USGS file is) and only 15% carry a year, so `worked()` can
 say what is under a place far more often than when anyone began digging it.
* **Nothing in play calls the registers yet.** They load, answer, and are checked. Placement and
 the player-facing systems come with the Terra++ patch below.

**The Terra++ patch this enables, still not applied.** Decision 2 keeps Terra++ changes as a
separate listed patch on the user's own build (`/home/user/terra3`), so it is written down, not
done; nothing in `terra3/` was touched. Where Terra++ is about to draw an OSM `railway`,
`highway` or `waterway=canal` with no `start_date`, it should call
`TerraOsmBridge.waysAllowed(lat, lon, year)` first and drop the way (or fall back to a track or a
path) where the answer is no; where it is placing a station, bridge, port, lighthouse, factory,
power station, mill, airport or mine, it should take the ones
`TerraOsmBridge.getDatedWorks(lat, lon, year, km)` offers, each carrying its own year, instead of
the population floor. That is the fix for step 31's two measurements, and it is what makes
"Sydney in 1850 has no railway" the rule instead of the exception. Open for whoever applies it:
what a modern OSM road becomes in a year before it existed - a track, a path, or nothing - and
how far from an OSM footprint a dated point may be substituted for it.

**Records:** `build_ways_works.py`, `fetch_ohm_ways.py`, `build_ways_grid.py`, `build_minerals.py`
and `famous_deposits_table.py`, `probe_step34.sh`, `probes/WaysProbe.java`,
`probes/WaysHookProbe.java`, `com.eternalengine.civilization.{WaysGrid, WaysWorks, Minerals}`,
`TerraOsmBridge.{waysAllowed, getDatedWorks, mineralsUnder}`, `HistoryChecks.ways`,
`logs/step34_ways_report.txt`, `logs/step34_places.txt`, and the part-by-part notes
`logs/step34_part1_notes.md` … `step34_part6_notes.md`.

## Step 35: water, fields, forests, climate and the sky by era (B2, B3, B4, B17, B22, B23, B25) - done in turn 126

XL, done in six parts over six turns. The question this step answers is the one a player asks the
moment they look up: *what did this land look like in this year - ploughed, grazed or wild forest?
where was the water, and when did a river or a sea move? what was the climate doing? what is in the
sky tonight, and has anything ever gone dark overhead?* Six systems, seven packs, seven registers,
all shipped in-mod and verified by the manifest.

### The seven packs

| Pack | Size | What is in it |
|---|---|---|
| `history/land_use.grid.gz` | 2.69 MB | Anthromes 12K resampled to 0.1°: 73 steps, 10,000 BCE to 2015 CE, 1,538,421 land cells, 2,393,643 changes, 19 anthropogenic biomes |
| `history/water_works.json.gz` | 74 KB | 3,884 water works in 11 groups - dams, tanks, stepwells, cisterns, qanats, aqueducts, baths, canals, dikes, drains, fountains - 1,907 of them with a year someone recorded |
| `history/water_changes.json.gz` | 15 KB | 158 rivers, coasts, deltas, seas, lakes and marshes that moved, 98 recorded and 60 estimated |
| `history/climate_periods.json.gz` | 10 KB | 84 named periods of climate from the end of the African humid period to 2022, 49 recorded and 35 estimated |
| `history/sky_stars.json.gz` | 98 KB | 5,666 naked-eye stars at J2000 with position, magnitude, colour and proper motion; 3,322 named |
| `history/sky_eclipses.bin.gz` | 964 KB | NASA's Besselian elements for 11,898 solar eclipses, and 12,064 lunar ones, 1999 BCE to AD 3000 |
| `history/sky_comets.json.gz` | 2 KB | 98 great comets of the past two millennia, with the date of perihelion and who saw them |

The eclipse pack stores **Besselian elements, not a list of paths**, which is the decision the whole
sky half rests on. A table of paths could only ever answer "was it visible at the places NASA
tabulated"; the elements let the mod answer "what did *this* square see, at this hour", which is the
question the player is actually standing in - 11,898 eclipses × 25 numbers each, with the geometry
computed in code at the moment it is asked.

### What the registers answer

```
LandUseGrid.landClass(lat, lon, year) "rice villages" / "wild woodlands" / "ice"
WaterChanges.standing(lat, lon, year) the Zuiderzee was "flooded" from 1287, "closed" from 1932
WaterWorks.near(lat, lon, year, km) Rome in AD 100: 26 works. Sydney in 1850: none.
ClimatePeriods.active(lat, lon, year) Cusco in 1650 feels the Andean Little Ice Age, not Europe's
SkyStars.poleStar(jd, mag) Thuban in 3000 BC, Kappa Dra in 1500 BC, Polaris now
SkyStars.above(lat, lon, jd, alt, mag) the naked-eye sky of that place, turned to that age
SkyEclipses.sighting(e, lat, lon) how much of the Sun went, and at what hour
SkyComets.describe(year) "A comet: Halley, at its brightest in 23 March AD 1066…"
```

`/ee check era` runs 27 checks on the land, water, works and climate registers and **27 of 27
pass**. `/ee check sky` runs 33 checks on the three sky registers and **33 pass, 0 fail**:
`worldfill/probe_sky.sh` runs both outside the game, and needs no Forge, no Minecraft and no gradle.

### Five real defects, found by measuring rather than reading

Each of these looked fine in a table and was wrong in use. They are written down because the same
traps are waiting in the next catalogue.

1. **Right ascension was in hours.** HYG's `ra` column is hours (0…24); `build_sky_stars.py`
 read it as degrees and the pack labelled it degrees, so the entire star catalogue sat inside 24°
 of the vernal equinox. The consequence was not a crash but a lie: precession could then never put
 a star near the pole of date, and `poleStar` returned Polaris at *every* epoch from 3000 BC to
 AD 3000. Fixed by `worldfill/patch_sky_stars.py`; the corrected column agrees with nineteen
 bright anchors to 0.007°.
2. **921 naked-eye stars were named with a bare Greek abbreviation.** HYG carries the Bayer letter
 with no constellation for many rows, and the builder only expanded the two-word form - so Kappa
 Draconis, the pole star of 1500 BC, was called "Kap". Now "Kappa Dra".
3. **`poleStar` was precessing the wrong pole.** It precessed the *J2000* pole and looked for the
 star nearest that, which is where the old pole now sits, not the new one; the two are 26° apart
 in 3000 BC. The pole of any era is simply declination +90 on the precessed frame.
4. **`observerPlane` was transposed.** It built the place vector from the basis matrix's *columns*
 instead of its *rows*, so ξ, η and ζ were each a mixture of all three. Nothing crashed; phantom
 partial eclipses appeared at Anyang, Rome, Edo and New York. It only surfaced because the Java
 output was diffed against the builder place by place - the modern spot checks passed, because
 they only exercise the inverse routine. The rule to carry forward: `axisPoint` and
 `observerPlane` are transposes of one another.
5. **Three sentences read badly.** "A annular eclipse"; a comet with no note left a dangling ". ";
 and ten comets named for their own year ("Great Comet of 371 BC") were given it twice.

### The sky, checked against things outside this mod

Precession was validated twice over: against the annual precession constants at T = 0.26 (the code
gives RA +0.3331° and dec +0.1447°, against 0.3330° and 0.1445° computed from m and n), and against
published pole-star facts. **Polaris is closest to the pole in AD 2100 at 0.46°** (published 0.45°);
**Thuban came within 0.094° - under six arc-minutes - around 2800 BCE** (published: less than ten
arc-minutes, in 2830 BCE); the succession Thuban → Kappa Draconis → Kochab → Polaris falls where
the published supersession dates say it should.

Eclipse geometry was checked two independent ways: against NASA's own published point of greatest
eclipse (six modern eclipses, all inside 0.1° and a quarter of an hour), and against **pyephem**,
an ephemeris library sharing no code with this mod, computing the Sun–Moon separation from the
ground. Modern eclipses agree to 0.002 in magnitude; the full 31-place table agrees with the
builder's Python line for line, 62 of 62, none beyond a rounding cent.

**Thales' eclipse, and a note this project had wrong.** The eclipse of 28 May 585 BC (Julian) is
22 May in the proleptic Gregorian calendar the pack stores; both are Julian day 1507900. Both
methods put its deepest point at **38.1° N, 45.2° W - the North Atlantic**, not the eastern
longitude an earlier note recorded. Anatolia saw a very deep partial, **94% at the Halys** with the
Sun only a few degrees up: the "day turned into night" of Herodotus, and not a total eclipse. The
Assyrian Bur-Sagale eclipse of 763 BC is 98% at Nineveh. Both are in `/ee check sky` as assertions.

### The Terra++ patch this enables, still not applied

Six public hooks, following the step-34 pattern (`waysAllowed`, `getDatedWorks`, `mineralsUnder`),
written down rather than applied, and nothing under `/home/user/terra3` was touched:

```
TerraOsmBridge.landUseAt(lat, lon, year) -> LandUse(name, level, shortName, settled, farmed, …)
TerraOsmBridge.waterChangedBy(lat, lon, year) -> List<WaterChange> the Zuiderzee, the Aral, Ur
TerraOsmBridge.worksNear(lat, lon, year, km) -> List<WaterWork> 26 works at Rome in AD 100
TerraOsmBridge.periodsAt(lat, lon, year) -> Climate(periods, °C, rain %, harvest, describe)
TerraOsmBridge.starsOver(lat, lon, jd, alt, mag) -> Sky(above, poleStar, describe)
TerraOsmBridge.eclipseAt(lat, lon, from, to, m) -> List<Eclipse>
```

Terra++ should ask `landUseAt` before drawing forest or farmland on a square, `waterChangedBy`
before drawing a coastline that has moved, and `worksNear` before placing a dam or a canal; the sky
hooks are what a night sky, a comet in the year it came, and an eclipse that darkens the world for
its length would be built from. Open for whoever applies it: what a total eclipse does to daylight
in a mod that also has a day-night cycle, and how far from a place's own grid cell a land-use class
may be borrowed.

### Known limits

* **Anthromes 12K is a model-based reconstruction, not observation** - land use inferred from
 population density and history, not mapped. Its 5-arcminute original was resampled to the mod's
 0.1° grid, so a cell averages about 144 source cells and the small classes vanish: a monastery
 garden inside a wild woodland is the woodland. Cropland tracks HYDE 3.3 at r = 0.994 across the
 46 years both cover; the settlement classes agree least, because the two data sets mean different
 things by "urban".
* **35 of the 84 climate periods are estimated**, and 60 of the 158 changes to the water. Both
 tables are written by hand from Wikipedia because nothing shippable can be fetched from here
 (Zenodo 403, figshare 202, GRanD 404, PAGES2k has left CRAN).
* **The climate periods are deliberately regional.** PAGES 2k (2019) found the Roman Warm Period,
 the Medieval Warm Period and the Little Ice Age not to be globally coherent episodes, so Cusco in
 1650 feels the Andean Little Ice Age and not Europe's, and a place no period reaches is answered
 with nothing rather than with an invented one - Ur in 2500 BC among them.
* **Ancient eclipse magnitudes are good to about 0.03**, which is 50 to 100 km of shadow: the
 uncertainty in ΔT three thousand years back. On the edge of a total path that is the difference
 between "98% of the Sun" and "total", as Nineveh in 763 BC shows. Modern eclipses are good to
 0.002.
* **The stars carry no radial velocity and no orbit.** Proper motion is treated as a straight line,
 which is right for a few thousand years and wrong for Barnard's Star over a hundred thousand. The
 Sun, Moon and planets are computed from the date rather than tabulated, and are not covered by
 the sky checks.
* **98 comets is what one Wikipedia table holds**, and it reaches back two millennia, not twelve.
* **Nothing in play calls any of the registers yet.** They load, answer, and are checked. Placement
 and the player-facing systems come with the Terra++ patch above.

**Records:** `build_land_use.py`, `build_water_changes.py`, `build_water_works.py`,
`build_climate_periods.py`, `build_sky_stars.py`, `build_sky_eclipses.py`, `build_sky_comets.py`,
`sky_time.py`, `patch_sky_stars.py`, `probe_sky.sh`, `com.eternalengine.civilization.{LandUseGrid,
WaterChanges, WaterWorks}`, `com.eternalengine.climate.ClimatePeriods`,
`com.eternalengine.sky.{SkyStars, SkyEclipses, SkyComets}`, `HistoryChecks.{era, sky}`,
`TerraOsmBridge.{landUseAt, waterChangedBy, worksNear, periodsAt, starsOver, eclipseAt}`, and the
part-by-part notes `logs/step35_part1_notes.md` … `step35_part6_notes.md`. Reports:
`logs/step35_era_check.txt` (27/27), `logs/step35_sky_check.txt` (33 pass),
`logs/step35_sky_verify.txt` (the two independent checks), `logs/step35_landuse_probe.txt`,
`logs/step35_water_probe.txt`, `logs/step35_climate_report.txt`.

## Step 36: building life, and player buildings across time (B10, B21, B27) - done in turn 128

**The question.** What state is this building in this year - going up, standing, damaged, ruin,
gone, or mended? What wrecked it? And what happens to the house I built when I jump to another
year, or switch to another timeline?

**The answer, in three registers.** `Disasters` (B27) over 27,004 hazards from 3000 BCE to AD
2026; `BuildingLife` (B10), which joins step 32's 23,534 famous buildings to them; and
`PlayerEdits` (B21), the one system in the mod where the world is changed by somebody standing in
it.

### The pack was thinner than it looked

Step 33's `build_hazards.py` produced 26,997 hazards, which sounds like a lot, and for a question
like "did anything happen in this region in this century" it is. Checked against the disasters a
player is most likely to ask about, it is not. **Of thirty famous ones, fourteen are absent
outright** - Vesuvius in AD 79, Krakatau in 1883, San Francisco in 1906, Messina in 1908,
Tangshan in 1976, Tohoku in 2011, Haiti in 2010, the Yellow River flood of 1887, the North Sea
flood of 1953, the Plague of Justinian, the Antonine Plague, the Spanish flu, Heimaey in 1973,
Damghan in 856 - and six more match only to the wrong event: "Indian Ocean 2004" finds an
*Earthquake at Indian Ocean: Felt In Maldives* three thousand kilometres away, and "Mt St Helens
1980" finds an earthquake rather than the eruption.

Three defects, three fixes:

* **No severity field.** The builder wrote the magnitude into the event's *name* and threw the
 number away as a field. Only 1,772 of 11,814 earthquakes and 4,427 of 6,849 eruptions have one
 to recover - 23% of the pack. Severity is now taken from the magnitude (6,199 events), then
 from the number of dead (1,299), then from the kind's own middle. Only the last is an estimate,
 and `severityEstimated()` says which.
* **Radii that do not scale.** Every event of a kind got the same radius - 50 km for an
 earthquake - so **Lisbon sat 344 km outside the 1755 earthquake that destroyed it**. For the
 four kinds whose reach is physics the radius now widens with the severity, up to tenfold:
 Lisbon goes to 434 km and the capital falls inside its own earthquake. The four kinds that
 travel by road keep the pack's radius; inflating a plague by magnitude would be nonsense.
* **143 events lost their year** and were filed under AD 1 to 99 - a tsunami with ten thousand
 dead in Lisbon dated to the year 1, the New Madrid earthquakes to the years 7, 16 and 23. Not
 recoverable, so **quarantined rather than guessed**; 68 set aside.

And a **75-event hand-written supplement** for the ones that are missing, one row at a time, each
carrying the Wikipedia article it came from, with a selftest that fails if a continent or a
millennium is left out. `FIRE` was added as a ninth kind, because fires are most of what happens
to a wooden town: the Great Fire of London and the Great Fire of Meireki are in it.

### The distinction the whole system turns on

An earthquake, an eruption, a tsunami, a flood and a fire **break things**. A plague, an
epidemic, a pandemic and a famine **break nothing at all** - they empty a place of the people who
would have mended it. A town shaken in 1349 has damaged houses by nightfall. A town emptied in
1349 has sound houses in 1349 and **ruins a generation later, because nobody is left to thatch a
roof**. The Black Death reaches London from the Crimea at 5,500 km and does not reach the
Americas, which is right; the Spanish flu and COVID-19 at 15,000 km reach everywhere, which is
also right.

### Four bugs the calibration found

The first version destroyed the Colosseum in AD 258 and the pyramids in 1348.

1. **A sixteen-year plague was applied sixteen times.** The year index holds an event under every
 year it runs, so the Antonine Plague came back sixteen times and its damage was subtracted
 sixteen times. *This was the whole ratchet.*
2. **A plague in 541 cost Rome 283 years of rot.** The rule asked "did anything happen across
 this interval?" and billed the entire interval at the unmaintained rate. Decay is now
 accounted in **years actually neglected**.
3. **A buried city got up and rebuilt itself.** Pompeii decayed to a ruin and then repaired to
 standing by AD 200. Hence the abandonment rule: above 0.70 damage a place walks away, unless
 it looks after itself well enough to rebuild - Pompeii did not, Lisbon and San Francisco did.
4. **The defaults were the medians of the notable events.** The ten thousand earthquakes whose
 magnitude did not survive are mostly smaller than the 1,772 whose magnitude did.

### Going back is not undoing

`PlayerEdits` keeps the record separately from the world. The world shows
`standingIn(year, branch)`; the record is `all()`, and only the player's own undo touches it. So a
jump to before the house was built **hides** it and a jump forward brings it back whole. A branch
inherits what its ancestors did **before** the split and nothing after it - which is the
difference between a divergence and a save game. And a player's buildings run through the same
`BuildingLife` arithmetic as the Colosseum: a villa begun outside Pompeii in AD 78 is a ruin in
AD 79.

### Verified

`/ee check life` - **31 passed, 0 failed, 2.2 s** (`logs/step36_life_check.txt`).

| Place | Year | Answer |
|---|---|---|
| Pompeii | 78 → 80 → 200 | standing → **5 ruins** → gone |
| Colosseum | 100 → 258 → 500 → 1349 → 2026 | standing → damaged → repaired → **damaged (the 1349 earthquake)** → damaged |
| London | 1660 → 1667 → 1700 | standing → **2 damaged, 3 ruins** (the Great Fire) → rebuilding |
| Lisbon | 1754 → 1756 → 1800 | standing → **5 damaged** → standing |
| Krakatau | 1883 | VEI 6, damage 0.90 |
| Giza | 2500 BC → 2026 | standing throughout |
| Hyderabad | 1877 | the Great Famine of 1876–78 - the same years step 35's climate periods call a drought |
| Ur | 2500 BC | nothing recorded |

31 places across six continents asked at once: 119 buildings in 0.5 s.

### Limits

* **77% of the scraped events carry no severity**, and their damage rests on the kind's own
 middle. Every such answer is flagged.
* **The radii are modelled, not measured** - a magnitude–distance relation, not a record of how
 far an event was felt.
* **The damage is a model, not a record.** No data set says which buildings a given earthquake
 touched, and every answer says so.
* **The supplement is 75 events, not a complete roll of the great disasters.** Every continent
 and every millennium is covered; none is exhaustive.
* **Famous buildings survive.** Cairo's mosques read `STANDING` straight through the Black Death,
 and that is right - what the plague emptied was ordinary housing, generated procedurally in
 play and served by the same `care` parameter. The ruins of 1380 show up in a village at low
 care, not in a monument.
* **`care` defaults to 0.50** and is the register's own guess at how much a place looks after
 itself.
* **`PlayerEdits` records edits; it does not place blocks.** Translating them into the world is
 the Terra++ hook, and a player's house is a fact until that lands.
* Pre-modern death tolls are ancient or medieval figures and often too high (1202 Syria's
 1.1 million). They drive severity on a log scale, so a factor of two hardly moves the answer.

### Files

`com.eternalengine.civilization.Disasters`, `com.eternalengine.buildings.{BuildingLife,
PlayerEdits}`, `HistoryChecks.life`, `TerraOsmBridge.{disastersAt, disasterLine,
buildingLifeAt, buildingLifeLine, playerBuildingsIn, playerJump, setPlayerEdits}`,
`worldfill/disaster_supplement.py` (the hand-written table) and `worldfill/build_disasters.py`.
Run `bash worldfill/probe_life.sh` - it provisions a JDK 17 and Gson itself and runs the check,
the hooks and a set of places. Reports `logs/step36_life_check.txt`; notes
`logs/step36_part1_notes.md` … `step36_part4_notes.md`.

## Step 37: event time, calendars, news by era and how fast it travels (A2, C23, C24, D8, C29, E20) - done in turn 132

Turn 129, "next". `SYSTEMS_PLAN.md` line 386. Two questions the mod could not answer before this step: *what
date is it in the calendar this place actually uses*, and *how long before news of something reaches the next
village*. Six parts, and - as in step 36 - the data mostly shipped already: the technology atlas carries the
news-speed curve (3 km/day before the roads to 500 by 1950) and the arrival year of the telegraph, the post,
the railway and radio in each of 130 countries, and `world_rulers` carries the polities for regnal years.
Only two new artefacts in the step: the calendar-region table and the beliefs table.

### What the registers answer

| Question | Register | Example |
|---|---|---|
| What date is it here? | `knowledge/Calendars` | `Delhi: 26 Jyeshtha 2005 VS` · `Beijing: the twenty-first day of the fifth month of Gengzi, the year of the Rat` · `Hyderabad: Fasli 1357 (26 Jyeshtha)` |
| How long does news take? | `news/NewsTravel` | Rome to Antioch about a month by sea in AD 100; the London post to Edinburgh three days in 1700 |
| How old is the news when it reaches you? | `news/NewsChannels` | months for a stone, a day for the wire, the same hour for the wireless |
| What is left of a rumour? | `civilization/Rumour` | 4 km, 0 hops: "Have you heard? the harvest failed." 8 124 km, 324 hops: "Word comes of something that happened away over there." |
| What do people here believe? | `knowledge/Beliefs` | Paris 1348: "The learned here say: illness is an imbalance of the four humours." |

**The Chinese calendar is computed from astronomy, not approximated.** Meeus, *Astronomical Algorithms*,
chapters 25 and 49 - the sun's apparent longitude and the times of the new moon, 25 periodic arguments and
14 planetary terms - in Beijing time. It reproduces **18 of 18** known Chinese New Year dates, 1966 to 2026.

**Two channels, not one.** A deliberate messenger runs at an absolute speed gated on the year the technology
reached *both ends*: foot 30 km/day, rider 60, sail 90, post 180, steamship 400, railway 700, motor 900, the
wire a day, the air the same day. The *incidental* channel - news going with whoever was travelling anyway,
which is what rumour runs on - uses the atlas's era curve instead, and it is the faster of the two before
about 1750. That is right rather than wrong: a lone rider in 1500 was slower than the post, but everybody in
the village was travelling anyway.

### Six defects the checks found

1. **`Calendars.ordinal` returned cardinals.** "the fifty year of X rule", "the nine day of the five month".
 Rewritten to true ordinals ("the 128th", "the twenty-first").
2. **The Deccan fell through to a Gregorian date before 1556.** The Saka row started at 1556, so Hyderabad in
 AD 100 printed a Julian date nobody there had heard of. A Saka row from 57 with `to = 1555` - the
 Satavahana, Chalukya, Rashtrakuta and Vijayanagara inscription era.
3. **`TechnologyAtlas.arrivesIn` returns a year, not a number of days.** `NewsTravel` multiplied
 `(arrivesIn - year) * 365.25`, which is only valid when a journey spans whole speed bands: 4 km came out
 at 220 days and Rome to Paris at 16 160. Fixed with a new `daysToCross(year, km, factor)`, which walks
 the bands carrying leftover kilometres. `arrivesIn` and `kmBetween` are public now rather than
 re-implemented.
4. **`technology.travel` mixes years with days.** The same bug, already in the atlas from step 30a. It is
 **left alone** - step 30a's 130-technology spread is built on it, and fixing it means re-checking that
 spread - and recorded against step 30a instead, with `daysToCross` and `eraSpeed` written beside it.
5. **A European argument was being put in a mouth that never made it.** `fixed_continents` covered the whole
 world from 3000 BC; it now covers the Old World and Europe only, because elsewhere the question was not
 framed in those terms at all. The same for alchemy, which now excludes the Americas: there is no
 transmutation of metals on record there before contact.
6. **`probe_calendars.sh` hid its own compile errors.** javac was piped through `grep -v warning || true`, so
 when a probe class failed to compile, three registers silently ran against stale classes. It now writes
 to a log and exits 1 with the errors printed.

Two smaller ones: `Beliefs.line()` started a sentence with a lowercase phrase ("everyone here says"), and
Chang'an in 800 had **no** element theory at all - a gap rather than a virtue, filled with `wuxing`.

### The Terra++ patch this enables, still not applied

Six public hooks, following the step-34 pattern (`waysAllowed`, `getDatedWorks`, `mineralsUnder`), written
down rather than applied, and nothing under `/home/user/terra3` was touched:

```
TerraOsmBridge.calendarAt(lat, lon, date) -> Calendars.Dated the date in the local calendar
TerraOsmBridge.newsDelay(from, to, year, mode) -> NewsTravel.Leg km, days, " forty-four days "
TerraOsmBridge.channelsAt(rank, ruled, lat, lon, year) -> NewsChannels.Here SCPWRT, and how old the news is
TerraOsmBridge.rumourAfter(km, hops, year, text) -> Rumour what is left after n mouths
TerraOsmBridge.beliefsAt(lat, lon, year) -> List<Beliefs.Belief>
TerraOsmBridge.beliefSaid(role, lat, lon, year, salt) -> String "It is held that ..."
```

Terra++ should ask `calendarAt` before printing a date anywhere near a place, `newsDelay` before deciding
whether a far-off event is known yet, and `beliefsAt` before generating a village's conversation. Open for
whoever applies it: whether a place's calendar should also drive its festivals (step 30b has its own
festival table and the two are not yet reconciled), and what a stone inscription's "months old" means for an
event the player caused yesterday.

### Verified

`bash worldfill/probe_calendars.sh` provisions a JDK 17 and Gson itself and runs four registers:
**261 checks, 0 failed** - 77 calendars, 32 travel, 46 news, 106 beliefs. Report
`logs/step37_calendars_check.txt`; notes `logs/step37_part1_notes.md`.

### Limits

* **A step-37 file that cannot be compiled here is only syntax-checked.** This workspace has no Gradle cache
 and no Minecraft jars, so most of the mod cannot be built. `probe_calendars.sh` compiles the dependency-free
 registers properly; `NewsService` and `TalkService` (which the new talk option was added to) go through
 `worldfill/syntax_gate.sh`, which catches a missing brace but not a wrong type or a missing import. **The
 new talk option has never run.** A real build is the first thing to do.
* **The talk box now has one more question than it had.** Step 24's note was that the box shows nine; with
 "What do people here believe?" an NPC with everything on offer - news, ruler, place, life, famous, self,
 market, papers, notes, belief - reaches ten. Nothing in the code caps it, and the option is withheld where
 the register has nothing on record, but nobody has looked at the box in a game.
* **30 beliefs is a sketch, not a survey.** Whole fields are missing: no mathematics, no economy, no law, no
 agriculture, no theories of mind. Extending the table is a matter of writing rows.
* **Calendar regions and belief extents are rectangles on a lat/lon grid,** so a box can include sea, desert
 and places where nobody lived that year. The caller asks about settlements, where that does not arise - but
 a belief recorded for the whole world therefore reaches the middle of the Pacific, where of course nobody
 held it.
* **Exactness varies by calendar, and the register says which.** Exact: Gregorian, Julian, Hijri (tabular),
 Saka, Chinese. Approximate: the Vikram and Fasli month, and every regnal year.
* **Regnal years count years of a *rule*, not of a monarch** - Cliopatria records polities, not kings, so
 "the 282nd year of Kingdom of England rule" is how long that polity has run.
* **The atlas's era curve is global:** 1850 Beijing uses the same 150 km/day as 1850 London. The per-country
 arrival years are in the atlas; the per-country speeds are not.
* **The incidental channel overtakes a lone rider after about 1750**, when the era curve passes 60 km/day:
 news that went with whoever was travelling anyway beats a rider who was sent. That is intended, but it
 means callers must ask `NewsTravel.fastest` rather than pick a mode - by 1900 the wire is the answer and
 neither channel matters.
* **Belief dates are "when it became common", not "when it was first argued."** Heliocentrism is marked 1687
 (Newton), not 1543 (Copernicus); deep time 1788 (Hutton). `now` may equal `belief` where the belief was
 right - the point of the register is *when*, not *whether*.

### Files

`com.eternalengine.knowledge.{Calendars, Beliefs}`, `com.eternalengine.news.{NewsTravel, NewsChannels,
NewsEras, NewsService}`, `com.eternalengine.civilization.Rumour`, `com.eternalengine.technology.TechnologyAtlas`
(`arrivesIn`, `kmBetween`, `daysToCross`, `eraSpeed` now public), `worldfill/{calendars_table,
build_calendars, beliefs_table, build_beliefs}.py`, `worldfill/probe_calendars.sh`,
`worldfill/syntax_gate.sh`, and the two packs `history/calendars.json.gz` (33 regions, 3.5 KB) and
`history/beliefs.json.gz` (30 beliefs, 4.7 KB).

## Step 38: who people are - jobs, families, daily life, needs, migrations, health (D2–D6, C7, C20, D17) - done in turn 139

`SYSTEMS_PLAN.md` line 387. The question this step answers is the one every other step has been
setting up: **when you meet a person in this world, who are they?** How long they expect to live,
who is at home, what work they do, how their day is shaped, what they are short of, whether the road
they are on is full of refugees, and whether anybody where they are can cure what they have caught.

Eight parts. The data mostly shipped again - five hand-written tables, six registers, one command.

### What the registers answer

| Question | Register | Example |
|---|---|---|
| How long will they live? | `people/LifeTable` | London 1850: a newborn expects 40 years; 2020: 81 |
| Who is at home? | `people/Households` | *"There are five of us at home: my wife of 36, our son of 12 and my mother of 71."* |
| What work do they do? | `people/Jobs` | 23 occupations by era and place, bound to the technology atlas |
| How is the day shaped? | `people/DayRound` | *"The work is set by the task, not by the clock"* · *"The market comes round every eighth day, the nundinae"* |
| What are they short of? | `people/Needs` | food, safety, faith, money, mood - read off the hazard pack and the day, not invented |
| Who else is on this road? | `people/Migrations` | *"Lahore to Amritsar, in about 2 days - though in 1947 the quickest thing on that road took the same day"* |
| Can anybody cure them? | `people/Health` | Oxford 1945: penicillin, care ×0.30. A Bihar village 1945: public health, care ×0.75 |

### The three things this step fixes

**1. Migration was a formula, not a record.** `population/MigrationSystem` models push and pull
between two regions with no distance, no route, no date and no names. It cannot say that in August
1947 the road from Lahore to Amritsar carried the largest movement of people in the history of the
world. `Migrations` is built the other way round - 38 dated records, each handed to step 37's
`NewsTravel` - so a migration is **a number of days, not a line on a map**. How these people moved
is decided, not assumed: on foot when driven out, by sail before 1807 and steamship after, mounted
for a conquest, and by the quickest thing that carries *bodies* for people who chose to go. A
channel that carries a message does not carry a family, so the wire, the airwave and the post are
excluded. The four Partition roads add to **15,700,000**; the three Atlantic slave-trade routes add
to **10,700,000 landed**, the Slave Voyages figure, and the builder fails if they stop doing so.

**2. The whole planet became modern in 1945.** `MedicineSystem.getMedicineTier("global", simYear, 5)`
decided how good the medicine was by the year alone. `Health` asks when each remedy actually reached
a place - six of them from step 30a's technology atlas, the rest by running the atlas's spread
function from the year and place they were learned in. `DiseaseEngine.tickLevel` now reads the tier
for where the level is. The old method is kept and documented as a fallback, not deleted. **This is
the part of the step that changes behaviour rather than adding a register.**

**3. Nothing here invents a number it cannot source.** Every row in all five tables carries the
source it came from, and where a figure is this table's own reading the row is marked `estimated`
and the printed sentence repeats the word: *"kills perhaps 50% of the people it reaches (estimated
by this table, not by any source)."*

### Limits, and they are the design

* **The migrations and the diseases are records, not fields.** A place in a year with no record is
 not a place where nobody moved or nothing was wrong; it is a place where nobody counted, and the
 registers say so out loud. Aleppo in 2015 returns nothing from `Migrations`, and it does not
 pretend that means Aleppo was quiet.
* **Needs is read off registers that already exist.** Food and safety come from the hazard pack's own
 effect table; faith from how many times the day stops to pray; money from whether there is a market
 and how much of the week the work takes. There is no new pack for it, and no invented index.
* **A need that does not apply is not a low score.** Money where nothing is bought or sold is a
 category error, not a zero - the Palaeolithic hunter is *steady*, not desperate.
* **Sixteen of the eighteen diseases carry a case fatality that is this table's reading and no
 source's**, and every one says so. Nothing here is a diagnosis or a prognosis; the figure is the
 published one for people who caught it untreated and often malnourished.
* **Disease geography is coarse and admitted to be coarse**: the vector band is |lat| ≤ 40 for
 malaria and yellow fever and ≤ 55 for the rest. The ocean barrier - 1492 for the Americas, 1788
 for Australia - is the one coarse rule that had to be exactly right, because smallpox in
 Tenochtitlan in AD 1000 would be worse than no register.
* **The step does not touch names, skins or looks** (decision 8 of part 1), and it does not model
 individual diagnosis. It models what a place and a year can offer a person.

### What is not wired up yet

The seven registers are built, probed and reachable from `VirtualVillager`
(`homeLine`, `aboutLine`, `jobLine`, `dayLine`, `needsLine`, `situationLine`, `roadsLine`,
`healthLine`), but none of those are called from the agent code. `AgentVirtualizationEngine`
still draws a role with `(byte) (1 + rand.nextInt(5))`. Bolting the life layer to the agents is
carried forward, along with the talk-box wiring, rather than half-done here.

### Files

`worldfill/{life_table,households_table,jobs_table,day_round_table,migrations_table,health_table}.py`
and their six builders; `eternal/src/main/java/com/eternalengine/people/{LifeTable,Households,Jobs,
DayRound,Needs,Migrations,Health}.java`; `worldfill/probe_lifetable/` (seven probe programs,
**2,269 checks**); `/ee check people`; the six packs `history/{life_table,households,jobs,day_round,
migrations,health}.json.gz`.


## Step 39: what is going on here - event scenes (D9) - done in turn 140

Twenty scenes, cast from the people a place and year actually has, and set off by something that
has already happened.

### What was there before

`PresenceLocalSpawner.sceneRoles(String effect)` was the whole of the mod's scene-making: four
keyword tests on the event's effect string, handing back two or three copies of `guard`, `citizen`
or `merchant`. It could not tell a coronation from a cattle market. It did not know what year it
was, where it was standing, or who was available. **The register replaces it, it does not sit
beside it** - two ways of making a scene is one too many.

### What a scene is here

Five things, and not one of them is a list of entities:

* **what** it is - one of the twenty D9 names, in eight groups: power (crowning, court day,
 procession, election, protest), justice (trial), worship (prayer, festival), trade (market day,
 a caravan or ship arriving), work (building works), suffering (plague, famine, flight,
 refugees, fire), war (battle, siege), life (wedding, funeral);
* **when** it is on - the trigger. Seven kinds, and every one of them is asked of a register that
 already exists: the event gazetteer (step 28), the hazard pack (step 36), `DayRound` for market
 and prayer days (step 38), `CultureAtlas` for feast days (step 30b), `Migrations` for refugees
 (step 38), the incident types, and the life table itself. **There is no new "when" pack.** Of
 the twenty, **5 are recorded, 4 mixed and 11 estimated** - the eleven say so in the printed
 sentence;
* **where** it stands - one of ten grounds: square, gate, temple, hall, field, river, street,
 cemetery, quay, works;
* **who** is in it - a cast given in the twelve work sectors of step 38's `Jobs`;
* **what they are doing** - the business of the scene, which is what you walk into.

### Two rules that keep it honest

**A scene needs a quorum.** A coronation wants three priests and three clerks. Rome has them. A
band of twenty-five foragers, whose regime gives two in the hundred to the shaman and none at all
to clerks, has nobody - because two in the hundred of twenty-five people is not a person. So each
part is filled up to the number of such people the place actually holds
(`Jobs.shareOf(sector) × crowd / 100`), and where fewer than half the parts can be filled the
scene is **not on at all**. A foraging band does not hold coronations, and the register does not
pretend otherwise by putting a farmer in a borrowed robe. Where some parts go unfilled the line
says so: *"The other 3 parts are unfilled: nobody here does that work."*

**Where the register does not know, it declines.** It will not say whether the hour of prayer is
on unless you tell it what hour it is. Better an empty street than a confident guess.

### What it does not do

* **It does not stage fighting.** Weapons and army gear are step 45 and armies in action are step
 40, so battle and siege hold the part of a war that is not the battle: the camp, the baggage,
 the wounded, the watchers - and for a siege, how short of food the town is, which is what a
 siege is actually about.
* **The suffering scenes are scenes of absence.** Five of the twenty are about people not being
 there. The register says how much quieter the street is, not how many corpses there are. A
 plague scene with seven people in it is a street that should have had seventy: *"The street is
 about 44% emptier than it should be."*
* **It does not invent a date.** Every trigger is asked of a register that already carries one.
* **It does not touch names, skins or looks**, and it does not move entities by itself - it hands
 the spawner a cast and a line.

### The two numbers it computes that nobody had before

**Funerals and weddings come off the death rate.** In a population that is not growing, the people
who marry in a year and the people who die in a year are each about one year's worth of births, so
out of *n* people with an expectation of life of *e₀* years there are `n / (e₀ × 365)` deaths a
day and about 85% as many weddings. A city of forty thousand where a newborn expects forty years
buries three people a day and has a funeral every day of the year; a village of three hundred
buries one person every six weeks and has nothing on at all for 2,851 days out of 3,000. That
difference is the point, and it comes out of the life table rather than anybody's sense of what a
village is like.

**A hazard only sets a scene off where it bites.** Step 36's pack records hazards over whole
regions and whole countries, and a box covering German New Guinea is not a reason for a street in
Glasgow to be empty. A hazard whose death rate here is under two in the hundred is not a scene, it
is news.

### What it says

```
Rome 100: There is a wedding here: a couple, two families who are not sure about each other,
 and a feast. In it: a priest, 2 servants, a craftsman, 2 farmers, a merchant.
London 1348: There is a plague here - Black Death, AD 1346: houses shut, the carts going round,
 and far fewer people about than there should be. The street is about 44% emptier
 than it should be. In it: 2 priests, 3 servants, a merchant, a craftsman.
Lahore 1947: There are refugees on the road here - The road here carries the Partition: a road
 full of people who did not choose to be on it. In it: 2 servants, 2 farmers,
 2 craftsmen, a merchant, a soldier.
Amazonia 100: There is a market day here: stalls, weighing, arguing about price. In it: a
 merchant, 2 craftsmen, 3 farmers, a servant, a herder. The other 3 parts are
 unfilled: nobody here does that work.
a Bihar village 1900: Nothing is going on here today.
```

### The customs that had to be right, and were fetched rather than cited

The route of a Roman triumph (Campus Martius → **Porta Triumphalis** → Via Sacra → Temple of
Jupiter); the assize courts, the grand assize of **twelve knights**, and the end of trial by
ordeal in **1215**; the weekly market on its charter day against the annual fair on its saint's
feast; the banns read on **three Sundays** running after Lateran IV; the wake the night before a
funeral and the dead carried by male kin; the first imperial coronation, Leo I crowned by
Patriarch Anatolius in **AD 457**.

### The last sweep

`SceneRun` asks the register about eleven places and eleven years. That is enough to know it works
and not enough to know it works *everywhere*, which is the standing instruction behind this whole
project. So `SceneSweep` asks thirty places on six continents across twelve dates from 2000 BC to
AD 2000, and then asks the same thirty again at six hours of the day: **540 queries**, and the one
question a scene register has to answer everywhere.

* every query gives an honest line, including the ones where the answer is *"Nothing is going on
 here today"* - the Amazon, at every hour, on every date;
* no scene is ever cast fuller than it holds, and none ever comes on without the thing that sets
 it off;
* **all twenty scenes come up somewhere.** A scene that never fires is a scene that does not
 exist, and the register should not be carrying dead rows.

```
Rome a wedding; a market day; a flight from flood, fire or earthquake; a plague
Lahore a wedding; a festival; a market day; a flight from flood, fire or earthquake;
 refugees on the road
Timbuktu a funeral; refugees on the road; a wedding; a festival; a market day
Cahokia a wedding; a market day; a funeral; a flight from flood, fire or earthquake;
 refugees on the road
Amazonia nothing on at any hour
```

### Two defects the sweep caught

**A siege was being read as a battle.** The match table asked for `battle` before `siege`, and
*"war siege"* contains *"war"* - so the Siege of Jerusalem produced *"two bodies of armed people,
and the ground between them"*, which is the one thing a siege is not. Asking for the narrower
thing first fixes it, and it is now a check in `/ee check scenes`.

**There were two fires in all of history.** Step 36's scraped pack of 26,997 hazards carries
earthquakes, volcanoes, plagues, tsunamis, famine and floods and **not one fire**; its hand-written
supplement had added two, London in 1666 and Edo in 1657. A register with a fire scene that can
never reach a fire is carrying a dead row. So four more went into the supplement, each on a
different continent in a different century and each carrying the article its figures came from:

| Fire | Year | What it was |
|---|---:|---|
| Great Fire of Rome | AD 64 | Began in the shops around the Circus Maximus on the night of 18–19 July; of fourteen districts three were razed, seven left as ruins, four untouched |
| 1547 Great Fire of Moscow | 1547 | 2,700 to 3,700 dead, 80,000 homeless |
| Fire of Moscow (1812) | 1812 | 14–18 September: 6,496 of the city's 9,151 residential buildings, 122 of its 329 churches, three-quarters of Moscow |
| Great Chicago Fire | 1871 | 8–10 October: about 300 dead, more than 17,000 buildings, 100,000 left homeless |

The supplement now stands at **79 events, of which six are fires**.

And one answer that looked like a defect and is not: **Moscow in 1812 comes out as a plague, not a
fire.** The fire burned three-quarters of the city, and the typhus epidemic on the retreat from it
killed 300,000. A register asked what is going on here is right to name the thing that killed more
people, and the sweep records which of the two it got rather than pretending only one is true.

### Limits

* **Eleven of the twenty casts are estimated.** The register says so in the sentence. Nobody
 published how many people stood at a village coronation.
* **The quorum threshold is a half, and that is a judgement**, not a source.
* **The crowd size comes from the caller.** The spawner hands over the settlement's own population;
 a caller that hands over a wrong number gets a wrong cast. The default is 200.
* **The three incident scenes depend on a caller.** An election, a protest and a trial have no
 register to be read from, because an incident is generated rather than recorded - so they are
 handed over by `CurrentAffairsEngine` whenever it builds a briefing from recent incidents, and
 they are not on otherwise. Sixteen of the nineteen kinds of incident set no scene off at all,
 which is deliberate: a good harvest is not a gathering.
* **The scene ground is not yet used to place anything.** The register says *where* a scene stands;
 the spawner still picks a spot the vanilla way inside the district. Ground-aware placement is
 carried forward with the rest of the wiring.
* **It does not model crowds moving**, queues, or the shape of a route. It says what is on, where,
 and who is in it.

### Verified

**2,311 checks in the sandbox, 0 failed**, across nine probe programs: 25 in
`probe_lifetable/SceneRun.java` (the register) and 17 in `probe_lifetable/SceneSweep.java` (the
540-query sweep over thirty places, twelve dates and six hours). `/ee check scenes` carries **19
checks** in the game, including the three the sweep caught. `syntax_gate.sh` is clean on every
file this step touched: `Scenes.java`, `Jobs.java`, `CultureAtlas.java`, `HistoryChecks.java`,
`PresenceLocalSpawner.java` and `CurrentAffairsEngine.java`.

### Files

`worldfill/scenes_table.py` (the twenty rows) and `worldfill/build_scenes.py` (pack builder with
its own self-test); `eternal/src/main/java/com/eternalengine/people/Scenes.java`; the pack
`history/scenes.json.gz` (20 scenes, 4.7 KB); three small additions to existing registers - 
`Jobs.pickIn` and `Jobs.shareOf`, `CultureAtlas.feastOn`; the rewritten scene path in
`villager/PresenceLocalSpawner.java`; the incident caller in
`affairs/CurrentAffairsEngine.java`; `/ee check scenes` in `civilization/HistoryChecks.java`;
and four fires added to step 36's `worldfill/disaster_supplement.py` (now 79 events, 6 fires),
which is the one place this step reaches back into an earlier step's data.

## Step 40: armies in action - formations, sieges, weapons of the era, morale, sides (D10) - done in turn 143

Five registers, one question each, and one claim running through all of them: **the rout is where
the dying happens.** Ardant du Picq, watching what a broken army actually does - *"Demoralized
and not feeling themselves supported, the ranks engaged followed them, and the routed mass let
itself be slaughtered. The weapons fell from their hands"* - and Peter Krentz, counting every
surviving casualty figure from Classical Greek sources, arrived at the same place by different
roads. Krentz's numbers: the winner loses about 5%, the loser about 14%. The gap between those two
figures is not marksmanship. It is the pursuit.

### What was there before

`BattleSimulator` was one dice roll and two constants. It added a size ratio, morale, supply, a
technology gap and a terrain bonus to get the odds; then it set the losses at **8% for the winner
and 18% for the loser, unconditionally** - whatever year it was, whatever either army was
carrying, and **however the loser went**. Then it moved morale by `+10`, `-2` or `-15`. None of
those numbers is wrong exactly. They are all *unattached*: nothing in the file said where 18% came
from, and the one thing every source about battle casualties is loudest about is that the loser's
losses are not a property of the loser at all but of how the loser left the field.

`Sieges` did not exist as a register and `War` had no notion of what kind of party was on each
side. **The registers replace the old code, they do not sit beside it** - two ways of fighting a
battle is one too many.

### The five registers

| Register | Rows | Asked by | What it answers |
|---|---:|---|---|
| `Formations` | 16 | lat, lon, year | how this army stood here and now |
| `Battles` | 4 bands, 4 breaks | two formations, ground, year | how the fight came out, and how the loser went |
| `Sieges` | 11 walls, 10 methods, 5 endings | a town, a besieger, a year | what the siege cost and when it stopped |
| `Morale` | 32 factors, 9 ways of raising, 11 desertion rates, 4 ways of breaking | 21 facts about an army | why these men are still standing |
| `Sides` | 14 kinds of party | a place and year, or a caller who knows | who is fighting, and whether they can be bound |

Five packs, **37 KB in the jar**, and every one of them carries its own gaps block.

### 1. How armies stood

Sixteen formations, each with the place and years it was used, the ground it wants, how deep and
how wide it stands, and what it is carrying. Thirteen recorded, three mixed.

```
Rome -200 the Roman line of cohorts
Greece -400 the hoplite phalanx
North India -300 the elephant screen
Wessex 1000 the shield wall
Edo 1600 the ashigaru pike block
Switzerland 1470 the Swiss pike square
Flanders 1700 the Spanish tercio
Sweden 1650 the Swedish brigade
France 1805 the line and the column
Virginia 1863 the skirmish line
Bohemia 1866 open order
Zululand 1879 the horns of the buffalo
the Western Front 1917 the fire team
```

A formation is not a costume. It changes the odds, and the ground changes it again:

```
the phalanx beats the Roman line 68 times in 200 on level ground
 and 38 times in 200 on broken ground
on broken ground the phalanx is at a real disadvantage: -0.12
```

which is Cynoscephalae and Pydna, and the register gets there without being told about them.

### 2. How a battle came out

Four **bands**, by what the armies were carrying:

```
shock winner 3-10% loser 10-20% (recorded - Krentz)
bow winner 2-6% loser 8-18% (estimated)
musket winner 8-15% loser 18-30% (estimated)
rifle winner 4-12% loser 12-25% (estimated)
```

The rifle band is **lower** than the musket band (25% against 30%), because casualty rates have
been falling since the seventeenth century: armies dispersed faster than weapons got more lethal.

Four **ways of losing**, each multiplying the loser's own band:

```
withdrawn x0.55 7% to 10% the line goes back but keeps its order, its officers and its rear
broken x1.5 20% to 27% the line comes apart and the men go, but it is late, or dark, or
 there is cover
pursued x2.2 30% to 40% it breaks in daylight on open ground and the winner has the
 cavalry to run it down
surrounded x3.2 43% to 58% both flanks are turned and there is no line to fall back to
```

All four come up in a real campaign. And the way an army fights is what makes a victory decisive:
**the Zulu horns, built to encircle, finish the job 100% of the time; the Roman line, built to
hold, finishes it 0%.** A model that charges both sides a flat percentage cannot say that, because
it has no way to ask.

Over 2,456 hoplite battles the register gives a winner's average of 6.4% and a loser's of 11.4% - 
inside Krentz's band, and not the old flat 18%.

### 3. What a siege cost

Eleven kinds of wall, ten methods, five endings - and **two clocks**, which is the whole idea. The
wall clock says when a practicable breach can be made; the food clock says how much bread the town
has. Whichever runs out first decides how the siege stops.

```
Rochester 1215, mined: 50 days record: 11 Oct to 30 Nov, about 50
Constantinople 1453, bombarded: 53 days record: 6 April to 29 May, 53 days
Vicksburg 1863, entrenched: 64 days record: 18 May to 4 July, 47 days
Kenilworth 1266, ringed by water: 615 days record: no breach was ever made; 172 days of hunger
```

Kenilworth is the case that shows the two clocks are worth having: on dry ground the same wall
falls to a mine in 188 days, through living rock in 248, and **ringed by water it cannot be
breached at all** - so the mere decided it and hunger finished it. A single-clock siege model has
no answer there except a wrong one.

Ground is not decoration either. Ladders are on the table against a `trace_italienne` and are not
against a medieval curtain, because the trace italienne is *low*: it stopped building upward and
started building outward.

Spread over 480 sieges the five endings come out as **terms 381, abandonment 16, starvation 20,
relief 11, storm 52** - the commonest ending is the one nobody guesses. Most sieges end without
the town being sacked (408 of 480), which matters, because a conditional surrender is a bargain
between two parties who can each be held to it, and that is a claim about *sides*.

### 4. Why men stood

Thirty-two factors - 19 recorded, 4 mixed, 9 estimated - and the register hands back **a number
with the reasons attached**:

```
1863, in line: the conscript army, 26 [mixed]; helped by the men beside him (+14), regular
 pay (+8), religion (+5), an officer in front of him (+6), the fear of
 punishment (+5), the shoulder of the man next to him (+5) [mixed] and their
 own ground (+8) [est]; hurt by no depth at all (-10) [mixed] - 67
1863, in skirmish: the same men; ... hurt by dispersion (-12) - 50
```

**Dispersion costs morale rather than granting it.** du Picq: *"since the invention of fire
arms... the more men think themselves isolated, the more need they have of high morale. We are
brought by dispersion to the need of a cohesion greater than ever before."* The skirmish line
needs *more* of it than the phalanx did, not less - and the register charges it for dispersion
while crediting depth, because the rear rank cannot see the carnage.

**Losing is worse than winning is good:** winning +14, losing −18. The record is unambiguous - 
*"Lee's men fought hungry through much of the Civil War, cheerfully and without complaint; it was
only when Grant and Sherman began to close in that they deserted."*

Desertion lands on the measured rates rather than a guess:

```
a long-service army in 1730 3.2%/yr (Duffy: Prussia 3.2, France 4.4, Saxony 7.0)
the Army of the Potomac, 1863, paid, advancing 3.0%/yr
the Army of Northern Virginia, 1864, unpaid 8.0%/yr
a hired company, paid / unpaid 8.4% / 16.8%
```

The nine ways of raising an army carry their own cohesion and their own desertion rate: a citizen
militia 36 cohesion and 3%/yr, a warlord band 14 and 12%/yr, slave soldiers 37 and 1.5%/yr - they
desert least of all, having nowhere to desert to.

### 5. Who was fighting, and as what

Fourteen kinds of party, and the question that decides sieges: **can this side be held to a
treaty?** Brecke's Conflict Catalog admits non-state actors, on the rule that *"conflicts between
warlords when there is no state involvement qualify as violent conflicts"* - which is what puts a
warlord band in the table at all. Six of the fourteen cannot treat: rebellion, separatist, tribal
confederacy, warlord band, steppe khanate, hired company, and civilians. A hired company cannot,
because its captain cannot deliver it.

**A side's worth is the weakest body in it**, because a line is only as good as the unit that
gives way: one warlord band in a coalition makes the whole side unbargainable.

This register has one rule about knowing things that turned out to matter more than the taxonomy:
**a map and a year cannot tell you that Florence is a commune.** `partyAt(43.77, 11.26, 1400)`
answers `sovereign_state`, and says so - the register declines to guess local parties from
latitude. A commune is named by the caller who knows, which in practice is the town itself. Which
is why, over 48 sieges of the same town:

```
as a commune 39 end in terms
unnamed 39 end in terms
as a warlord band 0
as a hired company 0
```

### What it says

```
Cynoscephalae 197 BC, on the ridge, 26000 against 26000:
 the Macedonian phalanx broke the Roman line of cohorts - broke and ran. The winner lost 7%,
 the loser 27%. Most of the loser's casualties were taken after it broke, not during the
 fighting: that is what a pursuit is.

Gaugamela 331 BC, on the plain, 40000 against 50000:
 the Macedonian phalanx broke the elephant screen - gave ground in order. The winner lost 6%,
 the loser 10%.

Waterloo 1815, on the field, 73000 against 68000:
 the line and the column, on both sides, broke its like - broke and ran. The winner lost 11%,
 the loser 39%.

Isandlwana 1879, in the open, 20000 against 1000:
 the horns of the buffalo broke the open order - encircled, with nowhere to go. The winner
 lost 5%, the loser 53%.
```

```
Kenilworth, 1266:
 174 days. The breach was practicable on day 615, opened by a counterweight stone-thrower. The
 garrison opened the gates rather than starve. They marched out with their arms and their
 lives, and the town was not sacked: a place that surrendered could not be ransacked. Of 1300
 people, 61 were dead, and 849 came through; 390 were put out of the gates as useless mouths,
 and more than half of them died in the ditch between the two armies.
```

### Four defects the probes caught

**A "how the loser went" multiplier of 1.0 defeats its own purpose.** With loser bands floored at
8–18% and Krentz's rout point at 12%, the `withdrawn` row at 1.0 meant *every* beaten army in the
register paid the full routed rate whatever how it went - nothing ever retired in good order, and
the four breaks were decoration. It is now 0.55, and the note in the pack records the finding. The
consequence is the one worth having: **an army that breaks always loses more than the side that
beat it (39 of 39), and one that retires in order does not necessarily** - it lost fewer in 2 of
81, which is why the same army can lose three battles and still be an army.

**A box generous enough to hold two regions tells you nothing.** The steppe box spanned the steppe
belt *and* northern China, so Pingyao in 1500 returned a khanate - and a khan's following cannot
be bound, so the siege register could never offer that town terms. Narrowed to the steppe proper.

**A gate that fires on silence is not a gate.** `canTreat` was written `p != null && p.willTreat()`,
which made the register's own ignorance into a refusal: every town whose party it did not name was
denied terms. That inverted the siege spread - 274 storms against 159 surrenders. Corrected to
`p == null || p.willTreat()`, the spread becomes 381 terms against 52 storms. **Silence is not
refusal**, and the difference is most of the register's output.

**The rout had to reach the army, not just the report.** Losses now go through
`Army.takeLosses`, so an army carries what it lost: 50,000 → 46,000 → 43,400, and `routing()` is
true at 13.2% gone against Krentz's 12%. Before part 6, a battle's casualties were printed and
forgotten.

### Limits

* **The rout is the whole of the casualty model, and it is one survey.** The shock band is Krentz's
 Greek figures; the bow, musket and rifle bands are estimated and say so every time they print.
* **Only one formation register row is measured against a named battle.** The rest is the record of
 what an army of that place and year was, not a prediction of what it did.
* **Wall strength is estimated throughout** - no source was read that ranks wall types against one
 another; the ordering is argued from what each wall was built to answer. The besiegers' clock is
 a single number, not a model of disease, weather and supply. **Water is a floor of three days
 and not a supply**, because the register does not yet know whether a town has a cistern or a
 well.
* **Every morale weight is this table's reading.** The factors are read; the number of points each
 is worth is not something any source put a figure on.
* **No commander in it.** du Picq, and everyone who has written since, would say that is where
 most of morale lives, and no row in the pack can express one.
* **Brecke's Conflict Catalog was never loaded.** It is a binary spreadsheet; the 14 kinds of
 party are read from the catalog's own description of its fields, and **not one of its 3,708
 conflicts is in the pack**. Its own coverage warning applies to every row: "quite complete" for
 Western and Eastern Europe, North, West, Central, East and South Africa - **and not for the
 rest.**
* **No row for Oceania, none for the Americas before 1491, none for sub-Saharan Africa outside the
 Zulu kingdom**, in the formation table; and the desertion figures are European and North
 American to a man. Not because those peoples did not form up, fight, or break - because nothing
 was read for them, and this project does not write a row it has not read.

### Verified

**143 checks in the sandbox, 0 failed**, across four probe programs written for this step: 18 in
`probe_lifetable/BattleRun.java` (formations and battles), 25 in `SiegeRun.java`, 53 in
`MoraleRun.java` and 29 in `ArmiesRun.java` (the part-6 wiring). `/ee check armies` carries **18
checks** in the game.

The in-game checks live in **`war/ArmyChecks.java`** rather than in `HistoryChecks`, for a concrete
reason: `HistoryChecks` reaches into half the mod and will not compile without Minecraft on the
classpath, so a check written only there would go unexercised until somebody built the mod. Here
the very same code is run by `probe_lifetable/CheckArmies.java` outside the game, every time the
probe runs - so a claim cannot pass in the build and fail in the game.

`syntax_gate.sh` is clean on every file this step touched: `Formations.java`, `FormationType.java`,
`Battles.java`, `BattleSimulator.java`, `Sieges.java`, `Morale.java`, `Sides.java`, `War.java`,
`Army.java`, `ArmyChecks.java` and `HistoryChecks.java`.

### Files

`worldfill/formations_table.py` + `build_formations.py`, `battle_table.py` + `build_battles.py`,
`siege_table.py` + `build_sieges.py`, `morale_table.py` + `build_morale.py`,
`sides_table.py` + `build_sides.py` (ten files, each builder with its own self-test); the five
packs `history/formations.json.gz` (6.9 KB), `battles.json.gz` (2.6 KB), `sieges.json.gz` (8.1
KB), `morale.json.gz` (13.7 KB) and `sides.json.gz` (5.7 KB); the mod side
`com/eternalengine/war/`: `Formations.java`, `Battles.java`, `Sieges.java`, `Morale.java`,
`Sides.java`, `BattleSimulator.java` rewritten to stand on the registers, and `Army.java`,
`War.java` and `Battles.java` wired to them in part 6; `war/ArmyChecks.java` and the `ARMIES` part
of `civilization/HistoryChecks.java`; and four probe programs under `worldfill/probe_lifetable/`.

## Step 41 - Famous people at their homes; families and dynasties (D11, C11)

Two registers, both new, both built from what Wikidata says and not from what a genre expects:
**where a person was** (D11) and **who was whose parent** (C11).

### The defect, and the line that said so

`SYSTEMS_PLAN.md` line 507: *someone born in Bombay who lived in England (T. H. White) is talked
about in Bombay, and the famous of a city who were born elsewhere are not "from here".*

Every question `FamousPeople` answers - `livingIn`, `diedIn`, `bornNear` - it answered **by
birthplace or by state**. A person was where he was born, for the whole of his life. T. H. White's
card has said he studied at Queens' College, Cambridge since step 27, and nothing in the mod could
use it.

The same question, asked both ways now:

```
at Cambridge in 1928: 352 people with a card were there, and only 6 of them were born there
T. H. White: 3 stays -- born Mumbai 1906 to 1964;
 studied at Cambridge, in a year the record does not give;
 died Piraeus 1964
```

That six is everything the mod could say before this step.

### What a stay is

A person, a place, two years, and **a why** - born, died, studied at, worked for, served in, member
of, party, founded, lived at, worked in - because *from here* and *here now* are different
answers, and a register that cannot tell them apart will go on putting a man in the city he was
born in. **352,250 stays over 58,375 places. 94,361 of the 148,510 people with a card - 64% - are
somewhere other than their birthplace.**

**An office is not a stay.** A position-held statement almost never carries a jurisdiction, and the
office item's country is a country, not somewhere a player can stand. So the register cannot say
where a court was; it can say who held the office and when, which is what the dynasties are for.

**A stay nobody dated says so.** 32% of the rows carry the person's own birth and death years
because no source dated them - a residence statement in Wikidata has a start year 18% of the time.
The page prints *in a year the record does not give* rather than a year nobody gave it.

### What a family is

Until now the only family in the mod was **the card links of a prose family** - whoever Wikidata
happened to name on the card - and `DynasticSuccessionEngine` generated heirs and coups with no
bloodline to work from at all: `DynasticHeir` carries a claim strength, a birth year and no
parents.

The pack holds **95,585 parent edges, 32,394 marriages, 91,168 named relatives and 3,312 houses**.
Wikidata states *child* 64,710 times against *father* 27,605, so one parent row is stored per pair
whichever way the source put it, and the register answers both directions. **Only 14% of edges have
both ends on a card** - a famous person's father is usually not famous himself - so the 91,168
relatives with no card are carried with their names and years; a person's page now names his
parents, his spouse and his children, and 48,075 people with a card (32%) have one.

### What a dynasty is: derived, not asserted

No source lists "the Habsburgs held the Holy Roman emperorship". The pack finds **parent-and-child
holders of one office** and calls a connected component of three or more a dynasty: **534 dynasties
across 275 offices**, 74% of them named after the house Wikidata gave.

That is as true of a republican *gens* as of a monarchy - the Metelli held the consulship across
seven generations - so the wording is **a family that held this office across N generations** and
never *a hereditary throne*.

| | | |
|---|---|---|
| sultan of the Ottoman Empire | Ottoman dynasty | 39 holders, 21 generations, 1299–1922 |
| duke of Bavaria | House of Wittelsbach | 21 holders, 10 generations, 1183–1425 |
| Monarch of Castile and Leon | the Monarchs of Castile and Leon | 19 holders, 16 generations |
| Roman consul | the family of the Roman consul | 18 holders, 7 generations, 122 BC–AD 32 |
| emir of Kuwait | House of Al Sabah | 17 holders, 8 generations, 1752–2023 |
| ancient Roman senator | Caecilii Metelli | 15 holders, 7 generations, 284–52 BC |

A surname fallback was tried and rejected: the last word of *Otto I Wittelsbach, Duke of Bavaria*
is **Bavaria**.

### Limits

* **The mod has not been compiled since this step began.** This workspace has no Gradle cache and
 no Minecraft jars, and the `knowledge` package will not compile without them (48 errors, all
 `net.minecraft`). `syntax_gate.sh` passes on every file touched - it catches a missing brace and
 **not** a wrong type, a wrong arity or a bad import. `tools/gradle_compile.sh` is the only real
 check, and it has not run.
* **Dynasties are inferred from office-holding, not from law.** A component of three parent-and-child
 holders is called a dynasty whether or not the office was hereditary, and 63 offices produced a
 component with no house at all. The Roman consulship is in the list; that is the rule working,
 not a mistake, but it means **the count is a count of families, not of thrones**.
* **32% of stays are dated by the person's life** because nothing dated them, and the register says
 so. A "lived at" row with no year is a claim he was there once, not a claim he was there in the
 year the player asks about.
* **989 of the 58,375 places have no name**, covering 2,023 rows: the register can point at them and
 cannot name them.
* **4,925 people are named by an edge and have no card and no name in the pack.** The register calls
 them *someone the record does not name* rather than inventing an uncle.
* **A page still places a person by birthplace for everything except the two new questions.** The
 "why is he here" question and the "who was here" list come from the register; the rest of the
 card is as it was.
* **The book's family tree is still the prose pack's links.** The one family card in the prose packs
 (`asaf_jahi`) is hand-written for Hyderabad in 1948 and has no Wikidata number, so nothing was
 replaced. `BookService.treeIds` now adds blood relatives for any family whose names *do* carry
 one - which today means none.
* **The succession engine still generates heirs without parents.** `DynasticHeir` was not changed;
 the register can now tell it who a claimant's father was, and nothing asks it yet.
* **An office is not a presence row**, so the register cannot say where a court was.
* **No new data was fetched for C11 beyond what step 27 already had**, plus six QLever queries for
 kinship, houses, residences and work locations. 57 exports, 4.6 MB, all on disk in
 `worldfill/raw/step41/`.

### Verified

**25 checks in the game and the sandbox, 0 failed**, run by
`civilization/FamousChecks.java` - the same class either way: `/ee check all` (the new `famous`
part) runs it inside a server, and `probe_famous41.sh` runs it outside one. **43 more** in the
probe's own sections, and the two builders' self-tests: `build_kinship.py --check` (34 assertions)
and `build_presence.py --check` (19 assertions).

`FamousChecks` lives next to the registers it checks and not in `HistoryChecks`, for the reason
step 40's did: `HistoryChecks` reaches into half the mod and will not compile without Minecraft on
the classpath, so a check written only there would go unexercised until somebody built the mod.

`syntax_gate.sh` is clean on every file this step touched: `Presence.java`, `Kinship.java`,
`FamousChecks.java`, `HistoryChecks.java`, `PlaceCards.java`, `BookService.java` and
`CardStore.java`.

### Files

`worldfill/fetch_step41.py` (six QLever queries), `worldfill/read_cards.py` (the shipped card
tiles), `worldfill/build_kinship.py` and `worldfill/build_presence.py` (the builders, each with its
own `--check`); the packs `history/kinship.json.gz` (3.4 MB) and `history/presence.json.gz`
(3.4 MB) with `history/presence.tiles` (6.1 MB, 1,206 groups) built by `build_tiles.py`; the mod
side `civilization/Presence.java`, `civilization/Kinship.java` and
`civilization/FamousChecks.java`, with `PlaceCards.java`, `BookService.java` and `CardStore.java`
wired to them; and `worldfill/probes/FamousStep41Probe.java` behind `worldfill/probe_famous41.sh`.

Next: step 42.

## Step 42 - Law, reputation, social order and reactions (C18, D7, D13, F2, F3, D18, F8) - done in turn 156

Seven systems, one spine, eight parts. **C18 (law and rights by era) is the spine**: D7, F3 and F8
all stand on it, and it was built first for that reason.

### The line in the plan, and what was there

`SYSTEMS_PLAN.md` line 275, for F8: *"crossing from one state to another (tolls, customs, passports
from the First World War, quarantine)."*

What the mod had when the step began: a `reputation/` ledger of 8 positive and 13 negative
dimensions with hardcoded deltas and **no place and no year** - one global number per player;
`PeopleMemory` remembering 64 people per place with no opinion of a player; **and no class system,
no caste, no guild and no law of any kind**. The plan records D7 as *"old code (class system)"* and
that code does not exist. `RoyalCourtManager` is a **throne room** - a ruler, a bodyguard and a
chancellor standing in a room - and not a court of law. There is no guard, no watch, no magistrate,
no punishment, no border and no permit anywhere in the mod.

So every person in this world has stood in the same relation to every other, in 3000 BC and in 1900
alike, and nobody has ever been stopped at a frontier.

### The survey, and the seven decisions

**Measured, not assumed.** Guessed QIDs turn out to be worthless - P2596 returned *Fang Ngil Masks →
Gabon* and P2482 returned baseball players - so every identifier was looked up by name first.
**Wikidata is thin**: 761 codes of law of which only **197 are dated**, 386 caste items, 535 guilds.
**Wikipedia is rich but country-granular**: 164 capital-punishment-by-country articles, 232
passports, ~150 slavery, 65 women's-suffrage subcategories, 49 serfdom.

1. A law row attaches to **the state and not the square**, keyed by polity QID plus a year span - 
 the mod already maps a point to its ruler through `RulerRegister.rulerAt(lat,lon,year)`, which is
 the only reason a country-granular source can answer a lat/lon question at all.
2. Wikipedia is **read, not queried** - there is no SPARQL form of those articles.
3. One pack with **two marks**: a date a source states is *recorded*; a reading for a region and era
 is *estimated* and says so.
4. The reputation engine is **kept and made local and dated** rather than rewritten, since F2 needs
 it per land and D13 per place.
5. D18 **extends `PeopleMemory` with an opinion of each player** rather than adding a second memory.
6. **Caste, guild and class cannot be fetched** - 386 and 535 mostly modern, mostly European items
 are not a picture of the world - so that table is hand-written and estimated throughout.
7. **F8 needs the neighbouring state**, so it is the one system that needs a state graph.

That seventh decision was wrong, and part 7 reversed it. See below.

### Part 2 - C18: the law pack

`build_law.py` → `history/law.json.gz`: **620 dated changes in the law over 237 polities, 326 BC to
AD 2026**, 23 KB, **0 problems**.

**The dates came from tables and not from prose**, because prose extraction is where a pack quietly
goes wrong - a sentence about a *proposed* abolition reads exactly like one about an enacted one - 
and three Wikipedia pages hold these facts as tables: the abolition-of-slavery timeline, women's
suffrage, and capital punishment by country.

Three parsing defects, each of which silently corrupts data: wikitext parsing lost the Jurisdiction
column wholesale (`[[File:...|22px]] Polis of [[Classical Athens|Athens]]` defeats any regex), so
the fetcher takes the **rendered HTML**; rowspan was ignored and then skipped, which refiles law
changes under the wrong year, so the grid is reconstructed and a carried cell repeated in every row
it covers; and `norm()` drops *of*, so the alias `united states of america` never fired and the join
missed.

Every row is keyed by the polity QID of `world_rulers.json.gz`, **the ruler register's own 1,581
states**, so a row can never name a state the mod cannot find. **250 of 620 rows are estimated** and
say so.

**And part 6 found a real defect in part 2.** The join matched by name and took whichever polity
came first in the file, so France's 1981 abolition sat on *Kingdom of France*, which ended in 1792 - 
and the mod read France in 2000 as having **no law at all**. Measured: **189 of 611 rows (31%) sat
outside their polity's span**. The fix **joins by ground and not by name**: a country now knows every
state that ever ruled a place inside it, built from the register's own place coordinates and
`countries.grid.gz`, and the year picks which one, weighted by how many places it ruled - French
Guiana alone otherwise files Brazil under France. **189 → 71**.

### Part 3 - D7: social order

`social_order_table.py` → `history/social_order.json.gz` + `SocialOrder.java`: **12 orders over 198
countries, 58 strata, 8.4 KB**, builder and probe both **0 problems**.

Twelve orders - the order of kin, the citizen and the slave, the four varnas and the jatis, the four
occupations, the three estates, the free/the protected/the owned, the castas, shi-no-ko-sho,
industrial classes, the working class and its party, the segmentary lineage, the settlers and the
colonised - **plus a default, because the mod covers every square of the map in every year and a
register that shrugs has failed**.

The half of D7 that is not a list of ranks is **`may`: who may address whom uninvited** (3 anyone,
2 his own order and beneath, 1 only when spoken to, 0 nobody). *The third estate does not open a
conversation with the first estate.*

Three defects the checks caught: the varna shares added up to **0.80 and not 1.00**; **India in 1700
was being described as a settler colony**, because the colour-bar row carried `IND` at priority 7
against the varnas' 6; and **every `may` was 3**, because the helper's default was 3 and not one row
passed a value - the whole feature was silently inert until all 62 strata were set by hand.

### Part 4 - D13 and D18: reactions, friendship and greetings

Four files, probe **31 checks / 0 problems**, and `/ee law` and `/ee standing`. New
`LawRegister.java` is the shared base D13 and F3 both stand on. New `Reactions.java` holds D13's
three reactions and D18's greeting and **imports no Minecraft**, so the probe runs the very code the
game runs - the split step 40 set down with `ArmyChecks`.

D13 answers **to the player**, **to the law** (graded by how long ago the law moved: *just changed /
still talk about it / the old men remember / the last change anyone wrote down*), and **to things out
of their time**, read differently by each order. New `PlayerStanding.java` is the saved opinion, per
128-block square and per player. **Friendship is a threshold and not a flag**, because a second
number would only ever disagree with the first.

The design mistake worth recording: the first `greet()` re-derived D7's rule from a threshold
(`may <= 1`) instead of asking it, and since the third estate is `may = 2` **the villein greeted the
lord as an equal** until the probe caught it.

### Part 5 - F2: reputation per land, and loyalty

Two files and `/ee fame`, probe **39 checks / 0 problems**, and **no new data pack** - this part is
code. The sides half already existed: step 40's `war/Sides` carries 14 kinds of party.

New `reputation/Fame.java` holds a **deed** and derives every opinion from two rules. **Fame
decays**, halving every 30 years - *not from a source*, and named in the code as a modelling choice.
**Fame travels**: a deed is worth nothing where it has not been heard.

The best mistake of the step: I first asked `NewsTravel.fastest(...)`, which is a king's dispatch - 
and in 1400 a rider reaches *Sydney* from Bordeaux in 288 days, so at the year grain this mod works
at everything arrives inside the same year and **the travel gate could never fire**. The right
channel is `NewsTravel.traveller`, the register's *"the one rumours run on"*: **10 months Bordeaux to
Constantinople in 1400, 3.0 years to Beijing, 5.9 to Sydney**, and 8 weeks to Beijing by 1900. So **a
deed worth +60 done in France in 1400 is worth nothing in Beijing in 1401 and is known there in
1402.**

**A land is a `CountryGrid` country, not a polity** - keying reputation to a state would make a deed
in the Kingdom of France unknown in the French Republic three fields away; reputation belongs to the
ground. **Loyalty is the other way round** and is owed to a `Sides.Party`, decaying at 60 years,
twice a name's, because a tale needs a witness and a promise does not.

**Part 8 added `/ee oath`**, which part 5 left unwritten: swear, strengthen, break, and see who is
in force where you stand. It says two things rather than hiding them - an oath can **outlive the body
it was sworn to** (*still bound, and nobody left to call on it*), and a party that `cannotTreat` - 
a band, a rising, an unpaid company - **will take your oath and cannot be held to it**.

### Part 6 - F3: law and crime by era

Four files, `/ee justice`, probe **52 checks / 0 problems**. `justice_table.py` →
`history/justice.json.gz` + `Justice.java`: **16 kinds of peace-keeping, 14 kinds of court, 8 kinds
of punishment**.

**Punishment is a repertoire and not a choice** - `punishments()` returns every punishment
available, because picking one silently deleted the other five *and killed the fallback row
outright*, two rows covering every country from before history. And the three fallbacks **were both
a row and the default**, so as rows they matched everywhere and the fallback could never fire - a
fallback that is also a row is a fallback that never runs.

**The one hard fact is not from this table**: whether a place still hangs people comes from the C18
law pack's own dated abolitions. France can hang a man in 1780 and not in 2000; Portugal not after
1867.

### Part 7 - F8: borders and permits

Four files, `/ee border`, probe **122 checks / 0 problems**. `borders_table.py` →
`history/border.json.gz` + `Borders.java`: **12 kinds of crossing over 198 countries, 5.1 KB**.

Every row is estimated - **but the dates on five of them are not readings**. They were pulled out of
the articles themselves: Ragusa **1377** (the trentino), the passport **1914** (the British Act) and
**1920** (League of Nations standardisation) - the First World War the plan names - the Zollverein
**1 January 1834**, sakoku **1633–1853**, Canton **1757–1842**.

**The border itself is not data.** The survey said F8 needed the neighbouring state, and the obvious
move was a country-adjacency graph. It was not built. `Borders.borderBetween` derives it from
`RulerRegister` on the fly - 24 samples along the leg, then 12 bisections - because **the ruler
register already is a state graph** (9,322 timelines over 1,581 polities) and a second one could only
ever disagree with it. This also unblocks part 5's fame-spreading, which had been recorded as
blocked on a graph.

```
Paris → Lyon 1300 SAME HANDS both the Kingdom of France
Paris → Cologne 1300 BORDER Kingdom of France | Holy Roman Empire Minor States, at 187 km
Delhi → Lahore 1700 SAME HANDS both the Mughal Empire
Delhi → Lahore 1950 BORDER Republic of India | Dominion of Pakistan
```

The Delhi–Lahore pair is the one worth keeping: **the same road crosses nothing in 1700 and crosses a
line in 1950**, and nothing about the road changed. The line is symmetric to 0.5 degrees with the
rulers swapping exactly.

**Three defects the probe caught.** `customs_house` ended at 1900 and `passport_control` began in
1914, leaving **1900–1914 answering "nothing here to stop you" for every country on earth**.
`crossing()` keyed the post on the *border point*, and since `CountryGrid.codeAt` of open water is
sea, **Shanghai → Edo in 1800 came back "open ground"** when what waits at the far end is the edict
that shut Japan; the post is now keyed on the **destination**, which is also truer, since the
crossing you satisfy belongs to the state you are entering. And the far side of a line was labelled
with the **destination's** ruler rather than the neighbour's, so Rome → Kraków in 1500 reported *"the
Papal States give way to the House of Jagiellon"* - true of the journey, false of the line.

**Two flags make the table work**: `sea` (a port; you only meet it off a ship) and `internal` (a toll
inside one state; you only meet it on a road). Without them the priority ordering had to choose
between a lazaretto and a turnpike, and chose wrong everywhere - **from 1377 to 1860 every Englishman
who crossed anything was told he was being quarantined**. With them: a man riding north through
England in 1800 meets **the turnpike**; a ship into Liverpool meets **the customs house**; a ship
into Venice meets **forty days in the lazaretto**. Same year, three answers. And the **Zollverein is
the row whose answer is that you are not stopped**, weighted to win.

One honest correction made mid-part: the lazaretto was first written across all of western Europe,
which quarantined Liverpool and Hamburg. It is a **Mediterranean** institution and now says so.

### What this step does not do

These are limits, not a backlog, and each is recorded where a caller will meet it:

- **D7, F3 and F8 are estimated throughout.** No source states what share of a society was brahmin
 in a given century, that the peace of a given century was kept by a paid watch, or that a frontier
 demanded a gift. Only C18's dates are recorded facts, and the register prints the mark with the
 answer.
- **71 law rows still sit outside their polity's span** - a year no polity covers, where the join
 takes the nearest instead of dropping the fact.
- **F3 has no crime yet.** Nothing commits a theft and nothing is accused, so the pack says what a
 court *would* do and nothing has been put before one.
- **The C18 pack cannot see a restoration.** It holds abolitions only, so a country that abolished
 and then restored capital punishment reads as having abolished it.
- **The border is only as good as the ruler register**, which is a nearest-place lookup. It genuinely
 answers *House of Jagiellon* for a point just north of the Papal States in 1500 - the Jagiellons
 ruled Bohemia and Hungary and their places are the nearest ones there. The line lands in the right
 place; who is on the far side of it inherits the register's sparseness.
- **The F8 default is nearly unreachable.** `tribute_gate` covers every country from 3000 BC, so the
 fallback only answers before that - which is honest, since a frontier needs a state on both sides.
 **`Australia in 1300 → "a gate and a gift"` is the kind of answer to distrust.**
- **`/ee check all` has no step-42 section.** The steps' own probes run outside Minecraft; the
 in-game check was not extended this step.
- **`tools/gradle_compile.sh` has still never run.** Every step-42 Java file is proven only against
 a bare JDK 17 by `syntax_gate.sh` and by the probes, which compile the real registers. **The mod
 has not been built against real Minecraft jars since step 41.**

### Files

`worldfill/build_law.py` (C18, with `worldfill/countrygrid.py`, a Python reader for
`countries.grid.gz`), `social_order_table.py` + `build_social.py` (D7), `justice_table.py` +
`build_justice.py` (F3), `borders_table.py` + `build_border.py` (F8); `worldfill/rebuild_all.sh`
rebuilds all four from their persisted sources.

The packs: `history/law.json.gz` (23 KB, **mixed**), `history/social_order.json.gz` (8.4 KB),
`history/justice.json.gz` (7.7 KB) and `history/border.json.gz` (5.1 KB) - the last three
**estimated** throughout, all four registered in `manifest.json` and `DATA_CREDITS.md`.

Mod side, none of which imports Minecraft unless it has to: `civilization/LawRegister.java`,
`civilization/SocialOrder.java`, `civilization/Reactions.java`, `villager/PlayerStanding.java`,
`reputation/Fame.java`, `reputation/LandReputation.java`, `civilization/Justice.java` and
`civilization/Borders.java`.

Probes (each compiles the real registers against a bare JDK 17 and Gson, so the code under test is
the code the game runs): `probe_step42.sh` (D7), `probe_step42b.sh` (31 checks), `probe_step42c.sh`
(39), `probe_step42d.sh` (52), `probe_step42e.sh` (122) - **244 checks, 0 problems**.

Commands: `/ee law`, `/ee standing`, `/ee fame`, `/ee oath`, `/ee justice`, `/ee border`.

Next: step 43 - sounds, signs, writing, sky (J2, J3, J4, E13).

## Step 43 - Sounds, signs, writing and sky (J2, J3, J4, E13) - done in turn 160

Four systems, six parts. **None of them existed.** Of the four, only J2 had any code at all, and
that code - `HistoricalAudioDirector` - was worse than nothing, because it chose one of six
soundscapes **from the year alone**: `x` and `z` were parameters it never read. China in 1000 was
"Classical Mediterranean"; Norway in 1200 was "Medieval Islamic"; the Aztecs in 1500 were
"Renaissance Europe"; **everything after 1920 was "Pastoral Ancient"**, filing the loudest centuries
there have ever been as prehistoric countryside. It also printed a chat message describing the
soundscape, which is a tell that it was never wired to anything.

### The survey, and seven decisions

The whole chain for scripts already existed, built by step 30b and step 38:

```
LocalLanguages.peoplesLanguage(lat, lon, year) -> language (6,741 living languages)
CultureAtlas.scriptOf(language, year) -> script (97 languages, dated)
```

The measurement that decided the step: **959 of the 960 polities carrying a religion join to the
ruler register's QIDs - 100%.** So the faith of a place can be dated by the polity's own span,
which is how a place gets a call to prayer at all. And `technology_table.py` carries, per country
with real arrival years, the steam engine (GBR 1712), the railway (GBR 1825, IND 1874), the car
(DEU 1886) and - decisively for part 5 - **the public post (DEU 1490)**.

1. **J2's faith half is derived**: place → ruler → `rel` → what you hear. `relP`'s twelve
 hand-written periods take precedence where they exist, being finer than a span.
2. **J2's machine half comes from the technology atlas**, so a place hears trains when the railway
 reached its *country*, not when a list mentions a station there.
3. **J4's air is derived from the same atlas plus population.** `WaysWorks` can only ever be a local
 amplifier, never a baseline - **Beijing and Rome are flat zero across five centuries**, which
 would give Victorian Birmingham smoke and Ming Beijing clean air, precisely backwards.
4. **J3 is a reading and says so**, because the chain stops dead at 1500.
5. **E13 owns letters and inscriptions as objects; J3 owns signs on walls.** They share one script
 lookup and did not build it twice.
6. **The stub is replaced, not extended.**
7. **No new data pack unless a part proves it cannot be derived.** Two did not (J4, E13); two did
 (J2, J3), and both are marked *estimated* throughout.

### Part 2 - J2: the soundscape (20 checks)

`HistoricalAudioDirector` now asks `Soundscape`, which answers from the place, and **it has stopped
printing chat messages** - the player did not ask, and the old one announced a guess as though it
were a fact. 27 sounds in four layers (ground 2, crowd 3, voice 16, machine 6), each with the faith
or the technology that puts it there and the time of day it belongs to.

The one invariant worth keeping: **1,818 place-years where the mod knows a faith, and 0 silent.**

### Part 3 - J3: signs and inscriptions in local scripts (18 checks)

40 scripts over 17 areas, and 11 kinds of sign. The check that matters: the obvious chain answers
**"Aymara in the Latin alphabet" at Cuzco in 1400**, a century before any alphabet reached Peru,
because `scriptOf` falls back to "the Latin alphabet" for 55 languages with no year bound. The
script of a place is now gated on **whether writing has reached it**, from the technology atlas.

### Part 4 - J4: sky and air (14 checks)

**No data pack, and deliberately so** - everything is derived, so a pack would be a second place for
the same numbers to drift apart. Smoke from the atlas per country and dated, dust and haze from the
climate register's own periods.

**The measurement that made severity matter**: taking the first active climate period naively puts
**100% of the world in drought from 2000 BC to AD 1800**, because the **Meghalayan stage** - a real
geological stage, 2250 BC to 1850 AD - is recorded with `radiusKm = 0`, which the register reads as
*everywhere*, at **severity 1**. Tambora is 8 and the volcanic winter of 536 is 9. The gate at
severity 5 is the difference between a geological background and the worst year to be alive.

**A defect the probe caught**: the first run reported **0 of 3,120 place-years with clear air** - the
whole world smoky from the Bronze Age including uninhabited steppe - because `fired_brick`, `steel`
and `iron` are *craft* techs with a share of 1.0 and Bronze-Age arrival dates. Two fixes: **no
people means no smoke at all**, and those weights cut to 0.05/0.04/0.04. A village with a smith is
not a smoky village.

### Part 5 - E13: writing as objects (32 checks)

The book existed in thirteen forms by place and year (step 22). What was missing was **the letter
and the inscription** - most of what writing has actually been for.

**The fact the part hangs on: before the post, a letter is not sent.** You gave it to somebody who
was going that way. Measured: **the post reaches Germany 1505, Britain 1635, Kaifeng 1898** (the
Royal Mail and the Imperial Post Office, both right) - and note the raw table says Germany *1490*,
but `arrivalAt` spreads a technology out from where it first appears, so a check written against
1490 fails. Whole-world by year: **1300 → 0 of 240 places can post; 1800 → 47; 1900 → 169.**

```
Florence to Avignon 1300 A letter of a sheet of parchment, written in the Latin alphabet with a
 pen cut from a quill. ... There is no post here in 1300: it goes with
 whoever is going that way, and arrives in about 2 months, if it arrives.
 Hardly anyone at the far end can read - about 3% - so it will be read
 aloud to whoever it is for.
London to Manchester 1850 ... by railway, and arrives the next day. About 99% of people at the far
 end could read it themselves.
Kaifeng to Hangzhou 1000 ... a sheet of paper, written in Chinese characters with a brush.
Uruk to Lagash −2400 ... a clay tablet, written in cuneiform with a reed stylus - pressed into
 the wet clay. It is an envelope of clay, with the same seal rolled across
 the join.
Cuzco 1400 Nothing is cut here that can be read: what is known is remembered and told.
```

**Three defects the probe caught.** (1) **A letter cannot go down a wire** - `NewsTravel.fastest`
answers "the telegraph, one day" for 1900, right about news and wrong about an object; 3,120
place-years swept, 0 by telegraph. (2) **The brush is a fact about the script, not the material** - 
paper reached China in 105, so a Kaifeng letter of 1000 is on paper and the material ladder then
hands the writer a quill; Chinese characters are brushed, so the script is asked first. (3) London
to Manchester in 1850 arrived **"within the hour"**, because the railway covers 260 km in a morning;
a letter is collected, sorted and delivered, and now costs a day of handling.

**Bronze is deliberately not modelled.** Cast inscriptions are real - the Roman bronze tablet, the
Shang ritual vessel - but no register says which monument was cast and which was carved, and every
rule tried that put bronze in ancient Rome also put a bronze tablet in **Paris in 1900**. A guess
that is right twice and wrong everywhere else is worse than the plain answer. There is a check named
after that decision.

### Part 6 - wiring, and a bug found while wiring

**`/ee signs`, `/ee air`, `/ee letter`** now reach all three systems. `/ee letter at <lat> <lon>
<year> to <lat> <lon> [sea]` is the one that shows the post moving.

Wiring them turned up a bug that was not step 43's: **`parsePlace`** - the shared helper every
`/ee` place command uses - fell back to `player.getX()` and `player.getZ()`, handing **block
coordinates to systems expecting degrees**. Every command that fell back to "where you are standing"
 - **`/ee law`, `/ee justice`, `/ee oath`, `/ee border` from step 42 included** - was asking about a
patch of ocean near 0,0. It now converts through `TerraCoordinateHelper.toGeo`, which returns
`[longitude, latitude]`.

**Both step-43 packs were mis-registered.** `soundscape.json.gz` and `scripts.json.gz` had no entry
in `build_manifest.py` and were falling through to the catch-all, listed as *"engine settings and
starting tables"* - and the soundscape was **counted as 30 faiths**, its longest list, rather than
27 sounds. Both now have real entries with their builders and row keys.

### What this step does not do

- **J2 plays note-block sounds.** The mod has no audio assets and this step cannot record any. What
 was fixed is **which** sound and **why**, which was nonsense; the harp is still a harp.
- **J3 before 1500 is a reading**, gated on the technology atlas and flagged `fromTable`.
- **J4's smoke weights are a choice, not a measurement** - no source states that Manchester's sky
 was a particular shade in 1850. *Whether* the cement works had reached Manchester is measured;
 how much smoke it made is this register's reading.
- **The quill covers the steel nib.** Nibs replaced quills from about 1830 and the register does not
 distinguish them, so a letter of 1850 is described as quill-written a generation late.
- **1840** (the Penny Black, and with it the gummed envelope) is the one date read from nowhere.
- **Rulers' own couriers are not modelled.** Kings kept riders long before any public post.
- **`/ee check all` has no step-43 section.** The steps' own probes run outside Minecraft.
- **`tools/gradle_compile.sh` has still never run.** Every step-43 Java file is proven only by
 `syntax_gate.sh` and by probes that compile the real registers against a bare JDK 17. **The mod
 has not been built against real Minecraft jars since step 41** - three steps ago now.

### Files

`worldfill/soundscape_table.py` + `build_soundscape.py` (J2), `script_table.py` +
`build_scripts.py` (J3). The packs: `history/soundscape.json.gz` (5.6 KB, **estimated**) and
`history/scripts.json.gz` (5.5 KB, **estimated**) - both now registered in `manifest.json` and
`DATA_CREDITS.md`. **J4 and E13 ship no pack at all**: both derive everything.

Mod side, none of which imports Minecraft unless it has to: `civilization/Soundscape.java` (J2),
`civilization/Signs.java` (J3), `civilization/Air.java` (J4) and `news/Writings.java` (E13).
`carto/HistoricalAudioDirector.java` was **rewritten**, not extended.

Probes: `probe_step43.sh` (20 checks), `probe_step43b.sh` (18), `probe_step43c.sh` (14),
`probe_step43d.sh` (32) - **84 checks, 0 problems.**

Commands: `/ee signs`, `/ee air`, `/ee letter`.

## Step 44 - Goods, prices, food, a working economy (E4, E5, E6, D16, E19) - done in turn 183

Five systems, nine parts, and **the largest step so far**: 289,117 probe checks across six probes
and six new or rewritten mod classes. What the five have in common is that the mod knew the *nouns*
of an economy and none of the *verbs* - it had goods, money, foods, shops and jobs, and no price
that moved, no chain of making, no meal, no workshop and no loan.

The survey measured what was there before deciding anything, and it is worth repeating because it
explains the shape of the step. **Half of E4 was already real and half was a stub.** Wages were
there and good - `money_table.json` carries **401 currencies each with a labourer's day's pay by
year** - and the price *level* was there too, because `culture.json.gz` carries the **Maddison
Project Database 2023** for 230 countries. **Prices were not there at all**: `CommodityPricingEngine`
was **twelve hardcoded numbers**, so silk was 28 in Chang'an in 800 and 28 in Amsterdam in 1650.
**E5 was one third done** (parts A and B), **E6 had foods but no diet**, **D16 had sellers, buyers
and workers but no makers**, and **E19 was nothing whatsoever**.

### Part 2 - E4: prices and shortages (32 checks)

`history/prices.json.gz` (658 KB) + `money/Prices.java` + `/ee prices`. **773 measured price
series - 193 markets × 89 goods, 115,474 observations, 965–1914**, each in grams of silver. Source:
**Allen–Unger, DANS doi 10.17026/dans-zsu-xavf** (CC BY-NC 4.0, flagged non-commercial).

Three things had to be built before a number could be read, and two of them are worth the telling:

- **The markets.** The database names 193 markets and gives no coordinates. Matching the names
 against the mod's own 30,151-town gazetteer was **tried and thrown away**, because it is wrong in
 the worst direction - three centuries of colonial naming put **Burgos, Valencia, Zaragoza and
 Valladolid in the Philippines**, Andalusia in **Alabama**, Navarre and Oviedo in **Florida**.
 All 193 are placed by hand.
- **The measures.** Guessing was tried first and was badly wrong: wheat is reported **21,470 times
 by the litre and 1,323 by the kilogram**, and the hand table said kilogram, so the first build
 kept 6% of the best-covered commodity in the database. The builder now counts the dominant measure
 and reports every disagreement (12 commodities were wrong).
- **Grain had to be converted or one measure loses a subcontinent.** Europe measured grain **by the
 litre** and British India **by the kilogram**, so picking litres **deleted every Indian market**.
 Grain is now converted at a bulk density (wheat 0.77 kg/L, oats 0.41, rice 0.75); the densities
 ship inside the pack, the **47,307 converted observations are declared**, and keeping rose to 92.5%.

**Shortages are derived, not listed** (`crises` held 26, all 1873 or later, so the mod knew 1929 and
nothing of the Great Famine): **1,225 shortage years over 141 markets**, read as grain costing at
least 1.8× the years around it. The Great Famine 1315–17 at 2.75×; **the Black Death makes grain
cheaper**, a third fewer buyers; the 1690s Paris 4.3×; the Great Winter of 1709 Douai 7.2×; the
Kipper und Wipper inflation, Leipzig barley **10.5× in 1622**. Worst single reading: **Wallachia
1829, millet at 15.5×**.

**Deliberately left out: `Slave`.** 179 observations, measured in *Individual Adult Male*. The source
prices human beings; they are not in the pack and the probe asserts it.

### Part 3 - E5 part C: growing the product list (31 checks)

132 → **529 products**. **No part C year was written by hand**: 268 × 17 = 4,556 hand-written years
is not honestly writable. Part C writes what each product *is* and derives every date - 
**397 new products, 72 from a technology, 35 from a mineral, 290 from a parent**. The mineral
register (`minerals.json.gz`, 143,302 USGS sites) was **tried and rejected**: it records where a
mineral has been *mapped by a survey*, not where it exists, so Cornwall's tin came out 1900 and
Cyprus's copper came out 1970.

### Part 4 - E5 part D: chains (30 checks)

`economy/chains.json.gz` - what each thing is made **from**, which is what was missing entirely. The
rule that took longest: **inputs are alternatives, not a list**, so bread needs grain *and* fuel,
and the fuel may be wood or charcoal - otherwise a bakery in the Tigris valley, where there is no
wood, cannot bake at all.

### Part 5 - E5 part E: disruptions (29 checks)

`economy/substitutes.json.gz` (38 products, 89 substitutes) + `money/Shortages.java` + `/ee shortage`.
The part where the mod's own registers first join: Hyderabad 1630 *the Deccan famine*; Memphis
−2200 *the 4.2-kiloyear event*; Tenochtitlan 1450 *the famine of One Rabbit*; Samarkand 1600 with
the road shut, **sugar 0.000 against wild food 0.760**.

### Part 6 - E6: food and drink by era and region (279,927 checks)

Two halves. **(1) The register the step had been missing.** **Khoury et al. 2016** had never been
fetched - it is why part C dropped the fruit and vegetables. Table S1 is 150 crops × 23 regions of
diversity. **Australia is the one area with no crops at all and that is a finding, not a gap.**
**Ten crops the atlas could not place now join it** - apples, citrus, dates, olives, peas, soybeans,
sweet potatoes, tomatoes, pineapples, palm oil - at **539 products, 0 problems**.

**(2) The diet.** Every food gets a **seat at the table** (grain, pulse, greens, fruit, protein, fat,
sour, sweet, seasoning, drink, stimulant). **The ordering took four readings of the output**:
already named, then cultivated, then made here, then longest established. **Cultivated outranking
*made here* is deliberate and sounds backwards - a place that brings its grain in by boat still eats
grain, not acorns**; with *made here* first, every place in the world ate acorns, because every
register dates a gathered food from the beginning of the world. And **no farming floor on a *brought*
year**: the atlas says farming reaches Polynesia in 1521 and the sweet potato is measured in the Cook
Islands by 1210, so the floor was erasing one of the best-attested facts in the subject.

Rome now says *wheat, peas, olives, olive oil, wine*; Cusco *potatoes, tomatoes, chillies, cacao*;
and **Tahiti 1100 has no sweet potato while Tahiti 1300 does**, which is the Pacific crossing.

### Part 7 - D16: makers (9,003 checks)

`money/Workshop.java` + `/ee workshop`. **There are no makers: no workplace turns an input into an
output.** Every product already carries `days`, what it is worth in **days of a worker's time**, and
read back to front that is a throughput. **21 products carry a measured value**; the rest take the
median of their own kind of work where that kind has three or more measurements - **craft** (15
measurements, 0.25 days) and **farming** (3, 0.08 days). **372 of 539 rated, 167 unrated and saying
so.**

**The thing that had to be given up:** no register says how the potters of a city divide between pots
and bricks - the 23 job tables stop at twelve kinds of work. Dividing the hands equally was tried
and is a lie in both directions: **353 products are made in South Asia in 1600**, so five hundred
craftsmen were each simultaneously a seventh of a baker, a seventh of a potter and a seventh of a
glassmaker. What ships instead is what is measured: `perHead`, `hands`, `rivals` and `ceiling()`, the
last offered as **the upper bound it is and labelled as one**.

Tenochtitlan 1500 has **no bread and brews from maize**; **Lagos 1700 is held back by a closed road**;
**Hyderabad 1600 is short of wheat because of Huaynaputina** - checked rather than assumed, because
the first read of that output looked like a bug, there being no disaster a person would name in
Hyderabad in 1600, and the register scores the Peru eruption at 0.30 on the land.

### Part 8 - E19: banking and credit (167 checks)

The survey came back **empty four ways**: no file mentions interest, usury, loan or credit;
`money_table.json` is money *changing*, not lending; `beliefs.json.gz` has no usury entry and
`foundation_religions.json` is two stub rows; and of 620 rows in `law.json.gz` exactly four touch
debt. **There is no bank, no lender, no loan, no interest and no bill of exchange anywhere in the
mod** - the money-changer changes coin at a fee, which is a bank's oldest function with the lending
left out.

So E19 ships as a hand-written **register**: `economy/credit.json.gz`, **29 rows, −3500 to 1950**.
Each row carries a **mark**: 12 **recorded** (a document states the rate), 9 **measured** (read off
many records - the best is the Ottoman cash waqf, where **1,559 of 1,563 Bursa waqfs returned 9–12%
between 1555 and 1823** and a sultan capped the effective rate at 11.5% by *fetva*), 8 **estimated**.
The mark is shown to the player.

**This is not a European table.** Mesopotamia, Egypt, Athens, Rome, Byzantium, Tang and Song China,
the Ottomans, Mughal India, colonial India, Italy, England, Holland and the United States are joined
by **West Africa and the Andes**, and two rules hold throughout:

- **An absence is recorded as a fact rather than filled with a guess.** 5 rows carry no rate at all.
 Pre-colonial West Africa had money, savings, deposit and credit without a *price* for credit.
 **The Inca kept the most careful accounts in the Americas and had no money whatsoever.** A player
 who asks the rate in Cusco in 1500 is told there was not one.
- **A ban on interest is not the absence of credit.** Where `lawful` is false, lending was
 restructured, not abandoned: the cash waqf, *murabaha* and *hiyal*, the Italian bill of exchange,
 the Venetian funded debt, Datini's discretionary deposits, Jewish lending in Angevin England.

**Reading the probe output rather than watching for a green line caught four real defects**, which is
the whole argument for printing checks: Sumer's grain maximum was unreportable (silver at 20%
overlapped grain at 33⅓% and list order hid the grain); **Agra quoted the hundi bill discount of
1–8% instead of the ṣarrāf's loan rate of 12–30%**, fixed with a kind tier and a new `bill` kind;
*Christians* was being decapitalised to *christians*; and **Hyderabad 1900 was silent**, fixed with
two colonial-India rows from **Keynes, *Indian Currency and Finance* (1913)** - the bazaar rate
stopping at 7–8% while the Presidency Banks rose to 12 - and the Banking Enquiry's 12–24%.

### What this step does not do

- **Nothing in the economy makes a loan.** E19 says what credit *cost*; it does not lend, and joining
 the register to `MarketLedger` is work this step does not do.
- **The mod still cannot join a silver price to a day's pay.** It knows a day's pay in local money
 and a price in silver, and nothing connects them. That is the remaining half of *prices and wages*,
 and it needs the money table to carry a silver weight that only 6 of its 401 currencies have.
- **`CommodityPricingEngine` still has its twelve numbers.** Wiring it was held until part 3 settled
 what the commodities are, rather than joining the two together twice.
- **Allen–Unger stops in 1914 and is European and Indian.** There is no market within 500 km of
 Hyderabad (nearest Allahabad, 960 km), which `/ee prices` says rather than guessing. Some of the
 source's own conversions are bad - **Tuscany's wheat is 28× the English price** - so every series
 also carries an index against its own time, and 80 of 773 are marked `suspect`.
- **167 of 539 products have no workshop rate.** An economy with no smiths and no herds is not a
 working economy, and that is the honest size of what is left of D16.
- **`rivals` is a count, not a share**, so `ceiling()` is a bound and `perHead` is the number to
 trust. `days` is a *value*, not measured time spent.
- **17 areas cannot separate the rice south from the millet north.** Guangzhou in 1200 is told
 *millet, or buckwheat, or rice* - true of East Asia, wrong for Canton.
- **Only 38 of 529 products have a substitute.** **Cusco, Sydney and prehistoric Siberia have no
 recorded disruption at all** and are left silent rather than invented.
- **A siege still starves nobody**: the 2,397 wars carry `effect: note` and contribute nothing.
- **Credit reaches 4 of 42 real cities in 1500 BC and 27 of 42 in 1600 AD**, and where nothing
 reaches the mod declines to answer. **Sub-Saharan Africa outside the Yoruba row and the whole of
 Southeast Asia have nothing** - the gap that is neither excusable nor yet filled.
- **`/ee shortage`, `/ee diet`, `/ee workshop` and `/ee credit` are syntax-checked only.**
 `EternalEngineCommands` cannot be compiled without the Minecraft jars, so the command wiring is
 the one part of this step that has never run. **`tools/gradle_compile.sh` has still never run** - 
 the mod has not been built against real Minecraft jars since step 41.

### Files

Python: `money_world.py`, `build_prices.py` (E4), `build_products_c.py` + `product_derivation.py` +
`country_areas.py` (part C), `build_chains.py` (part D), `build_substitutes.py` (part E),
`crop_origins.py` + `diet_roles.py` (E6), `credit_table.py` + `build_credit.py` (E19).

Packs: `history/prices.json.gz` (658 KB), `economy/products_world.json`, `economy/chains.json.gz`,
`economy/substitutes.json.gz`, `food/seats.json.gz` (1.4 KB), `economy/credit.json.gz` (6.6 KB) - 
all registered in `manifest.json` and `DATA_CREDITS.md`. **D16 ships no pack**; everything is
derived at runtime from packs that already ship.

Mod side: `money/Prices.java` (E4), `money/Shortages.java` (part E), `money/Diet.java` (E6),
`money/Workshop.java` (D16), `money/Credit.java` (E19).

Probes: `probe_step44.sh` (32, needs a re-fetch), `probe_step44c.sh` (31), `probe_step44d.sh` (30),
`probe_step44e.sh` (29), `probe_step44f.sh` (279,927), `probe_step44g.sh` (9,003),
`probe_step44h.sh` (167) - **289,117 checks, 0 problems.**

Commands: `/ee prices`, `/ee shortage`, `/ee diet`, `/ee workshop`, `/ee credit`.

Repairs made along the way: `probe_step43b/43c/43d` were failing to compile (`ProductAtlas` now
reaches `Jobs`); all three now pass. `probe_step42b` and `probe_step44` still fail **only** because
their downloaded source data is not in the persisted workspace.

Next: step 45 - weapons and army gear (E9, C19, A13), which per the standing instruction
**defers the weapons themselves to other mods** - what this plan can do is the armouring,
the supply of an army and the gear it carries, not new arms.

## Step 45 - Weapons and army gear (E9, C19, A13) - done in turn 189

Three systems, seven parts, **3,294 probe checks** over five probes, and one standing instruction
that shapes all of it: **vehicles and weapons defer to other mods**. The mod ships **no new
weapons**. What this step builds is the armouring, the supply of an army, the gear it carries, and
 - in parts 5 and 6 - the machinery that *resolves* weapons to other mods' items and refuses them
before their year.

The survey (part 1) found something unusual: **most of the raw material was already in the mod and
every join was missing.** The product atlas already carried a "weapons and armour" family of **33
dated products**; the technology atlas already knew when bronze, iron and gunpowder reached 258
countries; `RegimentCohort` already equipped soldiers - with `Items.IRON_SWORD`, in every century,
on every continent. Step 40 closed its own notes with *"Weapons themselves are D22 / step 45 - 
this step reads what an army was carrying, it does not write it."* **Step 45 had been promised
twice by earlier steps.**

### Part 2 - E9 A: the armoury (94 checks)

`war/armory.json.gz` (5,431 bytes) + `war/Armoury.java`. **24 kinds**, each with the year it
reaches each of 17 areas, when it leaves, where it **never** existed and why, what retires it, and
a vanilla item that stands for it.

Dates come from **three sources, and the split is the interesting part**: 11 kinds hand-written
per area, 13 read from the technology atlas (258 countries, spread-modelled), the rest from the
product atlas. The melee family is written by hand because part C derived products from *parents*,
and for weapons the parents are **materials** - a sword whose parent is `bronze_weapons` inherits
bronze's date, which is not a sword's date.

**Three findings are recorded rather than smoothed over.** The **bow was never invented in
Australia** - Australian woods test as sub-optimal for self-bows, a spear from a woomera carries
four times the kinetic energy of an arrow, and the diffusion ran *the other way*, the spearthrower
spreading to Torres Strait Islanders who *had* the bow. **No metal sword in the Americas before
1492**: the macuahuitl is a club with stone blades, which is not the same thing. And **no war
chariots in West Africa**, because the horse does not survive the tsetse belt.

4,500 place-years sampled: **0 with nothing, 3 to 16 kinds per place.**

### Part 3 - E9 B: the five ways, and the weapon laws (200 checks)

Two packs, **deliberately kept apart because they are facts about different things**:

| | `war/arms.json.gz` | `history/law.json.gz` kind 5 |
|---|---|---|
| asks | *how did an army come by its weapons?* | *what does the law say about who may have one?* |
| keyed by | **area and year** (a civilisation) | **the polity that rules the square** (a state) |
| rows | **18** | **13** of 633, over 240 polities |

Supply is a fact about warfare; a weapon law is a fact about a government. A merged table would
have to pick one granularity and lose the other.

The five ways are **issued, bring, buy, take, gift** - plus a sixth that is not a way of getting a
weapon but is the law that matters most of the time: **carry**. It is there because **keeping and
carrying are different laws in every age**, and a register with one flag instead of six misreads
both. The 1328 Statute of Northampton forbade *carrying*; nothing forbade *keeping*.

### Part 4 - C19: units and ranks (142 checks)

`war/units.json.gz` (10,685 bytes) + `war/Units.java`. **15 systems, 69 rungs, 17 areas, 10 named
to a polity**, verified against the mod's own 1,581-name ruler register.

The organising finding: **an army is counted in whatever base the society counts in.** Ten - 
Mongol, Inca, Ming, and the Inca's is also a tax roll, so the regiment and the census are the same
list. Twenty - Aztec, because Nahuatl counts in twenties and the *xiquipilli* of 8,000 is also the
cacao-bean pouch. Three - the Indian epics, whose *patti* is 1 elephant + 1 chariot + 3 horse +
5 foot. Two - Sparta, doubling 36 → 72 → 144 → 576. Eight - **Rome, whose century of eighty kept
the name of a levy of a hundred.**

And **no number at all for the Zulu**, whose *amabutho* count by **birth year**: a man belongs to
his age set's regiment, lives in its ikhanda, wears its shield colours, and may not marry until
the king releases the whole set. *"Rome numbers you; the Zulu date you"* - `rungFor(500)` correctly
returns nothing for them. Two systems rank **men, not units**: the Mughal mansabdari, whose *mansab*
fixes precedence and cavalry obligation and confers **no office**, and the Aztec orders, whose rank
is a count of captives. The Ottoman ranks are a kitchen: the *çorbacı* is the **soup-maker**.

**780 of 867 area-years fall to the default war party** - a gap in the register, not a claim that
South-East Asia or the Horn of Africa had no armies.

### Part 5 - A13 a: the item resolver (409 checks)

`war/weapon_items.json.gz` (5,914 bytes) + `war/WeaponItems.java`. This is where *"weapons defer to
other mods"* becomes code. **9 optional mods** named by modid with licence and dependencies, **20
item rows**, **2 ammunition rows**, **163 name tokens**, local names for **15 areas**.

Three rules:

1. **A tag beats an id**, wherever a mod publishes one. Spartan Weaponry's own wiki records that
 its registry names changed between 1.16.5 and 1.19.2 and broke datapacks that hard-coded them.
 `#spartanweaponry:spears` survives a rename.
2. **An unknown item is guessed from its name, and the guess is logged.** No register can list
 every item of every weapon mod, and a wrong guess is visible and fixable in a way a missing
 weapon is not.
3. **A missing weapon is never an error.** With no weapon mod installed every kind falls back to
 the vanilla item the armoury already names on all 24 kinds - **read, not duplicated**. The
 builder asserts the absence.

**The gap no mod fills:** **no Indian weapons exist for Java 1.20.1** (the only talwar, pata and
tabar is a Bedrock add-on, unusable) and **no matchlock mod exists at all**. So a talwar in 1650
Agra is a modded sabre **carrying the name** talwar. The local-name table is the honest fix for a
gap no mod fills, and cheaper than waiting for someone to model one.

### Part 6 - A13 b: the year gate and the role kit (2,427 checks)

`war/WarGear.java` is the whole decision layer and **touches no Minecraft** - which is why 2,427
checks run in four seconds with no classpath. `WarGearStacks` and `WeaponYearGate` do the wiring.

Part 6 **derives nothing that already exists**: the armoury already knew when each kind reaches
each place, when it leaves, where it never existed and what retires what. Part 6 composes that with
the resolver, and closes the one gap neither did alone - **judging an item by the year**. A known
mod item is the kind its row says; a vanilla item is every kind it stands for; anything else is
**guessed**, which is what stops an *unlisted* mod escaping the rules, so `mysterymod:toradar` is
refused in 1400 Agra and allowed in 1750.

**A placeholder cannot be gated to one kind.** `minecraft:iron_sword` stands for **eight** kinds at
once, so the gate takes the most permissive reading - and in pre-contact Australia all eight are
absent, so **the iron sword is refused there**, which is right: Australia had no metal at all. The
club and the spear are allowed, and that is what an Australian fighter gets. **The rules bite on
mod items, which is exactly where they need to.**

**The eighteen hard-coded items are gone.** `RegimentCohort` (8 sites), `RoyalCourtManager`,
`CaravanEntityGroup`, `BanditAmbushEngine`, `MerchantShipConvoy` and `ChronoNexusCampaignEngine`
now all ask one question: *weapon for (place, year, role)*. A Praetorian Guard in Gaul in 200 BC
is no longer a man in an iron helmet.

**Forge has no "cancel this craft" event** - `ItemCraftedEvent` fires *after* the item is taken and
no hook can refuse a craft. So the gate does the two things that are possible: it **empties the
result slot** while it holds an item that has not reached this place, and it **shuts the gun mods'
own benches** until the rifle's year - **AD 1866 in Europe**. And it **never takes items away**:
someone given a musket by an admin, creative mode or another mod keeps it. The gate governs the
world's soldiers and the world's crafting, not the player's inventory.

### What this step does not do

- **The mod ships no weapons.** Part 5 names nine optional mods; with none installed every kind
 falls back to vanilla. That is the standing instruction honoured, not a limitation worked around.
- **Only 6 of 20 item rows are recorded.** Musket Mod's five come from its own source; the sixth is
 Spartan Weaponry's spear tag. Every other row is `estimated` from a mod's naming pattern and
 **says so in the pack**. TaCZ's row is a placeholder, because its guns come from installed gun
 packs and no single id is safe.
- **The wiring half is syntax-gated only.** `WarGearStacks`, `WeaponYearGate` and the six edited
 call sites cannot be compiled here - 100 unresolved symbols without the Minecraft jars. Their
 *logic* is in `WarGear` and fully tested; their *plumbing* has never run.
 **`tools/gradle_compile.sh` has still never run** - the mod has not been built against real
 Minecraft jars since step 41.
- **Ammunition obeys the year rules only for Musket Mod.** Each gun mod has its own, and only the
 cartridge is recorded.
- **A tie is broken by later arrival.** Where two weapons coexisted - bow and crossbow in 1200 - 
 the register does not claim which predominated, and part 6 does not invent an answer.
- **780 of 867 area-years fall to the default war party** (part 4), and **sub-Saharan Africa
 outside the savannah row has no unit system at all**.
- **Nothing in this step joins the armoury to the armies in the field.** Step 40's `Sides`,
 `Battles` and `Morale` do not yet read it; D10 still carries its own weapon bands.
- **`CommodityPricingEngine` still has its twelve numbers** (step 44's debt, unchanged here).
- **The Ottoman *dhimmi* disarmament claim remains UNVERIFIED** and is not in the law pack.

### Files

Python: `armory_table.py` + `build_armory.py` (part 2), `arms_ways_table.py` + `build_arms.py` and
`weapon_law_table.py` + `build_law.py` (part 3), `unit_table.py` + `build_units.py` (part 4),
`weapon_items_table.py` + `build_weapon_items.py` (part 5).

Packs: `war/armory.json.gz` (5,431 B), `war/arms.json.gz` (5,617 B),
`history/law.json.gz` kind 5 (26,274 B, 13 of 633 rows), `war/units.json.gz` (10,685 B),
`war/weapon_items.json.gz` (5,914 B) - all registered in `manifest.json` and `DATA_CREDITS.md`.

Mod side: `war/Armoury.java`, `war/Arms.java`, `war/Units.java`, `war/WeaponItems.java`,
`war/WarGear.java` (pure), `war/WarGearStacks.java`, `war/WeaponYearGate.java`,
`compatibility/ModCompatibilityChecker.java` (14 new ids).

Probes: `probe_step45a.sh` (94), `probe_step45b.sh` (200), `probe_step45c.sh` (142),
`probe_step45d.sh` (409), `probe_step45e.sh` (2,427) - **3,294 checks, 0 failed.**

Commands: `/ee check` gains a weapons line (part 6).

## Step 46 - Vehicles, traffic, working animals (E10, E11, D14, A13) - done in turn 196

Four systems, seven parts, **2,081 probe checks** over seven probes, and the same standing
instruction that shaped step 45: **vehicles defer to other mods.** The mod ships **no vehicle
models**. What this step builds is *which* vehicle or animal is right for a place and year, the
traffic on the route, the working animals that draw it, the law of the road, and the resolver that
finds a vehicle in whatever mods are installed.

The survey found the same shape step 45 found: **most of the material was already here and the joins
were missing.** `RegimentCohort` equipped soldiers with a hardcoded iron sword; `LogisticsManager`
spawned **two to four donkeys for every caravan, in every era, on every continent** - including the
Andes, which had llamas from 4000 BC, and Australia, where the donkey arrives in 1788. That is step
45's eighteen hardcoded swords over again, and it is fixed the same way: one lookup for (place,
year).

### Part 2 - D14 A: the working animals (210 checks)

`economy/animals.json.gz` + `vehicle/WorkingAnimals.java`. **12 animals**, each with the year it
reaches each of 17 areas, what it does (port, pack, ride, pull, plough), how much it carries and how
far, and **where it never was**.

The dates are **read from the products atlas**, not rewritten - it already dated these animals in all
17 areas - and the register adds the three things it does not carry: the role, the load, and the
refusals. **Two corrections to the atlas are made and recorded**: reindeer were dated −2000 in West
Africa by a child inheriting a parent's date, and donkeys shared a date with horses in every area,
which cannot be right because the donkey is African and the horse is not.

**The register's sharpest row is the one with no entity.** Below the tsetse belt no beast survives,
so the carrier is a **human porter** - and a porter is a person, not a mob you spawn beside a cart.
Four working animals have no Minecraft entity at all: **ox, elephant, reindeer, water buffalo.**

### Part 3 - E11 A: the vehicles (1,405 checks)

`economy/vehicles.json.gz` + `vehicle/Vehicles.java`. **32 vehicles over six mediums**: foot, road,
rail, water inland, water sea, air. Each carries the year it reaches each area, what it **needs**
(water, a road, a dockyard, a railbed), how fast, how much, and what it **replaces**.

**The vehicle is not the point; the medium is.** A cart and a lorry are the same idea at two
`needs`. And the register's most useful column is `supersedes`: the horse did not replace the ox, it
replaced *nothing*, and the ox was still ploughing in 1950.

### Part 4 - E11 B: traffic (90 checks)

`economy/traffic.json.gz` + `trade/Traffic.java`. **How many go past, how heavy, and how far a good
can travel before it is worth more than the journey.**

**The model is one fraction.** Breaking distance = value per kg ÷ freight per kg-km. Wheat at 10
denarii a kilo reaches **286 km by road, 2,941 by river, 14,925 by sea**; white silk at 36,697
denarii a kilo has **no leash at all** at 1,048,486 km. That single ratio explains why the Roman
world moved grain on water and purple on foot.

And it agrees with a survey **1,400 years away to within 3%**: free river transport cost **road ÷
10.00** in England in 1700 (Bogart) and **road ÷ 10.29** in Diocletian's Edict of 301.

### Part 5 - E10 B: the law of the road (52 checks)

`history/law.json.gz` kind 7 + `LawRegister.roadLawsAt` / `roadClosedAt`. **22 rows over 10
jurisdictions and 9 shapes**, and the **first clean join in this project**: every row found its
polity, where step 45's unit ladder had missed Sparta and the Delhi Sultanate.

**A road is not a right of way, and almost never was.** The great Roman road system was a courier
service you could not ride on. Cologne had the **staple right**: you could be forbidden to *pass
through* without selling. The law of the road is always about **a class of person or a class of
vehicle**, which is exactly step 45's weapon laws wearing different clothes.

The nine shapes: `closed` (cursus publicus; the Inca road; the sekisho) · `toll` (the Rhine; the
turnpike; France 1790) · `forced` (the staple right) · `gauge` (the Qin axle; the US 1916 standard)
· `side` (keep-left, 1835) · `speed` (the red flag, 1865) · `hours` (Rome's daylight cart ban, which
is why Juvenal could not sleep) · `labour` (statute labour) · `ban` (Ming sedan chairs).

**One myth is refused:** that Roman ruts are the ancestor of standard gauge. The ruts at Pompeii are
1.32 to 1.47 m and the standard gauge is 1.435 m, which looks like proof and is coincidence.

### Part 6 - A13: the vehicle resolver (139 checks)

`economy/vehicle_mods.json.gz` + `vehicle/VehicleMods.java` + `VehicleModGate.java`. A13's whole line
is *"optional links; everything also works without them"*, which is a constraint on a feature and
imposes three duties. All three are kept:

1. **Never hand back nothing.** All 32 vehicles resolve to a mod, to a vanilla stand-in, or to a
 written reason there is neither. **11 take the third answer.**
2. **Never pretend a stand-in is the real thing.** A boat is not a ship and a minecart is not a
 cart, and every answer carries that flag.
3. **Never invent an id.** 5 providers are marked `read` (AstikorCarts Redux, MIT, its ids read from
 the mod's own DeferredRegisters), `content` (Immersive Vehicles and Create, whose ids live in JSON
 content packs, so they name **no id at all** and claim only vehicle *kinds*), or `vanilla`. A
 `content` provider that names an id fails the build.

Two of those mods ship a config list that is **exactly a question this step already answers**:
AstikorCarts' `pull_animals` and Small Ships' `dockyardBuildableShips`. So the step *reports* what
those lists should hold for a place and year through the mod's public surface, and does not edit
anyone's config. **Small Ships has no crafting recipes at all** - ships are built at a Dockyard - so
the gate refuses the Dockyard itself, the same shape as step 45's gun bench, and it distinguishes its
two refusals: **Paris in 1400 for want of water, Marseille in 3000 BC for want of years.**

### Part 7 - D14 B: herds, and the roads they made (124 checks)

`economy/herds.json.gz` + `vehicle/Herds.java`. Part 2 wrote its own limit down - *"herd animals are
out of scope... sheep, goats, pigs and poultry are not yet read as herds"* - and this part pays that
debt in the file where it was written. **28 herd rows over 15 animals and 13 areas, and 10 droves.**

**The finding reorders the subject: the herd is the missing reason for the road.**

| road | width | what sets it |
|---|---|---|
| Via Appia | 4 to 6 m | two carts passing |
| Chisholm Trail | ~200 m corridor | 1,500 to 2,500 cattle |
| **cañada real** | **75 m, by law** | a flock must walk **and eat** |

**A road you can eat is a different object from a road you can drive on.** A Roman road is two carts
wide; a Spanish cañada is 75 m wide because sheep spread out while they graze. The largest
road-building institution in early modern Europe was a **shepherds' guild**, moving 2.5 million
animals a year on foot. In this step's vocabulary a drove road is part 3's `foot` medium, part 5's
`forced` shape, and part 2's beasts **walking rather than pulling** - and the test is in the data:
`isDroveWidth` passes the cañada at 75 m and **fails the Indian bullock track at 6 m**, correctly,
because carts wore it.

Four claims are refused in the pack. The **giant medieval flock**: of the Mesta's 3,000 to 4,000
owners, two thirds of the migrating sheep were in flocks **under 100**. **Wool at the start**: the
first sheep were hair sheep and wool appears about 4000 BC. **The chicken at 8000 BC**: the 2022
PNAS reanalysis puts it at **1650 to 1250 BC at Ban Non Wat in Thailand**, and *not* on the Indian
subcontinent. And the herd as a countable thing: every figure is someone's tax roll.

The bison is the one herd in the register that **ended** - 30 to 60 million in 1800, and **1,091
counted by Hornaday in 1889** - and it is still gone in AD 3000, because the projection does not
restore what was destroyed.

The join to part 2 is the sharpest in the step: **six thousand years of herds in the Andes and no
draught animal.** `Herds.canPull("llama")` is false, so part 6's `pullAnimals("SAM", 1400)` contains
exactly one beast - **a dog** - because a dog can draw a cart and a llama cannot.

### The syntax gate was lying, and had been for five steps

Running it in part 6 reported "no syntax errors", and it had not looked at a single new file: the
gate carried a **fixed list of the ten files step 37 left behind**. Every "clean" report in parts 2
through 5 was a statement about ten old files. It now checks **every** `.java` file in one
invocation:

| | before | after |
|---|---|---|
| files | 10 | 428 |
| diagnostics | 100 (capped) | 4,246 |
| time | 42 s | 15 s |

Which retroactively validates parts 1 to 5, and they pass.

### Limits, stated

- **A `content`-pack provider is a promise, not an id.** A player with Immersive Vehicles gets "an id
 from a content pack" and no further help.
- **The gate polices the Dockyard, not the player.** A cog given by an admin sails in 3000 BC.
- **Create trains are not gated at all**: Create has a dozen front doors and none is the one a year
 gate should refuse.
- **Only 10 droves over 17 areas**, so `droveAt` returns null across most of the world rather than
 inventing a route.
- **Herd sizes are estimates from tax rolls** and the pack says so in its own refusals.
- **Fifteen animals have herd rows.** Geese, ducks, guinea fowl, guinea pigs, bees and silkworms do
 not.

Mod side: `vehicle/Vehicles.java`, `WorkingAnimals.java`, `Herds.java`, `VehicleMods.java`,
`VehicleModGate.java`, `trade/Traffic.java`, `civilization/LawRegister.java` (kind 7),
`clock/Projector.java`.
Probes: `probe_step46a.sh` (210), `46b` (1,405), `46c` (90), `46d` (52), `46e` (139), `46f` (124),
`46g` (61) - **2,081 checks, 0 failed.**


## The far end of the timeline: AD 3000, and the third mark

The world runs **3000 BC to AD 3000**. Every register in this project answers for every year in that
span, in every one of the 17 areas.

**The record does not run that far, and pretending otherwise would be the one lie this project
cannot afford.** The last year any source reaches is **AD 2026**. Everything after it is filled in by
projection, and a projection is dangerous precisely because it looks like data.

### The rule, in one line

> **A projected value must never be indistinguishable from a recorded one.**

Every number in this project carries a mark. Until step 46 there were **two**: `recorded` and
`estimated`. The future gets a **third** of its own, `projected`, and **the reader must show it**. A
player standing in Hyderabad in AD 2500 is told who ruled there on the last recorded day, told that
this is a projection, and told that nothing is recorded of the years between.

### What is projected, and what is never

Three things may be carried past the record, each for its own reason:

| carried | why | example |
|---|---|---|
| **Continuations** | a technology that arrived stays | the printing press is still in Europe in 2600 |
| **Computations** | the sky is calculated, not recorded, and is exact at any year | an eclipse in AD 2900 |
| **Persisting states** | the polity of the last recorded day goes on ruling | the state that held a square in 2026 holds it in 2600 |

Four things are **never** projected, and the code refuses them rather than defaulting:

- **no ruler, head of government, person or dynasty**;
- **no war, event, disaster**;
- **no price**;
- **no population figure past the last measured year.**

These are not "not yet implemented". `Projector.refusal(Kind, year)` returns the refusal, so a caller
cannot invent one by accident, and `Projector.mayCarry(Kind)` is `false` for all four.

### Where the mark lives, and why it is not a column in a pack

This is the design decision that took longest, and it is worth stating plainly:

> **A projection is a property of the ANSWER, not of the ROW.**

The row *"France is ruled by the Fifth Republic from 1958"* is a recorded fact and stays one
forever. The answer *"who rules France in 2600"* is a projection, and it is a projection only
because of the year it was asked about. Storing `projected` on the row would corrupt a true record;
storing it nowhere would let the answer pass as fact.

So the mark is attached where the answer is made, by `clock/Projector.java`, and every answer
carries a `phrase()` a reader can show:

 the press in AD 2600 is PROJECTED, from the last recorded year AD 2026: a technology that arrived stays

 AD 2600: no ruler or person is invented for a year past the record. The last recorded state is from AD 2026.

### The honest state of this, as of step 46

`Timeline` stated the rule in step 41 and **not one shipped data pack contained the word** until this
step. The rule was written down and never applied - the same failure as the syntax gate that watched
ten files, and the same lesson: **a policy nobody executes is a comment.**

What is now true:

- `clock/Timeline.java` owns the span, the line (`RECORDED_UNTIL`), the three marks, and `readAt`,
 which is the one place a projected year is read as the last recorded one.
- `clock/Projector.java` applies the mark to an answer, refuses the four kinds that must never be
 invented, and writes the refusal in words a player can read.
- `worldfill/probes/Step46Ad3000Probe.java`, **61 checks**, asserts both directions: what is carried
 says it is projected, and what is refused is refused at 2600 and still refused at 3000.
- `Herds` carries a second, harder rule that the general policy cannot express: **a kept herd is a
 continuable state and a destroyed wild herd is not.** Castile still has sheep in AD 3000; the bison
 is still gone, and `herdOf("bison", "NNA", 3000)` returns null rather than restoring what was
 killed.

What is still not done, and is written down here so it is not lost:

- **The mark is not yet shown in the in-game screens.** `Projector.phrase()` produces the sentence,
 but the HUD, the map tooltips and `/ee year` do not all call it yet. The command line is the only
 reader that does.
- **The packs store no projections at all, by design**, which means the projection is computed on
 every read rather than baked. That is correct but it has never been profiled against a caller that
 asks for many years at once.
- **`readAt` is a floor, not a forecast.** It says "the state of the last recorded day", which is the
 most defensible of the three carried kinds and the least interesting. Nothing in the mod models a
 trend into the future, and nothing should until there is a reason.

Next: step 47 - tools, what can be made when, clothes, animals and crops, wildlife and culture
(E7, E8, E12, E15, E17, E18, B5, B6, C15, E21, E22). It is the largest remaining step in phase 4 and
it inherits two registers this step built: part 2's working animals and part 7's herds are the half
of "animals and crops" that is about the animal rather than the field.

## Step 47 - Tools, what a year may use, clothes, wildlife, crops, healers, games, culture (E7, E8, E12, E15, E17, E18, B5, B6, C15, E21, E22) - done in turn 197

**Eleven systems, seven parts, 520 probe checks over nine probes.** The largest remaining step of
phase 4, and the one where the survey paid for itself more than in any step so far: **six of the
eleven systems already held their data and had no join**, one was listed in the plan as broken and
had already been fixed three steps earlier, and four were genuinely empty.

| system | what the plan asked | what actually happened |
|---|---|---|
| **E7** | tools and inventions as items | built: 27 tools over 8 families, 21 dated from the atlas, 6 written |
| **E8** | what a year may use | built: `real` / `myth` / `never`, because three kinds of impossible thing need three answers |
| **E22** | vanilla items and the era | built: 19 rows, 5 real, 4 myth, 10 never. **Decided in turns 73–81 and never written** |
| **E12** | clothes by era, region, class and job | the plan said "partly". **It was `modern` only, and everybody before 1945 was dressed in nothing** |
| **E21** | the player's own clothes | built: four levels, reports, never punishes |
| **B5** | wild animals by era | empty: the only wild animal anywhere was the bison. Built, 14 species |
| **B6** | crops by era | already true and no join: built the join, 26 rows |
| **E18** | animals and crops as items, as they spread | the same join, with the item on each row |
| **E15** | medicine and healers | the remedies were fixed in step 38; **the healers were missing entirely**. Built, 16 trades |
| **E17** | games and sports | "not yet" was right about the code and wrong about the data. Built, 21 games |
| **C15** | culture: clothes, food, music, games, customs, arts | five of six already lived somewhere; music and the arts did not. Built, 14 rows |

### Part 2 - E7: a tool's date is not its material's date (82 checks)

`economy/tools.json.gz` + `tools/Tools.java`. 27 tools, 8 families of work, all 17 areas.

**The rule the part exists to enforce** came out of a bug: the atlas derives a product from its
parent, and for tools the parent is a material, so a **microscope whose parent is glass became as old
as glass: 2500 BC in West Asia.** Step 46 found the same fault in reindeer and donkeys, which makes
three instances and therefore a class of error, and it is **fixed at the source**: the atlas now
derives microscopes from the telescope technology and dates them AD 1608. The register carries the
finer 1590 with the Janssen attribution and the warning that the attribution is a recollection given
sixty-five years after the fact.

Two of the seven things the plan names had no row anywhere, and the atlas has **woodblock prints but
no press and no loom of any kind**. The treadle loom is the sharper addition: it is expensive, so it
moved weaving out of the household into guilds, and the guilds excluded women. **A tool can reorganise
who is allowed to work.**

### Part 3 - E8 and E22: what a year may use (55 checks)

`economy/anachronisms.json.gz` + `tools/Anachronisms.java`. **Three kinds of impossible thing, three
answers:**

- **`real`** - a real thing existed and the game's version is just better: allowed from its year.
- **`myth`** - people believed it, so it existed as a belief and not as a function: **allowed and
 renamed**, because the object is real and the power is not.
- **`never`** - nothing like it has existed at any date: locked in a strict world, and allowed only
 for a time traveller, who is then seen carrying it.

Treating all of it as fantasy to delete removes the game; treating all of it as allowed makes the year
meaningless. **The middle kind is what turns a blacklist into a translation**: alchemy is real history,
so a brewing stand in 1300 is "an alchemist's bench" and the enchanting table is "a shrine, and a man
who says the words". 5 allowed, 4 renamed, 10 locked. The diamond is the sharpest: a real gem traded
from India by 300 BC that nobody made a tool of for two thousand years because it is brittle, so
**the gem is allowed and the pickaxe is not**.

### Part 4 - E12 and E21: the period wardrobe (73 + 29 = 102 checks)

**The sharpest bug in the step.** `SkinPoolDatabase` holds 40 garments and **every one arrives in
1873 or later**: jeans 1873, button_down 1900, crew_tee 1913. So its own code does the only thing it
can and returns an empty outfit for any year before the pool's modern turning point, which means
**every person in the world before 1945 is dressed in nothing.** The plan called E12 "partly: looks by
era"; it was looks by the *modern* era.

The culture pools carry a `lower` (dhoti, sari, tunic, robe, wrap), so the missing half is precise and
a little comic: **the top half of the body.** A weaver in the Deccan in 1400 wore a dhoti and no
shirt. 27 garments are added, all before 1873, over all 11 pools. **The finding: the wardrobe is a
technology and its dates are the history of tailoring.** Everything before 1300 is a *rectangle*, and
the **doublet of the 1340s** is the first European garment *cut* to a body, in the same decade as the
Black Death. The register also refuses the tempting error: the sherwani is dated 1850, so a Mughal
nobleman of 1600 wears the kaftan.

`Attire` judges what a player wears on four levels where the impossible outranks the merely foreign,
and **it reports and never punishes**. Its first model was wrong and a probe caught it: iron is
ancient but iron *plate* is 1350s, so material and form are separate tables, because **a shared word
in an item id is not a shared technology**.

### Part 5 - B5, B6 and E18: wildlife, crops, and both as items (43 + 47 = 90 checks)

**B6 and E18 were already true.** The atlas dates maize in Europe to 1520 and in Mesoamerica to 7000
BC, so the plan's example ("no maize, potatoes or chillies in India before the 1500s") was already
satisfied. What was missing is the *other half* of a spread, which is **where the thing came from**: a
year alone cannot tell a potato in Bengal in 1700 from a potato that was always there. So the register
is a **join** with the crop-origins register (Khoury et al. 2016, 150 crops, 23 regions, **no dates at
all**), and the year a crop left home falls out as the earliest year it is made outside its origin.

**The finding: the Columbian exchange is measurable and it took about a lifetime.** The chilli is in
Goa by 1540 and has displaced long pepper in Indian cooking within fifty years: a New World fruit made
South Asian food into what the world now calls South Asian food in less than one life.

**B5 was empty.** The only wild animal in the project was the bison, and it was there because it was
hunted in herds. `names/wildlife.json.gz` is 14 species and it is **a register of ranges ending**, not
of birth dates: gone from here and alive there (the lion out of Greece by 100 BC and out of India in
1884), gone everywhere with a year somebody watched (the aurochs at Jaktorów 1627, the pigeon 1914,
the thylacine 1936), or **never there at all**, which is the plan's own horse, kept as **an absence
with a reason**, because an extirpated animal can be reintroduced, an extinct one cannot, and one that
never lived there is not a conservation problem.

### Part 6 - E15, E17 and C15: healers, games, culture (82 + 39 + 70 = 191 checks)

**E15's remedies were fixed in step 38 and the plan does not know it.** What was missing is the
healers, and **a healer is not a remedy**: a remedy is a thing that works and spreads as technology
spreads, a healer is **a person you can get to**, so their data is a different shape: who is
available, how far a patient travels, what they will touch, and whether the neighbours approve.

Two findings. **Surgery is four thousand years older than anaesthesia** (trepanation is Neolithic,
cataract couching is Sushruta's, the part where the patient does not feel it is 1846), so gating the
knife on anaesthesia has the order of events backwards. And **the midwife is the oldest trained
practitioner and the least respected one**: universal because childbirth is, and prosecuted in Europe
from about 1450. That fact broke the register's own model, because one year in and one year out said
she *arrives* in Europe in 1450, before which nobody was born, so a row now carries an arrival **and a
separate list of standing changes**.

**E17's "not yet" was right about the code and wrong about the data.** A game is the cheapest thing a
culture exports and the last thing it gives up: board games cross every border in a few centuries and
the codified sports are all late (football 1863, basketball 1891), so before the nineteenth century a
crowd watches a **spectacle**, and the Mesoamerican ball game never leaves home because **it cannot be
exported without its gods**. This register also **refuses to guess**: nobody can say when polo reached
Java, so a game has an origin and only the spread years the record gives, and everywhere else the
answer is `unknown`, which is not `never`.

**C15 finished culture.** Clothes, food, games and customs all lived somewhere by then; music and the
arts had nothing. There is no year a place got music, so the register is of **the things that carry
music and pictures**, and its finding is that **every art form is older than the means of copying
it**: the phonograph in 1877 separated a performance from the performer for the first time in the
history of the species.

### What is done, and what is written down as not done

Done and asserted, all of it run by `sweep_all.sh`:

- nine packs shipped (`tools`, `anachronisms`, `wardrobe`, `wildlife`, `spread`, `healers`, `games`,
 `arts`, plus the atlas corrections), all Minecraft-free on the Java side so every check runs on a
 plain JDK 17;
- **520 checks, 0 failed**, and `sweep_all.sh` now runs 28 probes.

Recorded as **not done**, so it is not lost:

- **Nothing in this step is wired into a screen or a mob yet.** Every class here answers a question
 and no HUD, tooltip or spawn rule reads it. The wiring is step 48's job and the API is deliberately
 small for it: one `get()`, one lookup, one sentence.
- **The atlas's derived rows inherit their parent's origin.** That is right for flour and wrong for
 sorghum and groundnut, so an origin is claimed only for the 133 hand-written rows and every other
 row says `inherited`. **The derived rows are still wrong about where they come from** and fixing
 them means 17 hand-written dates each, which nobody has done.
- **There is no `chickens` and no `pigs` row in the atlas** and no `cocoa` (chocolate stands in for the
 drink). Barley is not missing: step 44 folded it into "wheat and barley".
- **The games and arts registers are sparse on purpose and the sparsity is uneven.** Europe has rich
 data and the Pacific has almost none, so `playableIn("PAC", 1800)` is a short list because nobody
 looked, not because nothing was played there.
- **Wildlife carries 14 species, not a fauna.** It carries the ones whose range has a recorded end,
 which is why the lion and the aurochs are in it and the house sparrow is not.

## Step 47b - the projection atlas: what AD 2027 to 3000 can honestly be

The question was whether the data that exists for 3000 BC to AD 2026 can be built for 2027 to 3000.
**Not all of it, and the reason is not effort.** The answer has three parts.

### Part 1 - the seam does not break anything, but it is not one date

`Timeline` declares the boundary in exactly one place: `RECORDED_UNTIL = 2026`, with
`FIRST_YEAR = -3000` and `LAST_YEAR = 3000`. Crossing 2027 changes no code path, because the
diffusion curve in `TechnologyAtlas.seriesAt` has never clamped at the seam and `LeaderRegister`
already carries the last recorded head forward rather than leaving a land without one.

What the transition *does* expose is that **the packs do not end together**. The engine's data has a
ragged edge, and it is worth writing down because it decides what a 2400 world can be shown:

| pack | data reaches | so what happens in 2400 |
|---|---|---|
| `technology_atlas` | 2008 | the curve continues; nothing new is invented |
| `products_world` | 2025 | everything still in use is available |
| `health` (remedies) | 2019 | the newest remedy carries |
| `wards / towns / ways_of_life` | the survey's end | the modern state carries |
| `traffic` | 2000 | the last state carries |
| `games` | 1930 | a 2400 town plays the games recorded by 1930 |
| `arts` | 1910 | and has the instruments recorded by 1910 |
| `wardrobe` | 1850 | the modern pool covers 1873 onward |
| `healers` | 1800 | every trade is present, so nothing is lost |
| `prices` | **1914** | no price is shown after 1914, by design, long before the guardrail |
| `armory` | 1800 | the newest weapon carries |

None of that is a bug: a pack whose dates are *arrivals* keeps answering past its last year, and a
pack whose dates are *observations* correctly stops. The bug would be a pack that returns a silent
zero, and `projection_plan.py` is what stops that.

### Part 2 - every pack now has a stated answer for 2400

`worldfill/projection_plan.py` classifies **all 120 shipped packs** and fails if any is left
unclassified: **5 computed, 64 carried, 32 refused, 14 past only, 5 template**. The point is the
guarantee, not the table: no part of the engine goes quiet at the seam and pretends nothing
happened.

The 32 refusals are the six kinds `Projector` will not invent, given a name in words: a person, a
ruler, an event, a war, a disaster, a price, and a population figure past the last measured year.

### Part 3 - what could be computed, computed

`history/projection.json.gz` + `clock/Carried.java`, 92 probe checks.

**No technology in the atlas arrives after 2025.** That single fact is what makes an honest
projection possible: the atlas contains no invention, so any statement about 2400 is a statement
about the **spread of things already invented in 2026**, which is the class the guardrail allows and
which the engine's own curve already computes.

**The finding: the future in it runs out in 2300.** 382 area-and-technology pairs were short of
common under an absolute test; measured against each technology's own ceiling the real backlog is
**42 pairs, and all 42 clear by 2300**. After that the curve is flat for seven hundred years. So the
honest answer to "what is the world like in 2400" is **"the world of 2026, fully spread"**, and the
two centuries to 2300 are not a story of new inventions but of the old ones arriving: the difference
between what humanity knows and what humanity has.

`Carried.flat(year)` exists so a caller can say *nothing further is computed* instead of repeating a
number without a word, which is the same rule step 46 set for projections.

### What this means for the story in `story/`

The chronicle in `story/The_Thousand_Years.md` narrates fusion in 2044, a space elevator in 2477 and
a Kessler Winter in 2519. **Every one of those is an invention, and this engine refuses to make
inventions.** The story is therefore fiction and is kept outside `resources/`; the data has nothing
to say about a space elevator because there is no technology in the atlas after 2025 and nothing
computed after 2300. That is not a gap to be filled with plausible text. It is the boundary the
guardrail draws, and the story crosses it deliberately and says so on its first page.

## Step 47c - what leaves, and testing the method on the past

Two of the five proposals, built. **121 checks** and one report that overturns a conclusion I had
already written down.

### The obsolescence atlas

`history/obsolescence.json.gz` + `clock/Obsolescence.java`, 29 checks.

The projection atlas measures **arrival**. A world is also **what has left**, and nothing measured
that. It is computable for the same reason arrival is: `TechnologyAtlas` has always carried the
`replaces` graph, and `share()` already multiplies a dying technology by the share of what replaced
it. So no year in this pack was invented.

**The finding is also the limit: the last technology this register can say goodbye to is the
steamship, and it leaves Australia in 2051.** Only 11 of the 130 technologies carry a successor, so
only 102 pairs have a computable end, 98 before the seam and 4 after. The other 1,956 pairs have no
successor in the data and persist to AD 3000. That is the carry rule working and it is the honest
shape of the register: it can say goodbye to eleven things.

What it earns is the point a year-by-year register can never show. **An obsolete technology is not a
dead one**: the matchlock is superseded in the 1720s and flintlocks are in use in the 1930s; gas
light and the kerosene lamp are both superseded by electricity in the 1930s and both are still sold.
A world in a single year is not of one era but of several standing next to each other.

### The backtest, which found that the method is bad

`worldfill/backtest_projection.py` → `logs/step47c_backtest.md`. Ten technologies carry a real
recorded adoption series. The test hides everything after 1970, 1980 or 1990, predicts the end of the
series with the engine's own formula, and compares. 1,836 predictions:

| variant | mean absolute error | bias | within 10 points |
|---|---:|---:|---:|
| A: `seriesAt` alone, which ships today | **22.5 points** | **+19.1** | 30% |
| B: plus the replacement factor | 25.1 points | +10.8 | 28% |

**It over-predicts by nineteen points on average.** The worst case is television in Haiti, predicted
to reach 74 per cent against 1 per cent recorded.

This matters beyond the number, because it **makes a sentence in this README false**. Step 47b says
the projected years are "computed rather than guessed". They are computed, and the computation has a
measured error of about twenty points and a known upward bias. The honest verdict is that the
projection atlas is good for the question **is this arriving**, and not good enough to print a share
as a number.

Variant B is the interesting result. Adding the replacement factor **halves the bias** and **raises
the average error**: it gets the direction right and the magnitude wrong. So the replacement factor
is licensed for the question **"does this survive"**, which is what the obsolescence atlas asks, and
is not licensed to replace the share numbers. **The backtest settled a design question with a
measurement instead of an opinion**, which is the only reason to run it.

### Left undone, and written down

- **The shares should be bands, not points.** `Carried.spread()` returns a double and nothing else;
 a UI that prints `84%` is overclaiming against its own error bar.
- **`d50` is untested.** The backtest measures the atlas's estimate as much as the extrapolation, and
 separating them needs a second estimate nobody has.
- **Only 9 technologies have series to test against**, all twentieth-century consumer goods, so the
 test says nothing about a farming tool or a medicine, which is most of the atlas.

## Step 47d - climate to AD 3000, under a stated assumption

`history/climate_projection.json.gz` + `climate/ClimateProjection.java`, 36 checks.

**Why this is allowed when a price is refused:** climate is arithmetic and not prophecy. Carbon
leaves the air at rates measured from the isotope record, temperature follows the logarithm of carbon
with a thermal lag, sea level follows temperature with a slower lag still. None of that says what
people will do, so the pack does not forecast. It answers **if emissions follow this path, then this
is what the physics does**, and the assumption is a field on every scenario.

Three paths: emissions stop in 2027, end by 2060, or stay flat to 2050 and end by 2120.

**Every value is a band, not a point**, which is the 47c lesson applied: the backtest showed that
this kind of projection printed as one number is wrong by about twenty points, so each value carries
low, mid and high from running the same physics at the two parameters nobody knows. Carbon's band is
**flat**, because carbon dioxide in the air is chemistry and no climate sensitivity changes it.

**The finding: about a fifth of every tonne of carbon is still in the air in AD 3000.** The box that
never empties holds 18.6 per cent forever, so even the zero scenario does not put the world back. And
**sea level is the one number in this project that only ever goes up**: the gap between the zero and
the delayed path is 0.49 m in 2100 and 2.38 m in 3000, because the ice term keeps integrating after
the temperature has stopped falling.

Not done, and said so: **this is not a climate model** (four boxes, no aerosols, no permafrost, no
regional detail, so it cannot say what happens to Bengal), the bands come from two parameters rather
than structural uncertainty, and **it has not been backtested** the way the technology projection was.

## Step 47e - the chronicler: a recorder for years nobody wrote down

**37 checks, 0 failed.** `timeline/Chronicler.java`, 314 lines, no Minecraft imports, and a probe
that compiles it against a bare JDK 17.

The hole this fills: 47b to 47d compute things *about* AD 2027 to 3000, and none of them is
*history*. Run the clock past 2026 and the timeline reaches the seam and goes quiet, because the
guardrail forbids inventing a ruler, a war, a price or a population figure. The way out is not to
invent the future but to **let the simulation write it down**: what the world actually does after the
seam becomes recorded history, in the same sense the shipped records are.

Four rules, each with a reason. **Worthiness thresholds**, per kind and not one number: a settlement
of four people is not history and a road of four metres is not a road (settlement 25, road 1,000 m,
field 50, technology 100, population 500, trade 1,000; the rare kinds at 1). **One line per process**,
so a ten-year road is one line with a span and not ten lines, indexed by line position rather than by
searching the title. **The fifty-year break**: a road begun in 1200 and resumed in 1500 is two roads.
**`PER_YEAR = 3`**, because a busy year should read as busy and not as a wall.

**The seam rule is the point of the class.** Before AD 2026 the shipped records are the authority and
only `AUTHORED` changes are recorded, which is what a diverged branch means: the player changed
something and the line says so. After 2026 there is nothing to overwrite. A `MODELLED` line is
refused *before* the seam, because a modelled past would be indistinguishable from a recorded one,
which is the guardrail stated as code. `seamLine()` reads: *before AD 2026 the records are the
authority and this chronicle only notes what changed. After it, nothing has happened yet in this
world: the years past the record are unwritten, not empty.*

`TimelineManager` now carries a `Chronicler` per branch beside its `BranchChronicle`, with
`chroniclerFor` and `record`. The two are separate objects on purpose: the chronicle annotates
shipped history, the chronicler **is** history once the record runs out. **Nothing in the simulation
calls `record()` yet**, and that is written down rather than hidden: the recorder is built and
tested, and feeding it from the simulation's own events is the next step's work.

**No data pack, deliberately.** `Chronicler` ships no resource file, so it adds no manifest rule and
no line to `DATA_CREDITS.md`; a shipped table of future events would be exactly the invented future
the guardrail refuses. Two bugs are recorded because both are the same lesson: the repeat rule
searched the title for the subject and matched nothing, and a null-provenance guard inserted by a
string replacement never ran because it landed outside the path that builds the `Line`. **After a
patch, assert the patch is in the body that runs.**

**Limits**: the thresholds are judgements in one place, not measurements; three lines a year is
arbitrary and a siege that changes everything gets one or none; the recorder trusts the event it is
handed, so nonsense in is nonsense with a provenance stamp; and it **cannot be validated against the
past**, because it is only ever fed by a running world, so the probe tests the rules and not the
history they would produce.

**Proposal 5, decided: keep the population refusal.** No population figure past the last measured
year. It is the refusal a reader will most want lifted, because "how many people live here in 2400"
is the first question anyone asks a future. 47b computes what arrives and 47c what leaves, both
bounded by data that exists; a population total has neither a measured rate nor a bound behind it in
the centuries where it would matter. The chronicler does not change it: it can record that the people
of a place changed in number and will not print how many.

## Step 48 - ways to change history, what counts as a change, player roles (F1, F5, G1, F9, F11)

**Parts 1 and 2 of 7 done. 44 checks, 0 failed.**

**Part 1, the survey** (`worldfill/logs/step48_part1_notes.md`). All four plan labels were right this
time, which is worth recording because they have been wrong before: F1 is *partly, stopping an event*
and that half is better than its label, since `player/InWorldInterventionDetector.java` already weighs
real player actions near a located event and refuses disasters by name; F5 is a market ledger and a VIP
takeover and no roles; G1 is two small classes and events only; F9 is the placeholder it says it is;
F11 has no quest system at all. Three measurements shaped the design. **A player may already stop a
battle and may not stop an earthquake**, so agency follows the same rule as the guardrail. **The force
arithmetic is small on purpose**: a kill weighs 1.0, a broken block 0.25, killing villagers 0.0, and
stopping a battle takes six units over at least three separate actions. And **nothing a player does is
stamped as history anywhere**, which is exactly what step 47e's chronicler exists for.

**Part 2, G1, the change record.** `timeline/ChangeRecord.java`, Minecraft-free. The decision is that
change is **classified, not enumerated**: F1's ten ways are points in one grid of **five `What`**
(event, person, place, knowledge, good) and **six `How`** (removed, added, earlier, later, bigger,
smaller), which is 30 cells and **28 filled**. Each filled cell carries a price in separate actions, a
gate (what a player must already have) and the chronicle kind it is recorded as. **The two holes are
named**: a person cannot be made earlier or later, because a birth is not a lever. Prices fall in the
order life does: one person's fate 3 actions, founding a town 5, stopping a battle 6, moving a discovery
7, and **starting a war 9, the dearest cell in the grid**. Nothing costs one or two actions, matching
the intervention detector's own three-action floor.

**The refusals are the vocabulary's own, and that is the point.** There is no `What` for a number of
people and none for money, so **a census and a price cannot be expressed by any caller**: a refusal that
is a missing word cannot be forgotten, because there is nothing to call. A war or a ruler that nobody
made *can* be expressed and is refused one layer up by provenance; the probe shows the real chronicler
turning a `MODELLED` ruler away in 2400 and keeping an `AUTHORED` one with the player's name on it. The
chronicler gained a **`PERSON`** kind for that, because a player changing one person's fate is history
and the recorder had no word for it.

Ten ways, ten distinct cells, all filled: **if a way cannot be placed in the grid, it is not a way to
change history**, and that is the test an eleventh way has to pass.

**Limits**: the grid is a design and not a measurement, and its prices are judgements in one table
chosen to be argued with; a gate is a phrase and not yet a permission check (part 4 turns them into
roles); this part says what a change is and not what follows from it, which is step 49 and would be a
different project here; and there is **no data pack**, because a design vocabulary is not a sourced
table.

**Part 3, F1, the ways priced and gated.** `timeline/Agency.java`, Minecraft-free. Part 2 said what a
change costs and not whether the player can do it at all, so each of the ten ways is now judged against
a **`Situation`** of five things and no more: how many people are within reach (from the town pack's own
counts), the player's standing (outsider, resident, notable, officer, ruler), how many follow them,
whether there is a workshop, and what is in the purse. There are **three answers**, because a bare no is
useless in a world: **yes** with the count and the cost, **not yet** with what is missing (*"a stranger
cannot do this here; it wants a resident, known by name"*), and **no** with the arithmetic (*"this needs
about 1000 people within reach and a village has 200"*). Reasons that cannot be argued with are checked
first, so a player in an empty valley is not told to go and collect fifty followers.

**The refusal list is read, not copied.** `Agency` uses `InWorldInterventionDetector.STOPPABLE_KINDS`
and `REFUSED_KINDS` directly and the probe asserts the sets are equal, so there is one list of what a
person may interrupt. A kind on neither list is a no: an unlisted kind is not a permission.

**The measured ordering, and it contradicted the plan.** Fed real town counts, a **stranger** can touch
a person and tell the future, and nothing else, at Cahokia 1100 (20,000), Tenochtitlan 1500 (212,500),
Rome -150 (300,000), Kolkata 1710 (12,000) and London 1801 (1,011,157). A **resident** holds the same
four ways in every one of them. **So the size of a place decides almost nothing**: once a town is big
enough to have a market, who you are and what you bring decides everything, and only a hamlet under a
thousand people is genuinely narrowed by its count. The crown is a **standing** requirement and not a
size one, which is the opposite of what this part expected to find.

Two bugs, both in the probe: the town pack carries **twelve** fields and its own header lists eleven, so
the reader stopped at town 131; and "nearest town" is the wrong question, because nearest to Tenochtitlan
in 1500 is *Greater Mexico City*, a modern metro area with no count that year, which read as an empty
city. It now takes the largest count within a degree, falling back to nearest only when nothing there is
counted. One rule was corrected against the code: a stranger cannot marry, because a marriage needs two
people and one of them has to know you.

**Limits**: the thresholds are judgements in one table (twenty people for a town, fifty behind you for a
war, a hundred for a crown, a thousand for a war to exist at all); **standing is not yet a thing in the
world**, so today every player is an outsider and four ways are permanently out of reach until part 4
makes roles; followers and the purse are not wired to anything; and no data pack, because the situations
are computed from packs that already ship.

**Part 4, F5, player roles.** `timeline/PlayerRoles.java`, Minecraft-free. Part 3 read a player's
standing out of a field nobody sets, so every player was an outsider and four ways were permanently out
of reach. A role is now **earned by doing the thing the role does**, counted from registers the mod
already keeps: ten sales in `MarketLedger` makes a merchant, three fights a soldier, twenty court days a
courtier, ten knowledge cards a scholar, and holding an office a ruler. **The highest standing wins** and
**the office outranks everything**. **A role lapses after twenty-five years of silence**, which is what
makes it a practice and not a badge: a merchant who traded in 1200 is one in 1225 and not in 1226, and
coming back takes one more sale because the deeds are still counted. Losing an office takes everything at
once.

Fed the same city (50,000 people, AD 1600) and six histories: nothing 2 ways, merchant 4, scholar 5,
soldier 7, courtier 6, ruler 10. **The finding: roles open different things, not more of the same
thing.** A soldier with thirty behind them can found a town; a courtier with an office and five followers
cannot, because founding a town wants twenty people who will stay and a court is not a crowd. So the
soldier can do more things than the courtier and stands lower on the ladder, and **what is monotone is
standing, not the count of ways**. The scholar is the clean case for roles existing at all: ten cards
gives a study that counts as a workshop and materials to buy, so a scholar can bring an invention early,
which a soldier with forty behind them cannot buy at any price.

Two bugs found by running it: **a lapsed role kept its standing bonus**, so a courtier idle for two
centuries still read as notable; and **a scholar could not do the one thing a scholar is for**, because
the purse for materials was empty, so learning ten cards left them unable to act. Both fixed, and the
second one is what a scholar's purse now exists for.

**Limits**: the thresholds are round numbers chosen so the first role is reachable in one session, and
nothing measures them; **the counters are not wired to the registers yet** (`Deeds` is filled by a caller,
and the joins from a sale, a fight, a card, a court day and an office are the next part's work, exactly as
`Chronicler.record` stood in step 47e); `holdsOffice` is a boolean and does not say which office or where;
roles have no art, GUI or name beyond the enum's own words; and no data pack, because a role table is a
design and not a source.

**Part 5, F9, how a player reaches another year.** `clock/TimeTravel.java`, Minecraft-free. There is **one
date for the world**, and that is not a preference: the town pack, the technology atlas, the sky and the
chronicler all answer for a year at a time, so two players in different years would need **two different
villages at the same coordinates**. So a player does not travel in time, the world does: the clock moves
and everybody moves with it, nobody is duplicated, and there is no paradox because there is no second copy
of anybody. Two ways to move it: it runs forward by itself, or `/ee date <year> <month> <day>` for an
operator, either direction. `doorways()` lists the honest options in the order the game is meant to be
played: let the clock run, travel (most of what people mean by it), read and be told, and the command last.
A player may not move the clock at all, not even one year forward, and the reason given is the shared date
rather than the permission.

**Going back is a fork, not an undo.** The packs still say Tenochtitlan held 212,500 people in 1500 and
will say so again when the clock returns there; what changes is that everything the player does from the
jump is theirs and `AUTHORED`. That gives **five outcomes and not three**, and the fifth is what this part
had to add after running it: going back *inside a world's own unwritten history* forks nothing, because
there is no record to fork. The first version of the code had two names for coming back to recorded years
and **no name at all** for that case; the probe caught it on a jump from 2400 to 2000.

**A real bug fixed outside the probe**: `TimeMachineItem` told players to use **`/ee time set <year>`**, a
command that does not exist, and announced "chrono drive calibrated" when the clock was not even running.
It now prints the year and the rule, and says plainly that it **reads the clock and does not move it**,
because two doors to one clock is how a save corrupts.

**Limits**: the item remains a prop and this part adds no item; a fork is a statement about provenance and
history, carried by the existing branch machinery, and **not** a promise that every chunk is copied; and
`TimeTravel` decides the policy but the command still calls `SimulationClockManager.setCurrentYear`
directly, so **the rule is checkable and not yet enforced at the door**, which is one line of the next
part's work.

**Part 6, F11, errands tied to real history.** `timeline/Errands.java`, Minecraft-free. A quest in most
games is authored; here it can be **read out of the record**, because the packs already date 23,535 famous
buildings and 184,060 people. Three kinds of work: **carry a letter** to a building that stands this year,
**help build** a building whose opening is within twenty-five years, and **find somebody** in the years
they were alive. The rule that keeps it honest is the project's own: an errand is offered only if the
record says the thing is there, so there is no letter to the Red Fort in 1600 because the pack dates it to
**1648**, and the probe sweeps four centuries around Delhi asserting that not one offer is anachronistic.
Delhi in 1600 offers a letter to the tomb of Sikandar Lodi (standing since 1517), and 1630 offers a day on
the **Taj Mahal** 179 km away, dated 1632.

**An errand pays in deeds and not in coins**, because a pay rate for a fictional job is a price. Carrying a
letter is a court day, a day on a scaffold is a sale, and a conversation is a card learned, which are
`PlayerRoles`' own three counters: **twenty letters carried is what makes a courtier**, and the probe
checks exactly that. **Past the seam there is nobody to be sent to**, because nobody is recorded there and
inventing a contact would be inventing a person; the code says so, and still offers letters, because the
buildings stand. That is the shape of the future here: **errands that are places, not persons**.

Three bugs, and the third is the one to keep: `Errand` did not carry the dates of the thing it was about,
so the probe could only check the rule by name and read 21 false failures (two buildings in two cities can
share a name); two code paths wrote different sentences for the same errand; and **a year was remembered
instead of read** - the refusal said the Red Fort dates to 1639 and the pack says 1648. The refusal now
says that it once said 1639, because this is the fourth time the project has caught itself inventing a
fact it could have looked up.

**Limits**: errands are **offered and not yet given out** (no command, no screen, no counter turns a
finished errand into a deed, the same state `Chronicler.record` was in at step 47e); 1,500 km and 25 years
are round numbers; a Wikidata opening year is sometimes when a building was begun and sometimes when it was
finished, so `HELP_BUILD` can be offered on a finished building; and `MEET` can only reach people the record
already knows, so there is nobody ordinary to be sent to.

**Part 7, the checks and the write-up. Step 48 is done: seven parts, 278 checks, 0 failed, five
Minecraft-free classes and five probes, and no new data pack.** The full note is
`worldfill/logs/step48_notes.md`.

| part | class | checks |
|---|---|---:|
| 2, G1 what counts as a change | `timeline/ChangeRecord.java` | 44 |
| 3, F1 the ways priced and gated | `timeline/Agency.java` | 81 |
| 4, F5 player roles | `timeline/PlayerRoles.java` | 57 |
| 5, F9 reaching another year | `clock/TimeTravel.java` | 57 |
| 6, F11 errands from the record | `timeline/Errands.java` | 39 |

**One promise from part 5 is now kept**: `TimeTravel.judge` is wired into `/ee date`, so the rule about who
may move the clock and what a jump does is checked **at the door** and not only in a test. It reports what
the jump means when it lands ("forward 400 years, past 2026. Nothing is recorded there, so from now on this
world writes its own history").

**What is wired, and what is only built**, which is the column to read before building on this step:
`TimeTravel` and the time machine item are wired or fixed; **`Chronicler.record` still has no caller**;
**nothing fills `PlayerRoles.Deeds`**, so the joins from `MarketLedger`, a fight, a knowledge card, a court
day and an office do not exist; **nothing offers or awards an `Errand`**; and nothing constructs a
`ChangeRecord.Act` or asks `Agency`. The step therefore delivers **the rules of agency, checked hard, and
not yet the plumbing that feeds them**, the same shape step 47e had. That plumbing is one join per register
and is the natural first work of step 49.

**Eleven bugs were found by running it, and nine were in the tests or in a sentence rather than in a
rule**: the town pack's twelve fields against an eleven-field header; "nearest town" giving a modern metro
area for Tenochtitlan in 1500; a probe merging 28 acts under the repeat rule and reading 12 lines in a year
that holds 3; a probe testing the lapse and calling it the role; an `Errand` without its subject's dates
forcing a name match and reading 21 false failures; two paths writing different sentences; and **a year
remembered instead of read**, 1639 against the pack's 1648, the fourth time this project has invented a
fact it could have looked up. The two real rule bugs were **a lapsed role keeping its standing bonus** and
**no name in the effect enum for going back inside the unwritten years**, and both were found by asserting
something specific rather than by reading the code.

## Step 49 - cause and effect, the what-if engine, rulers decide (G2, G3, D12)

**Step 50 done: six parts, 306 checks, 0 failed.**

**Part 1, the survey, and the measurement that decides the step.** The plan's own note warns that "the
cause-and-effect graph is thin", and it is thinner than that: I read the row keys of every history pack
looking for a link field, and **41,788 dated events ship with 120 stated causes between them**, all of them
in the 248 hand-written Deccan events. The `effect` field on all 2,397 wars is the literal string `"note"`.
The cause properties the plan counts were fetched and then not shipped, so a step that reads causes out of
the data would have nothing to read.

What can be computed where nothing is stated is time and place. Asking, for 1,500 sampled battles and
sieges, whether a war's span covers the date and its radius covers the place: **39% fall inside some war,
and 14% fall inside more than one**, so a computed dependency is ambiguous for one event in seven and has
to return candidates rather than an answer. G3's and D12's existing pieces were also measured and all of
them are wired already: `BattleSimulator` computes a win probability from size, morale, supply, formation
matchup, ground edge, technology gap and terrain; `Sieges`, `Sides` and `Battles` back it with 11 wall
kinds, 14 parties and 20 matchups; and `DynasticSuccessionEngine` carries four succession laws with heirs,
evaluation and usurpation, called by `SimulationEngine` and `Kinship`. So **D12 is not missing, it is old
and working**, and the work here is to make a change flow into it. **The refusal that shapes G3**: of the
seven things a what-if may change, five can be computed and a population consequence cannot, so the sixth
is refused by name.

**Part 2, the plumbing step 48 promised.** `timeline/DeedLedger.java`, Minecraft-free: five registers
already count the five things a role is made of, and this is the one class where they meet (a sale from
`MarketLedger`, a fight, a court day from `RoyalCourtManager`, a card from `KnowledgeCard`, an office from
the towns pack). It is **not a second register**: five counters and two years, because the truth of a sale
is in the ledger. **And it is the first caller `Chronicler.report` ever had**: taking an office and
intervening in an event are history and are recorded, while carrying a letter or reading a card is work and
is not, and giving up an office is an absence rather than a line. `TimelineManager` now owns one ledger per
server.

**Three bugs, and all three were about time**: an office taken in 1410 made a player a ruler in 1400;
taking an office refreshed the twenty-five-year practice window, so ten sales from 1300 read as recent in
1410; and a ruler with no practice behind them lapsed on the day of the coronation. The step 48 probe was
re-run to prove the older rule still holds and stays at 57 checks. The same lesson as step 48 from the other
side: **every bug in this class was a year, and none was a counter.**

**Limits**: the five call sites do not exist yet (they are Minecraft-facing, `tools/gradle_compile.sh` has
still never run, and they are named rather than written blind); the ledger is in memory and forgets on a
restart; and a player is a name rather than a UUID, which keeps it testable and needs a mapping later.

**Part 3, G2, what depends on what.** `timeline/Depends.java`, Minecraft-free. With no causal links in the
data, the graph is built from the two things every event carries: **a stated cause** where a hand-written
row has one (120 events, and the prose is carried on the edge and never parsed), and **time and place**
otherwise. The probe re-measures the survey's numbers in Java through the shipped class, so the figures are
reproducible: **36% of battles fall inside some recorded war and 14% inside more than one.** The finding is
worse than that suggests: a battle inside two wars contributes two edges and both are rivals, so in a graph
over 2,000 battles **1,398 edges carry 68% ambiguity**. A computed dependency is therefore the weaker kind
of evidence and the class says so, with `Basis.TIME_AND_PLACE`, `ambiguous()` and `usable()`, which is false
for an ambiguous edge. **It never tie-breaks**: every parent that fits is returned, nearest first, because
choosing silently between two plausible parents would be inventing an answer. `reach` walks forward only,
bounded by depth and years, and proves both directions: from 1756 a five-year horizon stops before the 1762
consequence and a fifty-year one reaches it. An event with no parent gets a sentence that is careful about
what that means: *"that is not a claim that it had no cause, only that no cause is recorded and none can be
computed."*

Two bugs, both in the probe: **`events_world.json` ships as plain JSON** while its neighbours are gzip, so
the reader lost 13,987 events and measured 26% instead of 39% (it now sniffs the first two bytes); and the
horizon assertion was backwards, with the code right and the test wrong.

**Limits**: the graph works for battles and wars and nothing else, because they are the only kinds with a
radius wide enough to contain their children; the radii are circles somebody drew and the graph inherits
their errors; and a stated cause's parent is chosen by nearest place and closest dates, which is a guess
about which war a sentence means.

**Part 4, G3, the what-if engine.** `timeline/WhatIf.java`, Minecraft-free. It does **not** re-derive physics
the mod already has: the strength of an army arrives as a **win probability from `BattleSimulator`**, because
that model already weighs size, morale, supply, formation matchup, ground, technology and terrain, and a
second answer to the same question is what this project refuses. What it does is **recompute the registers**:
the war (the probability moved), the border (only a **crossing of the halfway mark** changes hands), the
succession (four laws, including the **open succession** when there are no heirs), an invention (the atlas's
arrival year moved by up to forty years, then spread by distance expressed in years) and a faith (a share of
the people, never a claim about what they believe). **It corrects the survey**: the survey said one of G3's
seven could not be computed; it is **two**, population and money, and the money one is refused for the same
reason the price tables stop where they stop, so a what-if can say trade is disrupted and cannot say what
that costs. Both refusals are **in every answer**, with their reasons.

**Two rules keep the answer small.** Big trends resist: a change smaller than the trend the caller reports is
**absorbed** rather than reported, because most of what a person does is absorbed. And confidence falls with
the trend and the size of the change, **capped at 90%**, because the first version printed *100% sure* about
the outcome of a war.

On the real case, a battle made bigger at Rossbach in 1757 where the battle model gives the attacker 45%,
the engine answers: the war 45% becomes 95%, the border moves from France to Prussia, the steam engine
arrives in 1692 instead of 1712 and reaches other places ten years later, and Protestantism goes from 40% to
53%, with the people and the money refused underneath them.

Three bugs, each a different kind: **a refusal counted as a consequence**, so a world where nothing happened
reported that it had changed; **the open succession was missing**, so a ruler dying with nobody behind them
produced no answer at all when the absence of an heir is the most important answer there is; and **100%
sure**. A test-side error also: I asserted a coup and a senate would pick the same heir, and they should not,
which is the point of having four laws.

**Limits**: the probabilities are the caller's, so if the model is wrong every consequence is wrong the same
way; the four succession laws are **restated in eleven lines** rather than called from
`DynasticSuccessionEngine`, which needs a world state, and the duplication is named; a border is a holder and
not a line; and the spread rule is one number with a decimal point on it.

**Part 5, D12, rulers decide.** `timeline/Rulers.java`, Minecraft-free. It is **not** a rewrite of
`DynasticSuccessionEngine`, which is old wired code; it answers the different question of **why** a ruler
chooses what they choose, so a decision can be explained to a player instead of rolled. A ruler is **security,
treasure and army strength**, and every decision carries its sentence: **raise the tax** (a ruler below 30%
security will not, because a new tax turns a grumble into a rising; above 35% a tax collects less than it
costs; a treasury above three wars' worth means money is not the problem), **go to war** (below 30% security
the ruler who leaves comes back to a different country, below 100 treasure the army is unpaid, and only then
do the odds matter at 55% or a 70% army), and **name an heir** (a worried ruler names one because it shows who
the alternative is; a very secure one does not, because it makes a focus). **The order is the design**: the
throne before the money and the money before the odds, which is why a worried king refuses a 90% war. The
property the old engine lacks is checked by repetition: **two hundred identical questions give two hundred
identical answers and the same sentence**, so the reason is the answer. `reactTo` joins back to step 48: a big
change to a person is answered by a secure ruler and ignored by a weak one, and a town founded is not a threat
to a throne however big the town.

**And the two defects in the old engine are recorded rather than quietly worked around**: `USURPATION_COUP`
and `SENIORITY` both fall through to **`heirs.get(0)`**, which is a list order pretending to be a law, and
`attemptUsurpation` rolls **`Math.random()`** at 75% with an army and 35% without, so the same usurpation can
succeed or fail on a reload with no answer to why.

Two bugs, both in the probe and both the same mistake: I picked the wrong ruler twice, first asserting a king
with 50 in the treasury would go to war when the money rule comes first, then asserting a 52% chance passes a
55% bar. **Both times the engine was right and the test was describing a different king.**

**Limits**: three numbers are not a person, and there is no court, faction or rival in the model; the
thresholds are round numbers in one place; the two defects in the old engine remain; and nothing calls
`Rulers` yet, because security and army strength are not gathered from `WorldStateManager` and `war/Army` by
anything.

**Part 6, the chain and the write-up. Step 49 is done: six parts, 232 checks, 0 failed, four Minecraft-free
classes and five probes, and no new data pack.** The full note is `worldfill/logs/step49_notes.md`.

| part | class | checks |
|---|---|---:|
| 2, the plumbing step 48 promised | `timeline/DeedLedger.java` | 42 |
| 3, G2 what depends on what | `timeline/Depends.java` | 43 |
| 4, G3 the what-if engine | `timeline/WhatIf.java` | 66 |
| 5, D12 rulers decide | `timeline/Rulers.java` | 44 |
| 6, the chain | `probes/Step49ChainProbe.java` | 37 |

**The finding this step is worth: every part passed its own probe while the chain was broken.** The part 6
probe was written to see whether the parts meet, and it found in one run what four green probes had missed:
**a merchant had no followers at all**, so founding a town wanted twenty people who will come when you call and
no merchant could ever found one, which made the way a merchant's money is *for* the only way a merchant could
not take. A merchant's following is now their custom, one head per sale, and a ruler's following is their
office rather than their court days. **A probe per class proves the class; a probe per chain proves the game.**

**What is wired, and what is only built**: `Chronicler.record` **now has a caller** through `DeedLedger`;
`DeedLedger` is owned by `TimelineManager`, though **the five Minecraft-facing call sites do not exist yet**;
`PlayerRoles` is fed by it, so a role now comes from what a player did; and `Agency`, `ChangeRecord`,
`Errands`, `Depends`, `WhatIf` and `Rulers` are built and tested with **no caller**. `DynasticSuccessionEngine`
is **untouched**, with its two defects recorded rather than fixed.

**Nine bugs, six of them in a probe.** The three in `DeedLedger` were all about **time**: an office reaching
back before it was taken, an office refreshing a practice window, and a ruler lapsing on coronation day. The
three in `WhatIf` were all about **what counts as an answer**: a refusal counted as a consequence, the open
succession missing, and 100% sure. The chain bug was about **a field nobody had filled**.

## Step 50 - written stories and new knowledge for each timeline (G4, G5, G10)

**Parts 1 and 2 of 6 done.**

**Part 1, the survey.** Three systems from three sides of one subject: **what is written (G4), who wrote it
(G5), and what the writer believed (G10)**. The material is enormous and already dated: 30,151 towns of which
**3,892 carry a name by era, 2,582 of them dated** (Bombay until 1995, Edo until 1868), **23,535 buildings all dated** and 2,569
with an end year, **124,941 people with both dates**, and 110,447 works. The hole is that **every knowledge card
is anonymous**: a card knows when it is known from and how widely, and knows nothing about who says so, so the
mod cannot express two people in one square disagreeing, which is exactly what G10 is. The decision this survey
forces: **a story is not new data, it is a reading of what the packs hold, attributed to a voice**, and every
sentence carries its row.

**Part 2, G4 and G10.** `story/BranchStory.java`, Minecraft-free. A story is **an ordered reading of dated
rows**, told **in the name the place had that year** (*"It is Bombay in 1850, and Mumbai is what it is called
now: the record dates the change to 1995"*) and **by a voice that has something to gain**. Four voices, each with
its cost stated: a **chronicler at court** (a defeat becomes a withdrawal in good order), a **clerk of the tax
roll** (no interest in glory or famine, so a hard year looks like a short list), a **priest** (a good harvest is
a reward, a bad one a lesson), and a **traveller** (astonished by ordinary things, blind to what everybody takes
for granted). The same row in two voices is the whole of G10, and the function that does it always ends with the
honest note: **two voices over one row is not two sources, and where the record has one account the second voice
is a reading of the same rows.** That is what a card with one answer per question cannot say.

**G5's shape**: a branch's new knowledge is a voice that did not exist in the record, marked `AUTHORED` with the
player's name on it (*"That is Asha's account of it and not the record's"*), and a rumour about it marked
`MODELLED` (*"Nobody has looked"*), never passed off as `OBSERVED`.

Two bugs: **I counted three fixture rows dated by 1850 when there are two**, the engine having correctly left
the 1853 railway out as future, which is the third time in two steps that the test was wrong and the code right;
and `voices()` printed *"it a defeat becomes a withdrawal"*, a grammar bug no substring test would catch and
reading the output did.

**Limits**: four voices is a sample and a real archive has a hundred, and the ones this project has least of are
the ones that matter most, the losing side, the ordinary household and the woman of the house; the wording is a
**template** and a thirty-sentence story will repeat itself; and **nothing here reads a pack yet**, because
`Fact` is supplied by a caller and the join from `TownFacts`, `buildings_famous` and `ways_works` is not
written.

**Part 3, G10 as a card rather than as a reading.** The defect the survey found has a name now:
`Question.at(date)` keeps the last answer whose day has come, so **two answers dated the same day do not merely
disagree, one of them can never be heard**, and nothing says which was dropped. `knowledge/VoicedCard.java`
fixes that by holding voices **beside** the card: `Spoken(question, from, to, voice, text, record, provenance)`,
where `voice == null` is the anonymous answer every card holds today, kept as a value so the reader can be told
and the count quoted. `of(card)` with nothing added behaves exactly as the card did, and the reading says *"the
card does not say who tells you this"* rather than inventing a name to fill the hole. `accounts(qid, date)`
returns every live account in a **fixed order by voice** and not the caller's order; `disputed(date)` finds the
disagreements without reading English; `shadowed()` **reports the base card's unreachable answers** instead of
repairing them, because the fix belongs in `build_cards.py`. A card cannot be asked what the court decided by a
**traveller passing through**, a rule this project chose and not a fact it found. 66 checks.

The bug here was found by **reading the output, not by the assertions**: the probe was green at 63 and the note
under a claim and a rumour still said *"readings of the same rows"* about material with no row at all. The note
now branches on provenance and says **"nothing here is the record's word"**. A tooling finding went with it:
`knowledge/KnowledgeDate` imports the Minecraft clock, so **nothing in the knowledge package compiles headless**,
which is what `worldfill/stubs_headless/` is for.

**Part 4, the join and G5.** The limit parts 1 to 3 all ended on is gone: `story/PlaceRecord.java` **reads the
packs**. 30,151 towns (3,892 with names by era, 2,582 of them dated), 23,535 buildings and 110,447 works become
dated facts about one place, so the Bombay line now comes out of the pack rather than out of a table in a probe.
Distance is a plain scan of at most 133,982 rows, because a story is told when a player asks and not every tick.
**An estimate is never promoted to a fact**: a founding year recorded only to the century is `STRUCTURAL`
(`"in the 1300s"` is a bound and not 1348), a work dated from the technology atlas and a building dated from the
gazetteer's site window are `MODELLED`, and `Story.asMarkedText()` shows the marks to a reader. The probe
**recounts the pack independently** and demands that the join's modelled count equal the pack's estimated rows.

**The finding, and it is not the one the probe expected**: across the pack the record dominates, 82,304 works
recorded against 28,143 estimated, but **within 200 km of Mumbai 58 of 260 works carry a recorded year and 202
are estimated**. Three quarters of what a player would read there is an estimate. The first version of the probe
asserted the average held everywhere, which is how an average becomes a lie about a place.

**G5 is `knowledge/BranchKnowledge.java`**: a claim is a year, a question, an author and a sentence, and it is
never `OBSERVED`. Two branches from the same divergence point and the same year **share nothing**, because one
contains the invention and the other does not; a claim on a question the card does not ask comes back in
`Attached.unattached()` rather than vanishing. 104 checks.

**A number in the earlier notes was wrong**: the survey said 3,892 towns have a dated name change, and it is
2,582. 3,892 is how many carry names at all. Corrected in the part 1 and part 2 notes, in `BranchStory`'s and
`PlaceRecord`'s javadoc, in `README.md` and in `PROGRESS.md`. The step 29 notes that quote 3,892 for names by era
were right, which is what made it easy: the number was right and the sentence about it was wrong.

**Part 5, the written object a player reads.** `knowledge/WrittenThing.java` is **not a book, and the record says
so**: step 43 measured eleven kinds of written thing and **not one of them is a book**. So the object is a surface
that exists at that place in that year (`edict`, `temple_inscription`, `grave`, `notice`, `graffiti` and six
more), and the surface decides three things: **whether there is an object at all** (a place with no writing
refuses, and Cuzco's writing is dated 1576), **how much fits** (a gravestone holds 3 lines, an edict 12, a board
2, and what is left off is said out loud rather than silently dropped), and **whose wall it is** (*"A chronicler
at court did not put this up: the wall belongs to a priest, and the words on it were paid for by somebody
else"*). It adds no sentence of the past: the body is `Story.markedLines()`, marks and all. `wrap` never breaks a
word and `pages` is checked by reassembling every page against the whole.

**The bug this part found, by printing the output:** the first version took the writing from one year and the
date from another, and the probe printed *"the cut stone at the grave at Wanchaq in 1500, in the Latin
alphabet"*, a script recorded as reaching Peru 76 years later. `carve` now refuses when the two years disagree.
Fifth time in three steps that a green assertion and a wrong sentence ran together. 61 checks.

**Part 6, the chain.** Parts 2 to 5 each proved their own class, and step 49 taught that a probe per class proves
the class while only a probe per chain proves the game. So one probe runs the whole thing: **packs -> story ->
the surface the record has standing there -> the object a player reads -> a branch's claim cut into it -> a card
that can hold two answers**, and then checks the two rules that only appear at the end of a chain. A branch's
claim **is** on the card and **is not** on the stone, because a card is where a claim can live and a surface is
where it cannot. And the end of the record: **17 rows in the packs are dated after 2026** (a 2028 bridge, a 2100
memorial, fifteen works between 2027 and 2033), so `PlaceRecord.LAST_RECORDED` stops a story there. A story told
in **AD 2900** now contains no sentence after 2026, and the 2031 Mutiara line that was still a drawing is not on
any wall. 25 checks.

**Step 50, in one sentence:** a story here is not new data, it is a reading of what the packs already hold,
attributed to a voice, told in the name the place had that year, and cut into a surface the record says was
standing there. **Wired to nothing**: the five classes are called by the probes and by no game code, which is the
same state step 49 ended in.

## Step 51 - Terra++'s timelines, the tree, and cheap saves (A12, G6, G7, G8, A17)

**Step 51 done: six parts, 251 checks, 0 failed.**

**Part 1, the survey, and it found four holes with nothing behind them.** Branches were a **flat map with a
parent id**: no children, no depth, no ancestry, no cycle check. `setActiveTimelineBranch` was called from
**exactly one place**, at fork time, so **a branch a player left could not be re-entered at all**. The save was
**one whole `state.json`** for a world of 200-odd flags under 20 prefixes from 51 `setFlag` sites. And the only
backup was `backupIntervalMinutes` (30): **a timed copy that does not know what is about to happen.**

**The design, in one sentence:** a branch is a difference from its parent, so the root saves everything once and
every branch saves only what it changed; a branch cannot be entered before it split; and the copy you need before
a big change is the one taken by the code doing the damage.

**Part 2, G8, the cheap save.** `timeline/BranchSave.java`: the root whole, every branch as `changed` +
`removed` + its pins, restored by walking the chain from the root down. A missing parent is refused, a looping
save is refused, and the load-bearing method is `diff`, which compares what the chain restores against a **full**
save key by key and **names the branch whose delta introduced each disagreement**. On the fixture the whole
world's branches cost **22.4%** of saving them whole. 60 checks.

**Part 3, G7, the tree and travel.** `timeline/BranchTree.java`: children, depth, ancestry, orphans and loops
**drawn with a question mark rather than left out**, the book's pages, and the rule that makes travel honest:
**you cannot stand on a branch before it split.** Ask for a branch in 1850 that forks in 1857 and you are put on
the real history, and the trip **says why in words**. A branch with no save cannot be entered however well the
book draws it. 67 checks.

**Part 4, A17, the copy before the change.** `timeline/BeforeChange.java`: copies are taken by the code doing the
damage, **open until the change is answered**, a second of the same kind is refused **naming the open one**
(because the dangerous sequence is "the change went wrong and the copy was overwritten by the next thing"),
rotation **never takes an open copy**, and a **timed copy is explicitly not a before-change backup**. 47 checks.

**Part 5, G6 and A12, the world follows the timeline.** `terrabridge/BranchWorld.java` computes what stands on a
branch from the record and the branch's own statements, behind one narrow `Port` that Terra++ would implement.
With no Terra++, `absent()` **refuses every decision and says so**: a quiet success would make a world that obeyed
indistinguishable from a world never asked. The join is by **name**, which this project distrusts, so it is exact
and case-insensitive after trimming, never fuzzy, **two things with one name are refused as a question**, and
every statement the record cannot place is reported. 45 checks.

**Part 6, the chain** (the sixth part, after the survey). copy before the split -> split -> delta save -> the branch in the tree -> travel into it
and back -> the world on it -> the book's pages -> **the copy that undoes the lot**, restoring the world exactly.
32 checks.

**What was wrong**: `BranchTree.lines()` drew **nothing for a tree that loops** (it started from the roots and
there were none, so a broken save looked like an empty one); `diff` called a full save from a **later year** a
disagreement; `BranchWorld` let a row **the record itself had ended** stand. The last two were caught by the
probes, and two more were the old mistake in new clothes: **the test made a claim about the data instead of
asking the data** (62 of 62 things standing when 6 had ended).

**Wired to nothing.** Four classes, five probes, and not one call from the game. The five places that would join
them are named in `logs/step51_notes.md`.

**Limits**: a delta save is a promise that the state is a map of strings (so a system keeping its own list breaks
it silently); `BeforeChange` writes no files; travel does not move the clock; **universes are steps 53 to 56**;
and `gradle_compile.sh` has still never run, six steps of debt.

## Step 52 - several players, their pockets and their property (A10, A11, A16, F4, F7, F10)

**Step 52 done: seven parts, 329 checks, 0 failed.**

**Part 1, the survey, and decision 3 read before anything was designed.** The plan's own decision settles A11:
*"one shared date and timeline per world; universes are separate dimensions, so players can be in different
universes; time travel moves the world's date **for everyone**, with a vote or operator permission when several
people play."* So the answer is NOT private clocks: `SimulationClockManager`'s single year is right. What was
missing is the standing around it. The survey also found the two axes of "who may do what" already separated:
step 48's **in-world** axis (`PlayerRoles`, `Agency`) and the blunt **server** axis (`hasPermission(2)` on
every command), with no join between them and no rule for several people.

**Part 2, F10, the card.** `player/WhoYouAre`: name, local or traveller, start year and place, the family line
and the kit. The line is checked when the card is made (a parent born after their child is refused, two
relatives with one name are refused) and **never edited after**: the world may end a life and may not rewrite a
birth. A traveller's line is **carried, not recorded**, and the card says which kind of line it holds every
time. `chainToYou` is the list step 53's grandfather question will need. 45 checks.

**Part 3, A16, the server axis.** `player/Permissions`: every act in three kinds - **moves only you** (anyone),
**moves the shared world** (alone you may, with several it takes their vote or an operator), **rewrites what is
recorded** (operators only, alone or not). A vote is of **the people the act moves** and passes only on more
than half of them; a bystander cannot vote; one person has one word; and an operator may act without one or
close one by hand, on the record. 53 checks.

**Part 4, A11, time for several players.** `clock/Clocks`: universes with their own date and timeline, players
standing in exactly one world each, and three rules - a shared date **moves everyone in it**, a player **cannot
move a world they do not stand in** (except by its people's vote), and a **private year in a shared world is
always refused**, with the refusal naming the two ways that do work (another universe, or a moved shared date).
Three players stood in 2960 BC, 1576 and 1900 at once, lawfully. 67 checks.

**Part 5, A10, the saves nobody kept.** `player/PocketSave`: people, purses and notes keyed by
**(universe, branch)**, saved as the difference from the parent pocket like the world's flags (step 51), with
the same refusals (missing parent, loop) and `diff` checked key by key. Three payloads, three rules: **a purse
cannot go below zero** (refused, not clamped), **a note is written once** (appending is the only edit), and the
world may end a life but not rewrite a birth. Five branches cost **55%** of saving every pocket whole. 64 checks.

**Part 6, F4, property per timeline.** `player/Property`: deeds are per (universe, branch) - **the same blocks
on another branch are somebody else's, lawfully**, and each book names the timeline it answers for. One place,
one deed; what is yours you may sell, release or reshape; what is another's needs an operator (confiscation is
recorded with who and why); every change of hands stays in the book. 54 checks.

**Part 7, F7, and the chain.** `player/Together`: two players **share a world or they do not** (same universe
and timeline, and nothing in between); changing history that lasts needs **both axes** saying yes, with the
refusal naming whichever said no; and two hands on one thing **keep the first and refuse the second by name**,
with only an operator able to force it, on the record and saying why. The chain: cards -> standings -> a vote
that moves Delhi for both its people while Cuzco does not stir -> pockets per timeline -> the same blocks owned
differently on different branches -> shared/separate -> the record under it all (the town is **New Delhi** in
the pack, and the probe asks the pack instead of asserting). 46 checks.

**What was wrong**: `chainToYou` walked the line the wrong way and would have handed step 53 the ancestors
*above* the one asked for; `Property`'s owner check fell back to an "only you" action, so **a stranger could
sell, release or reshape anybody's deed**; `PocketSave` stored whole note lists in a delta (109% cost); and
three probe assertions claimed things about the data instead of asking it (2 of 3 IS a majority; the town is
New Delhi). The step's lesson is the running one: assertions check the machinery; only reading checks the claim.

**Wired to nothing.** Six classes, six probes, not one call from the game. The joins are named in
`logs/step52_notes.md`.

**Limits**: a vote has no window; `Together`'s first-touch rule lives only in memory; `Property` has no map and
its `MAX_SIDE` is a game default; `WhoYouAre` holds what the card claims and step 53 must still check it
against the record; **universes are only names until steps 53-56**; `gradle_compile.sh` has still never run.

## Step 57 - the long test walk and fixes (I1, I3, I4, I5, I7, I8, I11)

Step 56 made the ruptured universes reachable and mended. Step 57 measures the whole thing and gives
the performance rows their policy layers.

- **The long test walk (I1).** Spark is a live Minecraft profiler and cannot run here; the walk runs
  here over the shipped registers through the mod's own lookup code: 30 places (every area), 16 years
  (-2500 to 2000), 8 systems, 1,440 calls each, compressed from thirty minutes and honest about it.
  Every lookup average is 25 to 200 times inside the 2 ms budget; worst-call spikes move between
  systems between runs (GC/safepoint pauses) and are **named anyway**. **The loads are the story**:
  the gazetteer loads in 1,388 ms and the ruler register in 1,201 ms on this machine, which is exactly
  what must never run on the game thread.
- **`core/PerfBudget.java` (I1):** budgets as data, each naming its source (a game default, a
  measurement, or Minecraft's own 32,767-byte limit); `check` names every blow in words; no report is
  not a pardon.
- **`core/OffThread.java` (I3):** work is a class, not a place. Loading (measured 1.2-1.4 s),
  planning, path searches, saves and the network run off the game thread; ticking and world writes on
  it. A job on the wrong side is refused by name; a result touches the world only after hand-back.
- **`core/Distances.java` (I4, I5):** one distance table, two readers. Past 128 blocks people,
  vehicles and armies are **numbers only** (the population engine remembers them); the draw thins at 24
  and 64 and hides at 160 or the client's own view, whichever is nearer. The lines are game defaults
  and say so.
- **`network/PacketBudget.java` (I7):** a packet over Minecraft's limit is refused by name and by how
  much ("it is not slow, it never arrives"); a window over the rate budgets (20 packets/s, 200,000 B/s)
  is named in words.
- **`terrabridge/RebuildWait.java` (I8):** the wait while Terra++ rebuilds after a time jump is a
  state, not a stall: queued, rebuilt and left in words; a second wait while one runs is refused;
  more rebuilt than queued invents chunks and is refused; the end says it is over.
- **`core/CacheLimits.java` (I11):** a cache has bytes (64 MB, step 26's budget), evicts oldest first
  and **counts every drop**; an entry bigger than the whole cache is refused; a chunk keeps 12 rebuilt
  years (game default) and the save's line says which copies go past that.

**Limits.** This is not Spark and not the 30-minute live walk: it is a compressed run on this machine
over packed data. The worst-call spikes are pauses (they move between systems between runs) and are
named anyway. The distance lines and rate budgets are game defaults named as such; Minecraft's packet
limit is the one measured fact among them. `AsyncTaskManager` and `PerformanceMonitor` are not
modified; these are the policy layers they would be given. `RebuildWait` does not call Terra++; it is
the state the bridge's rebuild queue would report through.

**Probes.** `probe_step57a.sh` (PerfBudget, 24), `probe_step57b.sh` (the walk, 23), `probe_step57c.sh`
(OffThread, 29), `probe_step57d.sh` (Distances, 28), `probe_step57e.sh` (PacketBudget+RebuildWait, 36),
`probe_step57f.sh` (CacheLimits+chain, 28): 168 checks, 0 failed.

## Step 56 - travel with the way back, repair, and the old campaign (H7, H8, F6)

Step 55 gave a universe its logic and its story. Step 56 makes it reachable, mends it, and tells the
campaign as a story with the fantasy off.

- **`timeline/Passage.java`** is H7: travel between universes, portals and rifts, **and the way back**.
  One crossing books both legs at once ("the way back is booked before the way out"); a return is only
  along your own ticket; nobody is in two universes at once; nobody stands in a universe before it
  ruptured. A rift's ticket is booked too and says it is unstable. `outstanding()` lists who is away
  with the way home each holds: nobody is ever stranded. Travel is a "moves only you" act, so it takes
  no before-change copy: the ticket is the record.
- **`timeline/Repairs.java`** is H8: **rebuilding a fixed point lowers the stress**, in one call that
  cannot do half the work (`FixedPoints.restore` hands the weight back, `Stress.repair` brings the
  counter down). The screen line is the report: "rebuilding X lowered the stress from A to B". The fall
  claimed is the fall that happened, the clamp at zero is reported rather than swallowed, and every
  refusal carries through in `FixedPoints`' own words.
- **`chrononexus/Campaign.java`** is F6 per **decision 7**: the old campaign folded into time travel and
  paradoxes with the fantasy switched off. The story is six stations across the whole timeline (Ur
  -2900 to the far shore 2100), each asking for one act the mod has; walked in any order; a chapter not
  kept is **continued, never failed**; `pressure` is a gauge ("It rises and it falls. Nothing here
  erases you."); endings are words. **A player is never erased; no countdown deletes anybody.** The old
  `ChronoNexusCampaignEngine` keeps its phases and its countdown and nothing calls them.

**Limits.** `RealityRiftController` (particles) and Terra++'s commands are not called; `Passage` is the
rules layer they would use, and a rift's instability is named, not simulated. The counter clamp at zero
is the project's one clamp (step 53), with the unused part said out loud every time. `Campaign` pages
and records; it does not schedule or enforce. The chain's universes, crossings and repairs are test
fixtures; the timeline data is unchanged.

**Probes.** `probe_step56a.sh` (Passage, 30), `probe_step56b.sh` (Repairs, 32), `probe_step56c.sh`
(Campaign, 28), `probe_step56d.sh` (the chain, 23): 113 checks, 0 failed.

## Step 55 - broken logic, and the story in the new universe (H4, H6)

Step 54 gave a ruptured universe its land and its physics. Step 55 gives it its **logic** (H4) and its
**story** (H6).

- **`timeline/BrokenLogic.java`** is H4: a rule set of seven kinds (time runs backwards, eras mixed,
  events loop or come out of order, effects before causes, doubles of famous people, money values upside
  down, scrambled languages), **each naming what it bends** (the reading order, the era tags, the year
  order, the cause graph, the person register, the money values, the words). `make` refuses a rule set
  that breaks nothing, one rule named twice, and a rule set without a why. `diff` checks a reported set
  key by key; a universe that reports nothing is **not a pass**. **Proved or declared:** `scan` proves
  out-of-order, effects-before-causes and doubles from dated entries with cause links, and names the four
  it can never prove, because a scan that finds none proves nothing about them.
- **`story/UniverseStory.java`** is H6's first half: the universe's own **history and people**, keyed
  (universe, place). The mark (recorded or projected) is **computed from the year, never declared**; past
  2026 a line may continue a state but never names a new ruler, person, war, event, disaster, price or
  population (the guardrail refuses by word, in one place: `guardRefusal`); a person is **never
  projected** - the record's people or a named player's AUTHORED people, nothing else; an authored line
  or person must name its author.
- **`story/UniverseBook.java`** is H6's second half and the H4 tie: the **papers and book** of the
  universe (a guarded story is refused by name and the rest of the paper still prints; an empty book
  says so and never fills itself), and `Reading.through(ruleSet)` which bends every surface the way the
  universe's logic says and **names every rule applied** - backwards time reverses the reading order,
  scrambled languages shifts vowels one along (deterministic, named), money upside down reads values
  inverted, eras mixed marks lines from another age, and the three scan-provable kinds are named too
  even though a reader cannot see them.

**Limits.** This mod holds rule sets and surfaces; it does not generate a universe's history (the record
is the parent's, plus what a player authors, plus what the rules bend). The four declared kinds bend
readings deterministically but no scan can prove them; only a check of the universe's reported set can.
Scrambled languages is a toy vowel shift, named as such. The guardrail refuses by keyword and a
projected line that smuggles a ruler without naming one is a writing problem the keyword cannot see. The
chain's universes and stories are test fixtures; the timeline data is unchanged.

**Probes.** `probe_step55a.sh` (BrokenLogic, 57), `probe_step55b.sh` (UniverseStory, 33),
`probe_step55c.sh` (UniverseBook, 29), `probe_step55d.sh` (the chain, 27): 146 checks, 0 failed.

## Step 54 - the rupture check and broken physics (H3, H5)

Step 53 kept paradoxes out of ordinary play. Step 54 handles the two things a rupture is: a new universe
with other land (H3) and broken physics within Minecraft (H5).

- **`terrabridge/LandSpec.java`** is the land spec: `Spec(seaLevel, minY, maxY, upsideDown, mirror, why)`,
  `Mirror{NONE, EAST_WEST, NORTH_SOUTH}`, upside down as "the land's height profile is inverted", one named
  mirrored axis. `earth()` is Terra++'s own fallbacks (63 / -2032..2032) = the unbroken land. `make`
  refuses a sea outside the world, heights outside 16..4096, and a mirror that names no axis. `diff`
  compares key by key and treats a null report as **not a pass**.
- **`timeline/Ruptures.java`** is the register and the check. A universe's changes are **computed** against
  its parent, never declared. A rupture needs its copy taken first (kind RUPTURE, step 51), refuses one that
  changes no land ("a rupture that changes nothing is not a rupture"), and is named once. `check` compares
  what the generator reports with what was asked; with no Terra++ the check says it cannot check and passes
  nothing.
- **`terrabridge/BrokenPhysics.java`** is H5: the nine facts (gravity, fixed or racing sun, light, boiling
  water, exploding beds, extreme weather, strange mobs, floating blocks), **each naming its mechanism** -
  a Minecraft attribute (the Forge `forge:entity_gravity`), a dimension-type flag (`fixed_time`,
  `ambient_light`, `has_skylight`, `ultrawarm`, `bed_works`, `monster_spawn_light_level`), or a mod-side
  rule. Four of the nine are mod-side or half so (a racing sun, extreme weather, floating blocks entirely;
  strange mobs partly) and no screen may say Minecraft applied those. A sun that is both fixed and racing is
  refused; gravity below none is refused.
- **`timeline/RuptureEngine.java`** is the one call, in order: the copy, the universe, its land, its
  physics, and the generator's work checked. A refused rupture closes its copy and leaves nothing behind;
  a lying generator is named in the verdict; an unchecked one says it was unchecked.

**Limits.** This mod refuses and checks, it does not generate: no projection math here (step 34 rule).
"A racing sun" is a mod-side rule (a shortened day), not a dimension flag. "Floating blocks" has no vanilla
flag at all and is wholly mod-side. The physics *settings* reach the `WorldStateManager` flags when the
bridge connects; this step records the spec and what is broken, each fact with its mechanism. A check needs
the generator: no Terra++ means "not checked" and nothing passes. The chain's ruptures are test universes
(1576, 1857, 2026, 2100) with invented land; the timeline data is unchanged.

**Probes.** `probe_step54a.sh` (LandSpec, 38), `probe_step54b.sh` (Ruptures, 33), `probe_step54c.sh`
(BrokenPhysics, 39), `probe_step54d.sh` (RuptureEngine, 32), `probe_step54e.sh` (the chain, 26): 168
checks, 0 failed.

## Step 53 - paradox kinds, fixed points, one counter (H1, H2, G9)

**Step 53 done: six parts, 201 checks, 0 failed.**

**Part 1, the survey, and the model was half-determined already.** A branch is the safe path (step 51), so an
attempt to change the world in place is answered first with *"take it to a timeline branch"*; `clock/TimeTravel`
(step 48) moves the world's date for everyone and duplicates nobody, so **ordinary play makes no paradox at
all**; and G9's row says the rest exactly: events that resist change and become paradoxes **if forced**. The
survey also inventoried the old campaign's `ParadoxLoopController` (a 15-minute countdown that erases players):
the useful part is pressure that accumulates and can be relieved; the erasure fantasy stays off (decision 7).

**Part 2, G9, the fixed points.** `timeline/FixedPoints`: a declared register of dated events, each with why
it is fixed and what forcing costs. **It resists by refusing the in-place change and naming the safe way out**
- no dice, no hidden roll. Forcing breaks it on the record (whose hand, which reason) and hands its weight to
the counter; rebuilding it stands it back up and gives the weight back. 40 checks.

**Part 3, H1, the five kinds.** `timeline/Paradox`: grandfather (end an ancestor before the next of your line
is born - read from the frozen card of step 52 - or undo a traveller's named cause, or destroy a dated fixed
point), causal loop (a thing given before its own origin year, or one the record dates nowhere - **the
technology atlas's own 130 first years** are the origins: paper -300, the compass 1088, printed books 1440),
predestination (your attempt caused the event), meeting yourself (one person stamped twice at one place-year),
and telling the future (telling of a thing before the record knows it). **Every test answers with the paradox
or with the words that clear it**, never with silence: "Daulat died in 1840 and this is 1857: there is nobody
to end". 49 checks.

**Part 4, H2, the one counter.** `timeline/Stress`: one number in named parts (events, people, things,
buildings), every addition carrying who, when, what and why; **repair brings it down** (H8's arithmetic lives
here; its screen is step 56); and Terra++'s broken buildings reach it through one narrow seam, where
`absent()` reports them as **not counted** rather than as zero. **No threshold and no consequence is decided
here**: the counter counts. 39 checks.

**Part 5, the engine.** `timeline/ParadoxEngine`: one call per risky act returning the decision, every paradox
found, and every row booked. Forcing a fixed point is the one act it judges (an operator's hand, per
`Permissions`); every other act stands with its paradox on the books. 42 checks.

**Part 6, the chain.** A dated thing out of the real record (the Red Fort, whose year comes from the pack) ->
an attempt refused and sent to a branch -> **the branch taken cleanly, costing the counter nothing** -> an
operator's force that breaks it and books grandfather kind -> the other four kinds against real years -> and a
rebuild that brings the counter down by exactly the point's weight. 31 checks.

**What was wrong**: `undoAncestor` decided the chain by the earliest-born nearer relation instead of the next
one toward you (so the wrong year cleared); two probe counts forgot the forced-fixed-point row (it is
grandfather kind too); and one bad sed wrote a newline inside a Java string and two blind fixes made it worse
- the cure was to delete the damaged lines and rewrite them.

**Wired to nothing.** Four classes, five probes, not one call from the game. The joins are named in
`logs/step53_notes.md`.

**Limits**: no threshold and no consequence (deliberately); `attemptCaused` cannot observe causality, the
engine states it; origin years are tech-only; the register is declared, not derived from the packs; repairs
clamp at zero and say so (the one clamp in the project, and the doc says why a repair is not a purse);
`gradle_compile.sh` has still never run.

## Step 58 - checking performance mods (I9, I10)

Two small rows, one rule between them: **a check says what it checked**.

**I9, `compatibility/PerformanceMods.java`.** The six performance mods the plan names (Spark,
ModernFix, FerriteCore, Entity Culling, Embeddium, Canary), each with what it does, what in this mod
it touches, a verdict and its reason. The honesty split is the point: this environment has no
Minecraft and no Terra++, so **checked here is not checked live**. Three mods were checked against
this mod's own code paths and pack with confidence (Spark, a profiler that changes nothing;
ModernFix and FerriteCore, whose memory work overlaps nothing this mod does: its registers load
through its own loaders and are not model data). Three change paths this mod uses (Entity Culling
and Embeddium draw the crowds and nameplates; Canary changes when chunk work runs, and the rebuild
wait counts that work), so each owes a **named live test** and nothing is cleared without it. The
pack order is Spark first: measure before you tune.

**I10, `core/PerfGuide.java` + `eternal/HARDWARE_GUIDE.md`.** A hardware and settings guide for
players where every number names its source. The memory floor is **2,496 MB**, computed as 2,048
(Minecraft itself) + 128 (the measured registers, step 26) + 64 (the cache budget) + 256 (headroom);
the comfortable line is 3,520 MB, so "allocate about 4 GB". The recommended view distance is **8
chunks (128 blocks)**, which is exactly this mod's numbers-only line: past it people are counts, and
the population engine still remembers them. `advise` refuses nonsense in a named order (no memory
first, then a view below none, then one past Minecraft's own 32 chunks) and names the shortfall when
memory is under the floor without refusing. The settings table quotes the config's own defaults and
ranges (drawn figures 400 a district is a client budget; the crowd ceiling's own comment says
measure with /debug before raising it).

**Limits.** The three CHECK_LIVE mods are not cleared and step 60 must run their tests. The 2,048 MB
baseline is a game default estimate; only the 128 MB registers and the walk timings are measured.
The guide assumes the shipped distance table (24/64/128/160) and must move with it. No data packs
changed: the manifest stays 132 files (131 shipped) and DATA_CREDITS 187 lines. The chain probe
(`probe_step58d.sh`, 99 checks) covers the numbers, the three players (a laptop, a server, a bad
value refused), the six verdicts, and that the player document agrees with the class.

`gradle_compile.sh` has still never run.

## Step 59 - first steps for new players (J5)

The mod's command tree is several hundred literals deep and until now had no path into it. J5 is
the path: **six first steps**, each naming what to do and the exact command, what it teaches, and
the named fact that counts it done.

**The route (`player/FirstSteps.java`).** (1) Where and when you are, `/ee date`: one shared date
and timeline per world, and this place may use its own calendar. (2) Talk to a person: people stay
while you talk, and what they know is dated to their own time. (3) Your purse, `/ee purse`: money is
everywhere (401 kinds) and a purse cannot go below zero. (4) Buy the history book from a villager:
it is bought, not given, 13 forms by place and year. (5) Look and listen to the era: signs in the
local script, sounds that belong to the year. (6) How time works here: three kinds of act, a branch
is a difference from its parent, and a person moves time only if they may.

**The rules are the project's own.** Notes are written once: a finished step is never un-finished
and there is no reset. The next step is the first one not done, so walking the route out of order is
allowed and the page still shows the path. The graduation line is earned, refused while any step is
left, and claiming it twice says "already graduated: the line was earned once and stands". An
unknown fact is refused by name with the six listed.

**The command (`/ee firststeps`)** is the first module on the `CommandModule` framework, registered
through `CommandModuleRegistry` in `EternalEngineMod`; `/ee help` now opens with the route. The
chain probe (101 checks) also reads the real command tree on disk and checks that every command the
route names exists: a guide that names commands that do not exist is a lie.

**Limits.** Progress is held in memory and does not survive a server restart (the capability layer
is Forge and out of this sandbox's reach); persisting the six facts and marking them automatically
from the real actions is named future wiring in `FirstStepsCommands`'s docstring. `/ee firststeps
done` is the player's own hand meanwhile. If the command tree renames a command, probe part 4 fails
loudly by design. Not a live-game test: step 60 is the real test. No data packs changed: the
manifest stays 132 files (131 shipped) and DATA_CREDITS 187 lines.

`gradle_compile.sh` has still never run.

## Step 60 - your final test in the real game (all)

The plan's own words: this sandbox cannot show a real Terra++ world, the game's picture and true
multiplayer. Look, feel and real speed are checked in your final test. **Step 60 builds the test;
the run is yours, and until a session reports nothing is claimed as passed.**

**The register (`testing/LiveTest.java`): 55 tests in 8 phases.** Pre-flight (the sandbox suite
green first, then `/ee check all` on the server, as the `TEST_CHECKLIST.md` tradition runs it). The
era route: all 31 named place-years of the world-wide test set (§9, turn 96: Ur 2500 BC to Sao
Paulo 2020, six continents, five era bands, "no place or year comes first"), plus the timeline's two
ends (3000 BC: the record begins; AD 3000: everything past 2026 is marked projected and no person,
ruler, war, price or population is invented). Empty land must answer "nobody lives here". The world
sample: 400 random land points in each of 7 years, reported as recorded, estimated or missing. The
looks only a real screen has: the four checks the plan defers here by name (problems 11, 14, 19, 30:
the Xaero's link, the walking-away, the 13 book pictures, Minecraft's trade screen) plus look,
feel and real speed. Performance: the 30-minute Spark walk, step 58's three owed live tests (Entity
Culling in a packed square, Embeddium on the crowd-to-market walk, Canary across a time jump and the
rebuild wait), and the draw budgets at 24/64/128/160 blocks. Guardrails: one shared date for two
players, the projected mark at 2100 and 2500, the purse that cannot go below zero, notes written
once and the branch/ticket rules, fixed points that refuse and name the safe way out, and monsters
staying off. Multiplayer: the world answers the same to everyone, and only who may move time moves
it.

**Every test names its source** (the known-problem number, the system, the plan row), and coverage
is computed from the tests, not typed in. The session script (`eternal/FINAL_TEST.md`) is written
from the register and the probe (498 checks) holds the two in agreement, including that the plan
still defers exactly the four look rows.

**Limits.** **The run is outstanding:** it happens in your game, as the earlier sessions did, and
its results are step 61's input (a failure wants the place, the year, the exact command and what the
screen showed). Known limits in the route (problems 73 and 81) are not failures; the test is that
the game says so honestly instead of inventing. No data packs changed: the manifest stays 132 files
(131 shipped) and DATA_CREDITS 187 lines.

`gradle_compile.sh` has still never run.

## Step 61 - fixes from your test (all), and the project close

The record was yours to choose, and you chose the earlier sessions: `worldfill/TEST_CHECKLIST.md`
and the known-problems table (`SYSTEMS_PLAN.md` part 8, 83 rows) their findings were written into.

**The triage (`testing/Findings.java`): every one of the 83 problems, exactly once, in ten buckets.**
16 fixed in an earlier step and closed. 2 partly fixed with the residue written down (23: commodity
money stays coarse; 42: card descriptions may name a later country). **1 fixed in this step (60:
the town heads' titles wording pass, `TownFacts.prettyTitle`).** 28 handled by a step that has since
completed - re-marked, never assumed fixed: the row names what the completed step built and what
still wants a live look. 4 need a real screen: step 60's deferred looks (11, 14, 19, 30). 15 need
data we do not have (thin name lists, Wikidata gaps, records by hand, region packs). 6 need a fact
check like step 25's. 7 need a Terra++ patch (decision 2: mod-side first; 78 was verified: this mod
never calls the dead code). 2 are old unreviewed code. 2 are the model's own shape as documented
limits (24: one money per place; 81: the three empty test places say so honestly).

**The fix (problem 60).** Wikidata's office names arrive as typed: lower case ("the mayor of
Paris"), shouted, or long. `prettyTitle` title-cases around a small-words rule, keeps the leading
"the " the caller's article logic reads, quiets shouted words, and cuts over-long comma'd titles at
the comma - never inventing, never filling blanks. Two more rows were settled by verification:
82 is stale (`BuildingLife` reads the famous-buildings register now), 78 is Terra++'s tree.

**Limits.** The live look for the four screen rows and the live halves of the HANDLED rows is still
outstanding: that is step 60's run, and its protocol (`eternal/FINAL_TEST.md`) is ready. HANDLED
rows rest on what the named step built, checked where a grep or probe could check it; no deep pass
is claimed. `probe_towns.sh` needs a gradle-built mod (`gradle_compile.sh` has never run) and cannot
run in this sandbox; that pre-existing breakage is unchanged. No data packs changed: the manifest
stays 132 files (131 shipped) and DATA_CREDITS 187 lines. The chain probe (`probe_step61d.sh`,
469 checks) holds the register's arithmetic, the fix's wording cases and both verifications.

**The real build's nine errors (turn 216).** Your gradle run compiled the mod fully for the first
time and found nine errors; all fixed: `List` and `Nullable` imports, `SoundEvents.ELYTRA_LOOP` is
not a 1.20.1 name (now `ELYTRA_FLYING`), a long-to-int cast clamped at `Integer.MAX_VALUE`, a call
to `com.eternalengine.Project` that never existed (now `TerraCoordinateHelper.toGeo`, with the
index order corrected: toGeo returns [longitude, latitude], so the old code was about to hand
longitude to `lat`), and `WarGearStacks.firstInTag` rewritten on the tag API the build already
proves (`TagKey.create` plus an `ItemStack.is` scan, cached). Details in `logs/step61_notes.md`.

**The real build's second round (turn 217).** Eight lambda-capture errors in `EternalEngineCommands`
(a local mutated elsewhere in its method but captured by `sendSuccess(() -> ...)`): `good` in the
workshop, diet, shortage and prices answers, and `place` in the prices answer (it is reassigned by
`geoOf(source)`). All fixed with a `final` copy taken at the point of capture. The first build never
showed these because that check runs only after successful attribution. The set is exhaustive (the
check reports all such errors in one pass). Details in `logs/step61_notes.md` part 7.

**The real build's first run (turn 218).** The mod ran: a jump to Hyderabad 1948 landed on
Operation Polo, TradeDesk sold wheat, the money-changer minted coins, paper changed hands.
`/ee check all`: 434 passed, 4 FAILED, 11 known limits. All four failures are fixed:

1. **A famine hit everybody alike** (`Needs.growsFood`): the function matched the twelve kinds of
   work ("farming") but every caller passes plain names ("farmer"), so nobody was ever a food
   grower and the Kanki famine of AD 1229 hit a farmer and a weaver the same. It now matches both
   vocabularies and the craft names villagers carry.
2. **The hand-written disaster supplement said 75, holds 79**: the check constant is 79 and the
   pack's title is now derived from its row count (it had drifted to "sixty-three events").
3. **`prices.json.gz` is non-commercial** (Allen and Unger, CC BY-NC 4.0): plan decision 4 keeps
   its rule and takes one named exception, printed as a known limit on every check run. Any other
   non-commercial file fails the check.
4. **The data was 470 KB over the 64 MiB budget**: the six packs that still shipped as plain JSON
   (`deccan_rulers`, `present_telangana`, `events_world`, `present_hyderabad_metro`,
   `present_kamareddy`, `deccan_events`) now ship gzipped like every other big pack - same data,
   131 shipped files now 54,877,426 bytes, 12 MB under the budget.

**Verified in the real game (turn 219):** `/ee check all` on a fresh world reports 438 passed,
0 failed, 12 known limits (the 12th is the printed prices exception). All four fixes confirmed
live; run notes are triaged in `logs/step61_notes.md` part 8 and `TEST_CHECKLIST.md`.

## Step 62: history at your feet (the wiring phase, part 1, turn 220)

The user's verdict on the turn-218/219 builds was plain: *"i don't see any difference from now and
previous version"*. It was right: those rounds changed check wording and data packing, and the
deep systems of steps 48-57 are marked "wired to nothing: no call from the game". The wiring phase
exists to fix that: take what the probes proved and put doors on it a player can open.

**Part 1 is the reading** (`here/HereAndNow.java`, 371 checks, `probe_here.sh`): stand at a point
in a year and get the page the registers already held - the place and its name this year
(Shahjahanabad in Delhi 1650, Beiping until 1403), its people ("About 9.2 million people live in
Hyderabad"), its head ("Trajan is the Roman Emperor (since 98)"), its ruler ("Mughal Empire
(1556 to 1740)"), what the record of these years names hereabouts ("Operation Polo (Hyderabad)
(0.6 km away)"), and whose land the border data counts it. Two doors in the game: **`/ee here`**
prints the page, and **`/ee year set`** answers with the one-line form at once ("It is 1500.
Golconda, under Vijayanagara Empire."). Empty places say nobody as nobody; the AD 3000 guardrail
holds (no projected people, any ruler named past the record is marked "an estimate").

**Limits (step 62 part 1):** it is a page and two doors, not the world acting (parts 2-4 are the
arrival line, the visible acting-out, and the `/ee check all` row; requirements 5-6's visible
doors are step 63); the reading is only as wide as the packs (event names are the harvest's own
sentences; border civ ids print raw; two registers beside each other can surprise and are never
merged); reading output found three defects the assertions had not (a throwing `EventNews` stub
now carries the real pure `articleFits` body, "stretches past the record" wording was wrong and
now says "marks as an estimate", pack ids are tidied for display only); and the command paths are
checked here, not live, until the user rebuilds. Full record: `logs/step62_notes.md`.

**Turn 221 (the latest run's three doubts, all fixed):** NPCs at 17.4346, 78.5016 in 3000 BC were
the HYDE population grid's thin modelled presence, which the reading did not know about - it now
reads the same layer and marks it ("a modelled presence, not a measurement"), so the page and the
people agree. Most NPCs stood still because `settleDistant` settled everyone in reach, taking away
the walk goal `routineStep` had just promised them ("in somebody's sight: let them walk for real"):
now only the frozen are settled and the living walk near you. Few talk options, because "Who rules
here?" needed a knowledge card: now the ruler and place questions and a new "Where am I, and what
year is it?" are always answered, from the registers where no card exists. `probe_here.sh` 391
checks. Triage and what to see in the game: `TEST_CHECKLIST.md` turn 221.

## The runtime test program (turns 222-225)

The user's ask: *"a program for runtime tests of every aspect of the project where /ee test or /ee
check is the input and i will give you world file"*, singleplayer, **in-game only, zero installs**,
and then the rules that shaped it: the test **takes its own screenshots** ("I SAID YOU TAKE THE
SCREENSHOTS when testing in runtime"), screenshots are how anything gets **seen** ("if you want to
see anything use screenshots to achieve it"), and there is **no separate photo command** ("no need
separate command like /ee test photos").

**What the player runs:**

| Command | What it does |
|---|---|
| `/ee test everything` | The full runtime suite: engines (its `/ee check all` counters in the report), commands, places (the plan's spot-years including the turn-221 doubt point at 3000 BC), living (who within 32 blocks can walk) - then **the camera pass**, which writes `eternal_photo_report.txt` / `.json` beside `eternal_runtime_report.json` / `.txt` |
| `/ee test movement` (twice, 5 s apart) | Real motion, not only goal state: who moved more than two blocks |
| `/ee check all` | The whole-project check; writes nothing (P2's rule) |

**The camera pass** (inside `/ee test everything`, about five more minutes): your view (two frames),
the sky at noon and midnight (the clock is put back), the 31 era stops R1-R31 (the year is set, you
are teleported, and the test pilot **walks you through a loop of each stop** so the frames are
catched mid-stride and every system that reacts to a walking player is exercised; two frames per
stop), and last the screens book page (`etest_book_accents.png`, accents, wrapping, GUI scale - the
book is last because its open screen would fill every later frame). At every stop the photo report
also records live reads of the **wheat price, credit terms and ruler** at that place-year (the user:
the pilot is "for testing at multiple areas and time other features and system"). **Any movement
key press cancels the pilot instantly**; it only moves when the test asks. All frames go to the game's own
`screenshots/` folder as `etest_*.png`; every frame is judged in the workspace against the data
packs when the folder arrives. The run never starts twice at once.

**The wall items get in-run alternatives (turn 227):** frame smoothness is **measured, not
felt** - every shot's fps and client tick ms land in `etest_perf.txt` beside the frames, and every
era-stop line carries server tick ms; hours of play is compressed into the **day-pass** (one full
day round borrowed, every system asked again, the day given back); mid-session change needs no
agent because the suite is the mid-session actor (years, teleports, walking, the book). **What is
left to humans:** a real second multiplayer player (the run exercises talk and trade with NPCs as
counterparty instead), the feel of many real hours of play, and the four NEEDS_A_REAL_SCREEN rows
settled by the frames *when they arrive*, not before. **Three mapping gambles** ride on the next
rebuild and are one-line fixes if named: vanilla's `Screenshot.grab`, `ServerLevel.setDayTime`, and
the pilot's client fields (`options.keyUp` family, `yBodyRot`/`yHeadRot`).
**Not yet built:** `worldfill/runtime/read_world.py` (the world-save reader, first in the order of
work), the scenario tests (E economy day, P famine week, then T fork and X paradox after step 63),
`EeCommandSelfTest` counters, and regression guards for the 83 Findings rows. Design and order of
work: `worldfill/runtime/TEST_PLAN.md`; runbook: `worldfill/TEST_CHECKLIST.md` (turn 225 is current;
the command tables in turns 223-224 are history).

## Project state (steps 21-61)

The plan's 43 steps are complete as planned work: built, sandbox-tested, written down with their
limits. What remains is named, not hidden: `Findings.page()` is the backlog (the ten buckets),
`eternal/FINAL_TEST.md` is the real-game test still to run, and `gradle_compile.sh` has still never
run. The one data-licence exception (prices.json.gz, non-commercial) is named, printed every check
run, and documented in `logs/step61_notes.md` part 8. **The wiring phase (step 62 onward)** is the
answer to "no visible difference": part 1 (the reading, `/ee here`) is done; parts 2-4 and step
63 (timeline fork and paradox doors) are named in `logs/step62_notes.md`.

Historical report snapshot is archived as XZ with raw/archive hashes and guarded restoration via `archived_history_reports.py`. The original scripts still write newly generated reports to their original paths.

### Archived sample check logs (2026-11-03)
The original October sample logs `sample_ee_check_all_log.txt` and `sample_ee_check_all_player_log.txt` are losslessly archived as `.txt.xz` to conserve space. `python3 archived_history_reports.py NAME` verifies each, and `--restore` restores its original path only when there is enough space and no existing file. Their exact uncompressed and XZ hashes are in that helper. These are historical samples, not current live tests.

The historical `data_use_probe.json` output above is now stored as `data_use_probe.json.xz`; `archived_history_reports.py data_use_probe.json` checks it, and `--restore` is subject to storage and no-overwrite guards.

`build_places_report.json`, the historical generated report from `build_places.py`, is archived as `.json.xz`; `python3 worldfill/archived_history_reports.py build_places_report.json` verifies it, and `--restore` requires space and refuses overwrite. The generator still writes its original path.

Storage note: the historical generated `PRODUCT_ATLAS_TABLE.md` is archived as `.md.xz`. Use `python3 worldfill/archived_history_reports.py PRODUCT_ATLAS_TABLE.md --print` to read verified bytes, or `--restore` when space permits. Generators still write the original path; the archive does not overwrite it.

Storage note (2026-11-03): the generated historical `fact_audit_summary.json` is preserved as `fact_audit_summary.json.xz`; use `archived_history_reports.py fact_audit_summary.json --print` or `--restore` (space permitting). The generator still writes the original path.
