import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2850To2810Probe {
 static void ok(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void test(HistoryGazetteer g,String id,int start,int end,double lat,double lon,boolean regional,String caveat){
  var rs=g.allEvents().stream().filter(e->e.id().equals(id)).toList();ok(rs.size()==1,"ID "+id);var e=rs.get(0);
  ok(e.start()==start&&e.end()==end&&e.name().contains(caveat),"date/name "+id);ok(e.kind().equals("cultural")&&e.effect().equals("note")&&HistoryGazetteer.isRegional(e)==regional,"kind "+id);
  ok(g.eventsNear(lat,lon,start,.01).stream().anyMatch(h->h.event().id().equals(id)),"start "+id);ok(g.eventsNear(lat,lon,end,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  if(regional)ok(g.nearestLocalEvent(lat,lon,start).stream().noneMatch(h->h.event().id().equals(id)),"regional local "+id);
  ok(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==start&&n.end()==end-1).count()==1,"news "+id);
 }
 public static void main(String[] args){
  var g=HistoryGazetteer.get();
  test(g,"r2_shahr_sukhteh_c3000",-3000,-2619,30.59528,61.32639,false,"dates approximate");
  test(g,"wpy_d5d3fad419",-2832,-2831,37.5,-118.5,true,"age disputed");
  test(g,"wpr_0f1699c278",-2852,-2851,32.6128,113.5392,true,"not verified history");
  test(g,"r2_miaodigou_ii_regional_context",-3000,-2599,34.721,111.104,true,"classification debated");
  for(int y:new int[]{-2850,-2840,-2830,-2820,-2810}){
   int year=y;ok(g.eventsNear(30.59528,61.32639,y,.01).stream().anyMatch(h->h.event().id().equals("r2_shahr_sukhteh_c3000")),"Shahr "+year);
   ok(g.eventsNear(34.721,111.104,y,.01).stream().anyMatch(h->h.event().id().equals("r2_miaodigou_ii_regional_context")),"Miaodigou "+year);
  }
  System.out.println("PASS: batch archaeological contexts and two corrected references; Gazetteer and NewsIndex headless");
 }
}
