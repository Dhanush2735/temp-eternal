import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1400To1360Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==(id.equals("wpy_8ff1461c2d")||id.equals("wpd_41531029f4")?2:1),"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_3d541893df",-1400,-1399,25.72056,32.61028,false,"uncertain");
  e(g,"wpy_c29afda1bd",-1370,-1369,55.62833,9.2825,false,"1370 BC");
  e(g,"wpy_2ca1be7d69",-1370,-1369,35.05889,24.7925,false,"uncertain");
  e(g,"wpy_8ff1461c2d",-1380,-1379,36.75498,24.50458,false,"uncertain");
  e(g,"wpr_04f693a1c3",-1400,-1399,35.29806,25.16306,false,"uncertain");
  e(g,"wpd_70da390dbb",-1400,-1399,35.602,35.782,true,"uncertain");
  e(g,"wpd_35a3b918f1",-1400,-1399,35.602,35.782,true,"uncertain");
  e(g,"wpd_41531029f4",-1380,-1379,36.755,24.5046,false,"uncertain");
  e(g,"r2_amenhotep_iii_1390_reference",-1390,-1389,25.72056,32.61028,true,"uncertain");
  e(g,"r2_kadashman_enlil_i_1360_reference",-1360,-1359,32.536,44.42,true,"uncertain");
  System.out.println("PASS 10 reviewed records: Gazetteer and NewsIndex (headless); Phylakopi duplicate retained");
 }
}
