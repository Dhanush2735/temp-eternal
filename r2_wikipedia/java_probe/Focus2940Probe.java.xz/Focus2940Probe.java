import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
/** Full indexed resources and real loaders with stubs; not gameplay. */
public class Focus2940Probe {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
  var g=HistoryGazetteer.get();String id="wpy_9f829b7b30";var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();check(rows.size()==1,"missing/duplicate");var e=rows.get(0);
  check(e.start()==-3300&&e.end()==-2299&&e.name().contains("dates approximate"),"bad period");
  check(HistoryGazetteer.isRegional(e)&&e.kind().equals("cultural")&&e.effect().equals("note"),"bad type");
  for(int year:new int[]{-3300,-2940,-2501,-2300}){
   check(g.eventsNear(30.39556,119.99083,year,.01).stream().anyMatch(h->h.event().id().equals(id)),"missing year "+year);
   check(g.nearestLocalEvent(30.39556,119.99083,year).stream().noneMatch(h->h.event().id().equals(id)),"incorrect local classification");
  }
  for(int year:new int[]{-3301,-2299})check(g.eventsNear(30.39556,119.99083,year,.01).stream().noneMatch(h->h.event().id().equals(id)),"bad boundary "+year);
  check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-3300&&n.end()==-2300).count()==1,"bad news duration");
  System.out.println("PASS: Liangzhu period indexed for 2940 and original 2501; regional, proper bounds, headless");
 }
}
