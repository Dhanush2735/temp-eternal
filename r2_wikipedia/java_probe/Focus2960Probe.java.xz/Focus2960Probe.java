import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
/** Full index and actual loader classes, with minimal stubs; not gameplay. */
public class Focus2960Probe {
 static void check(boolean v,String m){if(!v)throw new AssertionError(m);}
 public static void main(String[] args){
  var g=HistoryGazetteer.get();String id="wpy_df3135a5e0";var r=g.allEvents().stream().filter(e->e.id().equals(id)).toList();check(r.size()==1,"missing/shared event");var e=r.get(0);
  check(e.start()==-3100&&e.end()==-2899&&e.name().contains("dates vary"),"wrong context interval");
  check(HistoryGazetteer.isRegional(e),"not regional");
  for(int year:new int[]{-3000,-2970,-2960,-2900}){
   check(g.eventsNear(37.0,25.16667,year,.01).stream().anyMatch(h->h.event().id().equals(id)),"year missing "+year);
   check(g.nearestLocalEvent(37.0,25.16667,year).stream().noneMatch(h->h.event().id().equals(id)),"incorrect local classification");
  }
  check(g.eventsNear(37,25.16667,-2899,.01).stream().noneMatch(h->h.event().id().equals(id)),"wrong exclusive end");
  check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-3100&&n.end()==-2900).count()==1,"NewsIndex interval");
  System.out.println("PASS: Cycladic period available in 2960 and 3000, regional-only; NewsIndex end correct (headless)");
 }
}
