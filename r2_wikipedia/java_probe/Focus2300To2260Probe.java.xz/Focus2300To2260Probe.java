import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2300To2260Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_8358910ec4",-2300,-2249,29.0,70.5,true,"dates approximate");
  e(g,"wpy_4dbdb5bae1",-2300,-2199,50.15,14.35417,true,"dates approximate");
  e(g,"wpy_02652cd455",-2300,-2299,29.241473,30.916729,true,"canal dates disputed");
  e(g,"r2_kerma_early_context",-2500,-2199,19.6008,30.40973,true,"dates approximate");
  e(g,"r2_caral_late_24th_23rd_context",-2299,-2249,-10.89361,-77.52028,false,"dates approximate");
  e(g,"r2_rimush_akkad_reign_context",-2279,-2269,32.0,45.5,true,"one approximate chronology");
  e(g,"r2_manishtushu_akkad_reign_context",-2270,-2254,32.0,45.5,true,"one approximate chronology");
  e(g,"r2_enheduanna_ur_disc_reference",-2300,-2299,30.96165,46.10513,false,"date approximate");
  for(int y:new int[]{-2300,-2290,-2280,-2270,-2260}) {
   ck(g.eventsNear(29.0,70.5,y,.01).stream().anyMatch(h->h.event().id().equals("wpy_8358910ec4")),"Harappan "+y);
   ck(g.eventsNear(50.15,14.35417,y,.01).stream().anyMatch(h->h.event().id().equals("wpy_4dbdb5bae1")),"Unetice "+y);
   ck(g.eventsNear(19.6008,30.40973,y,.01).stream().anyMatch(h->h.event().id().equals("r2_kerma_early_context")),"Kerma "+y);
   String caral=y==-2300?"r2_caral_continuation_context":"r2_caral_late_24th_23rd_context";
   ck(g.eventsNear(-10.89361,-77.52028,y,.01).stream().anyMatch(h->h.event().id().equals(caral)),"Caral "+y);
  }
  ck(g.eventsNear(31.4653,30.3667,-2300,.01).stream().noneMatch(h->h.event().id().equals("wpy_02652cd455")),"old Nile Delta pin");
  System.out.println("PASS: eight qualified records; Gazetteer and NewsIndex; headless");
 }
}
