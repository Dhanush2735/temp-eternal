import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import java.util.*;

/** Full indexed resources and actual loader classes; no Minecraft runtime. */
public class Focus3000Probe {
  static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
  static void event(HistoryGazetteer g,String id,String text,double lat,double lon,boolean regional){
    eventAt(g,id,text,lat,lon,regional,-3000);
  }
  static void eventAt(HistoryGazetteer g,String id,String text,double lat,double lon,boolean regional,int year){
    var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();
    check(rows.size()==1,"missing/duplicate ID "+id);var e=rows.get(0);
    check(e.start()==year&&e.end()==year+1,"year slot changed "+id);
    check(e.name().contains(text)&&e.name().startsWith("c. "+(-year)+" BC:"),"wrong name "+id);
    check(Math.abs(e.lat()-lat)<.00001 && Math.abs(e.lon()-lon)<.00001,"wrong coordinates "+id);
    check(HistoryGazetteer.isRegional(e)==regional,"wrong regional flag "+id);
    if (regional) check(g.nearestLocalEvent(lat,lon,year).stream().noneMatch(h->h.event().id().equals(id)),"regional event presented as local "+id);
    check(e.kind().equals("cultural") && e.effect().equals("note"),"wrong event kind/effect "+id);
    check(g.eventsNear(lat,lon,year,.01).stream().anyMatch(h->h.event().id().equals(id)),"spatial/year index misses "+id);
    var news=NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==year&&Math.abs(n.lat()-lat)<.00001&&Math.abs(n.lon()-lon)<.00001).toList();
    check(news.size()==1 && news.get(0).end()==year,"NewsIndex missing or wrong end "+id);
  }
  static void cycladicPeriod(HistoryGazetteer g){
    String id="wpy_df3135a5e0";var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();
    check(rows.size()==1,"missing/duplicate Cycladic period");var e=rows.get(0);
    check(e.start()==-3100&&e.end()==-2899&&e.name().contains("Grotta–Pelos")&&e.name().contains("dates vary"),"Cycladic chronology/caveat");
    check(HistoryGazetteer.isRegional(e)&&e.kind().equals("cultural")&&e.effect().equals("note"),"Cycladic classification");
    check(g.eventsNear(37.0,25.16667,-3000,.01).stream().anyMatch(h->h.event().id().equals(id)),"Cycladic period missing in 3000");
    check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-3100&&n.end()==-2900).count()==1,"Cycladic news duration");
  }
  static void dholaviraPeriod(HistoryGazetteer g){
    String id="r2_dholavira_early_c3000";var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();
    check(rows.size()==1,"missing/duplicate Dholavira period");var e=rows.get(0);
    check(e.start()==-3000&&e.end()==-2599&&e.name().contains("Dholavira")&&e.name().contains("chronology debated"),"Dholavira chronology/caveat");
    check(!HistoryGazetteer.isRegional(e)&&e.kind().equals("cultural")&&e.effect().equals("note"),"Dholavira classification");
    check(g.eventsNear(23.88861,70.21364,-3000,.01).stream().anyMatch(h->h.event().id().equals(id)),"Dholavira absent at 3000");
    check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-3000&&n.end()==-2600).count()==1,"Dholavira news duration");
  }
  static void shahrPeriod(HistoryGazetteer g){
    String id="r2_shahr_sukhteh_c3000";var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();
    check(rows.size()==1,"missing Shahr period");var e=rows.get(0);
    check(e.start()==-3000&&e.end()==-2619&&e.name().contains("dates approximate"),"Shahr chronology");
    check(!HistoryGazetteer.isRegional(e)&&e.kind().equals("cultural")&&e.effect().equals("note"),"Shahr classification");
    check(g.eventsNear(30.59528,61.32639,-3000,.01).stream().anyMatch(h->h.event().id().equals(id)),"Shahr at 3000");
    check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-3000&&n.end()==-2620).count()==1,"Shahr news duration");
  }
  public static void main(String[] args){
    var g=HistoryGazetteer.get();
    event(g,"wpy_23394c2b6a","Mound of the Hostages",53.57944,-6.61167,false);
    event(g,"wpy_88f05a4abb","A-Group culture",22.73056,32.00306,false);
    event(g,"wpr_28f26bb88f","dams and reservoirs",32.335,37.00333,false);
    event(g,"wpy_73ad8709b2","uncertain",51.17889,-1.82611,false);
    event(g,"r2_bryn_celli_ddu_c3000","Bryn Celli Ddu",53.2077,-4.2361,false);
    cycladicPeriod(g);
    event(g,"wpy_edef47079c","Helladic cultures",37.4,22.3,true);
    event(g,"wpr_b37a490265","Bronze Age cultures",39.0,25.0,true);
    event(g,"wpr_de1403e5a5","dates are uncertain",-33.86778,151.21,true);
    event(g,"r2_knossos_early_minoan_c3000","Knossos",35.29806,25.16306,false);
    event(g,"r2_harappa_ravi_c3000","Harappa",30.62889,72.86389,false);
    dholaviraPeriod(g);
    shahrPeriod(g);
    event(g,"r2_supe_valley_c3000","Supe Valley",-10.89361,-77.52028,true);
    event(g,"r2_valdivia_coast_c3000","Valdivia culture",-2.36528,-80.65361,true);
    event(g,"wpy_75cae27825","Puerto Hormiga",10.25861,-75.34611,true);
    event(g,"wpy_d3c69e6bff","Naqada culture",25.90167,32.72417,true);
    event(g,"wpy_0155748eec","Newgrange",53.69473,-6.47557,false);
    event(g,"wpr_17d9b47607","camel evidence",29.638,31.2209,true);
    eventAt(g,"wpy_5d4804a20a","wheat",36.4,118.4,true,-2600);
    check(g.eventsNear(53.351,-7.921,-3000,.01).stream().noneMatch(h->h.event().id().equals("wpy_23394c2b6a")),"Tara still indexed at old wrong location");
    check(g.eventsNear(4.0,-73.25,-3000,.01).stream().noneMatch(h->h.event().id().equals("wpy_75cae27825")),"Puerto Hormiga still at old Colombia location");
    check(g.eventsNear(32.8,35.6,-3000,.01).stream().noneMatch(h->h.event().id().equals("wpy_5d4804a20a")),"China wheat still in Levant at 3000 BCE");
    check(g.eventsNear(36.4,118.4,-3000,.01).stream().noneMatch(h->h.event().id().equals("wpy_5d4804a20a")),"China wheat incorrectly present in 3000 BCE");
    System.out.println("PASS: 19 reviewed 3000 BCE rows and one 2600 BCE correction indexed in Gazetteer and NewsIndex; old locations rejected (headless, no gameplay)");
  }
}
