import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2350To2310Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_5d84896301",-2350,-2349,34.54944,40.89,false,"chronology approximate");
  e(g,"wpr_275ba50b29",-2350,-2349,32,45.5,true,"chronology debated");
  e(g,"wpr_6e541442c9",-2350,-2349,32,46,true,"chronology approximate");
  e(g,"wpr_f804b92046",-2354,-2344,53.4,-8,true,"cause uncertain");
  e(g,"wpr_6053ddb7bb",-2345,-2180,29.638,31.2209,true,"one approximate chronology");
  e(g,"wpr_1a396908c8",-2334,-2278,32,46,true,"one approximate chronology");
  e(g,"wpr_c99c90fe8d",-2334,-2333,32,45.5,true,"dating approximate");
  e(g,"wpy_e3211aa207",-2334,-2333,33.1,44.1,true,"chronology approximate");
  e(g,"wpr_36dd7c7369",-2300,-2299,30.96165,46.10513,false,"date approximate");
  e(g,"r2_caral_continuation_context",-2499,-2299,-10.89361,-77.52028,false,"dates approximate");
  e(g,"r2_mature_harappan_continuation_context",-2499,-2300,29,70.5,true,"dates approximate");
  e(g,"r2_teti_egypt_reign_context",-2345,-2332,29.845,31.251,true,"one approximate chronology");
  for(int y:new int[]{-2350,-2340,-2330,-2320,-2310}) {
   ck(g.eventsNear(-10.89361,-77.52028,y,.01).stream().anyMatch(h->h.event().id().equals("r2_caral_continuation_context")),"Caral "+y);
   ck(g.eventsNear(29,70.5,y,.01).stream().anyMatch(h->h.event().id().equals("r2_mature_harappan_continuation_context")),"Harappan "+y);
  }
  ck(g.allEvents().stream().filter(x->x.id().equals("hz_9da164ef05")&&x.start()==-2310&&x.effect().equals("disruption")).count()==1,"GVP hazard retained");
  ck(g.eventsNear(29.0,41.0,-2350,.01).stream().noneMatch(h->h.event().id().equals("wpr_f804b92046")),"old Middle East pin");
  System.out.println("PASS: twelve qualified records; Gazetteer and NewsIndex; headless");
 }
}
