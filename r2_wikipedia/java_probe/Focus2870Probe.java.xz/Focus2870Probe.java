import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2870Probe {
 static void ok(boolean b,String m){if(!b)throw new AssertionError(m);}
 static HistoryGazetteer.Event row(HistoryGazetteer g,String id){var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();ok(rows.size()==1,id+" count");return rows.get(0);}
 public static void main(String[] args){
  var g=HistoryGazetteer.get();var d=row(g,"r2_dholavira_early_c3000");
  ok(d.start()==-3000&&d.end()==-2599&&d.name().contains("chronology debated"),"Dholavira dates");
  ok(d.kind().equals("cultural")&&d.effect().equals("note")&&!HistoryGazetteer.isRegional(d),"site note classification");
  ok(g.eventsNear(d.lat(),d.lon(),-2870,.01).stream().anyMatch(h->h.event().id().equals(d.id())),"Dholavira not in 2870 spatial index");
  ok(g.eventsNear(d.lat(),d.lon(),-2599,.01).stream().noneMatch(h->h.event().id().equals(d.id())),"Dholavira exclusive end");
  ok(NewsIndex.all().stream().filter(n->n.name().equals(d.name())&&n.start()==-3000&&n.end()==-2600).count()==1,"Dholavira news");
  var c=row(g,"wpr_c568ec23c5");ok(c.start()==-2874&&c.end()==-2873&&c.name().contains("One proposed")&&c.name().contains("date uncertain"),"calendar");
  ok(c.kind().equals("cultural")&&c.effect().equals("note")&&HistoryGazetteer.isRegional(c),"calendar classification");
  ok(g.eventsNear(c.lat(),c.lon(),-2874,.01).stream().anyMatch(h->h.event().id().equals(c.id())),"calendar missing");
  ok(g.eventsNear(c.lat(),c.lon(),-2900,.01).stream().noneMatch(h->h.event().id().equals(c.id())),"calendar old date remains");
  ok(NewsIndex.all().stream().filter(n->n.name().equals(c.name())&&n.start()==-2874&&n.end()==-2874).count()==1,"calendar news");
  System.out.println("PASS: Dholavira 2870 context and Egyptian calendar estimate in indexed loaders; headless");
 }
}
