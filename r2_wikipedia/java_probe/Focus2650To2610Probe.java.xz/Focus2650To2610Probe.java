import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2650To2610Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void event(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var es=g.allEvents().stream().filter(e->e.id().equals(id)).toList();ck(es.size()==1,"id "+id);var e=es.get(0);
  ck(e.start()==st&&e.end()==en&&e.name().contains(caveat),"slot "+id);
  ck(e.kind().equals("cultural")&&e.effect().equals("note")&&HistoryGazetteer.isRegional(e)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end boundary "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  event(g,"wpy_92a5ef9fcd",-2650,-2649,23.88611,70.21667,false,"dating debated");
  event(g,"wpy_caae285631",-2750,-2599,32,45.5,true,"period debated");
  event(g,"wpr_2163f58b67",-2650,-2649,32.12644,45.23338,false,"dating and function uncertain");
  event(g,"wpr_688f334891",-2650,-2649,29.638,31.2209,true,"evidence and dating uncertain");
  event(g,"wpr_2dc753b8b2",-2613,-2497,29.638,31.2209,true,"dates debated");
  for(int y:new int[]{-2650,-2640,-2630,-2620,-2610})ck(g.eventsNear(32,45.5,y,.01).stream().anyMatch(h->h.event().id().equals("wpy_caae285631")),"ED context "+y);
  System.out.println("PASS: five qualified archaeological/history notes in Gazetteer and NewsIndex; headless");
 }
}
