import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus2150To2110Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_260a5e939c",-2157,-2143,31.41139,46.40722,true,"approximate");
  e(g,"wpy_8e54a3a645",-2100,-1999,31.3259,45.6374,true,"uncertain");
  e(g,"wpy_f90966ad2f",-2116,-2115,31.3259,45.6374,true,"uncertain");
  e(g,"wpy_3f95a82df6",-2112,-2093,30.9628,46.1035,true,"approximate");
  e(g,"wpr_8800b2fc4b",-2144,-2123,31.562028,46.177583,true,"approximate");
  e(g,"wpr_067ab2d1cb",-2124,-2123,31.41139,46.40722,true,"disputed");
  e(g,"wpr_c4fade4eab",-2120,-2119,31.562028,46.177583,false,"approximate");
  e(g,"wpr_1c3c4c7f3e",-2138,-2137,30.9628,46.1035,true,"uncertain");
  e(g,"r2_la_erabum_sippar_mace_reference",-2150,-2149,33.058829,44.252153,false,"approximate");
  e(g,"r2_intef_ii_thebes_reign_context",-2112,-2062,25.72056,32.61028,true,"approximate");
  e(g,"r2_shimao_mid_22nd_context",-2150,-2109,38.5657,110.3252,false,"approximate");
  e(g,"r2_taosi_mid_22nd_context",-2150,-2109,35.8906028,111.4971722,false,"approximate");
  e(g,"r2_egypt_first_intermediate_mid_context",-2159,-2109,29.638,31.2209,true,"approximate");
  e(g,"r2_unetice_mid_22nd_context",-2149,-2099,50.15,14.35417,true,"approximate");
  e(g,"r2_kerma_mid_22nd_context",-2149,-2099,19.6008,30.40973,true,"approximate");
  e(g,"r2_caral_mid_22nd_context",-2149,-2099,-10.89361,-77.52028,false,"approximate");
  e(g,"r2_harappan_mid_22nd_context",-2149,-2099,29.0,70.5,true,"approximate");
  e(g,"hz_f90d76e294",-2150,-2149,31.1,35.5,true,"uncertain");
  ck(Disasters.get().loaded(),"disasters loader");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_f90d76e294")),"uncertain quake excluded from disaster loader");
  ck(g.eventsNear(31.41139,46.40722,-2150,.01).stream().anyMatch(h->h.event().id().equals("wpy_260a5e939c")),"Ur-Baba reference");
  System.out.println("PASS: eighteen qualified records; Gazetteer, NewsIndex, and Disasters; headless");
 }
}
