import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1750To1710Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_bd44316362",-1761,-1760,34.54944,40.89,false,"uncertain");
  e(g,"wpr_cf8d9f71bf",-1761,-1760,34.54944,40.89,true,"uncertain");
  e(g,"wpy_1f1222de6a",-1750,-1749,30.786,31.83,true,"uncertain");
  e(g,"wpy_7e0076a0fe",-1720,-1719,30.786,31.83,true,"uncertain");
  e(g,"wpy_8accc5c355",-1740,-1739,29.8,31.3,true,"uncertain");
  e(g,"wpy_d52c606b1f",-1735,-1734,35.45667,43.2625,true,"uncertain");
  e(g,"wpr_2dca19b488",-1750,-1749,35.45667,43.2625,true,"uncertain");
  e(g,"wpr_884eddd248",-1700,-1699,35.45667,43.2625,true,"uncertain");
  e(g,"wpr_aaf76ccaf5",-1500,-1499,30.5,74.5,true,"uncertain");
  e(g,"wpr_3aeaee08e0",-1749,-1711,32.5425,44.42111,true,"uncertain");
  e(g,"wpr_cdca23b7ac",-1750,-1749,56.19806,-159.39083,false,"uncertain");
  e(g,"hz_b4da9ad0a8",-1750,-1749,50.324,155.461,true,"uncertain");
  e(g,"hz_abd7f55c78",-1750,-1749,63.983,-19.666,true,"uncertain");
  e(g,"hz_12274e348b",-1750,-1749,64.9,-22.483,true,"uncertain");
  e(g,"hz_411a905168",-1750,-1749,53.891,-166.923,true,"uncertain");
  e(g,"hz_e236da4079",-1750,-1749,58.172,-155.361,true,"uncertain");
  e(g,"hz_d23301ccac",-1750,-1749,19.475,-155.608,true,"uncertain");
  e(g,"hz_7639a1fd69",-1750,-1749,36.921,138.036,true,"uncertain");
  e(g,"hz_9cf60cb5d9",-1750,-1749,-38.1569,176.5069,true,"uncertain");
  e(g,"hz_7b80660a1e",-1750,-1749,43.418,142.686,true,"uncertain");
  e(g,"hz_06d01bac01",-1750,-1749,55.832,160.326,true,"uncertain");
  e(g,"hz_eef53390c2",-1730,-1729,64.083,-21.416,true,"uncertain");
  e(g,"hz_901bd63cfb",-1720,-1719,33.086,131.249,true,"uncertain");
  e(g,"hz_bd15e7bfae",-1710,-1709,-41.105,-72.496,true,"uncertain");
  e(g,"r2_rim_sin_ii_1740_context",-1742,-1738,31.28583,45.85361,true,"uncertain");
  e(g,"r2_hammurabi_code_1753_reference",-1753,-1752,32.5425,44.42111,true,"uncertain");
  e(g,"r2_kerma_1750_1710_context",-1750,-1709,19.6008,30.40973,true,"uncertain");
  e(g,"r2_erlitou_1750_1710_context",-1750,-1709,34.693,112.689,true,"uncertain");
  e(g,"r2_sechin_alto_1750_1710_context",-1750,-1709,-9.4654,-78.2426,false,"uncertain");
  e(g,"r2_valdivia_1750_1710_context",-1750,-1709,-1.95,-80.72,true,"uncertain");
  e(g,"r2_britain_1750_1710_context",-1750,-1709,51.3,-1.8,true,"uncertain");
  ck(Disasters.get().loaded(),"disasters loader");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_b4da9ad0a8")),"removed hazard hz_b4da9ad0a8");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_abd7f55c78")),"removed hazard hz_abd7f55c78");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_12274e348b")),"removed hazard hz_12274e348b");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_411a905168")),"removed hazard hz_411a905168");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_e236da4079")),"removed hazard hz_e236da4079");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_d23301ccac")),"removed hazard hz_d23301ccac");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_7639a1fd69")),"removed hazard hz_7639a1fd69");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_9cf60cb5d9")),"removed hazard hz_9cf60cb5d9");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_7b80660a1e")),"removed hazard hz_7b80660a1e");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_06d01bac01")),"removed hazard hz_06d01bac01");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_eef53390c2")),"removed hazard hz_eef53390c2");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_901bd63cfb")),"removed hazard hz_901bd63cfb");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_bd15e7bfae")),"removed hazard hz_bd15e7bfae");
  for(int y:new int[]{-1750,-1740,-1730,-1720,-1710})ck(g.allEvents().stream().anyMatch(x->x.id().equals("r2_valdivia_1750_1710_context")&&x.start()<=y&&y<x.end()),"year "+y);
  System.out.println("PASS 31 reviewed records: Gazetteer, NewsIndex, Disasters (headless)");
 }
}
