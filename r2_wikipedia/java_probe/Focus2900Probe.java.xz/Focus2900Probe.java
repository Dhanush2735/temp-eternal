import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2900Probe {
 static void ok(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
  var g=HistoryGazetteer.get();String[] ids={"wpy_c391570504","wpy_519682d05d","wpy_7be5a5ae96","wpy_90456360c7","wpy_e710018ef5"};
  for(int i=0;i<ids.length;i++){
   final String id=ids[i];var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();ok(rows.size()==1,id+" missing/duplicate");var e=rows.get(0);
   ok(e.start()==-2900 && e.end()==(i==0?-2699:-2899),id+" time mismatch");
   ok(e.effect().equals("note")&&e.kind().equals("cultural"),id+" not a context note");
   ok(HistoryGazetteer.isRegional(e)==(i==0||i==2||i==3),id+" wrong regional status");
   ok(g.eventsNear(e.lat(),e.lon(),-2900,.01).stream().anyMatch(h->h.event().id().equals(id)),id+" not spatially visible");
   ok(g.eventsNear(e.lat(),e.lon(),e.end(),.01).stream().noneMatch(h->h.event().id().equals(id)),id+" wrong exclusive end");
   ok(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-2900&&n.end()==e.end()-1).count()==1,id+" wrong news range");
  }
  var ed=g.allEvents().stream().filter(e->e.id().equals(ids[0])).findFirst().orElseThrow();
  ok(ed.activeIn(-2850)&&ed.activeIn(-2700)&&!ed.activeIn(-2699),"period reference boundaries");
  System.out.println("PASS: five 2900 corrections in Gazetteer/NewsIndex, geo/range/effect checks; headless");
 }
}
