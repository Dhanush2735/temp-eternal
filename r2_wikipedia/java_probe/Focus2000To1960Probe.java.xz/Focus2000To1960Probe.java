import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus2000To1960Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_ea791ce370",-2000,-1999,17.4069,103.2414,false,"disputed");
  e(g,"wpy_7ccff70f11",-2000,-1999,19.28167,-103.69111,true,"disputed");
  e(g,"wpy_41cdea47a8",-2100,-1999,21.53083,-105.24722,true,"approximate");
  e(g,"wpy_83ad4a8bc1",-2000,-1999,45.15639,10.79111,true,"uncertain");
  e(g,"wpy_bc4e70f65a",-1900,-1899,35.29806,25.16306,false,"approximate");
  e(g,"wpy_b3f29630bb",-2000,-1949,36.0,138.0,true,"approximate");
  e(g,"wpy_d167a8b1bd",-1999,-1949,29.0,70.5,true,"approximate");
  e(g,"wpy_bb2fcab9b5",-2000,-1999,30.62889,72.86389,false,"disputed");
  e(g,"wpy_932aed2f28",-2000,-1899,27.32917,68.13889,false,"speculative");
  e(g,"wpy_fc667305b9",-2000,-1999,51.17889,-1.82611,false,"uncertain");
  e(g,"wpy_a55af1230d",-2000,-1999,18.2014,121.664,true,"uncertain");
  e(g,"wpy_24012ebb6a",-2000,-1999,48.0,44.0,true,"disputed");
  e(g,"wpy_ead68c6855",-2000,-1999,40.18,44.51,true,"disputed");
  e(g,"wpr_aa0d9f56b9",-2000,-1999,71.233,-179.417,true,"uncertain");
  e(g,"wpr_e1dba9658f",-2000,-1999,27.93139,30.87528,false,"approximate");
  e(g,"wpr_8dd3b24345",-1981,-1951,29.569,31.225,true,"approximate");
  e(g,"wpy_daf6a957ed",-1974,-1934,35.45667,43.2625,true,"approximate");
  e(g,"r2_mentuhotep_iii_reign_context",-2009,-1996,25.72056,32.61028,true,"approximate");
  e(g,"r2_mentuhotep_iv_reign_context",-1997,-1990,25.72056,32.61028,true,"approximate");
  e(g,"r2_shu_ilishu_isin_reign_context",-1985,-1974,31.885,45.26861,true,"approximate");
  e(g,"r2_iddin_dagan_isin_reign_context",-1975,-1953,31.885,45.26861,true,"approximate");
  e(g,"r2_unetice_early_20th_context",-1999,-1949,50.15,14.35417,true,"approximate");
  e(g,"r2_caral_early_20th_context",-1999,-1949,-10.89361,-77.52028,false,"approximate");
  e(g,"r2_sintashta_early_20th_context",-1999,-1949,52.486222,60.188278,true,"approximate");
  e(g,"r2_kerma_early_20th_context",-1999,-1949,19.6008,30.40973,true,"approximate");
  e(g,"r2_shimao_early_20th_context",-2009,-1959,38.5657,110.3252,false,"approximate");
  e(g,"r2_taosi_early_20th_context",-2009,-1959,35.8906028,111.4971722,false,"approximate");
  e(g,"r2_minoan_mm_ia_early_20th_context",-2009,-1959,35.30972,24.89333,true,"approximate");
  for(int y:new int[]{-1990,-1980,-1970,-1960}) ck(g.allEvents().stream().anyMatch(x->x.id().equals("wpy_d167a8b1bd")&&x.start()<=y&&y<x.end()),"Harappan context "+y);
  ck(g.allEvents().stream().anyMatch(x->x.id().equals("r2_harappan_mid_21st_context")&&x.start()<=-2000&&-2000<x.end()),"2000 Harappan");
  System.out.println("PASS: 28 qualified records, Gazetteer and NewsIndex; headless");
 }
}
