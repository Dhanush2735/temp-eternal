import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1300To1260Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()>=1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_5d3b37f303",-1300,-1299,32.63667,-91.41139,false,"uncertain");
  e(g,"wpy_edca273120",-1300,-1299,37.02722,21.695,false,"uncertain");
  e(g,"wpy_5be6dd0a9f",-1260,-1259,-17.8,178.0,true,"uncertain");
  e(g,"wpr_3aca385beb",-1300,-1299,37.73028,22.7575,false,"uncertain");
  e(g,"wpr_34ac1a8a62",-1300,-1299,37.72682,22.75387,false,"uncertain");
  e(g,"wpr_cc6e79716b",-1280,-1279,30.5903,32.5784,true,"uncertain");
  e(g,"wpd_dd8bcabe35",-1300,-1299,53.7625,13.308,false,"uncertain");
  e(g,"wpd_bfa03e2e46",-1300,-1299,51.731,19.3021,true,"uncertain");
  e(g,"wpd_5a050305be",-1260,-1259,-17.8,178.0,true,"uncertain");
  e(g,"hz_0065f2203b",-1300,-1299,0.029,-77.986,false,"uncertain");
  e(g,"hz_bb86fac83c",-1300,-1299,35.361,138.728,false,"uncertain");
  e(g,"hz_5dca4b8c9e",-1300,-1299,19.475,-155.608,false,"uncertain");
  e(g,"hz_7171eee203",-1300,-1299,-16.8412,-179.9644,false,"uncertain");
  e(g,"hz_05187012a3",-1300,-1299,38.404,14.962,false,"uncertain");
  e(g,"hz_2b3b545973",-1300,-1299,39.96,26.24,false,"uncertain");
  e(g,"hz_56d73a6e9e",-1290,-1289,37.77,-25.47,false,"uncertain");
  e(g,"hz_9684f7b6c6",-1290,-1289,63.633,-19.083,false,"uncertain");
  e(g,"hz_c6d2f9768d",-1280,-1279,63.633,-19.083,false,"uncertain");
  e(g,"hz_1781e99308",-1280,-1279,57.167,-170.213,false,"uncertain");
  e(g,"hz_c080eb1bc2",-1270,-1269,32.8849,131.085,false,"uncertain");
  e(g,"hz_b728165490",-1270,-1269,8.808,-82.543,false,"uncertain");
  e(g,"hz_177741c059",-1260,-1259,-6.52,155.62,false,"uncertain");
  e(g,"q1629242",-1270,-1269,34.55781,36.5196,true,"uncertain");
  e(g,"q85745983",-1275,-1265,35.0,33.0,true,"uncertain");
  e(g,"r2_seti_i_1290_context",-1290,-1289,25.72056,32.61028,true,"uncertain");
  e(g,"r2_alaksandu_1280_treaty_context",-1280,-1279,39.96,26.24,true,"uncertain");
  ck(Disasters.get().loaded(),"disasters loaded");
  for(String id:new String[]{"hz_0065f2203b","hz_bb86fac83c","hz_5dca4b8c9e","hz_7171eee203","hz_05187012a3","hz_2b3b545973","hz_56d73a6e9e","hz_9684f7b6c6","hz_c6d2f9768d","hz_1781e99308","hz_c080eb1bc2","hz_b728165490","hz_177741c059"})ck(Disasters.get().all().stream().noneMatch(d->d.id().equals(id)),"removed hazard "+id);
  System.out.println("PASS 26 reviewed records: Gazetteer, NewsIndex, Disasters (headless)");
 }
}
