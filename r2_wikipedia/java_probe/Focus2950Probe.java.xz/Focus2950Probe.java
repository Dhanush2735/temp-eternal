import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
/** Full indexed resources, real loader classes with stubs, not Minecraft. */
public class Focus2950Probe {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void event(HistoryGazetteer g,String id,double lat,double lon,String caveat){
  var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();check(rows.size()==1,"missing/shared "+id);var e=rows.get(0);
  check(e.start()==-2950&&e.end()==-2949&&e.name().contains(caveat),"bad reference "+id);
  check(HistoryGazetteer.isRegional(e)&&e.kind().equals("cultural")&&e.effect().equals("note"),"bad classification "+id);
  check(g.eventsNear(lat,lon,-2950,.01).stream().anyMatch(h->h.event().id().equals(id)),"spatial miss "+id);
  check(g.eventsNear(lat,lon,-2949,.01).stream().noneMatch(h->h.event().id().equals(id)),"wrong exclusive end "+id);
  check(g.nearestLocalEvent(lat,lon,-2950).stream().noneMatch(h->h.event().id().equals(id)),"wrong local classification "+id);
  check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-2950&&n.end()==-2950).count()==1,"bad news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  event(g,"r2_merneith_regency_reference_c2950",26.175,31.9083,"debated");
  event(g,"wpy_96a91ec2ba",16.,-93.,"timing varies");
  System.out.println("PASS: 2950 BCE Merneith and Mesoamerican context in indexed loaders; regional-only and correct interval (headless)");
 }
}
