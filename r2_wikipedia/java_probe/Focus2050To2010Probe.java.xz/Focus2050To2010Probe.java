import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus2050To2010Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_db8ab9c63c",-2050,-2049,19.6008,30.40973,true,"approximate");
  e(g,"wpy_4b64c0191c",-2049,-2048,52.96806,0.52139,false,"inference");
  e(g,"wpy_18f39f0412",-2040,-2039,25.72056,32.61028,true,"uncertain");
  e(g,"wpr_2926aea3f7",-2040,-2039,30.2081,31.071,true,"uncertain");
  e(g,"wpr_38d204150e",-2025,-2003,31.28583,45.85361,true,"disputed");
  e(g,"wpr_fe6d5b677f",-2018,-1984,31.885,45.26861,true,"approximate");
  e(g,"wpr_5605a9718a",-2055,-2003,25.72056,32.61028,true,"approximate");
  e(g,"r2_amar_sin_ur_reign_context",-2046,-2036,30.9628,46.1035,true,"approximate");
  e(g,"r2_shu_sin_ur_reign_context",-2037,-2027,30.9628,46.1035,true,"approximate");
  e(g,"r2_ibbi_sin_ur_reign_context",-2028,-2003,30.9628,46.1035,true,"approximate");
  e(g,"r2_unetice_mid_21st_context",-2049,-1999,50.15,14.35417,true,"approximate");
  e(g,"r2_caral_mid_21st_context",-2049,-1999,-10.89361,-77.52028,false,"approximate");
  e(g,"r2_harappan_mid_21st_context",-2049,-1999,29.0,70.5,true,"approximate");
  e(g,"r2_shimao_mid_21st_context",-2059,-2009,38.5657,110.3252,false,"approximate");
  e(g,"r2_taosi_mid_21st_context",-2059,-2009,35.8906028,111.4971722,false,"approximate");
  e(g,"r2_minoan_mm_ia_mid_21st_context",-2059,-2009,35.30972,24.89333,true,"approximate");
  e(g,"r2_sintashta_mid_21st_context",-2049,-1999,52.486222,60.188278,true,"approximate");
  e(g,"hz_8c3e8bede6",-2050,-2049,33.361,126.53,true,"uncertain");
  ck(Disasters.get().loaded(),"disasters loader");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_8c3e8bede6")),"uncertain Halla excluded from disaster loader");
  ck(g.eventsNear(29.638,31.2209,-1995,.01).stream().noneMatch(h->h.event().id().equals("wpr_5605a9718a")),"unsupported Mentuhotep death removed");
  for(int y:new int[]{-2050,-2040,-2030,-2020,-2010})ck(g.allEvents().stream().anyMatch(x->x.id().equals("wpr_5605a9718a")&&x.start()<=y&&y<x.end()),"year "+y);
  System.out.println("PASS: eighteen qualified records; Gazetteer, NewsIndex and Disasters; headless");
 }
}
