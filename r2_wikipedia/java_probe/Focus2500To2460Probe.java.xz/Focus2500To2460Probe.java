import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2500To2460Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpr_50ac5f8a36",-2500,-2499,35.86958,14.50681,false,"dating and use debated");
  e(g,"wpr_13fafb20ad",-2500,-2499,59.04871,-3.34175,false,"cause unknown");
  e(g,"wpy_69709ab4b6",-2500,-2499,35.45667,43.2625,false,"chronology approximate");
  e(g,"wpr_6a16252650",-2350,-2349,35.798,36.798,false,"dates debated");
  e(g,"wpy_e33cf19e37",-2500,-2399,27.32917,68.13889,false,"dating approximate");
  e(g,"wpy_bbd62646dd",-2500,-2399,51.0,15.0,true,"chronology and origins debated");
  e(g,"wpr_c8845dfc85",-2500,-2499,1.18167,110.46167,true,"dating approximate");
  e(g,"r2_egypt_fifth_dynasty_context",-2498,-2344,29.845,31.251,true,"one approximate chronology");
  ck(g.eventsNear(52.715,39.188,-2500,.01).stream().noneMatch(h->h.event().id().equals("wpy_69709ab4b6")),"old Assur pin");
  for(int y:new int[]{-2490,-2480,-2470,-2460}){
   ck(g.eventsNear(29.845,31.251,y,.01).stream().anyMatch(h->h.event().id().equals("r2_egypt_fifth_dynasty_context")),"Fifth Dynasty "+y);
   ck(g.eventsNear(27.32917,68.13889,y,.01).stream().anyMatch(h->h.event().id().equals("wpy_e33cf19e37")),"Mohenjo-daro "+y);
  }
  System.out.println("PASS: eight qualified records; Gazetteer and NewsIndex; headless");
 }
}
