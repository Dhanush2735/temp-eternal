import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2880Probe {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
  var g=HistoryGazetteer.get();String[] ids={"wpy_b6b2e7d8a7","wpr_b2dc3b122c"};int[] yr={-3000,-2880};
  for(int i=0;i<ids.length;i++){
   final String id=ids[i];var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();check(rows.size()==1,id+" count");var e=rows.get(0);
   check(e.start()==yr[i]&&e.end()==yr[i]+1&&e.name().contains("same tree")&&e.name().contains("date uncertain"),id+" text/date");
   check(e.effect().equals("note")&&HistoryGazetteer.isRegional(e),id+" not regional note");
   check(g.eventsNear(e.lat(),e.lon(),e.start(),.01).stream().anyMatch(h->h.event().id().equals(id)),id+" spatial missing");
   check(g.eventsNear(e.lat(),e.lon(),e.end(),.01).stream().noneMatch(h->h.event().id().equals(id)),id+" exclusive end");
   check(g.nearestLocalEvent(e.lat(),e.lon(),e.start()).stream().noneMatch(h->h.event().id().equals(id)),id+" local wrongly");
   check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==e.start()&&n.end()==e.start()).count()==1,id+" news range");
  }
  System.out.println("PASS: two uncertain references for one Prometheus tree in Gazetteer and NewsIndex; regional; headless");
 }
}
