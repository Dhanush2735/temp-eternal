import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2200To2160Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_86773360e4",-1981,-1974,25.72056,32.61028,false,"uncertain");
  e(g,"wpy_940174a93b",-2180,-2179,32.0,45.5,true,"disputed");
  e(g,"wpy_5f9d4d075d",-2200,-2099,35.30972,24.89333,true,"approximate");
  e(g,"wpy_0634475c07",-2215,-2214,32.0,45.5,true,"uncertain");
  e(g,"wpy_f59927a322",-2218,-2217,-16.0,135.0,true,"disputed");
  e(g,"wpr_2adae19fb6",-2200,-2199,20.58,121.9,true,"uncertain");
  e(g,"wpr_3a2c69b220",-2184,-2183,30.2081,31.071,true,"disputed");
  e(g,"wpr_aed4025ed4",-2184,-2183,30.2081,31.071,true,"disputed");
  e(g,"wpr_cb322cff15",-2184,-2180,30.2081,31.071,true,"uncertain");
  e(g,"wpr_2b5590fdef",-2160,-2159,30.2081,31.071,true,"uncertain");
  e(g,"r2_mawmluh_4_2ka_climate_context",-2200,-2099,25.2622,91.715,false,"uncertain");
  e(g,"r2_egypt_first_intermediate_early_context",-2181,-2159,29.638,31.2209,true,"one chronology");
  e(g,"r2_shu_turul_akkad_reign_context",-2168,-2153,32.0,45.5,true,"approximate");
  e(g,"r2_unetice_early_22nd_context",-2199,-2149,50.15,14.35417,true,"approximate");
  e(g,"r2_kerma_early_22nd_context",-2199,-2149,19.6008,30.40973,true,"approximate");
  e(g,"r2_caral_early_22nd_context",-2199,-2149,-10.89361,-77.52028,false,"approximate");
  e(g,"r2_harappan_early_22nd_context",-2199,-2149,29.0,70.5,true,"approximate");
  e(g,"r2_dudu_akkad_reign_context",-2189,-2167,32.0,45.5,true,"approximate");
  for(int y:new int[]{-2200,-2190,-2180,-2170,-2160}) {
   String suffix=y==-2200?"old":"new";
   String[] ids=y==-2200?new String[]{"wpy_4dbdb5bae1","r2_kerma_early_context","r2_caral_mid_23rd_century_context","r2_harappan_mid_23rd_century_context"}:new String[]{"r2_unetice_early_22nd_context","r2_kerma_early_22nd_context","r2_caral_early_22nd_context","r2_harappan_early_22nd_context"};
   for(String id:ids)ck(g.allEvents().stream().anyMatch(x->x.id().equals(id)&&x.start()<=y&&y<x.end()),"year coverage "+y+" "+id);
  }
  ck(g.eventsNear(25.72056,32.61028,-2200,.01).stream().noneMatch(h->h.event().id().equals("wpy_86773360e4")),"model no longer 2200");
  ck(g.eventsNear(37.0,45.31667,-2215,.01).stream().noneMatch(h->h.event().id().equals("wpy_0634475c07")),"old battlefield pin");
  System.out.println("PASS: eighteen qualified records; Gazetteer and NewsIndex; headless");
 }
}
