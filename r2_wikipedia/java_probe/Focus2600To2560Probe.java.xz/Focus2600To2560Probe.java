import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2600To2560Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_3abf8df06a",-2600,-2599,36.96472,-2.52222,false,"exact dates uncertain");
  e(g,"wpy_87f78c274a",-2570,-2569,32.54028,44.60472,false,"chronology uncertain");
  e(g,"wpy_43e669f564",-2600,-2333,32,45.5,true,"dates debated");
  e(g,"wpy_e850fd55a3",-2600,-2499,32,45.5,true,"dates approximate");
  e(g,"wpy_dd59a2e045",-2600,-2399,35.30972,24.89333,true,"labels differ");
  e(g,"r2_zambujal_chalcolithic_reference_c2600",-2600,-2599,39.07438,-9.28561,false,"date approximate");
  e(g,"r2_enhegal_lagash_reference_c2570",-2570,-2569,31.41139,46.40722,true,"status and date disputed");
  e(g,"r2_mature_harappan_early_context",-2600,-2499,29,70.5,true,"dates approximate");
  e(g,"r2_mesannepada_ur_reference_c2560",-2560,-2559,30.962,46.1047,true,"chronology disputed");
  ck(g.eventsNear(39.07438,-9.28561,-2600,.01).stream().noneMatch(h->h.event().id().equals("wpy_3abf8df06a")),"two Iberian sites separated");
  ck(g.eventsNear(31.41139,46.40722,-2570,.01).stream().noneMatch(h->h.event().id().equals("wpy_87f78c274a")),"two rulers separated");
  ck(g.allEvents().stream().filter(x->x.id().equals("pyramids_giza")&&x.start()==-2560).count()==1,"existing Great Pyramid retained");
  for(int y:new int[]{-2600,-2590,-2580,-2570,-2560})ck(g.eventsNear(29,70.5,y,.01).stream().anyMatch(h->h.event().id().equals("r2_mature_harappan_early_context")),"Indus "+y);
  System.out.println("PASS: nine qualified records, two split locations, Gazetteer and NewsIndex; headless");
 }
}
