import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2700To2660Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void event(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var es=g.allEvents().stream().filter(e->e.id().equals(id)).toList();ck(es.size()==1,"id "+id);var e=es.get(0);
  ck(e.start()==st&&e.end()==en&&e.name().contains(caveat),"slot "+id);
  ck(e.kind().equals("cultural")&&e.effect().equals("note")&&HistoryGazetteer.isRegional(e)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end boundary "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  event(g,"wpy_89c0278a8f",-2700,-2699,32,45.5,true,"dating varies");
  event(g,"wpy_546fcbfa59",-2900,-2599,29.47389,74.12972,false,"dates approximate");
  event(g,"wpy_28463ba207",-2650,-2649,32,45.5,true,"historicity and reign uncertain");
  event(g,"wpr_26c284b6d7",-2667,-2647,29.8711,31.2167,false,"dating varies");
  event(g,"wpr_2134db70df",-2700,-2699,25.09722,32.77944,false,"date approximate");
  event(g,"wpr_fd03c5fe3c",-2698,-2697,32.6128,113.5392,true,"legend, not verified history");
  event(g,"wpr_2c2d0e0c96",-2686,-2612,29.638,31.2209,true,"dating and sequence debated");
  for(int y:new int[]{-2700,-2690,-2680,-2670,-2660})ck(g.eventsNear(29.47389,74.12972,y,.01).stream().anyMatch(h->h.event().id().equals("wpy_546fcbfa59")),"Kalibangan period "+y);
  System.out.println("PASS: seven qualified archaeological/history notes in Gazetteer and NewsIndex; headless");
 }
}
