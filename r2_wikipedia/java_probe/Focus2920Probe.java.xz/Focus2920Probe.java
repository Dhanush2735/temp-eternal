import com.eternalengine.civilization.*;
import com.eternalengine.knowledge.NewsIndex;
/** Full indexed resources and real loaders/hint resolver with stub dependencies; not gameplay. */
public class Focus2920Probe {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void event(HistoryGazetteer g,String id,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();check(rows.size()==1,"missing/shared "+id);var e=rows.get(0);
  check(e.start()==-2920&&e.end()==-2919&&e.name().contains(caveat),"wrong slot or caveat "+id);
  check(e.kind().equals("cultural")&&e.effect().equals("note")&&HistoryGazetteer.isRegional(e)==regional,"bad class "+id);
  check(g.eventsNear(lat,lon,-2920,.01).stream().anyMatch(h->h.event().id().equals(id)),"spatial missing "+id);
  check(g.eventsNear(lat,lon,-2919,.01).stream().noneMatch(h->h.event().id().equals(id)),"bad boundary "+id);
  check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-2920&&n.end()==-2920).count()==1,"news missing "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  event(g,"wpy_cfc31e881d",39.9575,26.23889,false,"dates vary");
  event(g,"r2_anedjib_death_estimate_c2920",26.175,31.9083,true,"debated");
  var rows=g.allSites().stream().filter(s->s.id().equals("pl_550595")).toList();check(rows.size()==1,"Troy site missing/shared");var s=rows.get(0);
  check(s.civHint().isEmpty()&&s.occupiedStart()==-3000&&s.occupiedEnd()==641,"site hint or span wrong");
  check(s.occupiedIn(-2920),"site not indexed in reference year");check(CivHints.resolve(s.civHint(),RulerRegister.get()).isEmpty(),"blank hint incorrectly resolves");
  System.out.println("PASS: Troy and Anedjib notes and Troy site hint in full loaders; hint resolution checked, other fallbacks untested (headless)");
 }
}
