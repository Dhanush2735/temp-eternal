import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2890AkkadianProbe{
 static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
 public static void main(String[] args){
  var g=HistoryGazetteer.get();String[] ids={"wpy_f1bc01ef4a","wpy_7387a2ab6f"};int[] starts={-2600,-2400};
  for(int i=0;i<ids.length;i++){
   final String id=ids[i];var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();ok(rows.size()==1,"missing/duplicate "+id);var e=rows.get(0);
   ok(e.start()==starts[i]&&e.end()==starts[i]+1&&e.name().contains("approximate"),"bad date/name "+id);
   ok(e.effect().equals("note")&&e.kind().equals("cultural")&&HistoryGazetteer.isRegional(e),"bad effect "+id);
   ok(g.eventsNear(e.lat(),e.lon(),e.start(),.01).stream().anyMatch(h->h.event().id().equals(id)),"spatial missing "+id);
   ok(g.eventsNear(e.lat(),e.lon(),e.end(),.01).stream().noneMatch(h->h.event().id().equals(id)),"bad end "+id);
   ok(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==e.start()&&n.end()==e.start()).count()==1,"news "+id);
  }
  ok(g.eventsNear(33.7,43.5,-2890,.01).stream().noneMatch(h->h.event().id().equals(ids[0])),"old date remains");
  System.out.println("PASS: Akkadian reference notes in Gazetteer and NewsIndex; regional/exclusive end; headless");
 }
}
