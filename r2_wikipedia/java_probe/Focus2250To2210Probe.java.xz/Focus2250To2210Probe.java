import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2250To2210Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_3215cd2020",-2240,-2239,33.3,44.4,true,"site and population ranking uncertain");
  e(g,"wpy_c3ca5f6eca",-2220,-2219,60.2487611,-1.5393833,false,"date approximate");
  e(g,"wpr_9b98956b4a",-2250,-2249,29.638,31.2209,true,"reign chronology uncertain");
  e(g,"wpr_79e432a9b1",-2220,-2219,57.0511,-135.76052,false,"date uncertain");
  e(g,"r2_naram_sin_akkad_reign_context",-2255,-2217,32.0,45.5,true,"one approximate chronology");
  e(g,"r2_shar_kali_sharri_akkad_context",-2218,-2192,32.0,45.5,true,"one approximate chronology");
  e(g,"r2_naram_sin_stele_sippar_reference",-2250,-2249,33.058829,44.252153,false,"date approximate");
  e(g,"r2_el_gigante_maize_late_marcala",-2390,-2069,14.22,-88.06,false,"dates approximate");
  e(g,"r2_caral_mid_23rd_century_context",-2249,-2199,-10.89361,-77.52028,false,"dates approximate");
  e(g,"r2_harappan_mid_23rd_century_context",-2249,-2199,29.0,70.5,true,"dates approximate");
  for(int y:new int[]{-2250,-2240,-2230,-2220,-2210}) {
   String indus=y==-2250?"wpy_8358910ec4":"r2_harappan_mid_23rd_century_context";
   ck(g.eventsNear(29.0,70.5,y,.01).stream().anyMatch(h->h.event().id().equals(indus)),"Harappan "+y);
   ck(g.eventsNear(50.15,14.35417,y,.01).stream().anyMatch(h->h.event().id().equals("wpy_4dbdb5bae1")),"Unetice "+y);
   ck(g.eventsNear(19.6008,30.40973,y,.01).stream().anyMatch(h->h.event().id().equals("r2_kerma_early_context")),"Kerma "+y);
   String caral=y==-2250?"r2_caral_late_24th_23rd_context":"r2_caral_mid_23rd_century_context";
   ck(g.eventsNear(-10.89361,-77.52028,y,.01).stream().anyMatch(h->h.event().id().equals(caral)),"Caral "+y);
   ck(g.eventsNear(14.22,-88.06,y,.01).stream().anyMatch(h->h.event().id().equals("r2_el_gigante_maize_late_marcala")),"maize "+y);
  }
  ck(g.eventsNear(60.35667,-1.26056,-2220,.01).stream().noneMatch(h->h.event().id().equals("wpy_c3ca5f6eca")),"old Shetland point");
  System.out.println("PASS: ten qualified records; Gazetteer and NewsIndex; headless");
 }
}
