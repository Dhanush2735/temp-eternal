import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus150To110Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String kind,String effect,int newsEnd){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains("uncertain"),"slot "+id);
  ck(x.kind().equals(kind)&&x.effect().equals(effect)&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().anyMatch(n->n.name().equals(x.name())&&n.start()==st&&n.end()==newsEnd),"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();ck(Disasters.get().loaded(),"disasters loaded");
  e(g,"q2890102",-110,-109,36.46667,7.43333,true,"battle","military_presence",-109);
  e(g,"q9173584",-130,-129,39.14211,27.80176,true,"battle","military_presence",-129);
  e(g,"wpr_89bb8ef94c",-150,-149,32.9275,35.0817,true,"political","political",-150);
  e(g,"wpy_6693a9d53b",-140,-139,31.69889,35.30639,true,"cultural","note",-140);
  e(g,"wpy_9a0b6beffe",-130,-129,39.12947,27.18412,true,"cultural","note",-130);
  e(g,"wpy_126610db53",-120,-119,40.3,112.0,true,"cultural","note",-120);
  e(g,"wpr_e5ad4b52c2",-150,-149,40.682,37.1858,true,"cultural","note",-150);
  e(g,"wpr_57b6cb8983",-120,-119,40.3685,35.7361,true,"political","political",-120);
  e(g,"wpr_07e65c21e2",-120,-119,47.7,14.5,true,"cultural","note",-120);
  e(g,"wpy_cf27bccf55",-140,-139,41.90343,12.49902,true,"cultural","note",-140);
  e(g,"wpy_43c6ddc075",-150,-149,23.47944,77.73972,false,"cultural","note",-150);
  e(g,"wpy_65f123f6af",-150,-149,44.435,125.175,true,"cultural","note",-150);
  e(g,"wpy_36f57ea8f4",-150,-149,33.74569,72.81521,true,"cultural","note",-150);
  e(g,"hz_90cec16fbb",-141,-140,37.748,14.999,false,"volcano","disruption",-140);
  e(g,"hz_10446c1542",-150,-149,37.735,140.244,false,"cultural","note",-150);
  e(g,"hz_aba62ad8dd",-150,-149,33.137,139.766,false,"cultural","note",-150);
  e(g,"hz_8db77746e0",-150,-149,63.983,-19.666,false,"cultural","note",-150);
  e(g,"hz_54de3587c1",-150,-149,34.724,139.394,false,"cultural","note",-150);
  e(g,"hz_04c75f3089",-150,-149,54.596,160.27,false,"cultural","note",-150);
  e(g,"hz_f9d4b96d9a",-150,-149,46.853,-121.76,false,"cultural","note",-150);
  e(g,"hz_d5d28c5ab9",-150,-149,18.5615,-95.1989,false,"cultural","note",-150);
  e(g,"hz_850136a0f0",-150,-149,41.409,-122.193,false,"cultural","note",-150);
  e(g,"hz_e22ac56e5a",-150,-149,56.653,161.36,false,"cultural","note",-150);
  e(g,"hz_a0560859d3",-150,-149,-39.3,174.07,false,"cultural","note",-150);
  e(g,"hz_48d4381c86",-150,-149,37.02,-117.45,false,"cultural","note",-150);
  e(g,"hz_a92245fc20",-150,-149,38.404,14.962,false,"cultural","note",-150);
  e(g,"hz_ec87c44100",-130,-129,43.371,-113.493,false,"cultural","note",-130);
  e(g,"hz_5a51e9b870",-120,-119,56.0,10.0,true,"cultural","note",-120);
  e(g,"hz_eb38ec9eec",-120,-119,59.3626,-153.435,false,"cultural","note",-120);
  e(g,"hz_82e5cecbda",-120,-119,-45.9,-72.97,false,"cultural","note",-120);
  e(g,"r2_sima_tan_110_bce",-110,-109,34.6197,112.454,true,"cultural","note",-110);
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_10446c1542")),"removed hazard hz_10446c1542");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_aba62ad8dd")),"removed hazard hz_aba62ad8dd");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_8db77746e0")),"removed hazard hz_8db77746e0");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_54de3587c1")),"removed hazard hz_54de3587c1");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_04c75f3089")),"removed hazard hz_04c75f3089");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_f9d4b96d9a")),"removed hazard hz_f9d4b96d9a");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_d5d28c5ab9")),"removed hazard hz_d5d28c5ab9");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_850136a0f0")),"removed hazard hz_850136a0f0");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_e22ac56e5a")),"removed hazard hz_e22ac56e5a");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_a0560859d3")),"removed hazard hz_a0560859d3");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_48d4381c86")),"removed hazard hz_48d4381c86");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_a92245fc20")),"removed hazard hz_a92245fc20");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_ec87c44100")),"removed hazard hz_ec87c44100");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_5a51e9b870")),"removed hazard hz_5a51e9b870");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_eb38ec9eec")),"removed hazard hz_eb38ec9eec");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_82e5cecbda")),"removed hazard hz_82e5cecbda");
  System.out.println("PASS 31 reviewed records: Gazetteer, NewsIndex, Disasters (headless)");
 }
}
