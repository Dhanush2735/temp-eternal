import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2100To2060Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_1272829ae3",-2100,-1999,30.59528,61.32639,false,"disputed");
  e(g,"wpr_69a1ad91c3",-2070,-2069,32.6128,113.5392,true,"uncertain");
  e(g,"wpr_55fde6a476",-2100,-2099,51.17889,-1.82611,false,"uncertain");
  e(g,"wpy_b3aba82c82",-2100,-2049,52.486222,60.188278,true,"approximate");
  e(g,"wpy_ac82fa6e89",-2099,-2059,35.30972,24.89333,true,"approximate");
  e(g,"r2_shulgi_ur_reign_context",-2094,-2045,30.9628,46.1035,true,"approximate");
  e(g,"r2_intef_iii_thebes_reign_context",-2063,-2054,25.72056,32.61028,true,"approximate");
  e(g,"r2_ur_nammu_code_reference",-2100,-2099,30.9628,46.1035,true,"uncertain");
  e(g,"r2_ur_ziggurat_reference",-2100,-2099,30.96278,46.10306,false,"uncertain");
  e(g,"r2_unetice_early_21st_context",-2099,-2049,50.15,14.35417,true,"approximate");
  e(g,"r2_kerma_early_21st_context",-2099,-2049,19.6008,30.40973,true,"approximate");
  e(g,"r2_caral_early_21st_context",-2099,-2049,-10.89361,-77.52028,false,"approximate");
  e(g,"r2_harappan_early_21st_context",-2099,-2049,29.0,70.5,true,"approximate");
  e(g,"r2_shimao_early_21st_context",-2109,-2059,38.5657,110.3252,false,"approximate");
  e(g,"r2_taosi_early_21st_context",-2109,-2059,35.8906028,111.4971722,false,"approximate");
  e(g,"r2_egypt_first_intermediate_late_context",-2109,-2059,29.638,31.2209,true,"approximate");
  ck(g.eventsNear(51.75933,-1.26916,-2100,.01).stream().noneMatch(h->h.event().id().equals("wpy_1272829ae3")),"Shahr old pin");
  for(int y:new int[]{-2100,-2090,-2080,-2070,-2060}){
   for(String id:new String[]{"wpy_1272829ae3","wpy_b3aba82c82"})ck(g.allEvents().stream().anyMatch(x->x.id().equals(id)&&x.start()<=y&&y<x.end()),"focus "+y+" "+id);
  }
  System.out.println("PASS: sixteen qualified records; Gazetteer and NewsIndex; headless");
 }
}
