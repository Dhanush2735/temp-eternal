import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2400To2360Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_855df8b627",-2400,-2399,32.0,45.5,true,"dates uncertain");
  e(g,"wpy_01667ea4cb",-2400,-2399,35.45667,43.2625,false,"date approximate");
  e(g,"wpr_f39e3ae6b7",-2400,-2399,29.638,31.2209,true,"evidence and date uncertain");
  e(g,"wpr_36876518a3",-2440,-2439,29.903889,31.194167,false,"date approximate");
  e(g,"wpy_1ca9938dd7",-2360,-2359,63.99222,-19.66583,false,"dating disputed");
  e(g,"wpy_430deee4f7",-2501,-2299,30.4502,103.7508,true,"dates approximate");
  e(g,"wpy_35b2655ebf",-2501,-2299,30.77527,113.07972,true,"dates approximate");
  e(g,"r2_entemena_lagash_brotherhood_reference_c2400",-2400,-2399,31.562028,46.177583,false,"date approximate");
  e(g,"r2_unas_fifth_dynasty_reign_context",-2375,-2344,29.845,31.251,true,"one approximate chronology");
  e(g,"r2_lothagam_north_cemetery_context",-2400,-2349,2.93,36.06,true,"dates approximate");
  ck(g.allEvents().stream().filter(x->x.id().equals("hz_9da164ef05")&&x.start()==-2310&&x.effect().equals("disruption")).count()==1,"GVP hazard retained");
  for(int y:new int[]{-2400,-2390,-2380,-2370,-2360}) {
   ck(g.eventsNear(30.4502,103.7508,y,.01).stream().anyMatch(h->h.event().id().equals("wpy_430deee4f7")),"Baodun "+y);
   ck(g.eventsNear(30.77527,113.07972,y,.01).stream().anyMatch(h->h.event().id().equals("wpy_35b2655ebf")),"Shijiahe "+y);
   ck(g.eventsNear(2.93,36.06,y,.01).stream().anyMatch(h->h.event().id().equals("r2_lothagam_north_cemetery_context")),"Lothagam "+y);
  }
  System.out.println("PASS: ten qualified records; GVP retained; Gazetteer and NewsIndex; headless");
 }
}
