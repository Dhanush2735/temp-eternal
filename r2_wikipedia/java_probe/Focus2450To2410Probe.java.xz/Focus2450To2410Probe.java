import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2450To2410Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_2bcb6b8fd1",-2450,-2449,32.0,45.5,true,"chronology debated");
  e(g,"wpy_ad7d39c255",-2450,-2449,32.54028,44.60472,true,"dating uncertain");
  e(g,"wpy_085a89b0c3",-2410,-2409,32.0,45.5,true,"roles and dates uncertain");
  e(g,"wpy_eba1d942b0",-2400,-2399,34.54944,40.89,false,"date approximate");
  e(g,"wpy_2c06fecd84",-2500,-2499,-7.924,-79.307,false,"date approximate");
  e(g,"wpr_b5d46e1e49",-2500,-2499,-7.924,-79.307,false,"date approximate");
  e(g,"r2_stele_vultures_girsu_reference_c2450",-2450,-2449,31.562028,46.177583,false,"dating approximate");
  e(g,"r2_nyuserre_pyramid_abusir_c2450",-2450,-2449,29.89556,31.20361,false,"approximate period");
  e(g,"r2_nyuserre_egypt_reign_context",-2458,-2421,29.845,31.251,true,"one approximate chronology");
  ck(g.eventsNear(-9.4,-76.0,-2500,.01).stream().noneMatch(h->h.event().id().equals("wpy_2c06fecd84")),"old Peru pin");
  ck(g.eventsNear(34.54944,40.89,-2500,.01).stream().noneMatch(h->h.event().id().equals("wpy_eba1d942b0")),"old Ebih date");
  for(int y:new int[]{-2450,-2440,-2430}) ck(g.eventsNear(29.845,31.251,y,.01).stream().anyMatch(h->h.event().id().equals("r2_nyuserre_egypt_reign_context")),"Nyuserre "+y);
  for(int y:new int[]{-2450,-2440,-2430,-2420,-2410}) ck(g.eventsNear(29.845,31.251,y,.01).stream().anyMatch(h->h.event().id().equals("r2_egypt_fifth_dynasty_context")),"Fifth dynasty "+y);
  System.out.println("PASS: nine qualified records; Gazetteer and NewsIndex; headless");
 }
}
