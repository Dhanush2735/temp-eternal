import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1700To1660Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_c2ab7bc00f",-1700,-1699,50.15,14.35417,true,"uncertain");
  e(g,"wpy_889c900ba5",-1750,-1749,35.30972,24.89333,true,"uncertain");
  e(g,"wpy_633a7385b6",-1700,-1699,30.63,72.86,true,"uncertain");
  e(g,"wpy_fbc26e6d72",-1700,-1699,30.63,72.86,true,"uncertain");
  e(g,"wpy_d4af8d69cc",-1700,-1699,35.30972,24.89333,true,"uncertain");
  e(g,"wpy_9985be3fcc",-1700,-1699,35.30972,24.89333,true,"uncertain");
  e(g,"wpy_0fbd09bd86",-1700,-1699,35.30972,24.89333,true,"uncertain");
  e(g,"wpy_f4796cf151",-1700,-1699,35.29806,25.16306,false,"uncertain");
  e(g,"wpy_b5323c78b2",-1700,-1699,34.693,112.689,true,"uncertain");
  e(g,"wpy_ba3f1917fb",-1700,-1699,34.693,112.689,true,"uncertain");
  e(g,"wpy_5d2ff0c1af",-1700,-1699,34.693,112.689,true,"uncertain");
  e(g,"wpy_126c7cc606",-1700,-1699,37.30111,64.15531,true,"uncertain");
  e(g,"wpy_cbfafdbdcf",-1700,-1699,36.35136,25.40356,false,"uncertain");
  e(g,"wpy_c9cea0fa92",-1680,-1679,29.98,31.13,true,"uncertain");
  e(g,"wpr_367ec0e436",-1700,-1690,35.45667,43.2625,true,"uncertain");
  e(g,"wpr_973f0bf361",-1691,-1673,35.45667,43.2625,true,"uncertain");
  e(g,"wpr_ad97967835",-1674,-1661,35.45667,43.2625,true,"uncertain");
  e(g,"wpr_7b3438dee1",-1662,-1649,35.45667,43.2625,true,"uncertain");
  e(g,"r2_abi_eshuh_1700_reign_context",-1712,-1683,32.5425,44.42111,true,"uncertain");
  e(g,"r2_ammi_ditana_1700_reign_context",-1683,-1646,32.5425,44.42111,true,"uncertain");
  e(g,"r2_kerma_1700_1660_context",-1700,-1659,19.6008,30.40973,true,"uncertain");
  e(g,"r2_erlitou_1700_1660_context",-1700,-1659,34.693,112.689,true,"uncertain");
  e(g,"r2_sechin_alto_1700_1660_context",-1700,-1659,-9.4654,-78.2426,false,"uncertain");
  e(g,"r2_valdivia_1700_1660_context",-1700,-1659,-1.95,-80.72,true,"uncertain");
  e(g,"r2_britain_1700_1660_context",-1700,-1659,51.3,-1.8,true,"uncertain");
  for(int y:new int[]{-1700,-1690,-1680,-1670,-1660})ck(g.allEvents().stream().anyMatch(x->x.id().equals("r2_valdivia_1700_1660_context")&&x.start()<=y&&y<x.end()),"year "+y);
  System.out.println("PASS 25 reviewed records: Gazetteer and NewsIndex (headless)");
 }
}
