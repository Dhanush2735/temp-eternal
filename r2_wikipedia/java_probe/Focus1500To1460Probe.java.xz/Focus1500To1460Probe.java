import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1500To1460Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_5db023905d",-1500,-1499,-17.7,178.0,true,"uncertain");
  e(g,"wpy_945a4d622b",-1500,-1499,37.73056,22.75639,true,"uncertain");
  e(g,"wpy_1af9df2a7d",-1500,-1499,58.37278,22.66944,false,"uncertain");
  e(g,"wpr_3d08e2e9da",-1500,-1499,38.31667,127.23333,true,"uncertain");
  e(g,"wpd_ab995ec0a0",-1480,-1479,25.72056,32.61028,true,"uncertain");
  e(g,"wpd_d85f15d81a",-1460,-1459,32.536,44.42,true,"uncertain");
  System.out.println("PASS 6 reviewed records: Gazetteer and NewsIndex (headless)");
 }
}
