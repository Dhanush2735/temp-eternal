import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1950To1910Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==(id.equals("q113381157")?en:en-1)).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_767ff3335c",-1953,-1952,21.8,31.35,true,"uncertain");
  e(g,"wpy_2d38ee2677",-1942,-1941,51.19028,11.16972,false,"approximate");
  e(g,"wpr_227b87c9c2",-1924,-1923,31.885,45.26861,true,"uncertain");
  e(g,"wpr_758ef8354a",-1920,-1919,35.86405,102.81025,false,"disputed");
  e(g,"q113381157",-1920,-1919,35.8408,102.6102,true,"disputed");
  e(g,"r2_senusret_i_reign_context",-1961,-1916,29.56001,31.22094,true,"approximate");
  e(g,"r2_amenemhat_ii_reign_context",-1926,-1894,29.808,31.225,true,"approximate");
  e(g,"r2_ishme_dagan_isin_reign_context",-1954,-1934,31.885,45.26861,true,"approximate");
  e(g,"r2_lipit_ishtar_isin_reign_context",-1935,-1923,31.885,45.26861,true,"approximate");
  e(g,"r2_ur_ninurta_isin_reign_context",-1924,-1895,31.885,45.26861,true,"approximate");
  e(g,"r2_ikunum_assur_reign_context",-1935,-1920,35.45667,43.2625,true,"approximate");
  e(g,"r2_sargon_i_assur_reign_context",-1921,-1880,35.45667,43.2625,true,"approximate");
  e(g,"r2_gungunum_larsa_reign_context",-1932,-1905,31.28583,45.85361,true,"approximate");
  e(g,"r2_lipit_ishtar_law_reference",-1930,-1929,32.1278,45.2333,true,"uncertain");
  e(g,"r2_william_hippopotamus_meir_reference",-1920,-1919,27.40889,30.71056,false,"uncertain");
  e(g,"r2_kultepe_karum_ii_context",-1945,-1899,38.85,35.633,false,"approximate");
  e(g,"r2_senusret_i_pyramid_lisht_reference",-1940,-1939,29.56001,31.22094,false,"uncertain");
  e(g,"r2_unetice_mid_20th_context",-1949,-1899,50.15,14.35417,true,"approximate");
  e(g,"r2_caral_mid_20th_context",-1949,-1899,-10.89361,-77.52028,false,"approximate");
  e(g,"r2_sintashta_mid_20th_context",-1949,-1899,52.486222,60.188278,true,"approximate");
  e(g,"r2_kerma_mid_20th_context",-1949,-1899,19.6008,30.40973,true,"approximate");
  e(g,"r2_harappan_mid_20th_context",-1949,-1899,29.0,70.5,true,"approximate");
  e(g,"r2_shimao_mid_20th_context",-1959,-1909,38.5657,110.3252,false,"approximate");
  e(g,"r2_taosi_mid_20th_context",-1959,-1909,35.8906028,111.4971722,false,"approximate");
  e(g,"r2_minoan_mm_ia_mid_20th_context",-1959,-1909,35.30972,24.89333,true,"approximate");
  for(int y:new int[]{-1940,-1930,-1920,-1910}) ck(g.allEvents().stream().anyMatch(x->x.id().equals("r2_harappan_mid_20th_context")&&x.start()<=y&&y<x.end()),"Harappan context "+y);
  ck(g.allEvents().stream().anyMatch(x->x.id().equals("wpy_d167a8b1bd")&&x.start()<=-1950&&-1950<x.end()),"Harappan 1950");
  System.out.println("PASS: 25 qualified records, Gazetteer and NewsIndex; headless");
 }
}
