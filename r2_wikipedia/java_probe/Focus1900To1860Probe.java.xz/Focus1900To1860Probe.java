import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1900To1860Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_d63fc48c19",-1900,-1899,37.7,22.8,true,"uncertain");
  e(g,"wpy_6723ffdf8c",-1900,-1899,31.885,45.26861,true,"uncertain");
  e(g,"wpy_ea8afd288e",-1917,-1916,29.65,91.1,true,"uncertain");
  e(g,"wpy_05fa69a828",-1900,-1899,29.65,91.1,true,"uncertain");
  e(g,"wpy_f64f2c0f1d",-1860,-1859,21.5,30.97,true,"uncertain");
  e(g,"wpr_91175f45ba",-1900,-1699,14.85,-92.45,true,"uncertain");
  e(g,"wpr_d6410a49ca",-1900,-1499,14.85,-92.45,true,"uncertain");
  e(g,"wpr_8be6d9e6fa",-1900,-1899,22.52139,72.24944,false,"uncertain");
  e(g,"wpr_f647e86f4d",-2008,-1973,35.45667,43.2625,true,"uncertain");
  e(g,"wpr_4d8aee1120",-1887,-1877,29.23333,30.96667,true,"uncertain");
  e(g,"r2_puzur_ashur_ii_assur_reign_context",-1881,-1872,35.45667,43.2625,true,"uncertain");
  e(g,"r2_naram_sin_assur_reign_context",-1873,-1822,35.45667,43.2625,true,"uncertain");
  e(g,"r2_bur_suen_isin_reign_context",-1896,-1873,31.885,45.26861,true,"uncertain");
  e(g,"r2_lipit_enlil_isin_reign_context",-1874,-1867,31.885,45.26861,true,"uncertain");
  e(g,"r2_erra_imitti_isin_reign_context",-1868,-1860,31.885,45.26861,true,"uncertain");
  e(g,"r2_enlil_bani_isin_reign_context",-1860,-1835,31.885,45.26861,true,"uncertain");
  e(g,"r2_sumuel_larsa_reign_context",-1895,-1865,31.28583,45.85361,true,"uncertain");
  e(g,"r2_nur_adad_larsa_reign_context",-1866,-1849,31.28583,45.85361,true,"uncertain");
  e(g,"r2_sithathoriunet_pectoral_lahun_reference",-1887,-1877,29.23333,30.96667,true,"uncertain");
  e(g,"r2_erlitou_chronology_1900_reference",-1900,-1899,34.6925,112.69,true,"uncertain");
  for(int y:new int[]{-1900,-1890,-1880,-1870,-1860}) ck(g.allEvents().stream().anyMatch(x->x.start()<=y&&y<x.end()&&x.name().contains("uncertain")),"focus context "+y);
  System.out.println("PASS: 20 qualified records, Gazetteer and NewsIndex; headless");
 }
}
