import com.eternalengine.civilization.*;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2750To2710Probe {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void event(HistoryGazetteer g,String id,int start,int end,double lat,double lon,boolean region,String caveat){
  var es=g.allEvents().stream().filter(e->e.id().equals(id)).toList();check(es.size()==1,"event id "+id);var e=es.get(0);
  check(e.start()==start&&e.end()==end&&e.name().contains(caveat),"event dates "+id);
  check(e.kind().equals("cultural")&&e.effect().equals("note")&&HistoryGazetteer.isRegional(e)==region,"class "+id);
  check(g.eventsNear(lat,lon,start,.01).stream().anyMatch(x->x.event().id().equals(id)),"near "+id);
  check(g.eventsNear(lat,lon,end,.01).stream().noneMatch(x->x.event().id().equals(id)),"end "+id);
  check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==start&&n.end()==end-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  event(g,"wpy_6ff93fd0ea",-2750,-2749,33.26667,35.2,false,"date uncertain");
  event(g,"r2_keros_dhaskalio_phase_a_context",-2750,-2549,36.887,25.604,true,"dates approximate");
  for(int year:new int[]{-2750,-2740,-2730,-2720,-2710}) check(g.eventsNear(36.887,25.604,year,.01).stream().anyMatch(x->x.event().id().equals("r2_keros_dhaskalio_phase_a_context")),"context "+year);
  var ss=g.allSites().stream().filter(s->s.id().equals("pl_734000266")).toList();check(ss.size()==1,"site id");var s=ss.get(0);
  check(s.civHint().isEmpty()&&s.occupiedStart()==-4000&&s.occupiedEnd()==-1999,"site hint or saved boundaries");
  check(s.occupiedIn(-2750)&&CivHints.resolve(s.civHint(),RulerRegister.get()).isEmpty(),"site hint resolution");
  System.out.println("PASS: Tyre traditional date, early Keros context and blank Dhaskalio hint (headless)");
 }
}
