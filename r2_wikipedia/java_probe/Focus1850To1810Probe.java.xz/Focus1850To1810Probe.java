import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1850To1810Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"hz_acdb6a3c15",-1850,-1849,46.206,-121.49,true,"uncertain");
  e(g,"hz_1fe9cf137a",-1850,-1849,37.77,-25.47,true,"uncertain");
  e(g,"hz_90e04a4535",-1850,-1849,1.08,-77.68,true,"uncertain");
  e(g,"hz_4f9281c943",-1850,-1849,35.361,138.728,true,"uncertain");
  e(g,"hz_6612767bdb",-1850,-1849,20.7099,-156.2537,true,"uncertain");
  e(g,"hz_93562abf0d",-1850,-1849,61.64,-152.411,true,"uncertain");
  e(g,"hz_38db380d4c",-1850,-1849,63.633,-19.083,true,"uncertain");
  e(g,"hz_b682ac9d46",-1850,-1849,49.5641,154.8126,true,"uncertain");
  e(g,"hz_e0d94de408",-1830,-1829,32.8849,131.085,true,"uncertain");
  e(g,"q4178415",-1831,-1830,36.25583,117.1075,false,"uncertain");
  e(g,"r2_sin_iddinam_1850_1810_reign_context",-1849,-1842,31.28583,45.85361,true,"uncertain");
  e(g,"r2_sin_iqisham_1850_1810_reign_context",-1841,-1834,31.28583,45.85361,true,"uncertain");
  e(g,"r2_zambiya_1850_1810_reign_context",-1836,-1832,31.885,45.26861,true,"uncertain");
  e(g,"r2_iter_pisha_1850_1810_reign_context",-1833,-1828,31.885,45.26861,true,"uncertain");
  e(g,"r2_ur_du_kuga_1850_1810_reign_context",-1829,-1824,31.885,45.26861,true,"uncertain");
  e(g,"r2_suen_magir_1850_1810_reign_context",-1825,-1813,31.885,45.26861,true,"uncertain");
  e(g,"r2_warad_sin_1850_1810_reign_context",-1834,-1822,31.28583,45.85361,true,"uncertain");
  e(g,"r2_rim_sin_i_1850_1810_reign_context",-1823,-1762,31.28583,45.85361,true,"uncertain");
  e(g,"r2_sumu_la_el_1850_1810_reign_context",-1881,-1844,32.5425,44.421,true,"uncertain");
  e(g,"r2_sabium_1850_1810_reign_context",-1845,-1830,32.5425,44.421,true,"uncertain");
  e(g,"r2_senusret_iii_reign_1850_context",-1878,-1839,29.808,31.225,true,"uncertain");
  e(g,"r2_amenemhat_iii_reign_1850_context",-1859,-1812,29.79167,31.22361,true,"uncertain");
  e(g,"r2_black_pyramid_dahshur_reference",-1850,-1849,29.79167,31.22361,false,"uncertain");
  e(g,"r2_kahun_medical_papyrus_reference",-1825,-1824,29.23333,30.96667,false,"uncertain");
  e(g,"r2_valdivia_1850_1810_context",-1850,-1809,-1.95,-80.72,true,"uncertain");
  e(g,"r2_late_harappan_1850_1810_context",-1850,-1809,29,70.5,true,"uncertain");
  e(g,"r2_kerma_1850_1810_context",-1850,-1809,19.6008,30.40973,true,"uncertain");
  e(g,"r2_sintashta_1850_1810_context",-1850,-1809,52.486222,60.188278,true,"uncertain");
  e(g,"r2_minoans_1850_1810_context",-1850,-1809,35.30972,24.89333,true,"uncertain");
  ck(Disasters.get().loaded(),"disasters loader");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_acdb6a3c15")),"removed hazard hz_acdb6a3c15");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_1fe9cf137a")),"removed hazard hz_1fe9cf137a");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_90e04a4535")),"removed hazard hz_90e04a4535");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_4f9281c943")),"removed hazard hz_4f9281c943");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_6612767bdb")),"removed hazard hz_6612767bdb");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_93562abf0d")),"removed hazard hz_93562abf0d");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_38db380d4c")),"removed hazard hz_38db380d4c");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_b682ac9d46")),"removed hazard hz_b682ac9d46");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_e0d94de408")),"removed hazard hz_e0d94de408");
  for(int y:new int[]{-1850,-1840,-1830,-1820,-1810})ck(g.allEvents().stream().anyMatch(x->x.id().equals("r2_valdivia_1850_1810_context")&&x.start()<=y&&y<x.end()),"year "+y);
  System.out.println("PASS 29 reviewed records: Gazetteer, NewsIndex, Disasters (headless)");
 }
}
