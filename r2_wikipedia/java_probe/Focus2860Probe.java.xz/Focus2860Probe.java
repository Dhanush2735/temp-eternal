import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2860Probe {
 static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
 public static void main(String[] args){
  var g=HistoryGazetteer.get();var rows=g.allEvents().stream().filter(e->e.id().equals("r2_saqqara_gallery_reference_c2860")).toList();
  ok(rows.size()==1,"missing/duplicate Saqqara reference");var e=rows.get(0);
  ok(e.start()==-2860&&e.end()==-2859&&e.name().contains("One date proposed")&&e.name().contains("timing and attribution uncertain"),"date/name");
  ok(e.kind().equals("cultural")&&e.effect().equals("note")&&HistoryGazetteer.isRegional(e),"classification");
  ok(g.eventsNear(e.lat(),e.lon(),-2860,.01).stream().anyMatch(h->h.event().id().equals(e.id())),"spatial");
  ok(g.eventsNear(e.lat(),e.lon(),-2859,.01).stream().noneMatch(h->h.event().id().equals(e.id())),"exclusive end");
  ok(g.nearestLocalEvent(e.lat(),e.lon(),-2860).stream().noneMatch(h->h.event().id().equals(e.id())),"regional as local");
  ok(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-2860&&n.end()==-2860).count()==1,"news end");
  System.out.println("PASS: Saqqara uncertain period reference in Gazetteer and NewsIndex; regional; headless");
 }
}
