import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
/** Full indexed resources and real loader classes, stub dependencies, no Minecraft. */
public class Focus2910Probe {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
  var g=HistoryGazetteer.get();var rows=g.allEvents().stream().filter(e->e.id().equals("r2_semerkhet_death_estimate_c2910")).toList();
  check(rows.size()==1,"Semerkhet ID missing/duplicated");var e=rows.get(0);
  check(e.start()==-2910&&e.end()==-2909&&e.name().contains("One estimate")&&e.name().contains("dates are debated"),"incorrect slot or text");
  check(HistoryGazetteer.isRegional(e),"not regional");
  check(g.eventsNear(26.175,31.9083,-2910,.01).stream().anyMatch(h->h.event().id().equals(e.id())),"spatial index misses event");
  check(g.eventsNear(26.175,31.9083,-2909,.01).stream().noneMatch(h->h.event().id().equals(e.id())),"wrong exclusive end");
  check(g.nearestLocalEvent(26.175,31.9083,-2910).stream().noneMatch(h->h.event().id().equals(e.id())),"regional event reported as local");
  check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-2910&&n.end()==-2910).count()==1,"news wrong/missing");
  System.out.println("PASS: 2910 BCE Semerkhet reference in Gazetteer and NewsIndex; regional-only, exclusive end, full index; headless");
 }
}
