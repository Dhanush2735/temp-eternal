import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2800To2760Probe {
 static void ok(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void test(HistoryGazetteer g,String id,int start,int end,double lat,double lon,String caveat){
  var rows=g.allEvents().stream().filter(e->e.id().equals(id)).toList();ok(rows.size()==1,"id "+id);var e=rows.get(0);
  ok(e.start()==start&&e.end()==end&&e.name().contains(caveat),"date/name "+id);
  ok(HistoryGazetteer.isRegional(e)&&e.kind().equals("cultural")&&e.effect().equals("note"),"kind "+id);
  ok(g.eventsNear(lat,lon,start,.01).stream().anyMatch(h->h.event().id().equals(id)),"start "+id);
  ok(g.eventsNear(lat,lon,end,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ok(g.nearestLocalEvent(lat,lon,start).stream().noneMatch(h->h.event().id().equals(id)),"regional "+id);
  ok(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==start&&n.end()==end-1).count()==1,"news "+id);
 }
 public static void main(String[] args){
  var g=HistoryGazetteer.get();
  test(g,"wpr_c80b8b9274",-2775,-2774,29.638,31.2209,"conflict disputed");
  test(g,"wpr_eb589adcd2",-2750,-2749,46,25,"chronology disputed");
  test(g,"r2_met_cycladic_harp_date_c2800",-2800,-2699,37,25.16667,"findspot uncertain");
  test(g,"r2_tagus_early_beaker_28c",-2800,-2699,38.72,-9.14,"dating approximate");
  for(int y:new int[]{-2800,-2790,-2780,-2770,-2760}){
   int year=y;ok(g.eventsNear(37,25.16667,y,.01).stream().anyMatch(h->h.event().id().equals("r2_met_cycladic_harp_date_c2800")),"harp "+year);
   ok(g.eventsNear(38.72,-9.14,y,.01).stream().anyMatch(h->h.event().id().equals("r2_tagus_early_beaker_28c")),"beaker "+year);
  }
  System.out.println("PASS: two dated archaeological contexts and two corrected historical claims; Gazetteer/NewsIndex headless");
 }
}
