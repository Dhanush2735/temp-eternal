import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2890Probe{
 static void check(boolean v,String m){if(!v)throw new AssertionError(m);}
 public static void main(String[] args){
  var g=HistoryGazetteer.get();var rows=g.allEvents().stream().filter(e->e.id().equals("wpr_4328bf556a")).toList();
  check(rows.size()==1,"missing or duplicate");var e=rows.get(0);
  check(e.start()==-2890&&e.end()==-2889&&e.name().contains("dates debated")&&e.name().contains("Qa'a")&&e.name().contains("Hotepsekhemwy"),"slot or name");
  check(e.kind().equals("cultural")&&e.effect().equals("note")&&HistoryGazetteer.isRegional(e),"effect or region");
  check(g.eventsNear(e.lat(),e.lon(),-2890,.01).stream().anyMatch(h->h.event().id().equals(e.id())),"spatial index missing");
  check(g.eventsNear(e.lat(),e.lon(),-2889,.01).stream().noneMatch(h->h.event().id().equals(e.id())),"wrong exclusive end");
  check(g.nearestLocalEvent(e.lat(),e.lon(),-2890).stream().noneMatch(h->h.event().id().equals(e.id())),"regional treated as local");
  check(NewsIndex.all().stream().filter(n->n.name().equals(e.name())&&n.start()==-2890&&n.end()==-2890).count()==1,"news range");
  System.out.println("PASS: 2890 dynastic reference in Gazetteer and NewsIndex, regional, note, exclusive end; headless");
 }
}
