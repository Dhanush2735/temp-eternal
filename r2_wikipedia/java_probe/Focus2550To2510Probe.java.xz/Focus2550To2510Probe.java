import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
public class Focus2550To2510Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_5cf68a7cd3",-2550,-2549,29.97611,31.13083,false,"approximate construction date");
  e(g,"wpr_ba8e197c5d",-2550,-2549,29.97526,31.13758,false,"date and patron uncertain");
  e(g,"wpy_4adef08260",-2550,-2549,30.9615,46.1061,false,"species identification debated");
  e(g,"wpy_7749c5665a",-2600,-2399,51.17889,-1.82611,false,"approximate dating");
  e(g,"r2_caral_early_site_context",-2600,-2499,-10.89361,-77.52028,false,"approximate period");
  e(g,"r2_mesilim_kish_reference_c2550",-2550,-2549,32.54028,44.60472,false,"dating approximate");
  e(g,"r2_lugalshaengur_lagash_reference_c2530",-2530,-2529,31.41139,46.40722,true,"dating approximate");
  e(g,"r2_puabi_ur_burial_reference_c2550",-2550,-2549,30.9615,46.1061,false,"burial and status interpretations uncertain");
  ck(g.eventsNear(29.987,31.2118,-2550,.01).stream().noneMatch(h->h.event().id().equals("wpy_5cf68a7cd3")),"old pyramid pin");
  for(int y:new int[]{-2550,-2540,-2530,-2520,-2510}){
   ck(g.eventsNear(-10.89361,-77.52028,y,.01).stream().anyMatch(h->h.event().id().equals("r2_caral_early_site_context")),"Caral "+y);
   ck(g.eventsNear(51.17889,-1.82611,y,.01).stream().anyMatch(h->h.event().id().equals("wpy_7749c5665a")),"Stonehenge "+y);
  }
  System.out.println("PASS: eight qualified records, corrected pins, Gazetteer and NewsIndex; headless");
 }
}
