import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1350To1310Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_f43ecc66da",-1350,-1349,36.1225,114.31861,false,"uncertain");
  e(g,"wpy_289b214cca",-1340,-1339,37.73083,22.75611,false,"uncertain");
  e(g,"wpd_5cedb18ca0",-1350,-1349,17.75361,-94.76,false,"uncertain");
  e(g,"wpd_498dd7a7b5",-1350,-1349,37.73028,22.7575,false,"uncertain");
  e(g,"wpd_3b3b7fdb47",-1340,-1339,37.98417,23.72806,false,"uncertain");
  e(g,"wpd_8935137a32",-1320,-1319,36.12861,29.68583,false,"uncertain");
  e(g,"wpr_c26f3977f3",-1352,-1351,25.72056,32.61028,true,"uncertain");
  e(g,"hz_e760fb0b97",-1350,-1349,32.58528,35.18444,false,"uncertain");
  e(g,"hz_08a6b673a8",-1330,-1329,40.01972,34.61528,true,"uncertain");
  e(g,"r2_tutankhamun_1330_reign_context",-1330,-1329,25.72056,32.61028,true,"uncertain");
  e(g,"r2_mursili_ii_1310_reign_context",-1310,-1309,40.01972,34.61528,true,"uncertain");
  ck(Disasters.get().loaded(),"disasters loaded");
  for(String id:new String[]{"hz_e760fb0b97","hz_08a6b673a8"})ck(Disasters.get().all().stream().noneMatch(d->d.id().equals(id)),"removed hazard "+id);
  System.out.println("PASS 11 reviewed records: Gazetteer, NewsIndex, Disasters (headless)");
 }
}
