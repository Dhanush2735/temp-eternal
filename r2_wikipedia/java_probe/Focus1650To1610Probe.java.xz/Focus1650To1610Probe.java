import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1650To1610Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_e8519bd035",-1650,-1649,29.84467,31.25092,true,"uncertain");
  e(g,"wpy_bdee01b90d",-1650,-1649,29.8,31.3,true,"uncertain");
  e(g,"wpy_96bd2dc773",-1650,-1649,29.8,31.3,true,"uncertain");
  e(g,"wpy_dd5af48381",-1650,-1649,47.222472,8.814917,false,"uncertain");
  e(g,"wpy_62a4fa84d0",-1610,-1609,36.404,25.396,false,"uncertain");
  e(g,"wpr_78eca6f7c4",-1650,-1649,30.786,31.83,true,"uncertain");
  e(g,"wpr_6c9e67bcf8",-1650,-1649,26.185,31.91889,true,"uncertain");
  e(g,"wpr_bb07789076",-1650,-1649,30.786,31.83,true,"uncertain");
  e(g,"wpr_08bdaaa10c",-1650,-1649,37.73028,22.7575,false,"uncertain");
  e(g,"wpr_e7246afb4d",-1620,-1619,40.01972,34.61528,true,"uncertain");
  e(g,"wpw_f6f3fc519a",-1650,-1619,40.01972,34.61528,true,"uncertain");
  e(g,"hz_e05af7451b",-1650,-1649,10.463,-84.703,true,"uncertain");
  e(g,"hz_b012c702d5",-1610,-1609,36.4,25.4,true,"uncertain");
  e(g,"hz_de3b7315e5",-1610,-1609,36.404,25.396,true,"uncertain");
  e(g,"hz_16ec6e1df2",-1610,-1609,36.4,25.4,true,"uncertain");
  e(g,"r2_bazaya_assur_1650_context",-1649,-1621,35.45667,43.2625,true,"uncertain");
  e(g,"r2_ammi_saduqa_babylon_context",-1646,-1625,32.5425,44.42111,true,"uncertain");
  e(g,"r2_ammi_saduqa_venus_record_context",-1646,-1625,32.5425,44.42111,true,"uncertain");
  e(g,"r2_kerma_1650_1610_context",-1650,-1609,19.6008,30.40973,true,"uncertain");
  e(g,"r2_erlitou_1650_1610_context",-1650,-1609,34.693,112.689,true,"uncertain");
  e(g,"r2_sechin_alto_1650_1610_context",-1650,-1609,-9.4654,-78.2426,false,"uncertain");
  e(g,"r2_valdivia_1650_1610_context",-1650,-1609,-1.95,-80.72,true,"uncertain");
  e(g,"r2_britain_1650_1610_context",-1650,-1609,51.3,-1.8,true,"uncertain");
  e(g,"r2_lullaya_assur_1620_context",-1621,-1615,35.45667,43.2625,true,"uncertain");
  e(g,"r2_samsu_ditana_babylon_context",-1625,-1594,32.5425,44.42111,true,"uncertain");
  ck(Disasters.get().loaded(),"disasters loader");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_e05af7451b")),"removed hazard hz_e05af7451b");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_b012c702d5")),"removed hazard hz_b012c702d5");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_de3b7315e5")),"removed hazard hz_de3b7315e5");
  ck(Disasters.get().all().stream().noneMatch(d->d.id().equals("hz_16ec6e1df2")),"removed hazard hz_16ec6e1df2");
  for(int y:new int[]{-1650,-1640,-1630,-1620,-1610})ck(g.allEvents().stream().anyMatch(x->x.id().equals("r2_valdivia_1650_1610_context")&&x.start()<=y&&y<x.end()),"year "+y);
  System.out.println("PASS 25 reviewed records: Gazetteer, NewsIndex, Disasters (headless)");
 }
}
