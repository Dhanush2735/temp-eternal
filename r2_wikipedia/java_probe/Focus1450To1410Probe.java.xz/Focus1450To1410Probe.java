import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1450To1410Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_fad65f6585",-1450,-1449,35.29806,25.16306,true,"uncertain");
  e(g,"wpr_c646f12e1e",-1440,-1439,38.53333,27.23333,true,"uncertain");
  e(g,"wpr_9a2532289b",-1420,-1419,29.4677,31.2526,true,"uncertain");
  e(g,"wpr_674d9a4960",-1420,-1419,34.323,51.7242,true,"uncertain");
  e(g,"wpr_86ecbc29d2",-1439,-1438,40.01972,34.61528,true,"uncertain");
  e(g,"hz_b2de76385d",-1450,-1449,42.317,12.167,true,"uncertain");
  e(g,"hz_5ea2a8fec7",-1410,-1409,36.415,25.4325,true,"uncertain");
  e(g,"r2_amenhotep_ii_1410_reign_context",-1410,-1409,25.72056,32.61028,true,"uncertain");
  ck(Disasters.get().loaded(),"disasters loaded");
  for(String id:new String[]{"hz_b2de76385d","hz_5ea2a8fec7"})ck(Disasters.get().all().stream().noneMatch(d->d.id().equals(id)),"removed hazard "+id);
  System.out.println("PASS 8 reviewed records: Gazetteer, NewsIndex, Disasters (headless)");
 }
}
