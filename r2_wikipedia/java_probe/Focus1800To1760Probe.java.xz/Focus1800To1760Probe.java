import com.eternalengine.civilization.HistoryGazetteer;
import com.eternalengine.knowledge.NewsIndex;
import com.eternalengine.civilization.Disasters;
public class Focus1800To1760Probe {
 static void ck(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void e(HistoryGazetteer g,String id,int st,int en,double lat,double lon,boolean regional,String caveat){
  var rows=g.allEvents().stream().filter(x->x.id().equals(id)).toList();ck(rows.size()==1,"id "+id);var x=rows.get(0);
  ck(x.start()==st&&x.end()==en&&x.name().contains(caveat),"slot "+id);
  ck(x.kind().equals("cultural")&&x.effect().equals("note")&&HistoryGazetteer.isRegional(x)==regional,"category "+id);
  ck(g.eventsNear(lat,lon,st,.01).stream().anyMatch(h->h.event().id().equals(id)),"near "+id);
  ck(g.eventsNear(lat,lon,en,.01).stream().noneMatch(h->h.event().id().equals(id)),"end "+id);
  ck(NewsIndex.all().stream().filter(n->n.name().equals(x.name())&&n.start()==st&&n.end()==en-1).count()==1,"news "+id);
 }
 public static void main(String[] args){var g=HistoryGazetteer.get();
  e(g,"wpy_92aac72359",-1800,-1799,56.2,12.5,true,"uncertain");
  e(g,"wpy_ad932b5f42",-1800,-1799,30.786,31.83,true,"uncertain");
  e(g,"wpy_6d5948e754",-905,-904,8.6279,77.8732,false,"uncertain");
  e(g,"wpy_60ea454f72",-1800,-1699,29.0,70.5,true,"uncertain");
  e(g,"wpy_31c9e8ca1e",-1770,-1769,32.5425,44.42111,false,"uncertain");
  e(g,"wpy_5c2c59b982",-1808,-1807,35.45667,43.2625,true,"uncertain");
  e(g,"wpr_641ca1c7e8",-1700,-1699,39.9575,26.23889,false,"uncertain");
  e(g,"wpr_a2ee764345",-1792,-1749,32.5425,44.42111,true,"uncertain");
  e(g,"wpr_2fc4812558",-1775,-1760,34.54944,40.89,true,"uncertain");
  e(g,"r2_sin_muballit_babylon_1800_context",-1813,-1791,32.5425,44.42111,true,"uncertain");
  e(g,"r2_damiq_ilishu_isin_1800_context",-1814,-1791,31.885,45.26861,true,"uncertain");
  e(g,"r2_shamshi_adad_1800_reign_context",-1809,-1775,35.45667,43.2625,true,"uncertain");
  e(g,"r2_shibtu_mari_1770_context",-1773,-1760,34.54944,40.89,true,"uncertain");
  e(g,"r2_mari_investiture_mural_reference",-1775,-1760,34.54944,40.89,false,"uncertain");
  e(g,"r2_sechin_alto_1800_context",-1800,-1759,-9.4654,-78.2426,false,"uncertain");
  e(g,"r2_kultepe_1800_karum_context",-1800,-1759,38.8536,35.6333,false,"uncertain");
  e(g,"r2_valdivia_1800_context",-1800,-1759,-1.95,-80.72,true,"uncertain");
  e(g,"r2_early_maya_region_1800_reference",-1800,-1799,16.5,-90.5,true,"uncertain");
  for(int y:new int[]{-1800,-1790,-1780,-1770,-1760})ck(g.allEvents().stream().anyMatch(x->x.id().equals("r2_valdivia_1800_context")&&x.start()<=y&&y<x.end()),"year "+y);
  System.out.println("PASS 18 reviewed records: Gazetteer and NewsIndex (headless)");
 }
}
