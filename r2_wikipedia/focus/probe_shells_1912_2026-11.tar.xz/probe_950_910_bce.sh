#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; JAVA_HOME="${JAVA_HOME:-/tmp/eternal-java17}"; GSON="${GSON_JAR:-$ROOT/tools/jars/gson.jar}"
TMP="$(mktemp -d /tmp/eternal-2870-probe-XXXXXX)";trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/classes" "$TMP/res/data/eternalengine/eternal/history"
if [[ "${1:-}" == stage ]]; then cp /tmp/eternal-950-910-stage/{events_wikipedia.json.gz,events_wikipedia_regional.json.gz,events_hazards.json.gz,events_wars.json.gz,events_wikipedia_decades.json.gz,events_world.json.gz,events_wikidata_more.json.gz} "$TMP/res/data/eternalengine/eternal/history/"; fi
"$JAVA_HOME/bin/javac" -encoding UTF-8 -cp "$GSON" -d "$TMP/classes" \
 "$ROOT/r2_wikipedia/java_probe/com/eternalengine/civilization/HistoricalPresence.java" \
 "$ROOT/r2_wikipedia/java_probe/com/eternalengine/knowledge/KnowledgeDate.java" \
 "$ROOT/r2_wikipedia/java_probe/com/eternalengine/knowledge/DatedEvents.java" \
 "$ROOT/eternal/src/main/java/com/eternalengine/civilization/WaterChanges.java" \
 "$ROOT/eternal/src/main/java/com/eternalengine/civilization/Disasters.java" \
 "$ROOT/eternal/src/main/java/com/eternalengine/civilization/SettlementRank.java" \
 "$ROOT/eternal/src/main/java/com/eternalengine/civilization/SettlementYearEstimator.java" \
 "$ROOT/eternal/src/main/java/com/eternalengine/civilization/HistoryGazetteer.java" \
 "$ROOT/eternal/src/main/java/com/eternalengine/knowledge/NewsIndex.java" \
 "$(python3 "$ROOT/r2_wikipedia/probe_source_archive.py" extract Focus950To910Probe.java "$TMP")"
"$JAVA_HOME/bin/java" -Xmx1536m -cp "$TMP/classes:$TMP/res:$ROOT/eternal/src/main/resources:$GSON" Focus950To910Probe
